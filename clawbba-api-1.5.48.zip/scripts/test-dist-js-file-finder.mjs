#!/usr/bin/env node
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { findDistJsFile } from './openclaw-dist-paths.mjs'
import { repairWrongDistDtsImports, toolsSrcHasWrongDistDtsImport } from './clawbba-webchat-live-inject.mjs'

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'clawbba-dist-js-'))
fs.writeFileSync(path.join(tmp, 'server-plugins-BVVgDSdq.d.ts'), 'export declare function dispatchGatewayMethodInProcess(): void')
fs.writeFileSync(
  path.join(tmp, 'server-plugins-BniQMVzq.js'),
  'export async function dispatchGatewayMethodInProcess() {}',
)
fs.writeFileSync(path.join(tmp, 'global-singleton-la_KkjCS.js'), 'export {};')
fs.writeFileSync(
  path.join(tmp, 'global-singleton-DE6St75u.js'),
  'export function resolveGlobalSingleton() {}',
)

assert.equal(findDistJsFile(tmp, 'server-plugins-'), 'server-plugins-BniQMVzq.js')
assert.equal(
  findDistJsFile(tmp, 'global-singleton-', 'resolveGlobalSingleton'),
  'global-singleton-DE6St75u.js',
)

const broken = 'await import("./server-plugins-BVVgDSdq.d.ts");'
assert.ok(toolsSrcHasWrongDistDtsImport(broken))
const fixed = repairWrongDistDtsImports(broken, tmp)
assert.match(fixed, /import\("\.\/server-plugins-BniQMVzq\.js"\)/)
assert.ok(!toolsSrcHasWrongDistDtsImport(fixed))

console.log('test-dist-js-file-finder: ok')
