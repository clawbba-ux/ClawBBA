/**
 * OpenClaw image_generate: action=recover | tasks — poll ClawBBA until complete, save locally (no re-bill).
 * Auto-recover on background task timeout when job_id is known (mirrors video_generate recover UX).
 */
import fs from 'fs'
import path from 'path'
import {
  buildClawbbaResolveOpenRouterApiKeyHelper,
  VIDEO_RECOVER_AUTH_MARKER,
  upgradeClawbbaVideoRecoverAuth,
} from './clawbba-video-recover-patch.mjs'
import {
  recoverWebChatInjectNeedsUpgrade,
  stripLegacyRecoverWebChatInject,
  recoverFnHasWebChatDispatchInject,
} from './clawbba-webchat-live-inject.mjs'

export const IMAGE_RECOVER_MARKER = '/* clawbba-image-recover */'
export const IMAGE_RECOVER_AUTO_MARKER = '/* clawbba-image-auto-recover */'
export const IMAGE_RECOVER_WEBCHAT_LIVE_MARKER = '/* clawbba-image-recover-webchat-live */'

export function buildImageRecoverWebChatInjectBlock() {
  return `\t${IMAGE_RECOVER_WEBCHAT_LIVE_MARKER}
\tawait clawbbaDispatchWebChatMediaLiveInject({
\t\tsessionKey: agentSessionKey,
\t\tchatRunId,
\t\tmediaUrls: savedImages.map((img) => img.path),
\t\tsourceTool: "image_generate",
\t\tcompletionLabel: "image",
\t\tmessage: lines.join("\\n")
\t});`
}

const IMAGE_RECOVER_RETURN_NEEDLE = `\treturn {
\t\tcontent: [{ type: "text", text: lines.join("\\n") }],
\t\tdetails: {
\t\t\tjobId,
\t\t\trecovered: true,
\t\t\tpaths: savedImages.map((img) => img.path),`

const CLAWBBA_AUTH_HEADERS = `\tconst apiKey = await clawbbaResolveOpenRouterApiKey({ cfg, agentDir, authStore });
\tconst hdrs = { Authorization: \`Bearer \${apiKey}\`, Accept: "application/json" };`

function sharedImageRecoverHelpers() {
  return `
function clawbbaExtractImageJobIdFromError(error) {
\tconst msg = String(error?.message || error || "");
\tconst m = msg.match(/job_id=([0-9a-f-]{36})/i) || msg.match(/images\\/generations\\/([0-9a-f-]{36})/i);
\tif (m?.[1]) return m[1];
\tconst g = globalThis.__clawbbaLastImageJobId;
\treturn typeof g === "string" && g.trim() ? g.trim() : "";
}
function clawbbaImageRecoverLooksLikeTimeout(error) {
\tconst msg = String(error?.message || error || "").toLowerCase();
\treturn msg.includes("wait limit") || msg.includes("timeout") || msg.includes("timed out") || msg.includes("completed without image data");
}
function clawbbaDataUrlsFromPollData(data) {
\tconst urls = [];
\tconst choices = data?.choices;
\tif (!Array.isArray(choices)) return urls;
\tfor (const ch of choices) {
\t\tconst imgs = ch?.message?.images;
\t\tif (!Array.isArray(imgs)) continue;
\t\tfor (const entry of imgs) {
\t\t\tconst u = entry?.image_url?.url ?? entry?.imageUrl?.url;
\t\t\tif (typeof u === "string" && u.startsWith("data:image")) urls.push(u);
\t\t}
\t}
\treturn urls;
}
function clawbbaBufferFromDataUrl(dataUrl) {
\tconst m = String(dataUrl || "").match(/^data:([^;]+);base64,(.+)$/s);
\tif (!m) return null;
\treturn { mime: m[1], buffer: Buffer.from(m[2], "base64") };
}
async function clawbbaFetchImageBuffersFromPollBody(body, hdrs) {
\tconst out = [];
\tfor (const dataUrl of clawbbaDataUrlsFromPollData(body?.data)) {
\t\tconst parsed = clawbbaBufferFromDataUrl(dataUrl);
\t\tif (parsed?.buffer?.length) out.push(parsed);
\t}
\tif (out.length) return out;
\tconst rawUrls = Array.isArray(body?.images) ? body.images.map((u) => String(u || "").trim()).filter((u) => /^https?:\\/\\//i.test(u)) : [];
\tfor (const url of rawUrls) {
\t\ttry {
\t\t\tconst res = await fetch(url, { headers: hdrs, signal: AbortSignal.timeout(120000) });
\t\t\tif (!res.ok) continue;
\t\t\tconst mime = String(res.headers.get("content-type") || "image/png").split(";")[0].trim() || "image/png";
\t\t\tout.push({ mime, buffer: Buffer.from(await res.arrayBuffer()) });
\t\t} catch (_) {}
\t}
\treturn out;
}
async function clawbbaPollClawbbaImageJob({ baseUrl, hdrs, jobId, maxWaitMs }) {
\tconst pollIntervalMs = 5000;
\tconst deadline = Date.now() + maxWaitMs;
\tlet lastBody = null;
\twhile (Date.now() < deadline) {
\t\tconst pollRes = await fetch(\`\${baseUrl}/images/generations/\${encodeURIComponent(jobId)}\`, { method: "GET", headers: hdrs, signal: AbortSignal.timeout(60000) });
\t\tconst text = await pollRes.text();
\t\tlet body;
\t\ttry { body = JSON.parse(text); } catch { throw new Error(\`ClawBBA image poll invalid JSON: \${text.slice(0, 200)}\`); }
\t\tif (!pollRes.ok && pollRes.status !== 404) throw new Error(body?.message || body?.error || \`Poll HTTP \${pollRes.status}\`);
\t\tif (typeof clawbbaNoteMediaPollProgress === "function") clawbbaNoteMediaPollProgress(body);
\t\tconst st = String(body?.status || "").toLowerCase();
\t\tif (st === "failed") throw new Error(String(body?.error || body?.message || "ClawBBA image job failed"));
\t\tif (st === "completed") { lastBody = body; break; }
\t\tawait new Promise((r) => setTimeout(r, pollIntervalMs));
\t}
\tif (!lastBody) throw new Error(\`Image job not completed after \${maxWaitMs}ms (job_id=\${jobId}). Retry: image_generate action=recover jobId=\${jobId} timeoutMs=600000\`);
\tconst buffers = await clawbbaFetchImageBuffersFromPollBody(lastBody, hdrs);
\tif (!buffers.length) throw new Error(\`ClawBBA image job completed but no downloadable image (job_id=\${jobId})\`);
\treturn { pollBody: lastBody, buffers };
}
async function clawbbaSaveRecoveredImageBuffers({ cfg, buffers, filename }) {
\tconst mediaMaxBytes = resolveGeneratedMediaMaxBytes(cfg, "image");
\tconst savedImages = [];
\tfor (let i = 0; i < buffers.length; i++) {
\t\tconst b = buffers[i];
\t\tconst saved = await saveMediaBuffer(b.buffer, b.mime, "tool-image-generation", mediaMaxBytes, i === 0 ? filename : undefined);
\t\tsavedImages.push(saved);
\t}
\treturn savedImages;
}
function clawbbaBuildRecoveredImageToolResult({ jobId, pollBody, savedImages }) {
\tlet model = "unknown";
\ttry { model = pollBody?.data?.model || pollBody?.model || model; } catch (_) {}
\tconst attachments = savedImages.map((image) => ({ type: "image", path: image.path, mimeType: image.contentType, name: image.id }));
\tconst lines = [
\t\t\`Recovered image job \${jobId} from ClawBBA (no re-generation; user digital asset).\`,
\t\t\`Model: \${model}; already billed on platform when completed.\`,
\t\t"Do NOT call the message tool on WebChat/dashboard — images are injected into the chat transcript automatically.",
\t\t"Do NOT paste https download links or ~/.openclaw file paths — WebChat renders MEDIA: local files inline.",
\t\t"",
\t\t"Local delivery (reply with MEDIA lines — do NOT call image_generate generate again):",
\t\t...savedImages.map((img) => \`MEDIA:\${img.path}\`)
\t];
\treturn {
\t\tcontent: [{ type: "text", text: lines.join("\\n") }],
\t\tprovider: "openrouter",
\t\tmodel,
\t\tcount: savedImages.length,
\t\tpaths: savedImages.map((img) => img.path),
\t\tattachments,
\t\tcontentText: lines.join("\\n"),
\t\twakeResult: lines.join("\\n"),
\t\tmediaUrls: savedImages.map((img) => img.path),
\t\tdetails: {
\t\t\tjobId,
\t\t\trecovered: true,
\t\t\tpaths: savedImages.map((img) => img.path),
\t\t\tmodel,
\t\t\tcount: savedImages.length,
\t\t\tmedia: { mediaUrls: savedImages.map((img) => img.path), attachments },
\t\t\tattachments
\t\t},
\t\tlines
\t};
}`
}

export function buildClawbbaImageRecoverFnBlock(includeAuthHelper = true) {
  const auth = includeAuthHelper ? `${buildClawbbaResolveOpenRouterApiKeyHelper()}\n` : ''
  return `${IMAGE_RECOVER_MARKER}
${auth}${sharedImageRecoverHelpers()}
async function clawbbaRecoverImageTask({ cfg, args, agentDir, authStore, agentSessionKey, chatRunId }) {
\tconst jobIdRaw = readStringParam$1(args, "jobId");
\tlet jobId = typeof jobIdRaw === "string" ? jobIdRaw.trim() : "";
\tconst maxWaitMs = readNumberParam(args, "timeoutMs", { integer: true, strict: true }) ?? 600000;
\tconst orCfg = cfg?.models?.providers?.openrouter;
\tconst baseUrl = String(orCfg?.baseUrl || "").replace(/\\/$/, "");
\tif (!baseUrl) throw new ToolInputError("No openrouter provider baseUrl configured.");
${CLAWBBA_AUTH_HEADERS}
\tif (orCfg?.headers && typeof orCfg.headers === "object") {
\t\tfor (const [k, v] of Object.entries(orCfg.headers)) {
\t\t\tif (typeof v === "string" && v.trim()) hdrs[k] = v.trim();
\t\t}
\t}
\tif (!jobId) {
\t\tconst listRes = await fetch(\`\${baseUrl}/images/tasks?limit=10\`, { method: "GET", headers: hdrs });
\t\tconst listText = await listRes.text();
\t\tlet listBody;
\t\ttry { listBody = JSON.parse(listText); } catch { throw new Error(\`ClawBBA image tasks list invalid JSON: \${listText.slice(0, 200)}\`); }
\t\tif (!listRes.ok) throw new Error(listBody?.message || listBody?.error || \`Tasks list HTTP \${listRes.status}\`);
\t\tconst rows = Array.isArray(listBody?.data) ? listBody.data : [];
\t\tconst pick = rows.find((r) => String(r?.status || "").toLowerCase() === "completed")
\t\t\t|| rows.find((r) => String(r?.status || "").toLowerCase() === "pending");
\t\tif (!pick?.image_job_id && !pick?.job_id) throw new ToolInputError("No recoverable image task found. Pass jobId from a prior image_generate or GET /api/v1/images/tasks.");
\t\tjobId = String(pick.image_job_id || pick.job_id).trim();
\t}
\tconst filename = readStringParam$1(args, "filename");
\tconst { pollBody, buffers } = await clawbbaPollClawbbaImageJob({ baseUrl, hdrs, jobId, maxWaitMs });
\tconst savedImages = await clawbbaSaveRecoveredImageBuffers({ cfg, buffers, filename });
\tconst built = clawbbaBuildRecoveredImageToolResult({ jobId, pollBody, savedImages });
\tif (agentSessionKey) {
\t\tawait clawbbaDispatchWebChatMediaLiveInject({
\t\t\tsessionKey: agentSessionKey,
\t\t\tchatRunId,
\t\t\tmediaUrls: savedImages.map((img) => img.path),
\t\t\tsourceTool: "image_generate",
\t\t\tcompletionLabel: "image",
\t\t\tmessage: built.lines.join("\\n")
\t\t});
\t}
\treturn { content: built.content, details: built.details };
}
async function clawbbaListImageTasks({ cfg, agentDir, authStore, args, agentSessionKey, chatRunId }) {
\tconst orCfg = cfg?.models?.providers?.openrouter;
\tconst baseUrl = String(orCfg?.baseUrl || "").replace(/\\/$/, "");
\tif (!baseUrl) throw new ToolInputError("No openrouter provider baseUrl configured.");
${CLAWBBA_AUTH_HEADERS}
\tif (orCfg?.headers && typeof orCfg.headers === "object") {
\t\tfor (const [k, v] of Object.entries(orCfg.headers)) {
\t\t\tif (typeof v === "string" && v.trim()) hdrs[k] = v.trim();
\t\t}
\t}
\tconst limit = readNumberParam(args, "limit", { integer: true, strict: true }) ?? 10;
\tconst status = readStringParam$1(args, "status");
\tconst qs = new URLSearchParams({ limit: String(Math.min(50, Math.max(1, limit))) });
\tif (status) qs.set("status", status);
\tconst res = await fetch(\`\${baseUrl}/images/tasks?\${qs}\`, { method: "GET", headers: hdrs });
\tconst responseText = await res.text();
\tlet body;
\ttry { body = JSON.parse(responseText); } catch { throw new Error(\`ClawBBA image tasks invalid JSON: \${responseText.slice(0, 200)}\`); }
\tif (!res.ok) throw new Error(body?.message || body?.error || \`Tasks HTTP \${res.status}\`);
\tconst rows = Array.isArray(body?.data) ? body.data : [];
\tconst lines = [
\t\t\`ClawBBA image tasks (\${rows.length}):\`,
\t\t...rows.map((r) => \`- \${r.image_job_id || r.job_id} status=\${r.status} model=\${r.model || "?"} created=\${r.created_at || r.submitted_at || "?"}\`),
\t\t"",
\t\t"To fetch completed asset without re-billing: image_generate action=recover jobId=<id> timeoutMs=600000"
\t];
\tconst taskListText = lines.join("\\n");
\tif (agentSessionKey && typeof clawbbaDispatchReadOnlyToolTextReply === "function") {
\t\tawait clawbbaDispatchReadOnlyToolTextReply({
\t\t\tcfg,
\t\t\tsessionKey: agentSessionKey,
\t\t\tchatRunId,
\t\t\tmessage: taskListText,
\t\t\tlabel: "ClawBBA image tasks"
\t\t});
\t}
\treturn { content: [{ type: "text", text: taskListText }], details: { tasks: rows } };
}
async function clawbbaTryAutoRecoverImageFromGenerationError({ cfg, error, agentDir, authStore, agentSessionKey, chatRunId }) {
\tif (!clawbbaImageRecoverLooksLikeTimeout(error)) return null;
\tconst jobId = clawbbaExtractImageJobIdFromError(error);
\tif (!jobId) return null;
\ttry {
\t\tconst recovered = await clawbbaRecoverImageTask({
\t\t\tcfg,
\t\t\targs: { jobId, timeoutMs: 600000 },
\t\t\tagentDir,
\t\t\tauthStore,
\t\t\tagentSessionKey,
\t\t\tchatRunId
\t\t});
\t\tconst details = recovered?.details || {};
\t\tconst paths = Array.isArray(details.paths) ? details.paths : [];
\t\tconst attachments = Array.isArray(details.media?.attachments) ? details.media.attachments : paths.map((p) => ({ type: "image", path: p }));
\t\treturn {
\t\t\tprovider: details.provider || "openrouter",
\t\t\tmodel: details.model || "unknown",
\t\t\tcount: details.count || paths.length,
\t\t\tpaths,
\t\t\tattachments,
\t\t\tmediaUrls: paths,
\t\t\twakeResult: recovered?.content?.[0]?.text || \`Recovered image job \${jobId} after timeout.\`,
\t\t\tcontentText: recovered?.content?.[0]?.text || \`Recovered image job \${jobId} after timeout.\`
\t\t};
\t} catch (recoverErr) {
\t\ttry { log$5.warn("clawbba image auto-recover failed", { jobId, error: String(recoverErr?.message ?? recoverErr) }); } catch (_) {}
\t\treturn null;
\t}
}`
}

const IMAGE_EXECUTE_INSERT_NEEDLE =
  /\t\t\tif \(action === "status"\) return createImageGenerateStatusActionResult\(options\?\.agentSessionKey\);\n\t\t\tconst imageGenerationModelConfig = resolveImageGenerationModelConfigForTool\(\{/

const IMAGE_EXECUTE_INSERT =
  `\t\t\tif (action === "status") return createImageGenerateStatusActionResult(options?.agentSessionKey);
\t\t\tif (action === "tasks") return await clawbbaListImageTasks({ cfg, agentDir: options?.agentDir, authStore: options?.authProfileStore, args: params, agentSessionKey: options?.agentSessionKey, chatRunId: options?.runId });
\t\t\tif (action === "recover") return await clawbbaRecoverImageTask({ cfg, args: params, agentDir: options?.agentDir, authStore: options?.authProfileStore, agentSessionKey: options?.agentSessionKey, chatRunId: options?.runId });
\t\t\tconst imageGenerationModelConfig = resolveImageGenerationModelConfigForTool({`

const IMAGE_SCHEMA_ACTION_NEEDLE =
  'action: Type.Optional(Type.String({ description: "\\"generate\\" default; \\"status\\" session task; \\"list\\" providers; \\"tasks\\" ClawBBA job list; \\"recover\\" poll+download completed job (no re-bill)." })),'

const IMAGE_JOB_ID_PROPS = `\tjobId: Type.Optional(Type.String({ description: "ClawBBA image job_id for action=recover." })),
\tlimit: Type.Optional(Type.Number({ description: "Max rows for action=tasks.", minimum: 1 })),
\tstatus: Type.Optional(Type.String({ description: "Filter for action=tasks: pending|completed|failed|all." })),`

const IMAGE_RESOLVE_ACTION_RE =
  /function resolveAction\$2\(args\) \{\n\treturn resolveGenerateAction\(\{\n\t\targs,\n\t\tallowed: \[\n\t\t\t"generate",\n\t\t\t"status",\n\t\t\t"list"\n\t\t\],/

const IMAGE_RESOLVE_ACTION_REPLACEMENT = `function resolveAction$2(args) {
\treturn resolveGenerateAction({
\t\targs,
\t\tallowed: [
\t\t\t"generate",
\t\t\t"status",
\t\t\t"list",
\t\t\t"recover",
\t\t\t"tasks"
\t\t],`

/** @param {string} src */
export function imageResolveActionFnBlock(src) {
  const fnStart = src.indexOf('function resolveAction$2(args)')
  if (fnStart < 0) return ''
  const fnEnd = src.indexOf('\nfunction ', fnStart + 1)
  return src.slice(fnStart, fnEnd > fnStart ? fnEnd : fnStart + 500)
}

/** @param {string} src */
export function imageResolveActionAllowsTasks(src) {
  const fnBlock = imageResolveActionFnBlock(src)
  return /allowed:[\s\S]*?"tasks"/.test(fnBlock)
}

/** @param {string} src */
export function ensureImageResolveActionAllowsRecoverTasks(src) {
  if (!src.includes('function resolveAction$2(args)')) return src
  if (imageResolveActionAllowsTasks(src)) {
    return src
  }
  if (IMAGE_RESOLVE_ACTION_RE.test(src)) {
    return src.replace(IMAGE_RESOLVE_ACTION_RE, IMAGE_RESOLVE_ACTION_REPLACEMENT)
  }
  const fnBlock = imageResolveActionFnBlock(src)
  if (!fnBlock.includes('allowed:')) return src
  const fnStart = src.indexOf('function resolveAction$2(args)')
  const fnEnd = src.indexOf('\nfunction ', fnStart + 1)
  const fixedBlock = fnBlock.replace(
    /(\t\t\t"list"\n\t\t\],)/,
    '\t\t\t"list",\n\t\t\t"recover",\n\t\t\t"tasks"\n\t\t],',
  )
  if (fixedBlock === fnBlock) return src
  return src.slice(0, fnStart) + fixedBlock + src.slice(fnEnd > fnStart ? fnEnd : fnStart + 500)
}

const SCHEDULE_CATCH_NEEDLE = `\t\t} catch (error) {
\t\t\tparams.lifecycle.failTaskRun({
\t\t\t\thandle: params.handle,
\t\t\t\terror
\t\t\t});
\t\t\tawait params.lifecycle.wakeTaskCompletion({
\t\t\t\tconfig: params.config,
\t\t\t\thandle: params.handle,
\t\t\t\tstatus: "error",
\t\t\t\tstatusLabel: "failed",
\t\t\t\tresult: formatErrorMessage(error)
\t\t\t});
\t\t}`

const SCHEDULE_CATCH_REPLACEMENT = `\t\t} catch (error) {
\t\t\t${IMAGE_RECOVER_AUTO_MARKER}
\t\t\tlet clawbbaRecoveredImage = null;
\t\t\tif (params.toolName === "Image generation") {
\t\t\t\ttry {
\t\t\t\t\tclawbbaRecoveredImage = await clawbbaTryAutoRecoverImageFromGenerationError({
\t\t\t\t\t\tcfg: params.config,
\t\t\t\t\t\terror,
\t\t\t\t\t\tagentDir: params.agentDir,
\t\t\t\t\t\tauthStore: params.authStore,
\t\t\t\t\t\tagentSessionKey: params.handle?.requesterSessionKey,
\t\t\t\t\t\tchatRunId: params.handle?.requesterChatRunId
\t\t\t\t\t});
\t\t\t\t} catch (_) {}
\t\t\t}
\t\t\tif (clawbbaRecoveredImage) {
\t\t\t\tparams.lifecycle.completeTaskRun({
\t\t\t\t\thandle: params.handle,
\t\t\t\t\tprovider: clawbbaRecoveredImage.provider,
\t\t\t\t\tmodel: clawbbaRecoveredImage.model,
\t\t\t\t\tcount: clawbbaRecoveredImage.count,
\t\t\t\t\tpaths: clawbbaRecoveredImage.paths
\t\t\t\t});
\t\t\t\ttry {
\t\t\t\t\tawait params.lifecycle.wakeTaskCompletion({
\t\t\t\t\t\tconfig: params.config,
\t\t\t\t\t\thandle: params.handle,
\t\t\t\t\t\tstatus: "ok",
\t\t\t\t\t\tstatusLabel: "recovered after timeout",
\t\t\t\t\t\tresult: clawbbaRecoveredImage.wakeResult,
\t\t\t\t\t\tattachments: clawbbaRecoveredImage.attachments,
\t\t\t\t\t\tmediaUrls: clawbbaRecoveredImage.mediaUrls
\t\t\t\t\t});
\t\t\t\t} catch (wakeErr) {
\t\t\t\t\tparams.onWakeFailure?.("Image recover wake failed after successful recovery", { taskId: params.handle?.taskId, runId: params.handle?.runId, error: wakeErr });
\t\t\t\t}
\t\t\t\treturn;
\t\t\t}
\t\t\tparams.lifecycle.failTaskRun({
\t\t\t\thandle: params.handle,
\t\t\t\terror
\t\t\t});
\t\t\tawait params.lifecycle.wakeTaskCompletion({
\t\t\t\tconfig: params.config,
\t\t\t\thandle: params.handle,
\t\t\t\tstatus: "error",
\t\t\t\tstatusLabel: "failed",
\t\t\t\tresult: formatErrorMessage(error)
\t\t\t});
\t\t}`

const SCHEDULE_IMAGE_CALL_NEEDLE = `\t\t\t\tscheduleMediaGenerationTaskCompletion({
\t\t\t\t\tlifecycle: imageGenerationTaskLifecycle,
\t\t\t\t\thandle: taskHandle,
\t\t\t\t\tscheduleBackgroundWork,
\t\t\t\t\tprogressSummary: "Generating image",
\t\t\t\t\tconfig: effectiveCfg,
\t\t\t\t\ttoolName: "Image generation",`

const SCHEDULE_IMAGE_CALL_REPLACEMENT = `\t\t\t\tscheduleMediaGenerationTaskCompletion({
\t\t\t\t\tlifecycle: imageGenerationTaskLifecycle,
\t\t\t\t\thandle: taskHandle,
\t\t\t\t\tscheduleBackgroundWork,
\t\t\t\t\tprogressSummary: "Generating image",
\t\t\t\t\tconfig: effectiveCfg,
\t\t\t\t\tagentDir: options?.agentDir,
\t\t\t\t\tauthStore: options?.authProfileStore,
\t\t\t\t\ttoolName: "Image generation",`

/** @param {string} src @param {"image"|"video"} kind */
export function listTasksFnHasSessionKeyParam(src, kind) {
  const fnName = kind === 'video' ? 'clawbbaListVideoTasks' : 'clawbbaListImageTasks'
  const m = src.match(new RegExp(`async function ${fnName}\\(\\{([^}]*)\\}\\)`))
  const params = m?.[1] || ''
  return params.includes('agentSessionKey') && params.includes('chatRunId')
}

/** @param {string} src @param {"image"|"video"} kind */
export function ensureListTasksSessionKeyParams(src, kind) {
  const fnName = kind === 'video' ? 'clawbbaListVideoTasks' : 'clawbbaListImageTasks'
  if (!src.includes(`async function ${fnName}`)) return src
  let out = src
  if (!listTasksFnHasSessionKeyParam(out, kind)) {
    const oldSig = `async function ${fnName}({ cfg, agentDir, authStore, args }) {`
    const newSig = `async function ${fnName}({ cfg, agentDir, authStore, args, agentSessionKey, chatRunId }) {`
    if (out.includes(oldSig)) {
      out = out.replace(oldSig, newSig)
    }
  }
  const listCall = fnName
  const oldExec = `if (action === "tasks") return await ${listCall}({ cfg, agentDir: options?.agentDir, authStore: options?.authProfileStore, args: params });`
  const newExec = `if (action === "tasks") return await ${listCall}({ cfg, agentDir: options?.agentDir, authStore: options?.authProfileStore, args: params, agentSessionKey: options?.agentSessionKey, chatRunId: options?.runId });`
  if (out.includes(oldExec)) {
    out = out.replace(oldExec, newExec)
  }
  return out
}

/** @param {string} src @param {"image"|"video"} kind */
export function listTasksBlockIsHealthy(src, kind) {
  const fnName = kind === 'video' ? 'clawbbaListVideoTasks' : 'clawbbaListImageTasks'
  const start = src.indexOf(`async function ${fnName}`)
  if (start < 0) return true
  const end = src.indexOf('\nasync function ', start + 1)
  const block = src.slice(start, end > start ? end : src.length)
  if (!block.includes('taskListText')) {
    return !block.includes('clawbbaDispatchReadOnlyToolTextReply')
  }
  return block.includes('const taskListText = lines.join')
}

/** @param {string} src @param {"image"|"video"} kind */
export function ensureListTasksTaskListTextDeclared(src, kind) {
  const fnName = kind === 'video' ? 'clawbbaListVideoTasks' : 'clawbbaListImageTasks'
  const start = src.indexOf(`async function ${fnName}`)
  if (start < 0) return src
  const end = src.indexOf('\nasync function ', start + 1)
  const block = src.slice(start, end > start ? end : src.length)
  if (!block.includes('taskListText') || block.includes('const taskListText = lines.join')) {
    return src
  }
  let fixed = block
  if (fixed.includes('const text = lines.join("\\n")')) {
    fixed = fixed.replace('const text = lines.join("\\n")', 'const taskListText = lines.join("\\n")')
  } else {
    fixed = fixed.replace(
      /\n\tif \(agentSessionKey && typeof clawbbaDispatchReadOnlyToolTextReply === "function"\)/,
      '\n\tconst taskListText = lines.join("\\n");\n\tif (agentSessionKey && typeof clawbbaDispatchReadOnlyToolTextReply === "function")',
    )
    if (!fixed.includes('const taskListText = lines.join')) {
      fixed = fixed.replace(
        /\n\treturn \{\n\t\tcontent: \[\{ type: "text", text: taskListText \}\]/,
        '\n\tconst taskListText = lines.join("\\n");\n\treturn {\n\t\tcontent: [{ type: "text", text: taskListText }]',
      )
    }
    if (!fixed.includes('const taskListText = lines.join')) {
      fixed = fixed.replace(
        /\n\treturn \{ content: \[\{ type: "text", text: taskListText \}\]/,
        '\n\tconst taskListText = lines.join("\\n");\n\treturn { content: [{ type: "text", text: taskListText }]',
      )
    }
  }
  if (fixed === block) return src
  return src.slice(0, start) + fixed + src.slice(end > start ? end : src.length)
}

/** @param {string} src @param {"image"|"video"} kind */
export function upgradeListTasksFixTextVarCollision(src, kind) {
  const fnName = kind === 'video' ? 'clawbbaListVideoTasks' : 'clawbbaListImageTasks'
  const start = src.indexOf(`async function ${fnName}`)
  if (start < 0) return src
  const end = src.indexOf('\nasync function ', start + 1)
  const block = src.slice(start, end > start ? end : src.length)
  const hasFetchTextCollision = block.includes('const text = await res.text()')
  const hasLinesTextVar = block.includes('const text = lines.join')
  const hasResponseText = block.includes('const responseText = await res.text()')
  const needsTaskListText = block.includes('taskListText') && !block.includes('const taskListText = lines.join')

  if (hasResponseText && hasLinesTextVar && needsTaskListText) {
    let fixed = block.replace('const text = lines.join("\\n")', 'const taskListText = lines.join("\\n")')
    if (fixed !== block) {
      return src.slice(0, start) + fixed + src.slice(end > start ? end : src.length)
    }
  }

  if (!hasFetchTextCollision || !hasLinesTextVar) return src
  if (hasResponseText) return src
  const invalidJsonLabel = kind === 'video' ? 'ClawBBA video tasks invalid JSON' : 'ClawBBA image tasks invalid JSON'
  let fixed = block
    .replace('const text = await res.text()', 'const responseText = await res.text()')
    .replace('JSON.parse(text)', 'JSON.parse(responseText)')
    .replaceAll('${text.slice(0, 200)}', '${responseText.slice(0, 200)}')
    .replace('const text = lines.join("\\n")', 'const taskListText = lines.join("\\n")')
    .replace('message: text,', 'message: taskListText,')
    .replace('{ type: "text", text }', '{ type: "text", text: taskListText }')
    .replace('content: [{ type: "text", text }]', 'content: [{ type: "text", text: taskListText }]')
  if (!fixed.includes(invalidJsonLabel)) return src
  return src.slice(0, start) + fixed + src.slice(end > start ? end : src.length)
}

/** @param {string} src */
export function upgradeListImageTasksDirectReply(src) {
  let out = upgradeListTasksFixTextVarCollision(src, 'image')
  out = ensureListTasksTaskListTextDeclared(out, 'image')
  if (!out.includes('async function clawbbaListImageTasks')) return out
  out = ensureListTasksSessionKeyParams(out, 'image')
  const label = 'label: "ClawBBA image tasks"'
  if (
    out.includes('clawbbaDispatchReadOnlyToolTextReply') &&
    listTasksBlockIsHealthy(out, 'image') &&
    listTasksFnHasSessionKeyParam(out, 'image') &&
    out.includes('agentSessionKey: options?.agentSessionKey, chatRunId: options?.runId') &&
    out.includes(label)
  ) {
    return out
  }
  if (!out.includes('label: "ClawBBA image tasks"')) {
    out = out.replace(
      /\treturn \{ content: \[\{ type: "text", text: lines\.join\("\\n"\) \}\], details: \{ tasks: rows \} \};\n\}/,
      `\tconst taskListText = lines.join("\\\\n");
\tif (agentSessionKey && typeof clawbbaDispatchReadOnlyToolTextReply === "function") {
\t\tawait clawbbaDispatchReadOnlyToolTextReply({
\t\t\tcfg,
\t\t\tsessionKey: agentSessionKey,
\t\t\tchatRunId,
\t\t\tmessage: taskListText,
\t\t\tlabel: "ClawBBA image tasks"
\t\t});
\t}
\treturn { content: [{ type: "text", text: taskListText }], details: { tasks: rows } };
}`,
    )
  }
  return ensureListTasksTaskListTextDeclared(ensureListTasksSessionKeyParams(out, 'image'), 'image')
}

/**
 * @param {string} src
 */
export function upgradeImageRecoverWebChatLive(src) {
  if (!src.includes('clawbbaRecoverImageTask')) return src
  let out = src
  if (recoverWebChatInjectNeedsUpgrade(out)) {
    out = stripLegacyRecoverWebChatInject(out)
  }
  if (out.includes(IMAGE_RECOVER_RETURN_NEEDLE) && !recoverFnHasWebChatDispatchInject(out)) {
    out = out.replace(IMAGE_RECOVER_RETURN_NEEDLE, `${buildImageRecoverWebChatInjectBlock()}\n${IMAGE_RECOVER_RETURN_NEEDLE}`)
  }
  return out
}

/**
 * @param {string} filePath
 * @returns {'patched'|'upgraded'|'skip'|'pattern-missing'}
 */
export function patchImageGenerateRecoverAction(filePath) {
  let src = fs.readFileSync(filePath, 'utf8')
  let changed = false

  if (src.includes(IMAGE_RECOVER_MARKER) && src.includes('clawbbaRecoverImageTask')) {
    if (src.includes('resolveApiKeyForProvider({ provider: "openrouter"')) {
      src = upgradeClawbbaVideoRecoverAuth(src)
      changed = true
    }
    const withResolve = ensureImageResolveActionAllowsRecoverTasks(src)
    if (withResolve !== src) {
      src = withResolve
      changed = true
    }
    const withDirectReply = upgradeListImageTasksDirectReply(src)
    if (withDirectReply !== src) {
      src = withDirectReply
      changed = true
    }
    const upgraded = upgradeImageRecoverWebChatLive(src)
    if (upgraded !== src) {
      src = upgraded
      changed = true
    }
    if (!src.includes(IMAGE_RECOVER_AUTO_MARKER) && src.includes(SCHEDULE_CATCH_NEEDLE)) {
      src = src.replace(SCHEDULE_CATCH_NEEDLE, SCHEDULE_CATCH_REPLACEMENT)
      changed = true
    }
    if (changed) {
      fs.writeFileSync(filePath, src)
      return 'upgraded'
    }
    if (!listTasksFnHasSessionKeyParam(src, 'image')) {
      throw new Error(`image list tasks missing agentSessionKey param in ${path.basename(filePath)}`)
    }
    if (src.includes('clawbbaListImageTasks') && !listTasksBlockIsHealthy(src, 'image')) {
      throw new Error(`image list tasks taskListText not declared in ${path.basename(filePath)}`)
    }
    if (src.includes('clawbbaListImageTasks') && !imageResolveActionAllowsTasks(src)) {
      throw new Error(`image resolveAction$2 missing tasks/recover in ${path.basename(filePath)}`)
    }
    return 'skip'
  }

  if (!src.includes('function createImageGenerateTool(')) {
    return 'pattern-missing'
  }

  if (!src.includes('clawbbaResolveOpenRouterApiKey') && !src.includes(VIDEO_RECOVER_AUTH_MARKER)) {
    const fnBlock = buildClawbbaImageRecoverFnBlock(true)
    src = src.replace('function createImageGenerateTool(options) {', `${fnBlock}\nfunction createImageGenerateTool(options) {`)
    changed = true
  } else if (!src.includes('clawbbaRecoverImageTask')) {
    const fnBlock = buildClawbbaImageRecoverFnBlock(false)
    src = src.replace('async function clawbbaRecoverVideoTask(', `${fnBlock}\nasync function clawbbaRecoverVideoTask(`)
    changed = true
  }

  if (!src.includes('jobId: Type.Optional(Type.String({ description: "ClawBBA image job_id')) {
    if (src.includes(IMAGE_SCHEMA_ACTION_NEEDLE)) {
      src = src.replace(IMAGE_SCHEMA_ACTION_NEEDLE, `${IMAGE_SCHEMA_ACTION_NEEDLE}\n${IMAGE_JOB_ID_PROPS}`)
      changed = true
    }
  }

  if (IMAGE_EXECUTE_INSERT_NEEDLE.test(src) && !src.includes('action === "recover") return await clawbbaRecoverImageTask')) {
    src = src.replace(IMAGE_EXECUTE_INSERT_NEEDLE, IMAGE_EXECUTE_INSERT)
    changed = true
  }

  const withResolve = ensureImageResolveActionAllowsRecoverTasks(src)
  if (withResolve !== src) {
    src = withResolve
    changed = true
  }

  if (!src.includes(IMAGE_RECOVER_AUTO_MARKER) && src.includes(SCHEDULE_CATCH_NEEDLE)) {
    src = src.replace(SCHEDULE_CATCH_NEEDLE, SCHEDULE_CATCH_REPLACEMENT)
    changed = true
  }

  if (src.includes(SCHEDULE_IMAGE_CALL_NEEDLE) && !src.includes('authStore: options?.authProfileStore,\n\t\t\t\t\ttoolName: "Image generation"')) {
    src = src.replace(SCHEDULE_IMAGE_CALL_NEEDLE, SCHEDULE_IMAGE_CALL_REPLACEMENT)
    changed = true
  }

  if (!src.includes('clawbbaRecoverImageTask')) {
    return 'pattern-missing'
  }

  if (!imageResolveActionAllowsTasks(src)) {
    throw new Error(`image resolveAction$2 missing tasks/recover after patch in ${path.basename(filePath)}`)
  }
  if (src.includes('clawbbaListImageTasks') && !listTasksBlockIsHealthy(src, 'image')) {
    throw new Error(`image list tasks taskListText not declared after patch in ${path.basename(filePath)}`)
  }

  if (changed) {
    fs.writeFileSync(filePath, src)
    return 'patched'
  }
  return 'pattern-missing'
}
