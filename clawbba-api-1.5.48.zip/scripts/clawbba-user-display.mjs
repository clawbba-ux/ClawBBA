/**
 * 安装/验证脚本的**用户可见**文案（ClawBBA 品牌）。
 * OpenClaw 配置内部仍使用 models.providers.openrouter 与 openrouter/<model-id>，功能不变。
 */

export const VERIFY_PATCH_LABELS = {
  wake: 'wake reply (MEDIA delivery)',
  announceAuto: 'announce (WebChat automatic)',
  announceLive: 'announce (WebChat chat.inject helper)',
  webchatLiveWake: 'wake completion (WebChat live inject)',
  webchatLiveInjectHelper: 'WebChat live inject helper (agent:main:main)',
  modelRef: 'model-ref（平台 id → ClawBBA 媒体）',
  imgDispatch: 'image_generate 媒体模型（ClawBBA）',
  refImages: 'reference images (session → image/images)',
  imgConfig: 'ClawBBA 生图 image_config（全模型）',
  imgHeaders: 'ClawBBA 生图请求头 v2',
  imgHeadersSpread: 'ClawBBA 生图请求头合并',
  videoProvider: 'ClawBBA 生视频模型归一 + 超时',
  imgProvAsync: 'ClawBBA 生图 202 异步轮询（等到出图）',
  imgRecover: 'image_generate recover（轮询+下载）',
  imgRecoverLive: 'image recover (WebChat live inject)',
  imgRecoverAuto: 'image timeout auto-recover',
  videoRecoverLive: 'video recover (WebChat live inject)',
  mediaProgress: '生图/生视频进度推送（WebChat + 渠道）',
  userMediaModelDisplay: '用户可见模型名（ClawBBA 品牌）',
}

/** --flux-only 时必检项（label 须与 VERIFY_PATCH_LABELS 一致） */
export const VERIFY_PATCH_FLUX_ONLY_LABELS = new Set([
  VERIFY_PATCH_LABELS.modelRef,
  VERIFY_PATCH_LABELS.imgDispatch,
])

/** install-clawbba-api.sh 必检：含 WebChat 即时显示 chat.inject */
export const VERIFY_PATCH_INSTALL_LABELS = new Set([
  VERIFY_PATCH_LABELS.modelRef,
  VERIFY_PATCH_LABELS.imgDispatch,
  VERIFY_PATCH_LABELS.announceAuto,
  VERIFY_PATCH_LABELS.announceLive,
  VERIFY_PATCH_LABELS.webchatLiveWake,
  VERIFY_PATCH_LABELS.webchatLiveInjectHelper,
  VERIFY_PATCH_LABELS.wake,
  VERIFY_PATCH_LABELS.mediaProgress,
  VERIFY_PATCH_LABELS.videoRecoverLive,
  VERIFY_PATCH_LABELS.imgRecover,
  VERIFY_PATCH_LABELS.imgRecoverAuto,
  VERIFY_PATCH_LABELS.userMediaModelDisplay,
])
