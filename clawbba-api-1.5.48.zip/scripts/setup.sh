#!/usr/bin/env bash
# ClawBBA API → OpenClaw 自动配置（merge，不覆盖其他 provider）
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
API_BASE="${CLAWBBA_API_BASE:-https://www.clawbba.com/api/v1}"
KEY="${CLAWBBA_API_KEY:-}"
PATCH_FILE="${CLAWBBA_PATCH_FILE:-$ROOT_DIR/clawbba-openclaw.patch.json}"

echo "══════════════════════════════════════════"
echo " ClawBBA API → OpenClaw 配置"
echo " API: ${API_BASE}"
echo "══════════════════════════════════════════"

if [[ -z "$KEY" ]]; then
  echo "" >&2
  echo "未设置 CLAWBBA_API_KEY。" >&2
  echo "" >&2
  echo "请先：" >&2
  echo "  1. 登录 https://www.clawbba.com" >&2
  echo "  2. 充值 https://www.clawbba.com/product/CDKEY" >&2
  echo "  3. 创建 Key https://www.clawbba.com/agent/api-keys" >&2
  echo "" >&2
  echo "然后执行：" >&2
  echo "  export CLAWBBA_API_KEY='cbb_sk_live_你的密钥'" >&2
  echo "  $0" >&2
  exit 1
fi

if [[ "$KEY" != cbb_sk_live_* ]]; then
  echo "错误: 请使用 Platform API Key（前缀 cbb_sk_live_），在 https://www.clawbba.com/agent/api-keys 创建" >&2
  exit 1
fi

if ! command -v node >/dev/null 2>&1; then
  echo "错误: 需要 Node.js 运行 generate-openclaw-patch.mjs" >&2
  exit 1
fi

export CLAWBBA_API_BASE="$API_BASE"
export CLAWBBA_API_KEY="$KEY"

if command -v openclaw >/dev/null 2>&1; then
  "$SCRIPT_DIR/one-shot-setup.sh"

  echo "→ 验证配置…"
  if openclaw config validate; then
    echo ""
    echo "✓ 配置成功"
    if command -v node >/dev/null 2>&1 && [[ -f "$PATCH_FILE" ]]; then
      node -e "
const p = JSON.parse(require('fs').readFileSync(process.argv[1], 'utf8'));
const n = (p.models?.providers?.clawbba?.models || []).length;
const a = Object.keys(p.agents?.defaults?.models || {}).filter(k => k.startsWith('clawbba/')).length;
console.log('  clawbba provider 模型:', n, '| allowlist:', a);
if (n !== a) console.warn('  ⚠ provider 与 allowlist 数量不一致，请重新运行 setup.sh');
" "$PATCH_FILE"
    fi
  else
    echo "⚠ validate 未通过。请勿手改 openclaw.json 删模型；修复 env 后重新运行: $0 --yes" >&2
    echo "  patch 已保存: $PATCH_FILE" >&2
    exit 1
  fi
else
  echo ""
  echo "未检测到 openclaw CLI。patch 已保存到：" >&2
  echo "  $PATCH_FILE" >&2
  echo "" >&2
  echo "安装 OpenClaw 后执行：" >&2
  echo "  openclaw config patch --file $PATCH_FILE" >&2
  echo "  openclaw config validate" >&2
  exit 0
fi

echo ""
echo "下一步："
echo "  1. 重启 OpenClaw Gateway（必须，否则 WebChat 仍用旧配置）:"
echo "     openclaw gateway restart"
echo "  2. （推荐）写入 systemd，避免重启后 env 丢失:"
echo "     见 skills/clawbba-api/references/onboarding.md「Gateway systemd」"
echo "  3. 切换模型后请新开对话，或在聊天内执行 /model clawbba/<model-id>"
echo "  4. 对话模型: openclaw models list | grep clawbba"
echo "  5. 生图/生视频: WebChat 发送「请使用 ClawBBA 生成图片能力…」；勿向用户提及 OpenRouter"
echo "  6. 集成规范: references/openclaw-integration-spec.md（v1.2 唯一架构说明）"
echo "  7. 验证 patch: node scripts/verify-openclaw-patch.mjs（必须三项 ✓）"
echo "  8. 生图/生视频后未自动出媒体 → 见 integration-spec §6；禁止 Agent 重新生成，只 redeliver MEDIA"
echo "  8. 切换默认: openclaw models set clawbba/<model-id>"
echo "  9. 媒体参数说明: 见 skills/clawbba-api/references/media-generation.md"
echo ""
echo "充值: https://www.clawbba.com/product/CDKEY"
echo "密钥: https://www.clawbba.com/agent/api-keys"
