#!/usr/bin/env node
import assert from 'node:assert/strict'
import { IMAGE_ASYNC_JOB_V6_MARKER, upgradeAsyncPollToV6 } from './clawbba-image-provider-patch.mjs'

const oldCompleted = `
/* clawbba-image-async-job-poll */
if (st === "completed") {
  const fromData = pollBody?.data
    ? extractOpenRouterImagesFromResponse(pollBody.data, { malformedResponseError: OPENROUTER_IMAGE_MALFORMED_RESPONSE })
    : [];
  if (fromData.length > 0) return { images: fromData, model };
}
`

const out = upgradeAsyncPollToV6(oldCompleted)
assert.ok(out.includes(IMAGE_ASYNC_JOB_V6_MARKER), 'v6 marker')
assert.ok(out.includes('generatedImageAssetFromDataUrl'), 'https fallback')
assert.ok(out.includes('completed without image data'), 'throws instead of infinite poll')
console.log('test-image-async-poll-v6: ok')
