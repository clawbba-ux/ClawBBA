#!/usr/bin/env node
/**
 * Smoke test: image_generate recover + auto-recover on openclaw@2026.5.27.
 */
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { execSync } from 'node:child_process'
import {
  patchImageGenerateRecoverAction,
  IMAGE_RECOVER_AUTO_MARKER,
  IMAGE_RECOVER_MARKER,
} from './clawbba-image-recover-patch.mjs'
import { patchWebChatLiveInjectHelperInToolsFile } from './clawbba-webchat-live-inject.mjs'
import {
  patchReadOnlyToolTextReplyDist,
  READONLY_TOOL_INCOMPLETE_TURN_MARKER,
  READONLY_TOOL_TEXT_REPLY_V2_MARKER,
} from './clawbba-readonly-tool-reply-patch.mjs'

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'clawbba-img-recover-'))
const tgz = path.join(tmp, 'openclaw.tgz')
execSync(`npm pack openclaw@2026.5.27 --silent`, { cwd: tmp, stdio: 'pipe' })
const packed = fs.readdirSync(tmp).find((n) => n.endsWith('.tgz'))
fs.renameSync(path.join(tmp, packed), tgz)
execSync(`tar -xzf ${JSON.stringify(path.basename(tgz))}`, { cwd: tmp })

const dist = path.join(tmp, 'package', 'dist')
const toolsFile = fs.readdirSync(dist).find((n) => n.startsWith('openclaw-tools-'))
const pluginsFile = fs.readdirSync(dist).find((n) => n.startsWith('server-plugins-'))
const gatewayFile = fs.readdirSync(dist).find((n) => n.startsWith('gateway-request-scope-'))
const globalSingletonFile = fs.readdirSync(dist).find((n) => n.startsWith('global-singleton-'))
assert.ok(toolsFile, 'openclaw-tools bundle missing')
const toolsPath = path.join(dist, toolsFile)

assert.equal(
  patchWebChatLiveInjectHelperInToolsFile(toolsPath, pluginsFile, globalSingletonFile, gatewayFile),
  'patched',
)
assert.equal(patchImageGenerateRecoverAction(toolsPath), 'patched')
const readonly = patchReadOnlyToolTextReplyDist(dist, (d, prefix) => fs.readdirSync(d).find((n) => n.startsWith(prefix)))
assert.equal(readonly.tools, 'patched')
assert.equal(readonly.selection, 'patched')

const src = fs.readFileSync(toolsPath, 'utf8')
assert.ok(src.includes(IMAGE_RECOVER_MARKER))
assert.ok(src.includes('clawbbaRecoverImageTask'))
assert.ok(src.includes('clawbbaListImageTasks'))
assert.ok(src.includes('clawbbaTryAutoRecoverImageFromGenerationError'))
assert.ok(src.includes(IMAGE_RECOVER_AUTO_MARKER))
assert.ok(src.includes('action === "tasks") return await clawbbaListImageTasks'))
assert.ok(src.includes('action === "recover") return await clawbbaRecoverImageTask'))
assert.match(src, /function resolveAction\$2\(args\) \{[\s\S]*?"recover"[\s\S]*?"tasks"/)
assert.ok(src.includes('clawbbaDispatchReadOnlyToolTextReply'))
assert.ok(src.includes(READONLY_TOOL_TEXT_REPLY_V2_MARKER))
assert.ok(src.includes('if (chatRunId || clawbbaShouldInjectWebChatMediaLive(sessionKey))'))
assert.ok(src.includes('taskListText'))
assert.ok(src.includes('responseText = await res.text()'))
assert.ok(!/async function clawbbaListImageTasks[\s\S]*?const text = await res\.text\(\)[\s\S]*?const text = lines\.join/.test(src))
assert.ok(src.includes('label: "ClawBBA image tasks"'))
assert.ok(/async function clawbbaListImageTasks\(\{[^}]*agentSessionKey/.test(src))
assert.ok(src.includes('agentSessionKey: options?.agentSessionKey, chatRunId: options?.runId'))
assert.ok(src.includes('authStore: options?.authProfileStore'))
assert.ok(src.includes('agentDir: options?.agentDir'))
assert.ok(src.includes('toolName: "Image generation"'))

const selectionFile = fs.readdirSync(dist).find((n) => {
  if (!n.startsWith('selection-') || !n.endsWith('.js')) return false
  return fs.readFileSync(path.join(dist, n), 'utf8').includes('function resolveIncompleteTurnPayloadText(params)')
})
assert.ok(selectionFile, 'selection bundle missing')
const selectionSrc = fs.readFileSync(path.join(dist, selectionFile), 'utf8')
assert.ok(selectionSrc.includes(READONLY_TOOL_INCOMPLETE_TURN_MARKER))
assert.ok(src.includes('/images/tasks'))
assert.ok(src.includes('/images/generations/'))

assert.equal(patchImageGenerateRecoverAction(toolsPath), 'skip')

console.log('test-image-recover-patch: ok')
