#!/usr/bin/env node
/**
 * Unit tests for reference-image session parsing (clawbba-reference-images.mjs).
 */
import assert from 'node:assert/strict'
import {
  extractImageRefsFromMessage,
  looksLikeImageRef,
  messageTextFromRecord,
  paramsHaveReferenceImages,
} from './clawbba-reference-images.mjs'

assert.ok(looksLikeImageRef('/root/.openclaw/media/inbound/photo.png'))
assert.ok(looksLikeImageRef('data:image/png;base64,abc'))
assert.ok(!looksLikeImageRef('hello world'))

const withImagePart = {
  role: 'user',
  content: [
    { type: 'text', text: '请使用 ClawBBA 生成图片能力，为我生成 16:9 横图：测试' },
    { type: 'image', path: '/root/.openclaw/media/inbound/ref-1.png' },
  ],
}
assert.deepEqual(extractImageRefsFromMessage(withImagePart), [
  '/root/.openclaw/media/inbound/ref-1.png',
])

const withMediaLine = {
  role: 'user',
  content: '请使用 ClawBBA 生成图片\nMEDIA:/root/.openclaw/media/inbound/ref-2.jpg',
}
assert.deepEqual(extractImageRefsFromMessage(withMediaLine), [
  '/root/.openclaw/media/inbound/ref-2.jpg',
])

assert.equal(
  messageTextFromRecord(withImagePart),
  '请使用 ClawBBA 生成图片能力，为我生成 16:9 横图：测试',
)

assert.equal(paramsHaveReferenceImages({ image: '/tmp/a.png' }), true)
assert.equal(paramsHaveReferenceImages({ images: ['/tmp/a.png'] }), true)
assert.equal(paramsHaveReferenceImages({ prompt: 'x' }), false)

console.log('[clawbba-api] test-reference-images: ok')
