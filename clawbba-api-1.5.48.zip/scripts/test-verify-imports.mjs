#!/usr/bin/env node
import assert from 'node:assert/strict'
import {
  ensureRecoverFnParams,
  recoverFnHasAgentSessionKeyParam,
  recoverFnHasChatRunIdParam,
  recoverFnSignatureParams,
} from './clawbba-video-recover-patch.mjs'
import { recoverFnHasWebChatDispatchInject } from './clawbba-webchat-live-inject.mjs'

assert.equal(typeof ensureRecoverFnParams, 'function')
assert.equal(typeof recoverFnHasAgentSessionKeyParam, 'function')
assert.equal(typeof recoverFnHasChatRunIdParam, 'function')
assert.equal(typeof recoverFnSignatureParams, 'function')
assert.equal(typeof recoverFnHasWebChatDispatchInject, 'function')

const sample =
  'async function clawbbaRecoverVideoTask({ cfg, args, agentDir, authStore }) {\nawait clawbbaDispatchWebChatMediaLiveInject({'
const fixed = ensureRecoverFnParams(sample)
assert.ok(recoverFnHasAgentSessionKeyParam(fixed))
assert.ok(recoverFnHasChatRunIdParam(fixed))

console.log('test-verify-imports: ok')
