#!/usr/bin/env bash
# ClawBBA clawbba-api 一键安装 + 配置（OpenClaw 机器上运行）
# 公网: curl -fsSL https://www.clawbba.com/downloads/install-clawbba-api.sh | bash
set -euo pipefail

VERSION="${CLAWBBA_SKILL_VERSION:-1.5.48}"
INSTALL_BASE="${CLAWBBA_INSTALL_BASE:-https://www.clawbba.com/downloads}"
ZIP_NAME="clawbba-api-${VERSION}.zip"
ZIP_URL="${CLAWBBA_SKILL_ZIP_URL:-${INSTALL_BASE}/${ZIP_NAME}}"
SKILL_DIR="${OPENCLAW_SKILL_DIR:-${HOME}/.openclaw/skills/clawbba-api}"
KEY="${CLAWBBA_API_KEY:-}"

echo "══════════════════════════════════════════"
echo " ClawBBA clawbba-api ${VERSION} 一键安装"
echo "══════════════════════════════════════════"

if [[ -z "$KEY" ]]; then
  echo "" >&2
  echo "请先创建 Platform API Key：https://www.clawbba.com/agent/api-keys" >&2
  echo "" >&2
  echo "然后执行：" >&2
  echo "  export CLAWBBA_API_KEY='cbb_sk_live_你的完整密钥'" >&2
  echo "  curl -fsSL ${INSTALL_BASE}/install-clawbba-api.sh | bash" >&2
  exit 1
fi

if [[ "$KEY" != cbb_sk_live_* ]]; then
  echo "错误: CLAWBBA_API_KEY 须以 cbb_sk_live_ 开头" >&2
  exit 1
fi

for bin in node curl unzip openclaw; do
  if ! command -v "$bin" >/dev/null 2>&1; then
    echo "错误: 未找到 $bin，请先安装 OpenClaw CLI / Node.js / curl / unzip" >&2
    exit 1
  fi
done

STAGE="$(mktemp -d)"
cleanup() { rm -rf "$STAGE"; }
trap cleanup EXIT

echo "→ 下载 ${ZIP_URL} …"
curl -fsSL "$ZIP_URL" -o "${STAGE}/${ZIP_NAME}"

echo "→ 解压 …"
unzip -qo "${STAGE}/${ZIP_NAME}" -d "$STAGE/extract"
if [[ ! -f "${STAGE}/extract/SKILL.md" ]]; then
  echo "错误: zip 结构无效（根目录须含 SKILL.md）" >&2
  exit 1
fi

echo "→ 安装到 ${SKILL_DIR} …"
mkdir -p "$(dirname "$SKILL_DIR")"
rm -rf "$SKILL_DIR"
mkdir -p "$SKILL_DIR"
cp -a "${STAGE}/extract/." "$SKILL_DIR/"

export CLAWBBA_API_BASE="${CLAWBBA_API_BASE:-https://www.clawbba.com/api/v1}"
export CLAWBBA_API_KEY="$KEY"
export OPENROUTER_API_KEY="${OPENROUTER_API_KEY:-$CLAWBBA_API_KEY}"

echo "→ 校验 Key …"
"$SKILL_DIR/scripts/verify-key.sh"

echo "→ 写入 OpenClaw 配置（one-shot-setup + ClawBBA 媒体 patch）…"
"$SKILL_DIR/scripts/one-shot-setup.sh"

echo "→ 验证 ClawBBA runtime patch（未通过则自动重试 patch）…"
bash "$SKILL_DIR/scripts/ensure-openclaw-patches.sh" --install

echo "→ 验证 provider 配置 …"
node "$SKILL_DIR/scripts/verify-openclaw-runtime.mjs" || true

if [[ "${SKIP_GATEWAY_RESTART:-}" != "1" ]]; then
  echo "→ 重启 Gateway …"
  openclaw gateway restart || true
fi

echo ""
echo "✓ 安装完成"
echo "  skill: ${SKILL_DIR}"
echo "  模型:  openclaw models list | grep clawbba"
echo "  验证:  新开对话后执行 /model status（应显示 clawbba/…）"
echo "  诊断:  node ${SKILL_DIR}/scripts/verify-openclaw-runtime.mjs"
echo ""
echo "若 Gateway 由 systemd 管理，可写入 CLAWBBA_API_KEY 后 restart，例如："
echo "  sudo mkdir -p /etc/systemd/system/openclaw-gateway.service.d"
echo "  sudo tee /etc/systemd/system/openclaw-gateway.service.d/clawbba.conf <<EOF"
echo "[Service]"
echo "Environment=CLAWBBA_API_KEY=${CLAWBBA_API_KEY}"
echo "EOF"
echo "  sudo systemctl daemon-reload && openclaw gateway restart"
