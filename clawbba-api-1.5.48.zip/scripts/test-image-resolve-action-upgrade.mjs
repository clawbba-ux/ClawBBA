#!/usr/bin/env node
/** resolveAction$2 missing tasks/recover after partial image patch */
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { execSync } from 'node:child_process'
import {
  patchImageGenerateRecoverAction,
  imageResolveActionAllowsTasks,
  imageResolveActionFnBlock,
} from './clawbba-image-recover-patch.mjs'
import { patchWebChatLiveInjectHelperInToolsFile } from './clawbba-webchat-live-inject.mjs'

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'clawbba-img-resolve-'))
execSync('npm pack openclaw@2026.5.27 --silent', { cwd: tmp, stdio: 'pipe' })
execSync(`tar -xzf ${JSON.stringify(fs.readdirSync(tmp).find((n) => n.endsWith('.tgz')))}`, { cwd: tmp })
const dist = path.join(tmp, 'package', 'dist')
const toolsPath = path.join(dist, fs.readdirSync(dist).find((n) => n.startsWith('openclaw-tools-')))
const pluginsFile = fs.readdirSync(dist).find((n) => n.startsWith('server-plugins-'))
const globalSingletonFile = fs.readdirSync(dist).find((n) => n.startsWith('global-singleton-'))
const gatewayFile = fs.readdirSync(dist).find((n) => n.startsWith('gateway-request-scope-'))

assert.equal(
  patchWebChatLiveInjectHelperInToolsFile(toolsPath, pluginsFile, globalSingletonFile, gatewayFile),
  'patched',
)
assert.equal(patchImageGenerateRecoverAction(toolsPath), 'patched')

let src = fs.readFileSync(toolsPath, 'utf8')
const fnBlock = imageResolveActionFnBlock(src)
const strippedBlock = fnBlock.replace(
  /(\t\t\t"list",\n\t\t\t"recover",\n\t\t\t"tasks"\n\t\t\],)/,
  '\t\t\t"list"\n\t\t],',
)
assert.notEqual(fnBlock, strippedBlock, 'expected recover/tasks in resolveAction$2 after patch')
const fnStart = src.indexOf('function resolveAction$2(args)')
const fnEnd = src.indexOf('\nfunction ', fnStart + 1)
src = src.slice(0, fnStart) + strippedBlock + src.slice(fnEnd)
fs.writeFileSync(toolsPath, src)
assert.ok(!imageResolveActionAllowsTasks(src))

assert.equal(patchImageGenerateRecoverAction(toolsPath), 'upgraded')
assert.ok(imageResolveActionAllowsTasks(fs.readFileSync(toolsPath, 'utf8')))

console.log('test-image-resolve-action-upgrade: ok')
