#!/usr/bin/env node
/**
 * 修复 apply-openclaw-config 写入的非法字段（agents.defaults.systemPrompt → systemPromptOverride）
 */
import fs from 'fs'
import { getOpenclawJsonPath } from './openclaw-paths.mjs'

const cfgPath = getOpenclawJsonPath()
if (!fs.existsSync(cfgPath)) {
  console.error(`[clawbba-api] ✗ 未找到 ${cfgPath}`)
  process.exit(1)
}

const cfg = JSON.parse(fs.readFileSync(cfgPath, 'utf8'))
const d = cfg.agents?.defaults
if (!d || typeof d !== 'object') {
  console.error('[clawbba-api] ✗ agents.defaults 缺失')
  process.exit(1)
}

let fixed = false
if (typeof d.systemPrompt === 'string' && d.systemPrompt.trim()) {
  if (!d.systemPromptOverride?.trim()) d.systemPromptOverride = d.systemPrompt
  delete d.systemPrompt
  fixed = true
}

if (!fixed) {
  console.log('[clawbba-api] 无需修复（无 systemPrompt 字段）')
  process.exit(0)
}

const backup = `${cfgPath}.bak-schema-fix-${Date.now()}`
fs.copyFileSync(cfgPath, backup)
fs.writeFileSync(cfgPath, `${JSON.stringify(cfg, null, 2)}\n`, { mode: 0o600 })
console.log(`[clawbba-api] ✓ 已修复 systemPrompt → systemPromptOverride`)
console.log(`[clawbba-api]   backup: ${backup}`)
console.log('[clawbba-api] 请执行: openclaw config validate && openclaw gateway restart')
