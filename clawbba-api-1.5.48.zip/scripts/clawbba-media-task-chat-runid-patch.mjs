/**
 * Bind media background task delivery to the requester's chat runId (options.runId),
 * not the tool ledger runId (`tool:Image generation:…`) which breaks WebChat/WeChat routing.
 */
import fs from 'fs'

export const MEDIA_TASK_CHAT_RUNID_MARKER = '/* clawbba-media-task-chat-runid */'

const CREATE_HANDLE_NEEDLE = `\t\t\trequesterOrigin: params.requesterOrigin,
\t\t\ttaskLabel: params.prompt
\t\t};`

const CREATE_HANDLE_REPLACEMENT = `\t\t\trequesterOrigin: params.requesterOrigin,
\t\t\t${MEDIA_TASK_CHAT_RUNID_MARKER}
\t\t\trequesterChatRunId: typeof params.requesterChatRunId === "string" ? params.requesterChatRunId.trim() || void 0 : void 0,
\t\t\ttaskLabel: params.prompt
\t\t};`

const IMAGE_TASK_CALL_NEEDLE = `\t\t\tconst taskHandle = createImageGenerationTaskRun({
\t\t\t\tsessionKey: options?.agentSessionKey,
\t\t\t\trequesterOrigin: options?.requesterOrigin,
\t\t\t\tprompt,`

const IMAGE_TASK_CALL_REPLACEMENT = `\t\t\tconst taskHandle = createImageGenerationTaskRun({
\t\t\t\tsessionKey: options?.agentSessionKey,
\t\t\t\trequesterOrigin: options?.requesterOrigin,
\t\t\t\trequesterChatRunId: options?.runId,
\t\t\t\tprompt,`

const VIDEO_TASK_CALL_NEEDLE = `\t\t\tconst taskHandle = createVideoGenerationTaskRun({
\t\t\t\tsessionKey: options?.agentSessionKey,
\t\t\t\trequesterOrigin: options?.requesterOrigin,
\t\t\t\tprompt,`

const VIDEO_TASK_CALL_REPLACEMENT = `\t\t\tconst taskHandle = createVideoGenerationTaskRun({
\t\t\t\tsessionKey: options?.agentSessionKey,
\t\t\t\trequesterOrigin: options?.requesterOrigin,
\t\t\t\trequesterChatRunId: options?.runId,
\t\t\t\tprompt,`

const WRONG_CHAT_RUNID_RE = /chatRunId:\s*params\.handle\?\.runId/g
const CORRECT_CHAT_RUNID = 'chatRunId: params.handle?.requesterChatRunId'

const WRONG_AUTO_RECOVER_RUNID =
  'chatRunId: params.handle?.runId\n\t\t\t\t\t});'
const CORRECT_AUTO_RECOVER_RUNID =
  'chatRunId: params.handle?.requesterChatRunId\n\t\t\t\t\t});'

const FIND_ACTIVE_FN_OLD =
  /function clawbbaFindActiveChatRunIdForSession\(sessionKey, context, preferredRunId\) \{\s*const pref = typeof preferredRunId === "string" \? preferredRunId\.trim\(\) : "";\s*if \(!context\?\.chatAbortControllers\) return pref \|\| null;\s*if \(pref && context\.chatAbortControllers\.has\(pref\)\) return pref;\s*const sk = typeof sessionKey === "string" \? sessionKey\.trim\(\) : "";\s*let bestRunId = null;\s*let bestStartedAt = -1;\s*for \(const \[runId, active\] of context\.chatAbortControllers\) \{\s*if \(!active \|\| !sk \|\| !clawbbaSessionKeysMatch\(sk, active\.sessionKey\)\) continue;\s*const startedAt = typeof active\.startedAtMs === "number" \? active\.startedAtMs : 0;\s*if \(startedAt >= bestStartedAt\) \{\s*bestStartedAt = startedAt;\s*bestRunId = runId;\s*\}\s*\}\s*return bestRunId \|\| pref \|\| null;\s*\}/

const FIND_ACTIVE_FN_NEW = `function clawbbaFindActiveChatRunIdForSession(sessionKey, context, preferredRunId) {
\tconst pref = typeof preferredRunId === "string" ? preferredRunId.trim() : "";
\tif (!context?.chatAbortControllers) return pref || null;
\tif (pref) {
\t\tif (context.chatAbortControllers.has(pref)) return pref;
\t\treturn null;
\t}
\tconst sk = typeof sessionKey === "string" ? sessionKey.trim() : "";
\tlet bestRunId = null;
\tlet bestStartedAt = -1;
\tfor (const [runId, active] of context.chatAbortControllers) {
\t\tif (!active || !sk || !clawbbaSessionKeysMatch(sk, active.sessionKey)) continue;
\t\tconst startedAt = typeof active.startedAtMs === "number" ? active.startedAtMs : 0;
\t\tif (startedAt >= bestStartedAt) {
\t\t\tbestStartedAt = startedAt;
\t\t\tbestRunId = runId;
\t\t}
\t}
\treturn bestRunId || null;
}`

/**
 * @param {string} src
 */
export function upgradeMediaTaskChatRunIdRouting(src) {
  let next = src
  let changed = false

  if (!next.includes(MEDIA_TASK_CHAT_RUNID_MARKER) && next.includes(CREATE_HANDLE_NEEDLE)) {
    next = next.replace(CREATE_HANDLE_NEEDLE, CREATE_HANDLE_REPLACEMENT)
    changed = true
  }

  if (!next.includes('requesterChatRunId: options?.runId') && next.includes(IMAGE_TASK_CALL_NEEDLE)) {
    next = next.replace(IMAGE_TASK_CALL_NEEDLE, IMAGE_TASK_CALL_REPLACEMENT)
    changed = true
  }

  if (!next.includes('createVideoGenerationTaskRun({\n\t\t\t\tsessionKey: options?.agentSessionKey,\n\t\t\t\trequesterOrigin: options?.requesterOrigin,\n\t\t\t\trequesterChatRunId')) {
    if (next.includes(VIDEO_TASK_CALL_NEEDLE)) {
      next = next.replace(VIDEO_TASK_CALL_NEEDLE, VIDEO_TASK_CALL_REPLACEMENT)
      changed = true
    }
  }

  if (WRONG_CHAT_RUNID_RE.test(next)) {
    next = next.replace(WRONG_CHAT_RUNID_RE, CORRECT_CHAT_RUNID)
    changed = true
  }

  if (next.includes(WRONG_AUTO_RECOVER_RUNID)) {
    next = next.replace(WRONG_AUTO_RECOVER_RUNID, CORRECT_AUTO_RECOVER_RUNID)
    changed = true
  }

  if (FIND_ACTIVE_FN_OLD.test(next)) {
    next = next.replace(FIND_ACTIVE_FN_OLD, FIND_ACTIVE_FN_NEW)
    changed = true
  }

  return changed ? next : src
}

/**
 * @param {string} filePath
 * @returns {'patched'|'upgraded'|'skip'|'pattern-missing'}
 */
export function patchMediaTaskChatRunIdRouting(filePath) {
  let src = fs.readFileSync(filePath, 'utf8')
  const before = src
  src = upgradeMediaTaskChatRunIdRouting(src)

  if (!src.includes('requesterChatRunId')) {
    return 'pattern-missing'
  }

  if (src !== before) {
    fs.writeFileSync(filePath, src)
    return before.includes(MEDIA_TASK_CHAT_RUNID_MARKER) ? 'upgraded' : 'patched'
  }
  return 'skip'
}
