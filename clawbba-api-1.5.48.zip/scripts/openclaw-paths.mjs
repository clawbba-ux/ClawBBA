import fs from 'fs'
import path from 'path'
import os from 'os'

export function getOpenclawHome() {
  return (
    process.env.OPENCLAW_HOME ||
    process.env.CLAWDBOT_HOME ||
    path.join(os.homedir(), '.openclaw')
  ).replace(/\/$/, '')
}

export function getOpenclawJsonPath(openclawHome = getOpenclawHome()) {
  return path.join(openclawHome, 'openclaw.json')
}

function resolveAgentModelPath(agentDir, openclawHome = getOpenclawHome()) {
  const trimmed = String(agentDir || '').trim()
  if (!trimmed) return null
  const expanded = trimmed.startsWith('~')
    ? path.join(os.homedir(), trimmed.slice(1).replace(/^\//, ''))
    : path.resolve(trimmed)
  return path.join(expanded, 'models.json')
}

/** @param {string} [openclawHome] */
export function discoverAgentModelPaths(openclawHome = getOpenclawHome()) {
  const paths = new Set()
  const agentsRoot = path.join(openclawHome, 'agents')
  const openclawJsonPath = getOpenclawJsonPath(openclawHome)

  if (fs.existsSync(agentsRoot)) {
    for (const ent of fs.readdirSync(agentsRoot, { withFileTypes: true })) {
      if (!ent.isDirectory()) continue
      const modelPath = path.join(agentsRoot, ent.name, 'agent', 'models.json')
      if (fs.existsSync(modelPath)) paths.add(modelPath)
    }
  }

  if (fs.existsSync(openclawJsonPath)) {
    try {
      const cfg = JSON.parse(fs.readFileSync(openclawJsonPath, 'utf8'))
      const list = cfg.agents?.list
      if (Array.isArray(list)) {
        for (const agent of list) {
          if (!agent || typeof agent !== 'object') continue
          const custom = resolveAgentModelPath(agent.agentDir, openclawHome)
          if (custom && fs.existsSync(custom)) paths.add(custom)
        }
      }
    } catch {
      // ignore malformed openclaw.json
    }
  }

  return [...paths]
}
