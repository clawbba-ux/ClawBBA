#!/usr/bin/env bash
# 打包 clawbba-api 并复制到 public/downloads/（发布前在仓库根或本目录执行）
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
VERSION="$(node -e "import('${ROOT}/scripts/clawbba-openclaw-media-catalog.mjs').then(m=>console.log(m.CLAWBBA_SKILL_VERSION))")"
OUT_ZIP="$(cd "$ROOT/.." && pwd)/clawbba-api-${VERSION}.zip"
PUBLIC_DIR="$(cd "$ROOT/../../public/downloads" && pwd)"

cd "$ROOT"
rm -f "$OUT_ZIP"
zip -r "$OUT_ZIP" . \
  -x '*.DS_Store' \
  -x 'clawbba-openclaw.patch.json' \
  -x '*.tgz' \
  -x 'openclaw-*.tgz'

cp "$OUT_ZIP" "${PUBLIC_DIR}/clawbba-api-${VERSION}.zip"
echo "✓ ${PUBLIC_DIR}/clawbba-api-${VERSION}.zip ($(du -h "${PUBLIC_DIR}/clawbba-api-${VERSION}.zip" | cut -f1))"
