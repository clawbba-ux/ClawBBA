#!/usr/bin/env node
import assert from 'node:assert/strict'
import {
  CLAWBBA_IMAGE_ASYNC_MAX_WAIT_MS,
  IMAGE_ASYNC_JOB_V5_MARKER,
  upgradeAsyncPollToV5,
} from './clawbba-image-provider-patch.mjs'

const v4WithCap = `try {
/* clawbba-image-async-job-poll */
if (status === 202 && payload?.job_id) {
  const jobId = String(payload.job_id);
  /* clawbba-image-async-job-poll-v4 */
  const pollUrl = "https://www.clawbba.com/api/v1/images/generations/x";
  const pollStarted = Date.now();
  const optionalCapMs = typeof req.timeoutMs === "number" && req.timeoutMs > 0 ? req.timeoutMs : null;
  while (true) {
    if (optionalCapMs != null && Date.now() - pollStarted > optionalCapMs) {
      throw new Error(\`ClawBBA image job wait limit \${optionalCapMs}ms (job_id=\${jobId}). Job may still complete — poll GET \${pollUrl}\`);
    }
  }
}
} finally {
  await release();
}`

const out = upgradeAsyncPollToV5(v4WithCap)
assert.ok(out.includes(IMAGE_ASYNC_JOB_V5_MARKER), 'v5 marker')
assert.ok(out.includes('await release();'), 'release before poll')
assert.ok(!out.includes('optionalCapMs'), 'no req.timeoutMs cap')
assert.ok(out.includes(String(CLAWBBA_IMAGE_ASYNC_MAX_WAIT_MS)), '15min max wait')
assert.ok(out.includes('try { await release(); } catch (_) {}'), 'safe finally release')
console.log('test-image-async-poll-v5: ok')
