#!/usr/bin/env node
/**
 * 1.5.16 → 1.5.19：已有 inject helper 但无 broadcast reload 时必须能升级。
 */
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { execSync } from 'node:child_process'
import {
  buildWebChatLiveInjectHelperBlock,
  WEBCHAT_LIVE_INJECT_HELPER_MARKER,
} from './clawbba-webchat-live-inject.mjs'
import { patchWebChatLiveInjectHelperInToolsFile } from './clawbba-webchat-live-inject.mjs'

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'clawbba-inject-up-'))
execSync('npm pack openclaw@2026.5.27 --silent', { cwd: tmp, stdio: 'pipe' })
const tgz = fs.readdirSync(tmp).find((n) => n.endsWith('.tgz'))
execSync(`tar -xzf ${JSON.stringify(tgz)}`, { cwd: tmp })
const dist = path.join(tmp, 'package', 'dist')
const toolsFile = fs.readdirSync(dist).find((n) => n.startsWith('openclaw-tools-'))
const pluginsFile = fs.readdirSync(dist).find((n) => n.startsWith('server-plugins-'))
const gatewayFile = fs.readdirSync(dist).find((n) => n.startsWith('gateway-request-scope-'))
const globalSingletonFile = fs.readdirSync(dist).find((n) => n.startsWith('global-singleton-'))
const toolsPath = path.join(dist, toolsFile)

const legacyBlock = buildWebChatLiveInjectHelperBlock(pluginsFile, globalSingletonFile, gatewayFile)
  .replace(/clawbbaBroadcastWebChatSessionReload[\s\S]*?^async function clawbbaDispatchWebChatMediaLiveInject/m, 'async function clawbbaDispatchWebChatMediaLiveInject')
  .replace('const injectResult = await dispatchGatewayMethodInProcess', 'await dispatchGatewayMethodInProcess')
  .replace(/await clawbbaBroadcastWebChatSessionReload\([\s\S]*?\);/, '')

let src = fs.readFileSync(toolsPath, 'utf8')
const anchor = src.includes('/* clawbba-video-recover */')
  ? '/* clawbba-video-recover */'
  : 'async function executeVideoGenerationJob(params) {'
src = src.replace(anchor, `${legacyBlock}\n${anchor}`)
fs.writeFileSync(toolsPath, src)

assert.ok(fs.readFileSync(toolsPath, 'utf8').includes(WEBCHAT_LIVE_INJECT_HELPER_MARKER))
assert.ok(!fs.readFileSync(toolsPath, 'utf8').includes('clawbbaBroadcastWebChatSessionReload'))

assert.equal(
  patchWebChatLiveInjectHelperInToolsFile(toolsPath, pluginsFile, globalSingletonFile, gatewayFile),
  'patched',
)
const upgraded = fs.readFileSync(toolsPath, 'utf8')
assert.ok(upgraded.includes('clawbbaBroadcastWebChatSessionReload'))
assert.ok(upgraded.includes('clawbbaResolveGatewayBroadcastContext'))
assert.equal(
  patchWebChatLiveInjectHelperInToolsFile(toolsPath, pluginsFile, globalSingletonFile, gatewayFile),
  'skip',
)

console.log('test-webchat-inject-upgrade: ok')
