#!/usr/bin/env node
/**
 * Legacy recover block (__clawbbaSk.includes("webchat")) must upgrade to dispatch inject.
 */
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { execSync } from 'node:child_process'
import { patchVideoGenerateRecoverAction } from './clawbba-video-recover-patch.mjs'
import { patchWebChatLiveInjectHelperInToolsFile } from './clawbba-webchat-live-inject.mjs'
import { recoverFnHasWebChatDispatchInject } from './clawbba-webchat-live-inject.mjs'

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'clawbba-recover-legacy-'))
execSync('npm pack openclaw@2026.5.27 --silent', { cwd: tmp, stdio: 'pipe' })
const tgz = fs.readdirSync(tmp).find((n) => n.endsWith('.tgz'))
execSync(`tar -xzf ${JSON.stringify(tgz)}`, { cwd: tmp })
const dist = path.join(tmp, 'package', 'dist')
const toolsFile = fs.readdirSync(dist).find((n) => n.startsWith('openclaw-tools-'))
const pluginsFile = fs.readdirSync(dist).find((n) => n.startsWith('server-plugins-'))
const gatewayFile = fs.readdirSync(dist).find((n) => n.startsWith('gateway-request-scope-'))
const globalSingletonFile = fs.readdirSync(dist).find((n) => n.startsWith('global-singleton-'))
const toolsPath = path.join(dist, toolsFile)

assert.equal(
  patchWebChatLiveInjectHelperInToolsFile(toolsPath, pluginsFile, globalSingletonFile, gatewayFile),
  'patched',
)
assert.equal(patchVideoGenerateRecoverAction(toolsPath), 'patched')

const legacyBlock = `\t/* clawbba-video-recover-webchat-live */
\ttry {
\t\tconst __clawbbaSk = typeof agentSessionKey === "string" ? agentSessionKey.trim() : "";
\t\tif (__clawbbaSk && saved?.path && (__clawbbaSk.includes("webchat") || __clawbbaSk.includes(":dashboard:"))) {
\t\t\tawait dispatchGatewayMethodInProcess("chat.inject", { sessionKey: __clawbbaSk, message: lines.join("\\n"), label: "ClawBBA video" }, { timeoutMs: 3e4 });
\t\t}
\t} catch (_) {}`

let src = fs.readFileSync(toolsPath, 'utf8')
assert.ok(recoverFnHasWebChatDispatchInject(src))
const marker = '/* clawbba-video-recover-webchat-live */'
const markerIdx = src.indexOf(marker)
assert.ok(markerIdx >= 0)
const dispatchIdx = src.indexOf('await clawbbaDispatchWebChatMediaLiveInject({', markerIdx)
assert.ok(dispatchIdx > markerIdx)
const legacyStart = src.indexOf(marker, markerIdx)
const legacyEnd = src.indexOf('\n\treturn {', dispatchIdx)
assert.ok(legacyEnd > legacyStart)
src = `${src.slice(0, legacyStart)}${legacyBlock}\n${src.slice(legacyEnd)}`
fs.writeFileSync(toolsPath, src)
assert.ok(!recoverFnHasWebChatDispatchInject(fs.readFileSync(toolsPath, 'utf8')))

assert.equal(patchVideoGenerateRecoverAction(toolsPath), 'patched')
const upgraded = fs.readFileSync(toolsPath, 'utf8')
assert.ok(recoverFnHasWebChatDispatchInject(upgraded))
assert.ok(!upgraded.includes('__clawbbaSk.includes("webchat")'))
assert.ok(upgraded.includes('chatRunId,'))

console.log('test-video-recover-legacy-upgrade: ok')
