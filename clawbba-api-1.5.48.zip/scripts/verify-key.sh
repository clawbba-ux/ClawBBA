#!/usr/bin/env bash
# 校验 ClawBBA Platform API Key（不写 OpenClaw 配置）
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
API_BASE="${CLAWBBA_API_BASE:-https://www.clawbba.com/api/v1}"
API_BASE="${API_BASE%/}"
KEY="${CLAWBBA_API_KEY:-}"

if [[ -z "$KEY" ]]; then
  echo "错误: 请设置 CLAWBBA_API_KEY" >&2
  echo "示例: export CLAWBBA_API_KEY='cbb_sk_live_…'" >&2
  exit 1
fi

if [[ "$KEY" != cbb_sk_live_* ]]; then
  echo "错误: 请使用 Platform API Key（cbb_sk_live_ 前缀）" >&2
  echo "创建地址: https://www.clawbba.com/agent/api-keys" >&2
  exit 1
fi

echo "→ 校验余额 ${API_BASE}/account/balance"
BAL=$(curl -fsS "${API_BASE}/account/balance" -H "Authorization: Bearer ${KEY}" -H "Accept: application/json") || {
  echo "错误: 无法连接 ClawBBA API 或 Key 无效" >&2
  exit 1
}

echo "$BAL" | node -e "
let d='';process.stdin.on('data',c=>d+=c);process.stdin.on('end',()=>{
  try {
    const j=JSON.parse(d);
    const b=j.balance_usd;
    console.log('✓ Key 有效，余额 USD:', b);
    if (b!=null && Number(b)<=0) {
      console.warn('⚠ 余额为 0，请先充值: https://www.clawbba.com/product/CDKEY');
    }
  } catch(e) { console.log(d); }
});
"

echo "→ 拉取模型 ${API_BASE}/models"
MODELS=$(curl -fsS "${API_BASE}/models" -H "Authorization: Bearer ${KEY}" -H "Accept: application/json")
echo "$MODELS" | node -e "
let d='';process.stdin.on('data',c=>d+=c);process.stdin.on('end',()=>{
  const j=JSON.parse(d);
  const n=(j.data||[]).length;
  console.log('✓ 可用模型数量:', n);
});
"

echo "完成。运行 ./scripts/setup.sh 写入 OpenClaw 配置。"
