#!/usr/bin/env node
/**
 * Legacy body references agentSessionKey but function signature omits it.
 */
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { execSync } from 'node:child_process'
import {
  ensureRecoverFnParams,
  patchVideoGenerateRecoverAction,
  recoverFnHasAgentSessionKeyParam,
} from './clawbba-video-recover-patch.mjs'
import { patchWebChatLiveInjectHelperInToolsFile } from './clawbba-webchat-live-inject.mjs'

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'clawbba-recover-sig-'))
execSync('npm pack openclaw@2026.5.27 --silent', { cwd: tmp, stdio: 'pipe' })
const tgz = fs.readdirSync(tmp).find((n) => n.endsWith('.tgz'))
execSync(`tar -xzf ${JSON.stringify(tgz)}`, { cwd: tmp })
const dist = path.join(tmp, 'package', 'dist')
const toolsPath = path.join(
  dist,
  fs.readdirSync(dist).find((n) => n.startsWith('openclaw-tools-')),
)

patchWebChatLiveInjectHelperInToolsFile(
  toolsPath,
  fs.readdirSync(dist).find((n) => n.startsWith('server-plugins-')),
  fs.readdirSync(dist).find((n) => n.startsWith('global-singleton-')),
  fs.readdirSync(dist).find((n) => n.startsWith('gateway-request-scope-')),
)
patchVideoGenerateRecoverAction(toolsPath)

let src = fs.readFileSync(toolsPath, 'utf8')
src = src.replace(
  'async function clawbbaRecoverVideoTask({ cfg, args, agentDir, authStore, agentSessionKey, chatRunId }) {',
  'async function clawbbaRecoverVideoTask({ cfg, args, agentDir, authStore }) {',
)
fs.writeFileSync(toolsPath, src)
assert.ok(!recoverFnHasAgentSessionKeyParam(fs.readFileSync(toolsPath, 'utf8')))

assert.equal(patchVideoGenerateRecoverAction(toolsPath), 'patched')
const fixed = fs.readFileSync(toolsPath, 'utf8')
assert.ok(recoverFnHasAgentSessionKeyParam(fixed))
assert.ok(ensureRecoverFnParams(fixed) === fixed)

console.log('test-video-recover-fn-signature: ok')
