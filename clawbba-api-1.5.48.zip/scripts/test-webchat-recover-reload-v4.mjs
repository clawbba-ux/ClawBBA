#!/usr/bin/env node
/** v1.5.47: recover reload v4 — chat final carries MEDIA, always session.message */
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { execSync } from 'node:child_process'
import {
  patchWebChatLiveInjectHelperInToolsFile,
  upgradeWebChatRecoverReloadV4,
  WEBCHAT_RECOVER_RELOAD_V3_MARKER,
} from './clawbba-webchat-live-inject.mjs'

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'clawbba-reload-v4-'))
execSync('npm pack openclaw@2026.5.27 --silent', { cwd: tmp, stdio: 'pipe' })
execSync(`tar -xzf ${JSON.stringify(fs.readdirSync(tmp).find((n) => n.endsWith('.tgz')))}`, { cwd: tmp })
const dist = path.join(tmp, 'package', 'dist')
const toolsPath = path.join(dist, fs.readdirSync(dist).find((n) => n.startsWith('openclaw-tools-')))
const pluginsFile = fs.readdirSync(dist).find((n) => n.startsWith('server-plugins-'))
const globalSingletonFile = fs.readdirSync(dist).find((n) => n.startsWith('global-singleton-'))
const gatewayFile = fs.readdirSync(dist).find((n) => n.startsWith('gateway-request-scope-'))

assert.equal(
  patchWebChatLiveInjectHelperInToolsFile(toolsPath, pluginsFile, globalSingletonFile, gatewayFile),
  'patched',
)
let src = fs.readFileSync(toolsPath, 'utf8')
assert.ok(src.includes('webchat-recover-reload-v4'))
assert.ok(src.includes('message: mediaMessage ? { role: "assistant"'))

// Revert v4 only (keep v3) — simulates 1.5.46 empty chat final bug.
src = src.replace(`\t/* clawbba-webchat-recover-reload-v4 */\n`, '')
src = src.replace(
  `\t\t\tmessage: mediaMessage ? { role: "assistant", content: [{ type: "text", text: mediaMessage }] } : { role: "assistant", content: [] }`,
  `\t\t\tmessage: { role: "assistant", content: [] }`,
)
src = src.replace('if (mediaMessage) {', 'if (mediaMessage && !activeRunId) {')
fs.writeFileSync(toolsPath, src)
assert.ok(!src.includes('webchat-recover-reload-v4'))
assert.ok(src.includes(WEBCHAT_RECOVER_RELOAD_V3_MARKER))

assert.equal(
  patchWebChatLiveInjectHelperInToolsFile(toolsPath, pluginsFile, globalSingletonFile, gatewayFile),
  'upgraded-recover-reload-v4',
)
const upgraded = fs.readFileSync(toolsPath, 'utf8')
assert.ok(upgraded.includes('webchat-recover-reload-v4'))
assert.equal(upgradeWebChatRecoverReloadV4(upgraded), upgraded)

console.log('test-webchat-recover-reload-v4: ok')
