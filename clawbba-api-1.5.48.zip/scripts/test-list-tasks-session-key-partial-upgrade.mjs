#!/usr/bin/env node
/**
 * 1.5.41 partial upgrade: direct reply body references agentSessionKey but signature omits it.
 */
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { execSync } from 'node:child_process'
import {
  ensureListTasksSessionKeyParams,
  listTasksFnHasSessionKeyParam,
  patchImageGenerateRecoverAction,
  upgradeListImageTasksDirectReply,
} from './clawbba-image-recover-patch.mjs'
import {
  patchVideoGenerateRecoverAction,
  upgradeListVideoTasksDirectReply,
} from './clawbba-video-recover-patch.mjs'
import { patchWebChatLiveInjectHelperInToolsFile } from './clawbba-webchat-live-inject.mjs'
import { patchReadOnlyToolTextReplyDist } from './clawbba-readonly-tool-reply-patch.mjs'

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'clawbba-list-tasks-sig-'))
execSync('npm pack openclaw@2026.5.27 --silent', { cwd: tmp, stdio: 'pipe' })
const tgz = fs.readdirSync(tmp).find((n) => n.endsWith('.tgz'))
execSync(`tar -xzf ${JSON.stringify(tgz)}`, { cwd: tmp })
const dist = path.join(tmp, 'package', 'dist')
const toolsFile = fs.readdirSync(dist).find((n) => n.startsWith('openclaw-tools-'))
const toolsPath = path.join(dist, toolsFile)
const pluginsFile = fs.readdirSync(dist).find((n) => n.startsWith('server-plugins-'))
const globalSingletonFile = fs.readdirSync(dist).find((n) => n.startsWith('global-singleton-'))
const gatewayFile = fs.readdirSync(dist).find((n) => n.startsWith('gateway-request-scope-'))

assert.equal(
  patchWebChatLiveInjectHelperInToolsFile(toolsPath, pluginsFile, globalSingletonFile, gatewayFile),
  'patched',
)
assert.equal(patchVideoGenerateRecoverAction(toolsPath), 'patched')
assert.equal(patchImageGenerateRecoverAction(toolsPath), 'patched')
patchReadOnlyToolTextReplyDist(dist, (d, prefix) => fs.readdirSync(d).find((n) => n.startsWith(prefix)))

function simulatePartialListTasksUpgrade(src, fnName) {
  return src.replace(
    `async function ${fnName}({ cfg, agentDir, authStore, args, agentSessionKey, chatRunId }) {`,
    `async function ${fnName}({ cfg, agentDir, authStore, args }) {`,
  )
}

let src = fs.readFileSync(toolsPath, 'utf8')
src = simulatePartialListTasksUpgrade(src, 'clawbbaListVideoTasks')
src = simulatePartialListTasksUpgrade(src, 'clawbbaListImageTasks')
fs.writeFileSync(toolsPath, src)
assert.ok(!listTasksFnHasSessionKeyParam(src, 'video'))
assert.ok(!listTasksFnHasSessionKeyParam(src, 'image'))
assert.ok(src.includes('if (agentSessionKey && typeof clawbbaDispatchReadOnlyToolTextReply'))

assert.equal(patchVideoGenerateRecoverAction(toolsPath), 'patched')
assert.equal(patchImageGenerateRecoverAction(toolsPath), 'upgraded')
const fixed = fs.readFileSync(toolsPath, 'utf8')
assert.ok(listTasksFnHasSessionKeyParam(fixed, 'video'))
assert.ok(listTasksFnHasSessionKeyParam(fixed, 'image'))

let unit = simulatePartialListTasksUpgrade(fixed, 'clawbbaListVideoTasks')
unit = upgradeListVideoTasksDirectReply(unit)
assert.ok(listTasksFnHasSessionKeyParam(unit, 'video'))
unit = simulatePartialListTasksUpgrade(unit, 'clawbbaListImageTasks')
unit = upgradeListImageTasksDirectReply(unit)
assert.ok(listTasksFnHasSessionKeyParam(unit, 'image'))
assert.equal(ensureListTasksSessionKeyParams(unit, 'image'), unit)

console.log('test-list-tasks-session-key-partial-upgrade: ok')
