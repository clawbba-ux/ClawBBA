#!/usr/bin/env node
/**
 * 1.5.42 partial upgrade: responseText + direct reply reference taskListText but const missing.
 */
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { execSync } from 'node:child_process'
import {
  listTasksBlockIsHealthy,
  patchImageGenerateRecoverAction,
  imageResolveActionAllowsTasks,
} from './clawbba-image-recover-patch.mjs'
import { patchVideoGenerateRecoverAction } from './clawbba-video-recover-patch.mjs'
import { patchWebChatLiveInjectHelperInToolsFile } from './clawbba-webchat-live-inject.mjs'
import { patchReadOnlyToolTextReplyDist } from './clawbba-readonly-tool-reply-patch.mjs'

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'clawbba-tasklist-text-'))
execSync('npm pack openclaw@2026.5.27 --silent', { cwd: tmp, stdio: 'pipe' })
const tgz = fs.readdirSync(tmp).find((n) => n.endsWith('.tgz'))
execSync(`tar -xzf ${JSON.stringify(tgz)}`, { cwd: tmp })
const dist = path.join(tmp, 'package', 'dist')
const toolsPath = path.join(dist, fs.readdirSync(dist).find((n) => n.startsWith('openclaw-tools-')))
const pluginsFile = fs.readdirSync(dist).find((n) => n.startsWith('server-plugins-'))
const globalSingletonFile = fs.readdirSync(dist).find((n) => n.startsWith('global-singleton-'))
const gatewayFile = fs.readdirSync(dist).find((n) => n.startsWith('gateway-request-scope-'))

assert.equal(
  patchWebChatLiveInjectHelperInToolsFile(toolsPath, pluginsFile, globalSingletonFile, gatewayFile),
  'patched',
)
assert.equal(patchVideoGenerateRecoverAction(toolsPath), 'patched')
assert.equal(patchImageGenerateRecoverAction(toolsPath), 'patched')
patchReadOnlyToolTextReplyDist(dist, (d, prefix) => fs.readdirSync(d).find((n) => n.startsWith(prefix)))

function breakListTasksVar(src, fnName) {
  return src.replace(
    new RegExp(`(async function ${fnName}[\\s\\S]*?)const taskListText = lines\\.join`, 'm'),
    '$1/* broken */ const text = lines.join',
  )
}

let src = fs.readFileSync(toolsPath, 'utf8')
src = breakListTasksVar(src, 'clawbbaListVideoTasks')
src = breakListTasksVar(src, 'clawbbaListImageTasks')
fs.writeFileSync(toolsPath, src)
assert.ok(!listTasksBlockIsHealthy(src, 'video'))
assert.ok(!listTasksBlockIsHealthy(src, 'image'))

assert.equal(patchVideoGenerateRecoverAction(toolsPath), 'patched')
assert.equal(patchImageGenerateRecoverAction(toolsPath), 'upgraded')
const fixed = fs.readFileSync(toolsPath, 'utf8')
assert.ok(listTasksBlockIsHealthy(fixed, 'video'))
assert.ok(listTasksBlockIsHealthy(fixed, 'image'))
assert.ok(imageResolveActionAllowsTasks(fixed))

console.log('test-tasklist-text-broken-upgrade: ok')
