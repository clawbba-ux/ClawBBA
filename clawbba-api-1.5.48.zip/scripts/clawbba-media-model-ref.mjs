/**
 * ClawBBA 媒体模型 ID 规范（唯一来源）
 *
 * 用户话术 / ClawBBA 平台 id：  black-forest-labs/flux.2-pro
 * OpenClaw 生图/生视频 tool：    openrouter/black-forest-labs/flux.2-pro
 * 文本对话 /model：              clawbba/<text-model-id>
 *
 * @see references/media-model-ref.md
 */

/** ClawBBA Platform API 模型 id（vendor/model，无 provider 前缀） */
export const PLATFORM_MODEL_ID_RE = /^[a-z0-9][a-z0-9._-]*\/[a-z0-9][a-z0-9._-]+$/i

/** OpenClaw 已注册的生图/生视频 capability provider（不是 OpenRouter 平台 vendor 名） */
export const OPENCLAW_MEDIA_CAPABILITY_PROVIDERS = new Set([
  'openrouter',
  'openai',
  'fal',
  'minimax',
  'xai',
  'deepinfra',
  'comfy',
])

export const USER_MEDIA_MODEL_DISPLAY_FN = 'clawbbaFormatUserMediaModel'
export const USER_MEDIA_MODEL_DISPLAY_MARKER = '/* clawbba-user-media-model-display */'

/** 用户可见：openrouter/vendor/model → ClawBBA/vendor/model（内部仍用 openrouter/） */
export function formatClawbbaUserMediaModelRef(provider, model) {
  const p = String(provider || '').trim().toLowerCase()
  const m = String(model || '').trim()
  if (p === 'openrouter' || p === 'clawbba') {
    const platformId = stripPlatformModelId(m)
    return platformId ? `ClawBBA/${platformId}` : 'ClawBBA'
  }
  if (!m) return String(provider || 'ClawBBA')
  return `${provider}/${m}`
}

/** 注入 OpenClaw dist：Child result / chat.inject 里的 Generated … with … 文案 */
export function buildClawbbaUserMediaModelDisplayFnBlock() {
  return `${USER_MEDIA_MODEL_DISPLAY_MARKER}
function ${USER_MEDIA_MODEL_DISPLAY_FN}(provider, model) {
\tconst p = String(provider || "").trim().toLowerCase();
\tconst m = String(model || "").trim();
\tif (p === "openrouter" || p === "clawbba") {
\t\tconst id = m.replace(/^(clawbba|openrouter)\\//i, "");
\t\treturn id ? \`ClawBBA/\${id}\` : "ClawBBA";
\t}
\tif (!m) return String(provider || "ClawBBA");
\treturn \`\${provider}/\${m}\`;
}`
}

/** 去掉 clawbba/ 或 openrouter/ 前缀，得到平台 id */
export function stripPlatformModelId(raw) {
  return String(raw || '')
    .trim()
    .replace(/^(clawbba|openrouter)\//i, '')
}

/** 是否为合法 ClawBBA 平台模型 id（vendor/model） */
export function isPlatformModelId(raw) {
  const id = stripPlatformModelId(raw)
  return Boolean(id && PLATFORM_MODEL_ID_RE.test(id))
}

/**
 * 任意用户/Agent 写法 → OpenClaw 生图/生视频 tool.model 唯一合法值
 * @returns {string|null} openrouter/<platform-id>
 */
export function toOpenClawMediaModelRef(raw) {
  const id = stripPlatformModelId(raw)
  if (!id || !PLATFORM_MODEL_ID_RE.test(id)) return null
  return `openrouter/${id}`
}

/** 写入 Agent systemPrompt 的模型切换规范（简短版） */
export const CLAWBBA_MEDIA_MODEL_CANON = [
  '=== Media model ID (MANDATORY) ===',
  'User writes ClawBBA platform id in 模型 … clause, e.g. black-forest-labs/flux.2-pro or google/veo-3.1-fast.',
  'You MUST pass image_generate.model / video_generate.model as openrouter/<same-platform-id>, e.g. openrouter/black-forest-labs/flux.2-pro.',
  'Mapping: strip clawbba/ or openrouter/ if present, then always prefix openrouter/ for image_generate and video_generate.',
  'NEVER clawbba/ on image/video tools (No image-generation provider registered for clawbba).',
  'NEVER pass bare vendor/model without openrouter/ prefix unless runtime patch is verified — prefer openrouter/ always.',
  'Text chat ONLY uses /model clawbba/<id>. Image/video NEVER use /model.',
  'When user did not specify 模型: omit model param → OpenClaw uses imageGenerationModel.primary / videoGenerationModel.primary (already openrouter/… from setup).',
  'Full table: references/media-model-ref.md',
].join('\n')

/** 注入 OpenClaw dist 的 inline 归一化函数（image_generate / video_generate） */
export function buildOpenClawNormalizeModelFnBlock() {
  return `\t\t\tconst clawbbaToOpenClawMediaModel = (raw) => {
\t\t\t\tconst id = String(raw || "").trim().replace(/^(clawbba|openrouter)\\//i, "");
\t\t\t\tif (!id || !/^[a-z0-9][a-z0-9._-]*\\/[a-z0-9][a-z0-9._-]+$/i.test(id)) return null;
\t\t\t\treturn \`openrouter/\${id}\`;
\t\t\t};`
}

/** parseGenerationModelRef patch：未知 vendor → openrouter/<vendor>/<model> */
export function buildModelRefVendorRoutingBlock() {
  const providers = [...OPENCLAW_MEDIA_CAPABILITY_PROVIDERS].map((p) => `"${p}"`).join(', ')
  return `\t/* clawbba-openrouter-vendor-id */
\tconst __clawbbaImgProviders = new Set([${providers}]);
\tif (!__clawbbaImgProviders.has(provider)) return { provider: "openrouter", model: \`\${provider}/\${model}\` };`
}
