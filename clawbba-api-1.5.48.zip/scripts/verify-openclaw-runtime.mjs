#!/usr/bin/env node
/**
 * 验证 OpenClaw 运行时 clawbba provider 配置（baseUrl / apiKey / headers）。
 * setup.sh 在 sync models.json 之后调用。
 */
import fs from 'fs'
import { CLAWBBA_OPENCLAW_HEADERS } from './openclaw-provider-block.mjs'
import {
  discoverAgentModelPaths,
  getOpenclawHome,
  getOpenclawJsonPath,
} from './openclaw-paths.mjs'

const API_BASE = (process.env.CLAWBBA_API_BASE || 'https://www.clawbba.com/api/v1').replace(
  /\/$/,
  '',
)
const API_KEY = String(process.env.CLAWBBA_API_KEY || '').trim()
const openclawHome = getOpenclawHome()

function fail(msg) {
  process.stderr.write(`[clawbba-api] ✗ ${msg}\n`)
  process.exit(1)
}

function warn(msg) {
  process.stderr.write(`[clawbba-api] ⚠ ${msg}\n`)
}

function ok(msg) {
  process.stderr.write(`[clawbba-api] ✓ ${msg}\n`)
}

function checkProvider(name, provider) {
  if (!provider || typeof provider !== 'object') {
    fail(`${name}: provider 块缺失`)
  }
  const baseUrl = String(provider.baseUrl || '').replace(/\/$/, '')
  if (baseUrl !== API_BASE) {
    fail(
      `${name}: baseUrl 应为 ${API_BASE}，当前为 ${baseUrl || '(空)'}。OpenClaw 可能请求错误地址并出现 403 Your request was blocked`,
    )
  }
  const key = String(provider.apiKey || '').trim()
  if (key.startsWith('${') && key.endsWith('}')) {
    fail(
      `${name}: apiKey 仍是占位符 ${key}。请 export CLAWBBA_API_KEY 后重跑 setup.sh --yes，或 node scripts/fix-provider-config.mjs`,
    )
  }
  if (!key.startsWith('cbb_sk_live_')) {
    fail(`${name}: apiKey 格式无效（须 cbb_sk_live_ 开头）`)
  }
  const ua = provider.headers?.['User-Agent'] || provider.headers?.['user-agent']
  if (!ua) {
    fail(
      `${name}: 缺少 headers.User-Agent。OpenClaw WebChat 常见 403 Your request was blocked；请重跑 setup 或 fix-provider-config.mjs`,
    )
  }
  ok(`${name}: baseUrl + apiKey + User-Agent 正常`)
}

async function smokeChat(apiKey) {
  const res = await fetch(`${API_BASE}/chat/completions`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
      Accept: 'application/json',
      ...CLAWBBA_OPENCLAW_HEADERS,
    },
    body: JSON.stringify({
      model: 'google/gemini-2.0-flash-001',
      messages: [{ role: 'user', content: 'ping' }],
      max_tokens: 8,
    }),
  })
  const text = await res.text()
  if (res.ok) {
    ok(`POST /chat/completions → HTTP ${res.status}`)
    return
  }
  let body
  try {
    body = text ? JSON.parse(text) : {}
  } catch {
    body = { raw: text.slice(0, 120) }
  }
  if (String(body.raw || body.message || '').includes('Your request was blocked')) {
    fail('POST /chat/completions 被 CDN/WAF 拦截（403 blocked）。请检查 headers.User-Agent')
  }
  fail(
    `POST /chat/completions → HTTP ${res.status}: ${body.error || body.message || text.slice(0, 120)}`,
  )
}

const modelPaths = discoverAgentModelPaths(openclawHome)
if (!modelPaths.length) {
  warn(`未发现 agent models.json，跳过本地 provider 检查`)
} else {
  for (const modelPath of modelPaths) {
    const rel = modelPath.startsWith(openclawHome)
      ? modelPath.slice(openclawHome.length + 1)
      : modelPath
    const agentModels = JSON.parse(fs.readFileSync(modelPath, 'utf8'))
    checkProvider(`${rel} → clawbba`, agentModels.providers?.clawbba)
    if (agentModels.providers?.openrouter) {
      checkProvider(`${rel} → ClawBBA 媒体`, agentModels.providers.openrouter)
    }
  }
}

const openclawJsonPath = getOpenclawJsonPath(openclawHome)
if (fs.existsSync(openclawJsonPath)) {
  const cfg = JSON.parse(fs.readFileSync(openclawJsonPath, 'utf8'))
  checkProvider('openclaw.json → clawbba', cfg.models?.providers?.clawbba)
  const envKey = String(cfg.env?.CLAWBBA_API_KEY || '').trim()
  if (envKey.startsWith('${')) {
    fail('openclaw.json env.CLAWBBA_API_KEY 仍为占位符，请重跑 setup 或 fix-provider-config.mjs')
  }
  if (!envKey.startsWith('cbb_sk_live_')) {
    fail('openclaw.json env.CLAWBBA_API_KEY 无效')
  }
  ok('openclaw.json env 已写入真实 Key')

  const imgPrimary = String(cfg.agents?.defaults?.imageGenerationModel?.primary || '').trim()
  const vidPrimary = String(cfg.agents?.defaults?.videoGenerationModel?.primary || '').trim()
  if (imgPrimary.startsWith('clawbba/')) {
    fail(
      `imageGenerationModel.primary 不能为 ${imgPrimary}。须为 ClawBBA 默认生图模型（setup 写入）或重跑 setup.sh；文本对话仅用 clawbba/`,
    )
  }
  if (vidPrimary.startsWith('clawbba/')) {
    fail(
      `videoGenerationModel.primary 不能为 ${vidPrimary}。须为 ClawBBA 默认生视频模型（setup 写入）或重跑 setup.sh`,
    )
  }
  if (imgPrimary) ok(`imageGenerationModel.primary = ${imgPrimary}`)
  if (vidPrimary) ok(`videoGenerationModel.primary = ${vidPrimary}`)

  const visionPrimary = String(cfg.agents?.defaults?.imageModel?.primary || '').trim()
  if (visionPrimary.startsWith('openrouter/')) {
    fail(
      `imageModel.primary 不能为 ${visionPrimary}（ClawBBA 生图路由）。聊天看图须 clawbba/<vision-文本模型>；请重跑 setup.sh 或 fix-openclaw-vision-config.mjs`,
    )
  }
  if (visionPrimary && /flux\.|seedream|gemini-.*-image|dall-e/i.test(visionPrimary)) {
    fail(`imageModel.primary 误为生图模型: ${visionPrimary}`)
  }
  if (visionPrimary) ok(`imageModel.primary = ${visionPrimary}`)

  const chatPrimary = String(cfg.agents?.defaults?.model?.primary || '').trim()
  const clawbbaModels = cfg.models?.providers?.clawbba?.models
  if (chatPrimary.startsWith('clawbba/') && Array.isArray(clawbbaModels)) {
    const mid = chatPrimary.slice('clawbba/'.length)
    const def = clawbbaModels.find((m) => String(m?.id || '').trim() === mid)
    if (def && Array.isArray(def.input) && !def.input.includes('image')) {
      warn(
        `当前文本模型 ${chatPrimary} 在 provider 中未标记 image input；上传图可能被 offload。请重跑 setup.sh 或 fix-openclaw-provider-schema.mjs`,
      )
    }
  }
}

const keyForSmoke = API_KEY
if (!keyForSmoke.startsWith('cbb_sk_live_')) {
  warn('未设置 CLAWBBA_API_KEY，跳过在线 smoke test')
  process.exit(0)
}

await smokeChat(keyForSmoke)
