#!/usr/bin/env node
import assert from 'node:assert/strict'
import {
  VIDEO_IN_PROGRESS_STATUS_MARKER,
  upgradeVideoInProgressStatus,
} from './clawbba-video-provider-patch.mjs'

const sample = `
const OPENROUTER_VIDEO_MALFORMED_RESPONSE = "OpenRouter video generation response malformed";
async function pollOpenRouterVideo(params) {
  const status = normalizeOptionalString(payload.status);
  if (!status || ![
    "queued",
    "pending",
    "processing",
    "running",
    "completed"
  ].includes(status) && !isTerminalFailure(status)) throw new Error(OPENROUTER_VIDEO_MALFORMED_RESPONSE);
}
async function generateVideo(req) {
  if (submittedStatus && ![
    "queued",
    "pending",
    "processing",
    "running",
    "completed"
  ].includes(submittedStatus) && !isTerminalFailure(submittedStatus)) throw new Error(OPENROUTER_VIDEO_MALFORMED_RESPONSE);
}
`

const out = upgradeVideoInProgressStatus(sample)
assert.ok(out.includes(VIDEO_IN_PROGRESS_STATUS_MARKER), 'marker')
assert.equal((out.match(/"in_progress"/g) || []).length, 2, 'both status lists patched')
assert.ok(!out.includes('"running",\n\t\t\t"completed"'), 'running no longer adjacent to completed')

const again = upgradeVideoInProgressStatus(out)
assert.equal(again, out, 'idempotent')

console.log('test-video-in-progress-status: ok')
