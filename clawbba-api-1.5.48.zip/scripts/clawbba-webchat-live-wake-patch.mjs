/**
 * OpenClaw 2026.5.27+：生图/生视频完成后在 wakeMediaGenerationTaskCompletion 里
 * 立即 chat.inject，WebChat 无需刷新浏览器。
 */
import fs from 'fs'
import path from 'path'
import { dedupeClawbbaWakePatchBlocks } from './clawbba-patch-dedupe.mjs'

export const WEBCHAT_LIVE_WAKE_MARKER = '/* clawbba-webchat-live-wake */'

const WAKE_NEEDLE = `async function wakeMediaGenerationTaskCompletion(params) {
\tif (!params.handle) return true;
\tconst announceId = \`\${params.toolName}:\${params.handle.taskId}:\${params.status}\`;
\tconst mediaUrls = Array.from(new Set([...params.mediaUrls ?? [], ...mediaUrlsFromGeneratedAttachments(params.attachments)]));`

const WAKE_INJECT_BLOCK = `\t${WEBCHAT_LIVE_WAKE_MARKER}
\tif (params.status === "ok" && mediaUrls.length > 0) {
\t\tconst __clawbbaSk = typeof params.handle.requesterSessionKey === "string" ? params.handle.requesterSessionKey.trim() : "";
\t\tconst __clawbbaCh = normalizeMessageChannel(params.handle.requesterOrigin?.channel ?? "");
\t\tif (__clawbbaSk && (__clawbbaCh === "webchat" || __clawbbaSk.includes(":dashboard:"))) {
\t\t\ttry {
\t\t\t\tconst { clawbbaInjectWebChatGeneratedMediaLive } = await import("./ANNOUNCE_BASENAME");
\t\t\t\tawait clawbbaInjectWebChatGeneratedMediaLive({
\t\t\t\t\tsessionKey: __clawbbaSk,
\t\t\t\t\tchatRunId: params.handle?.requesterChatRunId,
\t\t\t\t\tmediaUrls,
\t\t\t\t\tsourceTool: params.toolName,
\t\t\t\t\tcompletionLabel: params.completionLabel,
\t\t\t\t\tmessage: typeof params.result === "string" && params.result.includes("MEDIA:") ? params.result : void 0
\t\t\t\t});
\t\t\t} catch (__clawbbaErr) {
\t\t\t\tlog$5.warn("clawbba webchat live wake inject failed", { error: String(__clawbbaErr?.message ?? __clawbbaErr) });
\t\t\t}
\t\t}
\t}`

function buildWakeReplacement(announceBasename) {
  return `async function wakeMediaGenerationTaskCompletion(params) {
\tif (!params.handle) return true;
\tconst announceId = \`\${params.toolName}:\${params.handle.taskId}:\${params.status}\`;
\tconst mediaUrls = Array.from(new Set([...params.mediaUrls ?? [], ...mediaUrlsFromGeneratedAttachments(params.attachments)]));
${WAKE_INJECT_BLOCK.replace('ANNOUNCE_BASENAME', announceBasename)}`
}

/**
 * @param {string} toolsPath
 * @param {string} announceBasename e.g. subagent-announce-delivery-DK-Ub9gW.js
 */
export function patchWebChatLiveWakeInToolsFile(toolsPath, announceBasename) {
  const raw = fs.readFileSync(toolsPath, 'utf8')
  let src = dedupeClawbbaWakePatchBlocks(raw)

  if (src.includes(WEBCHAT_LIVE_WAKE_MARKER)) {
    let changed = src !== raw
    if (src.includes('sessionKey: __clawbbaSk,') && src.includes('chatRunId: params.handle?.runId')) {
      src = src.replace(
        'chatRunId: params.handle?.runId,',
        'chatRunId: params.handle?.requesterChatRunId,',
      )
      changed = true
    }
    if (src.includes('sessionKey: __clawbbaSk,') && !src.includes('chatRunId: params.handle?.requesterChatRunId')) {
      src = src.replace(
        'sessionKey: __clawbbaSk,\n\t\t\t\t\tmediaUrls,',
        'sessionKey: __clawbbaSk,\n\t\t\t\t\tchatRunId: params.handle?.requesterChatRunId,\n\t\t\t\t\tmediaUrls,',
      )
      changed = true
    }
    if (changed) fs.writeFileSync(toolsPath, src)
    return changed ? 'upgraded-wake-runid' : 'skip'
  }

  if (!src.includes('async function wakeMediaGenerationTaskCompletion(params)')) {
    return 'wake-fn-missing'
  }

  if (!src.includes(WAKE_NEEDLE)) return 'wake-needle-missing'

  src = src.replace(WAKE_NEEDLE, buildWakeReplacement(announceBasename))
  fs.writeFileSync(toolsPath, src)
  return 'patched-wake'
}

/**
 * @param {string} dist
 * @param {(dist: string, prefix: string) => string|undefined} findDistFile
 */
export function patchWebChatLiveWakeDist(dist, findDistFile) {
  const toolsFile = findDistFile(dist, 'openclaw-tools-')
  const announceFile = findDistFile(dist, 'subagent-announce-delivery-')
  if (!toolsFile || !announceFile) return 'missing-file'
  const announceSrc = fs.readFileSync(path.join(dist, announceFile), 'utf8')
  if (!announceSrc.includes('export async function clawbbaInjectWebChatGeneratedMediaLive')) {
    return 'announce-live-helper-missing'
  }
  return patchWebChatLiveWakeInToolsFile(path.join(dist, toolsFile), announceFile)
}
