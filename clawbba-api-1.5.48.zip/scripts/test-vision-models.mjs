#!/usr/bin/env node
import assert from 'node:assert/strict'
import {
  applyVisionInputToProviderEntry,
  pickVisionTextModelId,
  resolveImageModelPrimary,
  rowSupportsVisionInput,
} from './clawbba-vision-models.mjs'
import { buildMinimalModelDefinition } from './openclaw-provider-block.mjs'

const rows = [
  { id: 'google/gemini-2.5-flash-preview', category: 'text', text_options: { supports_image_input: true } },
  { id: 'black-forest-labs/flux.2-flex', category: 'image' },
  { id: 'meta-llama/llama-3.1-8b-instruct', category: 'text', text_options: { supports_image_input: false } },
]

assert.equal(rowSupportsVisionInput(rows[0]), true)
assert.equal(rowSupportsVisionInput(rows[1]), false)
assert.equal(rowSupportsVisionInput(rows[2]), false)

const entry = buildMinimalModelDefinition(rows[0].id, 'Gemini', 'text')
applyVisionInputToProviderEntry(entry, rows[0])
assert.deepEqual(entry.input, ['text', 'image'])

assert.equal(pickVisionTextModelId(rows), 'google/gemini-2.5-flash-preview')
assert.equal(
  resolveImageModelPrimary(rows, 'meta-llama/llama-3.1-8b-instruct'),
  'clawbba/google/gemini-2.5-flash-preview',
)
assert.equal(
  resolveImageModelPrimary(rows, 'google/gemini-2.5-flash-preview'),
  'clawbba/google/gemini-2.5-flash-preview',
)

console.log('test-vision-models: ok')
