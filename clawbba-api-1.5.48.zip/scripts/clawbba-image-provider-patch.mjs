/**
 * OpenClaw openrouter image-generation-provider patches (ClawBBA).
 * - Poll ClawBBA async image jobs (HTTP 202 + job_id) until completed/failed
 * - Never double-read response body (avoids ReadableStream is locked)
 * - v5: release POST fetch guard before poll; do not cap poll with req.timeoutMs (180s)
 */
import fs from 'fs'
import path from 'path'

export const IMAGE_PROVIDER_MARKER = '/* clawbba-image-provider */'
export const IMAGE_HTTP_TIMEOUT_MARKER = '/* clawbba-image-http-timeout */'
export const IMAGE_ASYNC_JOB_MARKER = '/* clawbba-image-async-job-poll */'
export const IMAGE_ASYNC_JOB_V2_MARKER = '/* clawbba-image-async-job-poll-v2 */'
export const IMAGE_ASYNC_JOB_V3_MARKER = '/* clawbba-image-async-job-poll-v3 */'
export const IMAGE_ASYNC_JOB_V4_MARKER = '/* clawbba-image-async-job-poll-v4 */'
export const IMAGE_ASYNC_JOB_V5_MARKER = '/* clawbba-image-async-job-poll-v5 */'
export const IMAGE_ASYNC_JOB_V6_MARKER = '/* clawbba-image-async-job-poll-v6 */'

/** Hard safety cap for async poll only (POST returns 202 quickly). Not req.timeoutMs. */
export const CLAWBBA_IMAGE_ASYNC_MAX_WAIT_MS = 900000

function buildPollUrlResolverLines() {
  return `\t\t\t\t\t${IMAGE_ASYNC_JOB_V4_MARKER}
\t\t\t\t\tconst pollUrl = (() => {
\t\t\t\t\t\tconst pollBase = String(baseUrl || "").replace(/\\/$/, "");
\t\t\t\t\t\tconst raw = typeof payload.poll_url === "string" ? payload.poll_url.trim() : "";
\t\t\t\t\t\tif (raw.startsWith("http://") || raw.startsWith("https://")) return raw;
\t\t\t\t\t\tif (raw.startsWith("/")) {
\t\t\t\t\t\t\ttry {
\t\t\t\t\t\t\t\tconst origin = new URL(pollBase.includes("://") ? pollBase : \`https://\${pollBase}\`).origin;
\t\t\t\t\t\t\t\treturn \`\${origin}\${raw}\`;
\t\t\t\t\t\t\t} catch (_) {}
\t\t\t\t\t\t}
\t\t\t\t\t\treturn \`\${pollBase}/images/generations/\${encodeURIComponent(jobId)}\`;
\t\t\t\t\t})();`
}

function buildCompletedPollExtractBlock() {
  return `\t\t\t\t\t\tif (st === "completed") {
\t\t\t\t\t\t\t${IMAGE_ASYNC_JOB_V6_MARKER}
\t\t\t\t\t\t\tlet fromData = [];
\t\t\t\t\t\t\tif (pollBody?.data) {
\t\t\t\t\t\t\t\ttry {
\t\t\t\t\t\t\t\t\tfromData = extractOpenRouterImagesFromResponse(pollBody.data, { malformedResponseError: OPENROUTER_IMAGE_MALFORMED_RESPONSE });
\t\t\t\t\t\t\t\t} catch (_) {
\t\t\t\t\t\t\t\t\tfromData = [];
\t\t\t\t\t\t\t\t}
\t\t\t\t\t\t\t}
\t\t\t\t\t\t\tif (fromData.length === 0 && Array.isArray(pollBody?.images)) {
\t\t\t\t\t\t\t\tfor (const raw of pollBody.images) {
\t\t\t\t\t\t\t\t\tconst imgUrl = String(raw || "").trim();
\t\t\t\t\t\t\t\t\tif (!/^https?:\\/\\//i.test(imgUrl)) continue;
\t\t\t\t\t\t\t\t\ttry {
\t\t\t\t\t\t\t\t\t\tconst dl = await fetch(imgUrl, { headers, signal: AbortSignal.timeout(12e4) });
\t\t\t\t\t\t\t\t\t\tif (!dl.ok) continue;
\t\t\t\t\t\t\t\t\t\tconst mime = String(dl.headers.get("content-type") || "image/png").split(";")[0].trim() || "image/png";
\t\t\t\t\t\t\t\t\t\tconst b64 = Buffer.from(await dl.arrayBuffer()).toString("base64");
\t\t\t\t\t\t\t\t\t\tconst asset = generatedImageAssetFromDataUrl({ dataUrl: \`data:\${mime};base64,\${b64}\`, index: fromData.length });
\t\t\t\t\t\t\t\t\t\tif (asset) fromData.push(asset);
\t\t\t\t\t\t\t\t\t} catch (_) {}
\t\t\t\t\t\t\t\t}
\t\t\t\t\t\t\t}
\t\t\t\t\t\t\tif (fromData.length > 0) return { images: fromData, model };
\t\t\t\t\t\t\tthrow new Error(\`ClawBBA image job completed without image data (job_id=\${jobId}). poll GET \${pollUrl}\`);
\t\t\t\t\t\t}`
}

function buildAsyncPollLoopBody() {
  return `${buildPollUrlResolverLines()}
\t\t\t\t\tawait release();
\t\t\t\t\t${IMAGE_ASYNC_JOB_V5_MARKER}
\t\t\t\t\tconst pollStarted = Date.now();
\t\t\t\t\tconst maxWaitMs = ${CLAWBBA_IMAGE_ASYNC_MAX_WAIT_MS};
\t\t\t\t\tlet pollAttempt = 0;
\t\t\t\t\twhile (true) {
\t\t\t\t\t\tif (Date.now() - pollStarted > maxWaitMs) {
\t\t\t\t\t\t\tthrow new Error(\`ClawBBA image job wait limit \${maxWaitMs}ms (job_id=\${jobId}). Job may still complete — poll GET \${pollUrl}\`);
\t\t\t\t\t\t}
\t\t\t\t\t\tif (pollAttempt++ > 0) await new Promise((resolve) => setTimeout(resolve, 2000));
\t\t\t\t\t\tconst pollRes = await fetch(pollUrl, {
\t\t\t\t\t\t\theaders,
\t\t\t\t\t\t\tsignal: AbortSignal.timeout(6e4)
\t\t\t\t\t\t});
\t\t\t\t\t\tlet pollBody = null;
\t\t\t\t\t\ttry {
\t\t\t\t\t\t\tpollBody = await pollRes.json();
\t\t\t\t\t\t} catch (_) {
\t\t\t\t\t\t\tpollBody = null;
\t\t\t\t\t\t}
\t\t\t\t\t\tif (typeof clawbbaNoteMediaPollProgress === "function") clawbbaNoteMediaPollProgress(pollBody);
\t\t\t\t\t\tif (!pollRes.ok && pollRes.status !== 404) continue;
\t\t\t\t\t\tconst st = String(pollBody?.status || "").toLowerCase();
\t\t\t\t\t\tif (st === "failed") {
\t\t\t\t\t\t\tthrow new Error(String(pollBody?.error || pollBody?.message || "ClawBBA image job failed"));
\t\t\t\t\t\t}
${buildCompletedPollExtractBlock()}
\t\t\t\t\t}`
}

function findOpenRouterImageProviderFile(dist) {
  return fs.readdirSync(dist).find((name) => {
    if (!name.startsWith('image-generation-provider-') || !name.endsWith('.js')) return false
    const src = fs.readFileSync(path.join(dist, name), 'utf8')
    return (
      src.includes('buildOpenRouterImageGenerationProvider') ||
      (src.includes('OPENROUTER_BASE_URL') &&
        src.includes('async generateImage(req)') &&
        src.includes('extractOpenRouterImagesFromResponse'))
    )
  })
}

const GENERATE_TRY_NEEDLE = `\t\t\ttry {
\t\t\t\tawait assertOkOrThrowHttpError(response, "OpenRouter image generation failed");
\t\t\t\tconst images = extractOpenRouterImagesFromResponse(await response.json(), { malformedResponseError: OPENROUTER_IMAGE_MALFORMED_RESPONSE });
\t\t\t\tif (images.length === 0) throw new Error("OpenRouter image generation response missing image data");
\t\t\t\treturn {
\t\t\t\t\timages,
\t\t\t\t\tmodel
\t\t\t\t};
\t\t\t} finally {
\t\t\t\tawait release();
\t\t\t}`

function buildClawbbaThrowHttpError(status, payload) {
  return `\t\t\t\tconst __clawbbaErr = payload?.error?.message || payload?.message || (typeof payload?.error === "string" ? payload.error : null) || \`HTTP \${status}\`;
\t\t\t\tthrow new Error(\`OpenRouter image generation failed (HTTP \${status}): \${__clawbbaErr}\`);`
}

function buildAsyncJobPollBlock() {
  return `\t\t\t\t${IMAGE_ASYNC_JOB_MARKER}
\t\t\t\t${IMAGE_ASYNC_JOB_V2_MARKER}
\t\t\t\t${IMAGE_ASYNC_JOB_V3_MARKER}
\t\t\t\tconst status = response.status;
\t\t\t\tlet payload = null;
\t\t\t\ttry {
\t\t\t\t\tpayload = await response.json();
\t\t\t\t} catch (_) {
\t\t\t\t\tpayload = null;
\t\t\t\t}
\t\t\t\tif (status === 202 && payload?.job_id) {
\t\t\t\t\tconst jobId = String(payload.job_id);
\t\t\t\t\tglobalThis.__clawbbaLastImageJobId = jobId;
${buildAsyncPollLoopBody()}
\t\t\t\t}
\t\t\t\tif (status < 200 || status >= 300) {
${buildClawbbaThrowHttpError('status', 'payload')}
\t\t\t\t}
\t\t\t\tconst images = extractOpenRouterImagesFromResponse(payload ?? {}, { malformedResponseError: OPENROUTER_IMAGE_MALFORMED_RESPONSE });
\t\t\t\tif (images.length === 0) throw new Error("OpenRouter image generation response missing image data");
\t\t\t\treturn {
\t\t\t\t\timages,
\t\t\t\t\tmodel
\t\t\t\t};`
}

const GENERATE_TRY_REPLACEMENT = `\t\t\ttry {
${buildAsyncJobPollBlock()}
\t\t\t} finally {
\t\t\t\ttry { await release(); } catch (_) {}
\t\t\t}`

/** Upgrade v3 poll_url (relative path breaks fetch) → v4 absolute resolver */
function upgradePollUrlToV4(src) {
  if (src.includes(IMAGE_ASYNC_JOB_V4_MARKER)) return src
  const oldPollUrlBlock = `\t\t\t\t\tconst pollBase = String(baseUrl || "").replace(/\\/$/, "");
\t\t\t\t\tconst pollUrl = typeof payload.poll_url === "string" && payload.poll_url.trim()
\t\t\t\t\t\t? payload.poll_url.trim()
\t\t\t\t\t\t: \`\${pollBase}/images/generations/\${encodeURIComponent(jobId)}\`;`
  if (!src.includes(oldPollUrlBlock)) return src
  return src.replace(oldPollUrlBlock, buildPollUrlResolverLines())
}

const OPTIONAL_CAP_RE =
  /const pollStarted = Date\.now\(\);\s*\n\s*const optionalCapMs = typeof req\.timeoutMs === "number" && req\.timeoutMs > 0 \? req\.timeoutMs : null;\s*\n\s*while \(true\) \{\s*\n\s*if \(optionalCapMs != null && Date\.now\(\) - pollStarted > optionalCapMs\) \{\s*\n\s*throw new Error\(`ClawBBA image job wait limit \$\{optionalCapMs\}ms \(job_id=\$\{jobId\}\)\. Job may still complete — poll GET \$\{pollUrl\}`\);\s*\n\s*\}/

function buildV5PollLoopHead(indent = '\t\t\t\t\t') {
  const i = indent
  return `${i}await release();
${i}${IMAGE_ASYNC_JOB_V5_MARKER}
${i}const pollStarted = Date.now();
${i}const maxWaitMs = ${CLAWBBA_IMAGE_ASYNC_MAX_WAIT_MS};
${i}while (true) {
${i}\tif (Date.now() - pollStarted > maxWaitMs) {
${i}\t\tthrow new Error(\`ClawBBA image job wait limit \${maxWaitMs}ms (job_id=\${jobId}). Job may still complete — poll GET \${pollUrl}\`);
${i}\t}`
}

const OLD_COMPLETED_BLOCK_RE =
  /if \(st === "completed"\) \{\s*\n\s*const fromData = pollBody\?\.data\s*\n\s*\? extractOpenRouterImagesFromResponse\(pollBody\.data[\s\S]*?if \(fromData\.length > 0\) return \{ images: fromData, model \};\s*\n\s*\}/

/** Set global job id on 202 for background auto-recover when poll times out */
function upgradeAsyncPollGlobalJobId(src) {
  if (src.includes('globalThis.__clawbbaLastImageJobId')) return src
  const re =
    /if \(status === 202 && payload\?\.job_id\) \{\s*\n\s*const jobId = String\(payload\.job_id\);/
  if (!re.test(src)) return src
  return src.replace(re, (m) => `${m}\n\t\t\t\t\tglobalThis.__clawbbaLastImageJobId = jobId;`)
}

/** v5 completed handler (empty data → infinite poll) → v6 with https fallback + throw */
export function upgradeAsyncPollToV6(src) {
  if (!src.includes(IMAGE_ASYNC_JOB_MARKER)) return src
  if (src.includes(IMAGE_ASYNC_JOB_V6_MARKER)) return src
  if (OLD_COMPLETED_BLOCK_RE.test(src)) {
    return src.replace(OLD_COMPLETED_BLOCK_RE, buildCompletedPollExtractBlock().trim())
  }
  return src
}

/** v4 + optionalCapMs → v5: release POST guard; poll up to 15min (not req.timeoutMs) */
export function upgradeAsyncPollToV5(src) {
  if (!src.includes(IMAGE_ASYNC_JOB_MARKER)) return src
  if (src.includes(IMAGE_ASYNC_JOB_V5_MARKER)) return src

  let next = upgradePollUrlToV4(src)

  if (OPTIONAL_CAP_RE.test(next)) {
    next = next.replace(OPTIONAL_CAP_RE, (m) => {
      const indent = m.match(/^(\s*)const pollStarted/)?.[1] || '\t\t\t\t\t'
      return buildV5PollLoopHead(indent)
    })
  } else if (next.includes('const pollStarted = Date.now();') && !next.includes('await release();')) {
    next = next.replace(
      /(\s*)const pollStarted = Date\.now\(\);/,
      (m, indent) => `${indent}await release();\n${indent}${IMAGE_ASYNC_JOB_V5_MARKER}\n${indent}const pollStarted = Date.now();\n${indent}const maxWaitMs = ${CLAWBBA_IMAGE_ASYNC_MAX_WAIT_MS};`,
    )
  }

  if (!next.includes('try { await release(); } catch (_) {}')) {
    next = next.replace(
      /\} finally \{\s*\n\s*await release\(\);\s*\n\s*\}/g,
      '} finally {\n\t\t\t\ttry { await release(); } catch (_) {}\n\t\t\t}',
    )
  }

  return next
}

/** Revert mistaken 120s DEFAULT_TIMEOUT_MS reduction (POST-only; poll is separate after v5) */
function upgradeHttpTimeoutDefault(src) {
  if (src.includes(`${IMAGE_HTTP_TIMEOUT_MARKER}\nconst DEFAULT_TIMEOUT_MS = 12e4`)) {
    return src.replace(
      `${IMAGE_HTTP_TIMEOUT_MARKER}\nconst DEFAULT_TIMEOUT_MS = 12e4;`,
      `${IMAGE_HTTP_TIMEOUT_MARKER}\nconst DEFAULT_TIMEOUT_MS = 9e5;`,
    )
  }
  return src
}

/** Remove duplicate tail left by v1→v2 upgrade; strip assertOk after body consumed */
function upgradeExistingAsyncPollBlock(src) {
  if (!src.includes(IMAGE_ASYNC_JOB_MARKER)) return src

  src = src.replace(
    /\t\t\t\treturn \{\s*\n\t\t\t\t\timages,\s*\n\t\t\t\t\tmodel\s*\n\t\t\t\t\};\s*\n\t\t\t\tawait assertOkOrThrowHttpError\(response, "OpenRouter image generation failed"\);[\s\S]*?return \{\s*\n\t\t\t\t\timages,\s*\n\t\t\t\t\tmodel\s*\n\t\t\t\t\};/,
    `\t\t\t\treturn {
\t\t\t\t\timages,
\t\t\t\t\tmodel
\t\t\t\t};`,
  )

  src = upgradeAsyncPollToV5(src)
  src = upgradeAsyncPollToV6(src)
  src = upgradeAsyncPollGlobalJobId(src)
  src = upgradeHttpTimeoutDefault(src)

  if (src.includes(IMAGE_ASYNC_JOB_V6_MARKER)) return src
  if (src.includes(IMAGE_ASYNC_JOB_V5_MARKER)) return upgradeAsyncPollToV6(src)

  const blockRe =
    /\/\* clawbba-image-async-job-poll \*\/[\s\S]*?return \{\s*\n\t\t\t\t\timages,\s*\n\t\t\t\t\tmodel\s*\n\t\t\t\t\};\s*\n(?=\t\t\t\} finally)/
  if (!blockRe.test(src)) return src
  return src.replace(blockRe, `${buildAsyncJobPollBlock()}\n`)
}

/**
 * @param {string} dist
 * @returns {'patched'|'upgraded'|'skip'|'missing'|'pattern-missing'}
 */
export function patchOpenRouterImageProvider(dist) {
  const file = findOpenRouterImageProviderFile(dist)
  if (!file) return 'missing'

  const filePath = path.join(dist, file)
  let src = fs.readFileSync(filePath, 'utf8')
  const before = src

  src = upgradeExistingAsyncPollBlock(src)

  if (!src.includes(IMAGE_HTTP_TIMEOUT_MARKER)) {
    if (src.includes('const DEFAULT_TIMEOUT_MS = 18e4;')) {
      src = src.replace(
        'const DEFAULT_TIMEOUT_MS = 18e4;',
        `const DEFAULT_TIMEOUT_MS = 18e4; ${IMAGE_HTTP_TIMEOUT_MARKER}`,
      )
    } else if (src.includes('const DEFAULT_TIMEOUT_MS = 9e5;')) {
      src = src.replace(
        'const DEFAULT_TIMEOUT_MS = 9e5;',
        `const DEFAULT_TIMEOUT_MS = 9e5; ${IMAGE_HTTP_TIMEOUT_MARKER}`,
      )
    }
  }

  if (!src.includes(IMAGE_ASYNC_JOB_MARKER)) {
    if (src.includes(GENERATE_TRY_NEEDLE)) {
      src = src.replace(GENERATE_TRY_NEEDLE, GENERATE_TRY_REPLACEMENT)
    } else if (src.includes('await assertOkOrThrowHttpError(response, "OpenRouter image generation failed")')) {
      return 'pattern-missing'
    }
  }

  if (src !== before) {
    if (!src.includes(IMAGE_PROVIDER_MARKER)) {
      src = src.replace(
        'async generateImage(req) {',
        `${IMAGE_PROVIDER_MARKER}
\t\tasync generateImage(req) {`,
      )
    }
    fs.writeFileSync(filePath, src)
    return before.includes(IMAGE_ASYNC_JOB_MARKER) ? 'upgraded' : 'patched'
  }
  return 'skip'
}
