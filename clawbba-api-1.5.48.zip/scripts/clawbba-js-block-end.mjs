/**
 * Find matching `}` for `{` at openBraceIndex, skipping strings / template literals.
 */
export function findJsBlockEnd(src, openBraceIndex) {
  let depth = 0
  let inSingle = false
  let inDouble = false
  let inTemplate = false
  let templateExprDepth = 0
  let escape = false

  for (let i = openBraceIndex; i < src.length; i++) {
    const c = src[i]

    if (escape) {
      escape = false
      continue
    }

    if (inSingle) {
      if (c === '\\') escape = true
      else if (c === "'") inSingle = false
      continue
    }
    if (inDouble) {
      if (c === '\\') escape = true
      else if (c === '"') inDouble = false
      continue
    }
    if (inTemplate) {
      if (c === '\\') escape = true
      else if (c === '`' && templateExprDepth === 0) inTemplate = false
      else if (c === '$' && src[i + 1] === '{') {
        templateExprDepth++
        i++
      } else if (templateExprDepth > 0) {
        if (c === '{') templateExprDepth++
        else if (c === '}') templateExprDepth--
      }
      continue
    }

    if (c === "'") {
      inSingle = true
      continue
    }
    if (c === '"') {
      inDouble = true
      continue
    }
    if (c === '`') {
      inTemplate = true
      continue
    }

    if (c === '{') depth++
    else if (c === '}') {
      depth--
      if (depth === 0) return i + 1
    }
  }

  return src.length
}

export function findJsFunctionBodyEnd(src, fnNeedle) {
  const idx = src.indexOf(fnNeedle)
  if (idx < 0) return -1
  const brace = src.indexOf('{', idx + fnNeedle.length)
  if (brace < 0) return -1
  return findJsBlockEnd(src, brace)
}
