#!/usr/bin/env node
import assert from 'node:assert/strict'
import {
  repairLegacyPluginImport,
  toolsSrcHasLegacyPluginImport,
  buildClawbbaPickModuleExportHelper,
} from './clawbba-webchat-live-inject.mjs'

const legacy = `${buildClawbbaPickModuleExportHelper()}
async function clawbbaDispatchWebChatMediaLiveInject(params) {
\ttry {
\t\tconst { dispatchGatewayMethodInProcess } = await import("./server-plugins-BniQMVzq.js");
\t\tawait dispatchGatewayMethodInProcess("chat.inject", {}, { timeoutMs: 3e4 });
\t} catch (_) {}
}`

assert.ok(toolsSrcHasLegacyPluginImport(legacy))
const fixed = repairLegacyPluginImport(legacy)
assert.ok(!toolsSrcHasLegacyPluginImport(fixed))
assert.match(fixed, /clawbbaPickModuleExport\(pluginsModule, "dispatchGatewayMethodInProcess", \["r"\]\)/)

console.log('test-plugin-import-repair: ok')
