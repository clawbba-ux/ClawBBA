#!/usr/bin/env node
/**
 * 仅打 Flux 必需 patch（model-ref vendor→openrouter + image/video model 归一化）
 * 不修改 buildImageConfig，不会因 aspect patch 失败而中断。
 *
 * 用法: node scripts/patch-flux-critical.mjs
 */
import fs from 'fs'
import path from 'path'
import { patchImageGenerateMediaDispatch, patchVideoGenerateMediaDispatch } from './clawbba-media-dispatch-patch.mjs'
import { findAllOpenclawDists, findDistJsFile, formatOpenclawDistDiscoveryReport } from './openclaw-dist-paths.mjs'
import { buildModelRefVendorRoutingBlock } from './clawbba-media-model-ref.mjs'

const MODEL_REF_MARKER = '/* clawbba-model-ref */'
const VENDOR_MODEL_REF_MARKER = '/* clawbba-openrouter-vendor-id */'

function findDistFile(dist, prefix) {
  return findDistJsFile(dist, prefix)
}

function findModelRefFile(dist) {
  const files = fs.readdirSync(dist).filter((name) => name.startsWith('model-ref-') && name.endsWith('.js'))
  return (
    files.find((name) => fs.readFileSync(path.join(dist, name), 'utf8').includes('function parseGenerationModelRef')) ||
    files[0] ||
    null
  )
}

function patchClawbbaModelRef(dist) {
  const file = findModelRefFile(dist)
  if (!file) return 'missing'
  const filePath = path.join(dist, file)
  let src = fs.readFileSync(filePath, 'utf8')
  if (src.includes('__clawbbaImgProviders')) return 'skip'

  const vendorRouting = buildModelRefVendorRoutingBlock()

  if (src.includes(MODEL_REF_MARKER)) {
    const oldPatch = `\t${MODEL_REF_MARKER}
\tif (provider === "clawbba") provider = "openrouter";
\treturn {
\t\tprovider,
\t\tmodel
\t};`
    if (src.includes(oldPatch)) {
      src = src.replace(
        oldPatch,
        `\t${MODEL_REF_MARKER}
\tif (provider === "clawbba") provider = "openrouter";
${vendorRouting}
\treturn {
\t\tprovider,
\t\tmodel
\t};`,
      )
      fs.writeFileSync(filePath, src)
      return 'patched'
    }
    const looseNeedle = `\tif (provider === "clawbba") provider = "openrouter";
\treturn {
\t\tprovider,
\t\tmodel
\t};`
    if (src.includes(looseNeedle)) {
      src = src.replace(
        looseNeedle,
        `\tif (provider === "clawbba") provider = "openrouter";
${vendorRouting}
\treturn {
\t\tprovider,
\t\tmodel
\t};`,
      )
      fs.writeFileSync(filePath, src)
      return 'patched'
    }
    if (src.includes(MODEL_REF_MARKER)) {
      const beforeReturn = src.indexOf('\treturn {\n\t\tprovider,\n\t\tmodel\n\t};')
      if (beforeReturn > 0 && !src.includes('__clawbbaImgProviders')) {
        src = src.replace(
          '\treturn {\n\t\tprovider,\n\t\tmodel\n\t};',
          `${vendorRouting}\n\treturn {\n\t\tprovider,\n\t\tmodel\n\t};`,
        )
        fs.writeFileSync(filePath, src)
        return 'patched'
      }
    }
    return 'skip'
  }

  const needle = `\tif (!provider || !model) return null;
\treturn {
\t\tprovider,
\t\tmodel
\t};`
  if (!src.includes(needle)) return 'missing'
  src = src.replace(
    needle,
    `\tif (!provider || !model) return null;
\t${MODEL_REF_MARKER}
\tif (provider === "clawbba") provider = "openrouter";
${vendorRouting}
\treturn {
\t\tprovider,
\t\tmodel
\t};`,
  )
  fs.writeFileSync(filePath, src)
  return 'patched'
}

function main() {
  const dists = findAllOpenclawDists()
  if (!dists.length) {
    console.error('[clawbba-api] ✗ 未找到 OpenClaw dist')
    process.exit(1)
  }
  console.log(formatOpenclawDistDiscoveryReport(dists))
  for (const dist of dists) {
    const tools = findDistFile(dist, 'openclaw-tools-')
    if (!tools) {
      console.error(`[clawbba-api] ✗ 无 openclaw-tools in ${dist}`)
      continue
    }
    const toolsPath = path.join(dist, tools)
    const r4 = patchClawbbaModelRef(dist)
    const r6 = patchImageGenerateMediaDispatch(toolsPath)
    const r7 = patchVideoGenerateMediaDispatch(toolsPath)
    console.log(`[clawbba-api] ${dist}\n  modelRef=${r4} imgDispatch=${r6} vidDispatch=${r7}`)
    const modelRefFile = findModelRefFile(dist)
    const mr = fs.readFileSync(path.join(dist, modelRefFile), 'utf8')
    const toolsSrc = fs.readFileSync(toolsPath, 'utf8')
    if (!mr.includes('__clawbbaImgProviders')) {
      console.error('[clawbba-api] ✗ model-ref 仍缺 __clawbbaImgProviders，请同步 skill v1.3.1')
      process.exit(1)
    }
    if (!toolsSrc.includes('clawbbaToOpenClawMediaModel')) {
      console.error('[clawbba-api] ✗ image_generate 仍缺 clawbbaToOpenClawMediaModel')
      process.exit(1)
    }
  }
  console.log('[clawbba-api] ✓ ClawBBA 关键 patch 已就绪（已存在则显示 skip）')
}

main()
