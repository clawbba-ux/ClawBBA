/**
 * ClawBBA × OpenClaw — 文本对话看图（vision chat），与生图/生视频分离。
 * OpenClaw 对 input 不含 image 的模型会 offload 附件，再走 media-understanding / image 工具；
 * 若误落到 openrouter 生图模型（如 flux）会 400 upstream_error。
 */

/** setup 为 imageModel 选 vision 文本模型时的优先级（须为 catalog category=text） */
export const PATCH_VISION_TEXT_MODEL_PREFER = [
  'google/gemini-2.5-flash-preview',
  'google/gemini-2.0-flash-001',
  'google/gemini-2.5-flash',
  'openai/gpt-4o',
  'openai/gpt-4o-mini',
  'anthropic/claude-sonnet-4',
  'anthropic/claude-3.5-sonnet',
]

/** 无 text_options 时的保守启发（与 server buildTextOptionsPayload 对齐） */
const VISION_TEXT_ID_RE =
  /gemini-(2\.[05]|3\.|3-)|gpt-4o|gpt-4\.1|gpt-5|claude-3\.5|claude-sonnet-4|claude-opus-4|qwen.*vl|llava|pixtral|glm-4v/i

/** 生图专用 id — 不可作 imageModel / 聊天 vision */
const IMAGE_GEN_ONLY_ID_RE =
  /flux\.|seedream|dall-e|gpt-.*image|gemini-.*-image|imagen|grok-imagine-image|stable-diffusion/i

export function normCatalogCategory(m) {
  return String(m?.category || '').toLowerCase()
}

export function rowSupportsVisionInput(m) {
  if (!m || normCatalogCategory(m) !== 'text') return false
  const id = String(m.id || '').trim()
  if (!id || IMAGE_GEN_ONLY_ID_RE.test(id)) return false
  const to = m.text_options
  if (to && typeof to === 'object') {
    if (to.supports_image_input === true) return true
    if (to.supports_image_input === false) return false
    const mods = to.input_modalities
    if (Array.isArray(mods) && mods.some((x) => String(x).toLowerCase().includes('image'))) {
      return true
    }
  }
  return VISION_TEXT_ID_RE.test(id)
}

export function providerModelAcceptsImageInput(entry) {
  return Array.isArray(entry?.input) && entry.input.some((x) => String(x).toLowerCase() === 'image')
}

export function applyVisionInputToProviderEntry(entry, catalogRow) {
  if (!entry || !catalogRow) return entry
  if (normCatalogCategory(catalogRow) !== 'text') return entry
  if (!rowSupportsVisionInput(catalogRow)) return entry
  if (providerModelAcceptsImageInput(entry)) return entry
  entry.input = ['text', 'image']
  return entry
}

export function pickVisionTextModelId(rows) {
  const textRows = (rows || []).filter((m) => normCatalogCategory(m) === 'text' && rowSupportsVisionInput(m))
  const ids = new Set(textRows.map((m) => String(m.id || '').trim()).filter(Boolean))
  for (const p of PATCH_VISION_TEXT_MODEL_PREFER) {
    if (ids.has(p)) return p
  }
  return textRows[0]?.id ? String(textRows[0].id).trim() : null
}

/** imageModel 须 clawbba/<text-vision>；禁止 openrouter 生图模型 */
export function isValidClawbbaImageModelRef(ref) {
  const s = String(ref || '').trim()
  if (!s.startsWith('clawbba/')) return false
  const id = s.slice('clawbba/'.length)
  return Boolean(id) && !IMAGE_GEN_ONLY_ID_RE.test(id)
}

export function resolveImageModelPrimary(rows, defaultTextId) {
  const textId = String(defaultTextId || '').trim()
  const primaryRow = (rows || []).find((m) => String(m.id || '').trim() === textId)
  if (primaryRow && rowSupportsVisionInput(primaryRow)) {
    return `clawbba/${textId}`
  }
  const visionId = pickVisionTextModelId(rows)
  return visionId ? `clawbba/${visionId}` : null
}
