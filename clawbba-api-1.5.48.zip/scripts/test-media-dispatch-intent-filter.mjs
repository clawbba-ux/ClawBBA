#!/usr/bin/env node
import assert from 'node:assert/strict'
import {
  MEDIA_DISPATCH_INTENT_FILTER_MARKER,
  upgradeMediaDispatchIntentFilters,
} from './clawbba-media-dispatch-patch.mjs'

const sample = `
/* clawbba-media-dispatch */
await (async () => {
  if (/请使用\\s*ClawBBA\\s*生成(图片|视频)/i.test(t)) { mediaText = t; break; }
});
/* clawbba-media-dispatch */
await (async () => {
  if (/请使用\\s*ClawBBA\\s*生成(图片|视频)/i.test(t)) { mediaText = t; break; }
});
`

const out = upgradeMediaDispatchIntentFilters(sample)
assert.ok(out.includes(MEDIA_DISPATCH_INTENT_FILTER_MARKER), 'marker')
assert.ok(out.includes('生成图片/i.test(t)'), 'image intent')
assert.ok(out.includes('生成视频/i.test(t)'), 'video intent')
assert.ok(!out.includes('生成(图片|视频)'), 'old alternation removed')

console.log('test-media-dispatch-intent-filter: ok')
