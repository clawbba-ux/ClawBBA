#!/usr/bin/env node
/**
 * User VM state: clawbbaListImageTasks + execute tasks handler exist but resolveAction$2 not updated.
 */
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { execSync } from 'node:child_process'
import {
  patchImageGenerateRecoverAction,
  imageResolveActionAllowsTasks,
  imageResolveActionFnBlock,
} from './clawbba-image-recover-patch.mjs'
import { patchWebChatLiveInjectHelperInToolsFile } from './clawbba-webchat-live-inject.mjs'

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'clawbba-img-partial-'))
execSync('npm pack openclaw@2026.5.27 --silent', { cwd: tmp, stdio: 'pipe' })
execSync(`tar -xzf ${JSON.stringify(fs.readdirSync(tmp).find((n) => n.endsWith('.tgz')))}`, { cwd: tmp })
const dist = path.join(tmp, 'package', 'dist')
const toolsPath = path.join(dist, fs.readdirSync(dist).find((n) => n.startsWith('openclaw-tools-')))
const pluginsFile = fs.readdirSync(dist).find((n) => n.startsWith('server-plugins-'))
const globalSingletonFile = fs.readdirSync(dist).find((n) => n.startsWith('global-singleton-'))
const gatewayFile = fs.readdirSync(dist).find((n) => n.startsWith('gateway-request-scope-'))

assert.equal(
  patchWebChatLiveInjectHelperInToolsFile(toolsPath, pluginsFile, globalSingletonFile, gatewayFile),
  'patched',
)
assert.equal(patchImageGenerateRecoverAction(toolsPath), 'patched')

let src = fs.readFileSync(toolsPath, 'utf8')
assert.ok(src.includes('action === "tasks") return await clawbbaListImageTasks'))
assert.ok(imageResolveActionAllowsTasks(src))

const fnStart = src.indexOf('function resolveAction$2(args)')
const fnEnd = src.indexOf('\nfunction ', fnStart + 1)
const brokenBlock = imageResolveActionFnBlock(src).replace(
  /(\t\t\t"list",\n\t\t\t"recover",\n\t\t\t"tasks"\n\t\t\],)/,
  '\t\t\t"list"\n\t\t],',
)
src = src.slice(0, fnStart) + brokenBlock + src.slice(fnEnd)
fs.writeFileSync(toolsPath, src)
assert.ok(src.includes('action === "tasks") return await clawbbaListImageTasks'))
assert.ok(!imageResolveActionAllowsTasks(src))

assert.equal(patchImageGenerateRecoverAction(toolsPath), 'upgraded')
const fixed = fs.readFileSync(toolsPath, 'utf8')
assert.ok(imageResolveActionAllowsTasks(fixed))

console.log('test-image-partial-resolve-upgrade: ok')
