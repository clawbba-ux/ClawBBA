#!/usr/bin/env node
import assert from 'node:assert/strict'
import {
  parseSqliteUtcDateMs,
  jobCreatedAtMs,
  computeImageJobProgress,
  formatElapsedZh,
} from '../../../server/openrouter-job-progress.js'

const utcNow = '2026-05-30 02:45:00'
const utcMs = parseSqliteUtcDateMs(utcNow)
assert.ok(utcMs, 'parse sqlite utc')
const localParse = new Date(utcNow.replace(' ', 'T')).getTime()
assert.ok(Math.abs(utcMs - localParse) >= 7 * 3600 * 1000, 'UTC vs local should differ by ~8h in +8 TZ')

const fakeNow = utcMs + 4 * 60 * 1000
const origNow = Date.now
Date.now = () => fakeNow
try {
  const progress = computeImageJobProgress({
    status: 'pending',
    createdAt: utcNow,
    requestBodyJson: JSON.stringify({ model: 'openai/gpt-5.4-image-2' }),
  })
  assert.ok(progress.elapsed_ms < 10 * 60 * 1000, `elapsed should be ~4min not ${progress.elapsed_label}`)
  assert.match(progress.elapsed_label, /^[0-4] 分/)
  assert.ok(progress.progress_percent <= 55, `percent should be ~50 for 4min/8min, got ${progress.progress_percent}`)
} finally {
  Date.now = origNow
}

assert.equal(formatElapsedZh(480_000), '8 分 0 秒')
assert.equal(jobCreatedAtMs({ createdAt: utcNow }), utcMs)

console.log('test-job-progress-utc: ok')
