#!/usr/bin/env node
/**
 * 修复 OpenClaw 运行时 clawbba provider（真实 apiKey + baseUrl + headers）。
 * 适用于 1.1.0 及更早安装后 models.json 仍为 ${CLAWBBA_API_KEY} 占位符的情况。
 *
 * 用法:
 *   export CLAWBBA_API_KEY='cbb_sk_live_…'
 *   node scripts/fix-provider-config.mjs
 */
import fs from 'fs'
import path from 'path'
import {
  buildClawbbaProviderBlock,
  buildOpenclawEnvBlock,
  buildOpenrouterProviderBlock,
} from './openclaw-provider-block.mjs'
import {
  discoverAgentModelPaths,
  getOpenclawHome,
  getOpenclawJsonPath,
} from './openclaw-paths.mjs'
import { openrouterModelsNeedRebuild } from './openclaw-provider-block.mjs'
import { sanitizeOpenclawProviders } from './fix-openclaw-provider-schema.mjs'

const API_KEY = String(process.env.CLAWBBA_API_KEY || '').trim()
const openclawHome = getOpenclawHome()

function usage() {
  process.stderr.write(
    '用法: export CLAWBBA_API_KEY=cbb_sk_live_… && node scripts/fix-provider-config.mjs\n',
  )
}

if (!API_KEY.startsWith('cbb_sk_live_')) {
  usage()
  process.exit(1)
}

function patchProvidersObject(providers, { preserveClawbbaModels = true } = {}) {
  if (!providers || typeof providers !== 'object') return false
  let changed = false

  const prevClawbbaModels = preserveClawbbaModels
    ? providers.clawbba?.models
    : undefined

  const clawbbaBlock = buildClawbbaProviderBlock(API_KEY, {
    models: Array.isArray(prevClawbbaModels) ? prevClawbbaModels : undefined,
  })
  if (!Array.isArray(clawbbaBlock.models)) {
    delete clawbbaBlock.models
  }

  const nextClawbba = JSON.stringify(providers.clawbba || {})
  providers.clawbba = clawbbaBlock
  if (JSON.stringify(providers.clawbba) !== nextClawbba) changed = true

  const nextOpenrouter = JSON.stringify(providers.openrouter || {})
  const prevMedia = providers.openrouter?.models
  providers.openrouter = buildOpenrouterProviderBlock(API_KEY, {
    models: openrouterModelsNeedRebuild(prevMedia) ? undefined : prevMedia,
  })
  if (JSON.stringify(providers.openrouter) !== nextOpenrouter) changed = true

  if (sanitizeOpenclawProviders(providers, { apiKey: API_KEY })) changed = true

  return changed
}

function writeJson(filePath, value) {
  fs.writeFileSync(filePath, `${JSON.stringify(value, null, 2)}\n`, { mode: 0o600 })
}

let touched = 0

for (const modelPath of discoverAgentModelPaths(openclawHome)) {
  let parsed
  try {
    parsed = JSON.parse(fs.readFileSync(modelPath, 'utf8'))
  } catch (e) {
    process.stderr.write(`[clawbba-api] 跳过无效 JSON ${modelPath}: ${e.message || e}\n`)
    continue
  }
  if (!parsed.providers || typeof parsed.providers !== 'object') parsed.providers = {}
  if (patchProvidersObject(parsed.providers)) {
    writeJson(modelPath, parsed)
    touched += 1
    const rel = modelPath.startsWith(openclawHome)
      ? modelPath.slice(openclawHome.length + 1)
      : modelPath
    process.stderr.write(`[clawbba-api] fixed ${rel}\n`)
  }
}

const openclawJsonPath = getOpenclawJsonPath(openclawHome)
if (fs.existsSync(openclawJsonPath)) {
  const cfg = JSON.parse(fs.readFileSync(openclawJsonPath, 'utf8'))
  cfg.env = { ...(cfg.env || {}), ...buildOpenclawEnvBlock(API_KEY) }
  if (!cfg.models) cfg.models = {}
  if (!cfg.models.providers) cfg.models.providers = {}
  const changed = patchProvidersObject(cfg.models.providers, { preserveClawbbaModels: true })
  if (changed || cfg.env.CLAWBBA_API_KEY === API_KEY) {
    writeJson(openclawJsonPath, cfg)
    touched += 1
    process.stderr.write('[clawbba-api] fixed openclaw.json\n')
  }
}

if (!touched) {
  process.stderr.write('[clawbba-api] 无需修改（provider 已是真实 Key + headers）\n')
} else {
  process.stderr.write(
    `[clawbba-api] 完成：已更新 ${touched} 个配置文件。请执行 openclaw gateway restart\n`,
  )
}
