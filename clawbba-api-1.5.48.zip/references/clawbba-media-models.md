# ClawBBA 生图 / 生视频模型（OpenClaw）

安装 `clawbba-api` 后，`setup.sh` 会从 `GET /api/v1/models` 同步**全部**生图、生视频模型到 OpenClaw，并写入**默认生图/生视频模型**。

**用户未指定模型时**：Agent 直接调用工具，使用内置默认，**不要**强制编号菜单。可选模型对照见 **`references/model-picker.md`**。

## 用户话术模板

### 生图（推荐自然语言）

**默认模型（不写模型名）：**

```
请使用 ClawBBA 生成图片能力，为我生成 9:16 竖图：（画面描述）
```

**指定模型：**

```
请使用 ClawBBA 生成图片能力，模型 google/gemini-3.1-flash-image-preview，为我生成 9:16 竖图：（画面描述）
```

也可用友好名：`用 Nano Banana 2 模型`、`用 FLUX.2 Pro` — Agent 应映射到下表 `model_id`。

**可选参数（写在话术里即可）：**

| 用户说法 | Agent 传给工具 |
|----------|----------------|
| 9:16 / 竖图 | `aspectRatio: "9:16"` |
| 16:9 / 横图 | `aspectRatio: "16:9"` |
| 2K / 4K | `resolution: "2K"` 等（须符合该模型 `clawbbaImage` 枚举） |
| 参考图 / 图生图 | `image` 或 `images` |

### 生视频

**默认模型：**

```
请使用 ClawBBA 生成视频能力，为我生成 16:9、8 秒视频：（画面描述）
```

**指定模型：**

```
请使用 ClawBBA 生成视频能力，模型 google/veo-3.1-fast，为我生成 9:16、5 秒视频：（画面描述）
```

| 用户说法 | Agent 传给工具 |
|----------|----------------|
| 16:9 / 9:16 | `aspectRatio` |
| 8 秒 / 5 秒 | `duration` |
| 720p / 1080p | `resolution` |
| 带音频 / 不要音频 | `audio: true/false` |

## 生图模型（ClawBBA 站内可用）

| model_id | 常用称呼 | 说明 |
|----------|----------|------|
| `google/gemini-3.1-flash-image-preview` | Nano Banana 2 | **默认**，速度快，支持 9:16 |
| `google/gemini-3-pro-image-preview` | Nano Banana Pro | 高质量 |
| `google/gemini-2.5-flash-image` | Nano Banana | 经济型 |
| `black-forest-labs/flux.2-pro` | FLUX.2 Pro | 写实风格 |
| `black-forest-labs/flux.2-max` | FLUX.2 Max | 旗舰 FLUX |
| `black-forest-labs/flux.2-flex` | FLUX.2 Flex | 灵活构图 |
| `black-forest-labs/flux.2-klein-4b` | FLUX.2 Klein | 轻量 |
| `bytedance-seed/seedream-4.5` | Seedream 4.5 | 字节 Seedream |
| `openai/gpt-5.4-image-2` | GPT-5.4 Image | OpenAI 生图 |
| `openai/gpt-5-image` | GPT-5 Image | OpenAI |
| `openai/gpt-5-image-mini` | GPT-5 Image Mini | 经济 |
| `x-ai/grok-imagine-image-quality` | Grok Imagine | xAI 高质量 |
| `sourceful/riverflow-v2-pro` | Riverflow Pro | Sourceful |

完整列表：`GET /api/v1/models` 筛选 `category: image`，或 WebChat 执行 `/tool image_generate action=list`。

## 生视频模型

| model_id | 常用称呼 | 说明 |
|----------|----------|------|
| `google/veo-3.1-fast` | Veo 3.1 Fast | **默认**，速度快 |
| `google/veo-3.1` | Veo 3.1 | 高质量 |
| `google/veo-3.1-lite` | Veo 3.1 Lite | 经济 |
| `bytedance/seedance-2.0` | Seedance 2.0 | 字节 |
| `bytedance/seedance-2.0-fast` | Seedance 2.0 Fast | 快速 |
| `bytedance/seedance-1-5-pro` | Seedance 1.5 Pro | 上一代 Pro |
| `kwaivgi/kling-v3.0-pro` | Kling 3.0 Pro | 可灵 Pro |
| `kwaivgi/kling-v3.0-std` | Kling 3.0 Standard | 可灵标准 |
| `openai/sora-2-pro` | Sora 2 Pro | OpenAI 视频 |
| `alibaba/wan-2.7` | Wan 2.7 | 阿里万相 |
| `alibaba/wan-2.6` | Wan 2.6 | 阿里 |
| `minimax/hailuo-2.3` | Hailuo 2.3 | MiniMax |
| `x-ai/grok-imagine-video` | Grok Imagine Video | xAI |

完整列表：`GET /api/v1/models` 筛选 `category: video`，或 `/tool video_generate action=list`。

## Agent 解析规则

0. 用户未指定模型 → 使用 `imageGenerationModel.primary` / `videoGenerationModel.primary`，**直接生图/生视频**
1. 用户话术中写 `模型 google/…` 或友好名 → 映射为 `model` 参数
2. 用户仍说「模型编号 N」→ 查 `model-picker.md` 对照表
3. 用户指定模型后 **只尝试该模型**；失败简短说明，勿 silent 换模型（除非用户同意）

## 切换默认模型（高级）

```bash
openclaw config set agents.defaults.imageGenerationModel.primary openrouter/black-forest-labs/flux.2-pro
openclaw config set agents.defaults.videoGenerationModel.primary openrouter/google/veo-3.1
openclaw gateway restart
```

或在 WebChat 每次话术里写 `模型 …` 即可，无需改配置。
