# ClawBBA Platform API v1

Base URL（生产）：`https://www.clawbba.com/api/v1`

## 鉴权

```http
Authorization: Bearer cbb_sk_live_xxxxxxxx
Content-Type: application/json
```

## 余额

```bash
curl -s https://www.clawbba.com/api/v1/account/balance \
  -H "Authorization: Bearer $CLAWBBA_API_KEY"
```

响应示例：

```json
{
  "object": "account.balance",
  "balance_usd": 1.234567,
  "currency": "USD"
}
```

## 模型列表

```bash
curl -s https://www.clawbba.com/api/v1/models \
  -H "Authorization: Bearer $CLAWBBA_API_KEY"
```

OpenClaw 中模型引用格式：`clawbba/<model_id>`，其中 `model_id` 来自列表中的 `id` 字段。

生图 / 生视频模型还会附带：

- `image_options` — 宽高比、分辨率、modalities 等（`category: image`）
- `video_options` — 时长、分辨率、SKU、图生视频等（`category: video`）

`setup.sh` 将这些选项写入 `openclaw.json` 的 `agents.defaults.models.*.params`，并配置 OpenClaw 媒体工具，详见 `references/media-generation.md`。

## 对话 / 生图（OpenAI 兼容）

```bash
curl https://www.clawbba.com/api/v1/chat/completions \
  -H "Authorization: Bearer $CLAWBBA_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "google/gemini-3-pro-image-preview",
    "messages": [{"role": "user", "content": "a cat"}]
  }'
```

支持 `stream: true`。

## 费用预估（不扣费）

```bash
curl -X POST https://www.clawbba.com/api/v1/chat/completions/estimate \
  -H "Authorization: Bearer $CLAWBBA_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"model":"anthropic/claude-sonnet-4","messages":[{"role":"user","content":"hi"}]}'
```

## 余额预检（不足时 402）

```bash
curl -X POST https://www.clawbba.com/api/v1/chat/completions/preflight \
  -H "Authorization: Bearer $CLAWBBA_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"model":"anthropic/claude-sonnet-4","messages":[{"role":"user","content":"hi"}]}'
```

## 异步生图轮询

```bash
curl https://www.clawbba.com/api/v1/images/generations/JOB_ID \
  -H "Authorization: Bearer $CLAWBBA_API_KEY"
```

## 视频

```bash
curl -X POST https://www.clawbba.com/api/v1/videos \
  -H "Authorization: Bearer $CLAWBBA_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"model":"...","prompt":"..."}'
```

## 异步生视频轮询

```bash
curl https://www.clawbba.com/api/v1/videos/JOB_ID \
  -H "Authorization: Bearer $CLAWBBA_API_KEY"
```

## OpenClaw 配置说明

`setup.sh` 写入的配置等价于：

```json5
{
  env: {
    CLAWBBA_API_KEY: "cbb_sk_live_…", // setup 时写入真实 Key
    OPENROUTER_API_KEY: "cbb_sk_live_…",
  },
  models: {
    mode: "merge",
    providers: {
      clawbba: {
        baseUrl: "https://www.clawbba.com/api/v1",
        apiKey: "cbb_sk_live_…",
        api: "openai-completions",
        headers: {
          "User-Agent": "curl/8.4.0 (ClawBBA-OpenClaw)",
          "HTTP-Referer": "https://www.clawbba.com",
          "X-Title": "ClawBBA OpenClaw",
        },
        models: [/* 从 /models 动态填充；仅 id、name、input?、contextWindow? */],
      },
      openrouter: {
        baseUrl: "https://www.clawbba.com/api/v1",
        apiKey: "cbb_sk_live_…",
        headers: { /* 同上 */ },
      },
    },
  },
  agents: {
    defaults: {
      model: { primary: "clawbba/<default-text-model-id>" },
      imageGenerationModel: { primary: "openrouter/<default-image-model-id>", timeoutMs: 600000 },
      videoGenerationModel: { primary: "openrouter/<default-video-model-id>", timeoutMs: 600000 },
      models: {
        "clawbba/<model-id>": {
          params: { clawbbaImage: { /* image_options 子集 */ }, clawbbaVideo: { /* video_options 子集 */ } },
        },
      },
    },
  },
}
```

官方文档：https://docs.openclaw.ai/concepts/model-providers
