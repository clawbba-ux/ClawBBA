# ClawBBA 接入向导

## 为什么需要这三步？

ClawBBA 按 **账户余额** 计费。OpenClaw 通过 **Platform API Key** 调用 `https://www.clawbba.com/api/v1`，与网页 Agent 共用同一余额与扣费规则。

## 步骤 1：注册 / 登录

打开 https://www.clawbba.com ，使用邮箱注册或登录。

## 步骤 2：充值

打开 https://www.clawbba.com/product/CDKEY ，购买并兑换 CDKey，为账户增加 USD 余额。

没有余额时，API 可能返回 402 或预检失败。

## 步骤 3：创建 API Key

1. 打开 https://www.clawbba.com/agent/api-keys  
2. 点击「创建 API Key」，命名如 `OpenClaw 本机`  
3. **立即复制** 以 `cbb_sk_live_` 开头的完整密钥（关闭后无法再次查看）

## 步骤 4：安装本技能

```bash
openclaw skills install clawbba-api
```

## 步骤 5：自动配置

```bash
export CLAWBBA_API_KEY='cbb_sk_live_粘贴你的密钥'
./skills/clawbba-api/scripts/setup.sh --yes
openclaw config validate
openclaw gateway restart
```

`--yes` 跳过交互确认。`setup.sh` 会在 `openclaw.json` 写入生图/生视频所需的全部 env，用户只需 export `CLAWBBA_API_KEY`。

## 步骤 6：开始使用

- **对话**：`clawbba/<model-id>` 或 `/model clawbba/<model-id>`
- **生图 / 生视频**：OpenClaw 2026.5+ 内置 `image_generate` / `video_generate`（见下文）

## 步骤 7：生图快速体验（WebChat）

安装并重启 Gateway 后，**新开对话**，直接发送：

```
请使用 ClawBBA 生成图片能力，为我生成 9:16 竖图：亚洲女性，皮肤白皙，爱笑，现代房间灯光
```

指定模型示例：

```
请使用 ClawBBA 生成图片能力，模型 google/gemini-3.1-flash-image-preview，为我生成 9:16 竖图：…
```

**正常结果：**

- Agent 调用 ClawBBA 生图能力（内部 `image_generate`）；若出现 `Background task started`，等待即可
- 完成后 Agent 用 Markdown 呈现：`![描述](https://www.clawbba.com/uploads/agent-generated/…jpg)`
- 所有 ClawBBA 生图模型均可在话术里用 `模型 {model_id}` 切换，见 `references/clawbba-media-models.md`

**生视频：**

```
请使用 ClawBBA 生成视频能力，模型 google/veo-3.1-fast，为我生成 16:9、8 秒视频：一只猫在雨夜街头奔跑
```

详细说明：`references/media-generation.md` · Agent 行为：`references/openclaw-agent-behavior.md`

## 常见问题

**Q: 安装 skill 会自动帮我登录吗？**  
A: 不会。登录、充值、创建 Key 必须在浏览器完成；skill 的 `setup.sh` 只负责写入 OpenClaw 配置。

**Q: API Key 是什么格式？**  
A: ClawBBA Platform Key 以 `cbb_sk_live_` 开头，只能在 https://www.clawbba.com/agent/api-keys 创建，用于 `https://www.clawbba.com/api/v1`。

**Q: 生图/生视频工具不可用？**  
A: 确认 OpenClaw ≥ 2026.5、已运行 `setup.sh --yes` 并 `openclaw gateway restart`，WebChat **新开对话**。

**Q: 生图成功但只有 URL、没有图片预览？**  
A: 让 Agent 使用 `![描述](url)` 嵌入；若仍无预览，点击 `https://www.clawbba.com/uploads/agent-generated/…` 链接查看。详见 `references/openclaw-agent-behavior.md`。

**Q: Agent 报余额不足但我有余额？**  
A: 多为 Gateway 鉴权配置（401），重跑一键安装或 `fix-provider-config.mjs`，不要反复充值或换模型。

**Q: 如何更新模型列表？**  
A: 重新运行 `./scripts/setup.sh --yes`（会 merge 最新 catalog）。

**Q: OpenClaw 说只有 1 个模型 / validate 失败怎么办？**  
A: **不要**让 Agent 用 `node -e` 手改 `openclaw.json`。请重跑 `./scripts/setup.sh --yes`，然后检查：

```bash
node -e "const c=require(process.env.HOME+'/.openclaw/openclaw.json'); console.log('provider', c.models.providers.clawbba.models.length, 'allowlist', Object.keys(c.agents.defaults.models).filter(k=>k.startsWith('clawbba/')).length)"
openclaw config validate
```

两者数量应接近（等于 ClawBBA 模型总数）。再 `openclaw gateway restart`。

**Q: API 直接 curl 成功，但 OpenClaw 切换模型无效？**  
A: 常见两类原因：

1. **Agent 本地 `models.json` 覆盖了 `openclaw.json`**（OpenClaw 已知行为）。`setup.sh --yes` 会自动 sync；也可手动检查：

```bash
node -e "const p=require(process.env.HOME+'/.openclaw/agents/main/agent/models.json'); console.log('models.json clawbba', p.providers?.clawbba?.models?.length)"
```

2. **当前会话锁定了旧模型**。新开对话，或在聊天执行 `/model clawbba/<model-id>` / `/model status`。

**Q: curl 成功，但 WebChat 报 `403 Your request was blocked`？**  
A: 这是 **OpenClaw 嵌入式路径** 的已知问题，不是 ClawBBA API 故障。服务端日志里若 **没有** 对应时间的 `POST /api/v1/chat/completions`，说明请求 **没到 ClawBBA**。

常见原因与修复：

1. **`models.json` 里 `baseUrl` 错误或缺失**（OpenClaw 会打到别的地址）：

```bash
node -e "const p=require(process.env.HOME+'/.openclaw/agents/main/agent/models.json'); console.log(p.providers?.clawbba?.baseUrl, p.providers?.clawbba?.apiKey?.slice(0,16))"
```

应为 `https://www.clawbba.com/api/v1` 且 Key 以 `cbb_sk_live_` 开头（**不是** `${CLAWBBA_API_KEY}`）。

2. **Gateway 未重启**，WebChat 仍用内存里的旧配置 → `openclaw gateway restart`

3. **缺少 `headers.User-Agent`**（OpenClaw pi 客户端 UA 可能被 CDN 拦截）→ 升级到 **1.1.4** 或运行：

```bash
export CLAWBBA_API_KEY='cbb_sk_live_…'
node ~/.openclaw/skills/clawbba-api/scripts/fix-provider-config.mjs
openclaw gateway restart
```

4. 运行诊断：`node scripts/verify-openclaw-runtime.mjs`（需 `export CLAWBBA_API_KEY=…`）

**已装 1.1.0 的用户**：不必卸载，任选其一即可：

```bash
# 方式 A：一键重装（推荐，会拉 1.1.4）
export CLAWBBA_API_KEY='cbb_sk_live_…'
curl -fsSL https://www.clawbba.com/downloads/install-clawbba-api.sh | bash

# 方式 B：仅修复 provider（保留现有 skill 目录）
export CLAWBBA_API_KEY='cbb_sk_live_…'
node ~/.openclaw/skills/clawbba-api/scripts/fix-provider-config.mjs
openclaw gateway restart
```

## Gateway systemd（推荐）

```bash
sudo mkdir -p /etc/systemd/system/openclaw-gateway.service.d
sudo tee /etc/systemd/system/openclaw-gateway.service.d/clawbba.conf <<EOF
[Service]
Environment=CLAWBBA_API_KEY=cbb_sk_live_你的密钥
Environment=OPENROUTER_API_KEY=cbb_sk_live_你的密钥
EOF
sudo systemctl daemon-reload
sudo systemctl restart openclaw-gateway
```

**Q: 如何卸载？**  
A: `openclaw skills uninstall clawbba-api`（或 `clawhub uninstall clawbba-api`），并手动 `openclaw config unset models.providers.clawbba` 如需要。
