# ClawBBA 模型对照表（可选参考）

**默认流程：** 用户未指定模型时，Agent 直接调用 `image_generate` / `video_generate`，使用 `setup.sh` 写入的 **`imageGenerationModel.primary` / `videoGenerationModel.primary`**。**不要**强制弹出编号菜单。

本文件仅供：用户主动问「有哪些模型」、或话术中写了 `模型 google/…` 时查 `model_id`。

完整 model_id 表见 `clawbba-media-models.md`。

## ⛔ 与 `/model` 切换对话模型无关

| 操作 | 作用 | 适用 |
|------|------|------|
| `/model clawbba/deepseek/…` | 切换**文本对话**模型 | 聊天、推理 |
| `image_generate` 的 **`model` 参数** | 指定**生图**模型 | 生图 |
| `video_generate` 的 **`model` 参数** | 指定**生视频**模型 | 生视频 |

**禁止**用 `/model clawbba/google/gemini-…-image` 或 `/model openrouter/…-image` 来「选定生图模型」——OpenClaw 对话会话只能跑**文本模型**；生图必须调用 **`image_generate` 工具**，并在工具参数里写 `model`（未写则用内置默认）。

## 生图模型（编号仅作对照，非必须）

| 编号 | 称呼 | model_id |
|------|------|----------|
| **1** | Nano Banana 2（**默认·快**） | `google/gemini-3.1-flash-image-preview` |
| 2 | Nano Banana Pro | `google/gemini-3-pro-image-preview` |
| 3 | Nano Banana | `google/gemini-2.5-flash-image` |
| 4 | FLUX.2 Pro | `black-forest-labs/flux.2-pro` |
| 5 | FLUX.2 Max | `black-forest-labs/flux.2-max` |
| 6 | Seedream 4.5 | `bytedance-seed/seedream-4.5` |
| 7 | GPT-5.4 Image | `openai/gpt-5.4-image-2` |
| 8 | Grok Imagine | `x-ai/grok-imagine-image-quality` |

## 生视频模型

| 编号 | 称呼 | model_id |
|------|------|----------|
| **1** | Veo 3.1 Fast（**默认·快**） | `google/veo-3.1-fast` |
| 2 | Veo 3.1 | `google/veo-3.1` |
| 3 | Seedance 2.0 | `bytedance/seedance-2.0` |
| 4 | Kling 3.0 Pro | `kwaivgi/kling-v3.0-pro` |
| 5 | Sora 2 Pro | `openai/sora-2-pro` |
| 6 | Wan 2.7 | `alibaba/wan-2.7` |

## 用户仍说「模型编号 N」时

| 用户说法 | Agent 动作 |
|----------|------------|
| 模型编号 1 / 用 1 号 | 查上表 → `image_generate({ model: "<model_id>", … })` |
| 已写完整 model_id | 直接使用 |

## 推荐话术（默认模型，一条消息）

```
请使用 ClawBBA 生成图片能力，为我生成 9:16 竖图：（画面描述）
```

指定模型：

```
请使用 ClawBBA 生成图片能力，模型 black-forest-labs/flux.2-pro，为我生成 16:9 横图：（画面描述）
```
