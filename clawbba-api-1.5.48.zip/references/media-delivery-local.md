# 生图/生视频完成后：本地资产交付（OpenClaw 标准）

ClawBBA 通过 OpenClaw 的 `image_generate` / `video_generate` 生成媒体时，**文件会保存在用户 OpenClaw 机器本地**（用户资产），例如：

| 类型 | 典型目录 |
|------|----------|
| 图片 | `~/.openclaw/media/tool-image-generation/` |
| 视频 | `~/.openclaw/media/tool-video-generation/` |

**交付给用户应优先用 OpenClaw 本地路径 + `MEDIA:` 指令**，不要把 ClawBBA 公网 URL 当作主要方案。

## 正常流程

1. 用户发话术 → `Background task started` → Agent 只回「正在生成，请稍候」
2. 10–60 秒后 inter-session（`sourceTool=image_generate` 或 `video_generate`）
3. Completion agent **在同一条 assistant 回复**里写简短说明 + **`MEDIA:` 行**

## 成功时 Agent 必须做什么

在 Child result 里查找：

- **`Local delivery`** 块里的 `MEDIA:/root/.openclaw/media/...`
- 或 **Attachments** 里的 `path="/root/.openclaw/media/..."`

**复制到用户可见 assistant 回复：**

```text
已用 ClawBBA 生成图片（Flux.2 Pro · 16:9）

MEDIA:/root/.openclaw/media/tool-image-generation/image-1---xxxx.png
```

视频同理：

```text
已用 ClawBBA 生成视频（Veo · 16:9 · 8s）

MEDIA:/root/.openclaw/media/tool-video-generation/video-1.mp4
```

WebChat 会把 `MEDIA:` 解析为内联预览/可下载资产（路径在 `~/.openclaw/media` 允许范围内）。**用户文件留在本机**，不依赖 clawbba.com 链接是否过期。

## WebChat / Dashboard（重要）

| 禁止 | 原因 |
|------|------|
| `message` 工具 `action: send`（无有效 target） | Feishu 绑定会话报 `Action send requires a target` |
| 只把 `MEDIA:…` 写在日志/内心独白、不放进 assistant 最终回复 | 用户看不到 |
| 用 ClawBBA `https://www.clawbba.com/uploads/…` 代替本地 `MEDIA:` | 非用户资产；服务端会堆积文件 |

OpenClaw 内置 completion 可能仍写「必须用 message 工具」——**有 Local delivery / path= 时以本规则为准：assistant 回复 + MEDIA 行**。

**v1.1.9+ patch**（v1.1.10 起自动识别 **pnpm / npm** 全局 OpenClaw 路径）还会修改 OpenClaw `subagent-announce-delivery`：WebChat / Dashboard 的 `image_generate` / `video_generate` completion **不再**强制 `message_tool_only`（否则会 suppress 自动 MEDIA 交付，且 message 工具报 `Action send requires a target`）。

**v1.5.19+ patch**（recover 专用）：`chat.inject` 后通过 fallback gateway context 广播 `session.message` + 活跃 `options.runId` 触发 `chat.history` reload；生图/生视频后台 wake 路径同样加固。

**v1.5.15+ patch** 在 `video_generate action=recover` 下载到本机后立即 `chat.inject`，WebChat **无需刷新**即可看到 recover 的视频。

**v1.5.13+ patch** 在 `wakeMediaGenerationTaskCompletion`（生图/生视频任务刚完成时）通过 `chat.inject` 立即推送 `MEDIA:` 行到 WebChat，**无需刷新浏览器**；安装时会校验 `webchatLiveWake` + `announceLive` patch。

**v1.5.5+ patch** 在生图/生视频完成时通过 `chat.inject` 立即推送 `MEDIA:` 行到 WebChat，**无需刷新浏览器**（修复 OpenClaw 2026.5.27 在会话活跃时 `session.message` 延迟 reload 的问题）。

**v1.5.6+ patch** 将 WebChat 上传的参考图从会话消息解析为 `image_generate.image` / `images`（及视频的 `imageRoles`），对齐 OpenClaw 官方图生图参数；详见 `media-dispatch-spec.md` §3.1.1。

## 会话锁（session file locked）

若日志出现 `session file locked (timeout 60000ms)`：

```bash
# 确认无 stale 进程后
rm -f ~/.openclaw/agents/main/sessions/*.jsonl.lock
openclaw gateway restart
```

然后 **新开 WebChat 对话** 再试生图。

## 飞书原生会话

用户确实在飞书对话时，才用 `message` 工具，且 `target` 必须是有效飞书 ID；**不能**用 `current` / `webchat`。

## setup

```bash
export CLAWBBA_API_KEY='cbb_sk_live_…'
./skills/clawbba-api/scripts/setup.sh --yes
openclaw gateway restart
```

`setup.sh` 会运行 `patch-openclaw-media-delivery.mjs`（本地 MEDIA 交付）。若曾装 v1.1.5 公网 URL patch，本脚本会自动升级。
