# 已迁移

生图/生视频交付说明已改为 **本地资产 + MEDIA:** 方案，见：

**[`media-delivery-local.md`](./media-delivery-local.md)**

公网 `https://www.clawbba.com/uploads/agent-generated/…` 仅作 API 内部/异步轮询辅助，**不是**用户资产交付主路径。
