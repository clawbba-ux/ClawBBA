# ClawBBA 媒体模型 ID 规范（Model Ref Canon）

**唯一规则：** 用户说平台 id，OpenClaw 工具用 `openrouter/` + 同一平台 id。

## 1. 三种场景，三种前缀

| 场景 | 用户怎么说 | OpenClaw / Agent 怎么用 | 示例 |
|------|------------|-------------------------|------|
| **文本对话** | `/model` 或默认文本模型 | `clawbba/<platform-id>` | `clawbba/google/gemini-2.5-flash-preview` |
| **生图** | `请使用 ClawBBA 生成图片能力，模型 …` | `image_generate.model` = **`openrouter/<platform-id>`** | `openrouter/black-forest-labs/flux.2-pro` |
| **生视频** | `请使用 ClawBBA 生成视频能力，模型 …` | `video_generate.model` = **`openrouter/<platform-id>`** | `openrouter/google/veo-3.1-fast` |

**平台 id** = ClawBBA 模型目录里的 `vendor/model`，**不带** `clawbba/` 或 `openrouter/`。

## 2. 自动映射（clawbba-api 统一处理）

```
用户话术：模型 black-forest-labs/flux.2-pro
    ↓ strip clawbba/ | openrouter/（若有）
平台 id： black-forest-labs/flux.2-pro
    ↓ 生图/生视频 tool 必填前缀
OpenClaw： openrouter/black-forest-labs/flux.2-pro
    ↓ ClawBBA Platform API body.model
计费 id： black-forest-labs/flux.2-pro
```

实现位置：

| 层 | 作用 |
|----|------|
| Agent `systemPrompt` | 规则 + 映射表（`clawbba-media-model-ref.mjs`） |
| OpenClaw runtime patch | session 解析用户「模型 …」→ `openrouter/<id>`；Agent 若仍传 bare id 也会归一化 |
| `setup.sh` | `imageGenerationModel.primary` / `videoGenerationModel.primary` 已是 `openrouter/<默认>` |

**禁止：**

- ❌ `clawbba/black-forest-labs/flux.2-pro` → `No image-generation provider registered for clawbba`
- ❌ 裸 `black-forest-labs/flux.2-pro`（无 patch 时）→ `No image-generation provider registered for black-forest-labs`

## 3. 标准用户指令 → 工具参数

### 生图（你的示例）

**用户：**

```
请使用 ClawBBA 生成图片能力，模型 black-forest-labs/flux.2-pro，为我生成 16:9 横图：性感的韩国女性，皮肤白皙，爱笑，房间内灯光，展示身材
```

**Agent 必须：**

```javascript
image_generate({
  model: "openrouter/black-forest-labs/flux.2-pro",
  aspectRatio: "16:9",
  prompt: "性感的韩国女性，皮肤白皙，爱笑，房间内灯光，展示身材",
})
```

### 生视频

**用户：**

```
请使用 ClawBBA 生成视频能力，模型 google/veo-3.1-fast，为我生成 16:9、8 秒视频：海边日落
```

**Agent 必须：**

```javascript
video_generate({
  model: "openrouter/google/veo-3.1-fast",
  aspectRatio: "16:9",
  durationSeconds: 8,
  prompt: "海边日落",
})
```

## 4. 参数映射表（图片 + 视频）

### 生图 `image_generate`

| 用户话术 | 工具参数 | 值 |
|----------|----------|-----|
| `模型 black-forest-labs/flux.2-pro` | `model` | `openrouter/black-forest-labs/flux.2-pro` |
| `FLUX.2 Pro` | `model` | `openrouter/black-forest-labs/flux.2-pro` |
| `Nano Banana 2` | `model` | `openrouter/google/gemini-3.1-flash-image-preview` |
| `16:9` / `横图` / `横屏` | `aspectRatio` | `"16:9"` |
| `9:16` / `竖图` / `竖屏` | `aspectRatio` | `"9:16"` |
| `1:1` | `aspectRatio` | `"1:1"` |
| `2K` / `4K` / `1K` | `resolution` | `"2K"` / `"4K"` / `"1K"` |
| 冒号后画面描述 | `prompt` | **仅**画面描述（去掉「模型…」「16:9 横图…」前缀句） |

### 生视频 `video_generate`

| 用户话术 | 工具参数 | 值 |
|----------|----------|-----|
| `模型 google/veo-3.1-fast` | `model` | `openrouter/google/veo-3.1-fast` |
| `16:9` / `横图` | `aspectRatio` | `"16:9"` |
| `9:16` / `竖图` | `aspectRatio` | `"9:16"` |
| `8 秒` / `5秒` | `durationSeconds` | `8` / `5` |
| `720p` / `1080p` | `resolution` | `"720p"` / `"1080p"` |
| `带音频` / `不要音频` | `audio` | `true` / `false` |

## 5. 默认模型（用户未写「模型 …」）

`setup.sh` 写入：

```json
"imageGenerationModel": { "primary": "openrouter/google/gemini-3.1-flash-image-preview" },
"videoGenerationModel": { "primary": "openrouter/google/veo-3.1-fast" }
```

Agent **省略** `model` 参数即可。切换默认：

```bash
openclaw config set agents.defaults.imageGenerationModel.primary openrouter/black-forest-labs/flux.2-pro
openclaw config set agents.defaults.videoGenerationModel.primary openrouter/google/veo-3.1
```

## 6. 部署（一次性）

```bash
export CLAWBBA_API_KEY='cbb_sk_live_…'
cd ~/.openclaw/skills/clawbba-api
./scripts/setup.sh --yes
node scripts/patch-openclaw-media-delivery.mjs
node scripts/verify-openclaw-patch.mjs
openclaw gateway restart
```

验证：新开对话，发 §3 示例话术；日志不得出现 `No image-generation provider registered for black-forest-labs`。

## 7. 相关文档

- `references/media-dispatch-spec.md` — 话术 → 全参数 → API 字段
- `references/clawbba-media-models.md` — 友好名 → 平台 id
- `references/openclaw-integration-spec.md` — 架构与交付
