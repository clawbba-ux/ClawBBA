# ClawHub 上架与本地测试指南

Publisher：**clawbba-ux**

## 合规要点（ClawHub）

- 技能为公开文件夹 + 根目录 `SKILL.md`
- 发布即 **MIT-0**（见 `LICENSE`）
- 版本号必须 **semver**：如 `1.1.0`
- 包内 **不得** 包含真实 API Key
- 使用 `--clawscan-note`（CLI）或网页安全说明字段，描述外网访问与配置写入行为

## 1. 安装 ClawHub CLI（可选）

网页发布可跳过本节；CLI 适合脚本化或 CI。

```bash
npm i -g clawhub
clawhub --help
clawhub login
```

无浏览器环境：`clawhub login --token clh_…`

## 2. Publisher（clawbba-ux）

账户已绑定 Publisher `clawbba-ux` 时可跳过创建。

```bash
clawhub whoami
# 首次若无 publisher：
# clawhub publisher create clawbba-ux --display-name "ClawBBA"
```

## 3. 发布前检查

在本目录（`packages/clawbba-api`）执行：

```bash
clawhub inspect clawbba-ux/clawbba-api --files 2>/dev/null || true

# 干跑发布（若 CLI 支持）
clawhub skill publish . --version 1.1.0 --owner clawbba-ux --dry-run 2>/dev/null || true
```

## 4. 正式发布

### 方式 A — 网页（推荐）

1. 打开 https://clawhub.ai/skills/publish?ownerHandle=clawbba-ux  
2. 上传 `packages/clawbba-api-1.1.0.zip`（zip 解压后根目录须为 `SKILL.md`，见 §7）  
3. 填写 slug `clawbba-api`、版本 `1.1.0`、changelog  
4. ClawScan 说明（建议填写）：

   > Reads CLAWBBA_API_KEY from env, calls https://www.clawbba.com/api/v1 (balance/models/chat/videos), merges models.providers.clawbba + openrouter baseUrl for image_generate/video_generate, and writes image_options/video_options into openclaw.json. No bundled secrets.

### 方式 B — CLI

```bash
cd /var/www/crypto-payment-demo/packages/clawbba-api

clawhub skill publish . \
  --version 1.1.0 \
  --owner clawbba-ux \
  --clawscan-note "Reads CLAWBBA_API_KEY from env, calls https://www.clawbba.com/api/v1 (balance/models/chat/videos), merges models.providers.clawbba + openrouter baseUrl for image_generate/video_generate, and writes image_options/video_options into openclaw.json. No bundled secrets."
```

成功后访问：https://clawhub.ai/clawbba-ux/clawbba-api

## 5. 本机完整测试流程

### A. 未上架 — 本地目录安装

```bash
openclaw skills install /var/www/crypto-payment-demo/packages/clawbba-api --as clawbba-api --force
# 或
clawhub install /var/www/crypto-payment-demo/packages/clawbba-api --force
```

### B. 已上架 — 从 ClawHub 安装

```bash
openclaw skills install clawbba-api
# 或
clawhub install clawbba-api
```

### C. 配置 OpenClaw

在 https://www.clawbba.com/agent/api-keys 创建 Platform Key 后：

```bash
export CLAWBBA_API_KEY='cbb_sk_live_你的密钥'

# 进入技能目录（路径因 workspace 而异）
SKILL_DIR="$(find . -path '*/skills/clawbba-api/scripts/setup.sh' 2>/dev/null | head -1 | x dirname | x dirname)"
cd "$SKILL_DIR" || cd ./skills/clawbba-api

./scripts/verify-key.sh
./scripts/setup.sh
openclaw config validate
```

### D. 验证模型

```bash
openclaw models list | grep clawbba || openclaw config get models.providers.clawbba --json
```

重启 Gateway / 新开 OpenClaw 会话后，在 Agent 中选择 `clawbba/<model-id>`。

## 6. 更新版本

修改技能后 bump semver，重新打包（§7），再通过网页或 CLI 发布：

```bash
clawhub skill publish . --version 1.1.5 --owner clawbba-ux \
  --clawscan-note "Default image/video models; no mandatory numbered picker; see README changelog."
```

用户更新：`clawhub update clawbba-api` 或 `openclaw skills update clawbba-api`

## 7. 打包 zip（网页上传 / 发给他人）

**重要**：zip 解压后根目录必须是 `SKILL.md`，不能多一层 `clawbba-api/` 目录。

```bash
cd /var/www/crypto-payment-demo/packages/clawbba-api
bash scripts/pack-release-zip.sh
# 或手动（须排除误放的 openclaw-*.tgz，否则 zip 会膨胀到 ~23MB 且 unzip 可能异常）：
# zip -r ../clawbba-api-1.4.7.zip . -x '*.DS_Store' -x 'clawbba-openclaw.patch.json' -x '*.tgz' -x 'openclaw-*.tgz'
```

zip 位于：`packages/clawbba-api-1.1.5.zip`

**公网分发（部署到站点后可用）：**

```bash
# 复制到 public/downloads/（随 release 更新）
cp packages/clawbba-api-1.3.1.zip public/downloads/
cp packages/clawbba-api/scripts/install.sh public/downloads/install-clawbba-api.sh
chmod +x public/downloads/install-clawbba-api.sh
```

用户一键命令：

```bash
export CLAWBBA_API_KEY='cbb_sk_live_…'
curl -fsSL https://www.clawbba.com/downloads/install-clawbba-api.sh | bash
```

Zip 直链：`https://www.clawbba.com/downloads/clawbba-api-1.1.5.zip`

验证结构：

```bash
unzip -l packages/clawbba-api-1.1.5.zip | head
# 应看到 SKILL.md、scripts/、references/ 等在 zip 根路径，而非 clawbba-api/SKILL.md
```
