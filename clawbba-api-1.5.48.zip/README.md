# clawbba-api

Connect [OpenClaw](https://docs.openclaw.ai/) to the [ClawBBA Platform API](https://www.clawbba.com/api/v1) with your `cbb_sk_live_…` key — chat, image, and video models through one OpenAI-compatible endpoint.

## Quick start

1. Register / sign in: https://www.clawbba.com  
2. Top up balance: https://www.clawbba.com/product/CDKEY  
3. Create API key: https://www.clawbba.com/agent/api-keys  
4. **One-line install on your OpenClaw machine:**

```bash
export CLAWBBA_API_KEY='cbb_sk_live_YOUR_KEY'
curl -fsSL https://www.clawbba.com/downloads/install-clawbba-api.sh | bash
```

5. Restart OpenClaw Gateway or start a new agent session (the script tries `openclaw gateway restart`).

Manual setup (if skill already installed):

```bash
export CLAWBBA_API_KEY='cbb_sk_live_YOUR_KEY'
export OPENROUTER_API_KEY="$CLAWBBA_API_KEY"
./scripts/setup.sh --yes
openclaw config validate
```

## Image & video in OpenClaw (2026.5+)

After `setup.sh`, OpenClaw’s built-in **`image_generate`** and **`video_generate`** tools call the same ClawBBA Platform API (via repointed `models.providers.openrouter`). See [references/media-generation.md](./references/media-generation.md).

```bash
export OPENROUTER_API_KEY="$CLAWBBA_API_KEY"
/tool image_generate action=list
/tool video_generate action=list
```

## Install from ClawHub

Publisher: [clawbba-ux/clawbba-api](https://clawhub.ai/clawbba-ux/clawbba-api)

```bash
npm i -g clawhub
clawhub login
clawhub install clawbba-api
cd skills/clawbba-api   # or your workspace skills path
export CLAWBBA_API_KEY='cbb_sk_live_YOUR_KEY'
./scripts/setup.sh
```

Or with OpenClaw CLI:

```bash
openclaw skills install clawbba-api
export CLAWBBA_API_KEY='cbb_sk_live_YOUR_KEY'
./skills/clawbba-api/scripts/setup.sh
```

## Verify key only

```bash
CLAWBBA_API_KEY='cbb_sk_live_…' ./scripts/verify-key.sh
```

## Changelog

### 1.5.43

- **Fix:** WebChat 执行 `/tool image_generate action=tasks` 无输出 — 微信绑定 session 会先走 `sendMessage` 且 `clawbbaShouldInjectWebChatMediaLive` 为 false，导致跳过 `chat.inject`；现 **有 `chatRunId` 时优先 WebChat inject**（Dashboard `/tool` 场景）。
- **Fix:** Agent 规则补充 — `action=tasks|list|status` 须原文回显工具结果，避免空回复。

### 1.5.42

- **Fix（严重）:** 1.5.41 导致 Gateway 无法监听 18789 — `clawbbaListImageTasks` / `clawbbaListVideoTasks` 内 HTTP 响应体与任务列表均声明 `const text`，`openclaw-tools` **SyntaxError**，systemd 显示 running 但端口未监听。已改为 `responseText` + `taskListText`；patch 完成后强制 `node --check openclaw-tools-*.js`。

### 1.5.41

- **Fix:** `/tool image_generate action=tasks`（及 `video_generate action=tasks`）工具执行成功但 Agent 空回复 → `incomplete turn … payloads=0` — 只读 action 完成后**直接推送**任务列表到 WebChat（`chat.inject`）/ 微信等渠道（`sendMessage`），并抑制随后的 incomplete-turn 错误提示。

### 1.5.40

- **Fix:** `image_generate action=tasks|recover` 报 `action must be "generate", "status", or "list"` — patch 漏改 `resolveAction$2` 的 allowed 列表；现与 execute handler 一致放行 `tasks` / `recover`。

### 1.5.39

- **Fix:** 图片/进度仍发到错误会话 — 1.5.38 误用 `handle.runId`（`tool:Image generation:…` 工具 run）作 WebChat `chatRunId`；controller 找不到后回退到**其它活跃会话**。现改为 `requesterChatRunId: options.runId`（用户聊天 run，如 `f7ecaee3-…`），且指定 runId 不存在时**不再**误绑其它 tab。

### 1.5.38

- **Fix:** 进度「已等待 480 分」— SQLite `datetime('now')` 为 UTC，Node 按本地解析导致 +8h 偏差；服务端 `parseSqliteUtcDateMs` 统一按 UTC 计算 elapsed。
- **Fix:** 新建会话但图片/进度发到旧会话 — WebChat 广播不再 loose-match 所有 `:main`；`chatRunId` 绑定 task handle.runId（进度 inject + wake 完成）；每任务重置 poll progress 锚点。

### 1.5.37

- **Feature:** 生图超时恢复（对齐 `video_generate recover`）— `image_generate action=tasks` 列出 ClawBBA job；`action=recover jobId=<id> timeoutMs=600000` 轮询 `GET /api/v1/images/generations/:id` 并下载到 `~/.openclaw/media/tool-image-generation/`（**不二次扣费**）。
- **Feature:** 后台生图任务超时/失败时 OpenClaw **自动 recover**（已知 `job_id` 或 `globalThis.__clawbbaLastImageJobId`），WebChat 即时注入 MEDIA。
- **API:** `GET /api/v1/images/tasks`；poll 响应含 `clawbba_recovery.recover_hint`。

### 1.5.36

- **Fix:** 上游已 `completed` 但 OpenClaw 永不取图 — 旧 poll 在 `data` 无 inline 图时 **无限 2s 轮询**（进度条可到 100% 但 `generateImage` 不返回）。v6：completed 时从 `pollBody.images` https 回退下载；否则立即报错。服务端 poll GET 自动 **重建 data URL**（`enrichCompletedImageJobForPoll`）。
- **Fix:** Agent `read ~/.openclaw/media` → EISDIR — 规则改为禁止读目录；参考图解析拒绝裸 `~/.openclaw/media` 路径。
- **UX:** 进度推送节流（keepalive 5s→12s，里程碑最小间隔 25s），减轻微信通道负载。

### 1.5.35

- **Fix:** `gpt-5.4-image-*` 已扣费但 180s 超时无图 — OpenClaw async poll v5：**202 后立即 `release()` POST fetch guard**（不再与 `fetchWithSsrFGuard` 共用 180s 计时）；轮询上限改为 **15 分钟**（不再用 `req.timeoutMs` 180000 截断）。`setup.sh` 写入 `imageGenerationModel.timeoutMs: 600000`。

### 1.5.34

- **Fix:** Gateway `clawbbaInjectMediaProgressLive has already been declared` — 修复 dedupe 在模板字符串 `{}` 处误截断；安装时 strip 重复 export 并重建单一 WebChat helper 块。

### 1.5.33

- **Fix:** 1.5.32 安装后 Gateway 无法启动 — `image-generation-provider` 进度 helper 误插入对象字面量内（ParseError）；`clawbbaInjectMediaProgressLive` 重复声明。安装时会自动 dedupe + repair。

### 1.5.32

- **UX:** 生图/生视频后台任务期间自动推送进度（百分比 + 进度条 + 已等待时间）。WebChat 经 `chat.inject`；微信/Telegram 等外部渠道经 `sendMessage`；轮询 GET job 返回 `progress_percent` / `progress_bar`。

### 1.5.31

- **Fix:** 202 异步 job 轮询 `Failed to parse URL from /api/v1/images/generations/...` — 服务端 `poll_url` 改为绝对 URL；OpenClaw patch v4 在客户端将相对路径解析为 `https://www.clawbba.com/api/v1/...`。

### 1.5.30

- **Fix:** 生图 `ReadableStream is locked` — patch 在 `response.json()` 后不再调用 `assertOkOrThrowHttpError`（避免重复读 body）；清理 v2 升级遗留的重复代码块。
- **Fix:** 202 异步 job 轮询 `missing image data` — 服务端 job 结果改为写入 **data:image** inline URL（OpenClaw 只认 data URL，不认 https）。

### 1.5.29

- **Fix:** `openai/gpt-5.4-image-*` 生图经 ClawBBA 网关 504 / 已扣费无图 — 慢模型改 **202 异步 job**；OpenClaw provider **轮询直到出图**（`clawbba-image-async-job-poll-v2`，无固定 900s 总超时）。服务端上游 fetch 亦等到返回或断连 recovering。

### 1.5.27

- **UX:** 生图/生视频 Child result 与 WebChat 注入文案中，`Generated … with openrouter/…` 改为用户可见的 `ClawBBA/<平台模型>`；内部仍用 `openrouter/` 调用，功能不变。

### 1.5.26

- **Fix:** 安装校验 `verify-openclaw-patch.mjs` 漏 import `recoverFnHasWebChatDispatchInject`，导致 `ReferenceError` 与「patch 仍未就绪」误报。

### 1.5.25

- **Fix:** `dispatchGatewayMethodInProcess is not a function` — OpenClaw `server-plugins-*.js` 只导出 minified 名 `r`；inject 改用 `clawbbaPickModuleExport(..., ["r"])`，gateway context 同理（`t`/`n`）。

### 1.5.24

- **Fix:** recover 仍须刷新 — patch 误把 `server-plugins-*.d.ts` 写入 dynamic import，运行时报 `Stripping types is currently unsupported`，`clawbba webchat media live inject failed`；`findDistJsFile` 只选 `.js`，并自动修复已打 patch 机器上的 `.d.ts` import。

### 1.5.23

- **Fix:** WebChat `video_generate action=recover` 完成后仍须刷新 — 活跃 run 期间 `session.message` 会被 Control UI 延迟；reload 依赖 `chatAbortControllers` 命中 runId，长时间 recover 后 controller 可能已过期。现强制使用 `options.runId` 广播空 `final` 触发 `chat.history`，并向 raw/canonical 双 sessionKey 投递。

### 1.5.22

- **Fix:** 1.5.21 zip 漏导出 `ensureRecoverFnParams` / `recoverFnHasAgentSessionKeyParam`，导致 patch 与 verify 运行时 ReferenceError / SyntaxError。

### 1.5.21

- **Fix:** `video_generate action=recover` 报 `agentSessionKey is not defined` — 遗留 inject 引用 `agentSessionKey` 但 `clawbbaRecoverVideoTask` 函数签名未声明；升级误判「文件含 agentSessionKey 字符串」而跳过补参；verify 增加函数签名校验。

### 1.5.20

- **Fix:** recover 仍走 1.5.15 遗留 `__clawbbaSk.includes("webchat")` 分支（`agent:main:main` 永不触发 inject）— 升级误判「文件里已有 dispatch 函数」；现按 `clawbbaRecoverVideoTask` 函数体校验并强制替换。

### 1.5.19

- **Fix:** `video_generate action=recover` WebChat 仍须刷新 — 生图/生视频走 wake/announce（后台完成）；recover 是前台同步工具，无 gateway ALS scope，且 `chatAbortControllers` 存 raw sessionKey、`options.runId` 未传入。现用 fallback gateway context + `chatRunId` + `session.message`/`sessions.changed` 三重 reload，与 OpenClaw WebChat 规范对齐。

### 1.5.18

- **Fix:** 1.5.17 从 1.5.16 升级时 patch 校验失败（`video recover WebChat live inject`）— 升级用正则未转义 `/* */` 导致静默未写入 `clawbbaPromptWebChatHistoryReload`；并加强校验与手术式回退升级。

### 1.5.17

- **Fix:** WebChat `recover`/前台工具完成后仍须刷新 — `chat.inject` 使用 `runId=inject-*`，与活跃 `chatRunId` 不匹配时 Control UI 不会拉 `chat.history`；注入后额外用活跃 run 广播空 `final` 触发即时 reload。

### 1.5.16

- **Fix:** `video_generate action=recover` WebChat 仍须刷新 — 1.5.15 误判 session（`agent:main:main` 不含 `webchat` 字符串）；改用 OpenClaw 原生 `parseAgentSessionKey` / `inferDeliveryFromSessionKey` 判定内部渠道，并直接 `dispatchGatewayMethodInProcess('chat.inject')`。

### 1.5.15

- **Fix:** WebChat 执行 `video_generate action=recover` 后需刷新才显示视频 — recover 完成时 `chat.inject` 推送 `MEDIA:`（与后台生图/生视频 wake 路径同类问题）。

### 1.5.14

- **修复 Gateway 无法启动**：1.5.13 重复注入 `clawbbaInjectWebChatGeneratedMediaLive` 导致 `already been declared`；安装时自动 dedupe，wake 路径改用动态 `import()`。

### 1.5.13

- **WebChat 即时显示（加固）**：在 `wakeMediaGenerationTaskCompletion` 完成时 `chat.inject` 推送 `MEDIA:`（不依赖 announce steer 分支）；导出 `clawbbaInjectWebChatGeneratedMediaLive`；安装必检 `webchatLiveWake` + `announceLive`；`ensure-openclaw-patches.sh` 不再吞掉 patch 失败。

### 1.5.12

- **Fix:** WebChat 生图/生视频完成后需刷新浏览器 — 适配 OpenClaw 新版 `resolveQueueEmbeddedPiMessageOutcome`；`chat.inject` live patch；`install` 强制校验 `announceLive`

### 1.5.11

- **Fix:** `--flux-only` 校验误报失败（已 patch 且全 ✓ 仍提示「patch 仍未就绪」）— 修正 critical 计数；已装完整 patch 时自动识别通过

### 1.5.10

- **Change:** 安装流程用 `ensure-openclaw-patches.sh` 自动打 patch + 验证 + 失败重试；`gateway restart` 仍由 install 自动执行，无需再手动跑 patch 命令

### 1.5.9

- **Fix:** `verify-openclaw-patch.mjs` 恢复 `path` 导入（1.5.8 误删导致 ReferenceError）

### 1.5.8

- **Change:** 安装/验证日志与 patch 检查项改为 **ClawBBA** 展示名（内部仍用 OpenClaw `openrouter` provider，功能不变）

### 1.5.7

- **Fix:** 文本对话上传图片 — `models.providers.clawbba` 为 vision 文本模型标记 `input: ["text","image"]`；`agents.defaults.imageModel` 指向 `clawbba/<vision-文本>`，不再误用 `openrouter/flux.*` 做「Describe this image」
- **New:** `fix-openclaw-vision-config.mjs`、`clawbba-vision-models.mjs`；`verify-openclaw-runtime` 校验 `imageModel`
- **Doc:** `openclaw-integration-spec.md` §1.1 区分聊天看图 vs 生图

### 1.1.6

- **Change:** 媒体交付改为 **OpenClaw 本地资产 + `MEDIA:`**（图片/视频）；`patch-openclaw-media-delivery.mjs` 替代公网 URL 方案；Agent 规则禁止依赖 clawbba.com/uploads 作主交付
- **Doc:** `references/media-delivery-local.md`

### 1.1.5

- **Fix:** 生图成功后 WebChat 自动交付 — API 响应携带 `CLAWBBA_IMAGE_URLS` + 公网 Markdown；`setup.sh` 运行 `patch-openclaw-image-delivery.mjs` 注入 completion 通知；Agent 规则禁止 WebChat 使用 `message` 工具发图
- **Doc:** `references/image-delivery-webchat.md`

### 1.1.4

- **Change:** 取消强制「模型编号」菜单；未指定模型时使用 `imageGenerationModel.primary` / `videoGenerationModel.primary`
- **Docs:** `openclaw-agent-behavior.md` — 禁止 `/model` 切换生图；`Background task started` 后只回复一句
- **Sync:** API Keys 页 OpenClaw 接入改为默认话术 + 可选模型 chips（v1.1.4）

### 1.1.3

- **New:** `references/model-picker.md` — 生图 1–8、生视频 1–6 编号菜单与 Agent 话术模板
- **Docs:** `openclaw-agent-behavior.md` — 生图前必须弹出编号菜单；禁止向用户提及 OpenRouter
- **Docs:** `SKILL.md` — 编号选模型用户话术；`always: true` + systemPrompt 注入 ClawBBA 品牌规则
- **Fix:** `setup.sh` 安装后提示编号引导与 OpenRouter 翻译说明
- **Sync:** API Keys 页 OpenClaw 一键接入与生图模型编号 chips 对齐

### 1.1.1

- **Fix:** 安装时向 `models.json` / `openclaw.json` 写入**真实** `cbb_sk_live_…`（不再使用 `${CLAWBBA_API_KEY}` 占位符，避免 WebChat `403 Your request was blocked`）
- **Fix:** 为 `clawbba` / `openrouter` provider 添加 `headers.User-Agent`（OpenClaw pi 客户端兼容）
- **New:** `scripts/fix-provider-config.mjs` — 已装 1.1.0 用户一键修复
- **New:** `scripts/verify-openclaw-runtime.mjs` — 安装后自检（setup 失败则中断）
- **Docs:** `references/error-translation.md` — 禁止向用户复述 OpenRouter；工具报错翻译模板
- **Fix:** skill `always: true` + `agents.defaults.systemPrompt` 注入 ClawBBA 品牌规则（安装时写入）
- **Docs:** `references/clawbba-media-models.md` — 全部生图/生视频 model_id、用户话术模板、模型切换说明
- **Docs:** 完善 `media-generation.md` / `onboarding.md` 与 API Keys 页模型一键复制话术

### 1.1.0

- 全量模型 catalog、sync agent `models.json`、公网一键安装脚本

## License

MIT-0 (see [LICENSE](./LICENSE)). Publishing on ClawHub releases this skill under MIT-0 per ClawHub policy.

## Links

- API base: `https://www.clawbba.com/api/v1`
- Docs in skill: `references/onboarding.md`, `references/api-endpoints.md`
- Publish guide: [PUBLISH.md](./PUBLISH.md)
