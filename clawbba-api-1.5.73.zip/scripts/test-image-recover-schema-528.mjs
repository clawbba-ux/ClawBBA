#!/usr/bin/env node
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import {
  ensureImageRecoverSchemaProps,
  imageGenerateSchemaHasRecoverJobId,
  patchImageGenerateRecoverAction,
} from './clawbba-image-recover-patch.mjs'

const sourceTools = process.argv[2] || '/tmp/oc528/package/dist/openclaw-tools-C1FG9NMc.js'
let src = fs.readFileSync(sourceTools, 'utf8')
assert.ok(!src.includes('ClawBBA image job_id'), 'vanilla dist should lack jobId prop')

const patched = ensureImageRecoverSchemaProps(src)
assert.ok(patched.includes('ClawBBA image job_id'))
assert.ok(imageGenerateSchemaHasRecoverJobId(patched), 'jobId must be inside ImageGenerateToolSchema')
assert.ok(patched.includes('action=tasks'))
assert.ok(patched.includes('action=recover'))

const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'clawbba-img-schema-'))
const toolsPath = path.join(tmpDir, path.basename(sourceTools))
fs.copyFileSync(sourceTools, toolsPath)
assert.equal(patchImageGenerateRecoverAction(toolsPath), 'patched')
const out = fs.readFileSync(toolsPath, 'utf8')
assert.ok(out.includes('ClawBBA image job_id'))
assert.ok(out.includes('clawbbaListImageTasks'))

console.log('test-image-recover-schema-528: ok')
