#!/usr/bin/env node
/**
 * 修复 openclaw.json 中 models.providers 结构（OpenClaw 2026.5+）
 * - openrouter.models 必须为完整 ModelDefinitionConfig[]（不能只删 key）
 * - 移除残缺/从 clawbba 误拷的 models 条目，改为生图/生视频合法列表
 */
import fs from 'fs'
import {
  buildClawbbaProviderBlock,
  buildMinimalModelDefinition,
  buildOpenrouterMediaModelsFromCatalogRows,
  buildOpenrouterProviderBlock,
  buildStaticOpenrouterMediaModels,
  enrichAgentModelsProviderBlock,
  isValidOpenclawModelDefinition,
  openrouterModelsNeedRebuild,
} from './openclaw-provider-block.mjs'
import {
  applyVisionInputToProviderEntry,
  normCatalogCategory,
  rowSupportsVisionInput,
} from './clawbba-vision-models.mjs'
import {
  discoverAgentModelPaths,
  getOpenclawHome,
  getOpenclawJsonPath,
} from './openclaw-paths.mjs'

const API_BASE = (process.env.CLAWBBA_API_BASE || 'https://www.clawbba.com/api/v1').replace(
  /\/$/,
  '',
)
const API_KEY = String(process.env.CLAWBBA_API_KEY || '').trim()

async function fetchCatalogFromApi() {
  if (!API_KEY.startsWith('cbb_sk_live_')) return { mediaModels: null, rows: [] }
  const res = await fetch(`${API_BASE}/models`, {
    headers: { Authorization: `Bearer ${API_KEY}`, Accept: 'application/json' },
  })
  if (!res.ok) return { mediaModels: null, rows: [] }
  const body = await res.json()
  const rows = Array.isArray(body.data) ? body.data : []
  const media = buildOpenrouterMediaModelsFromCatalogRows(rows)
  return { mediaModels: media.length ? media : null, rows }
}

function sanitizeClawbbaModelEntry(m, catalogRow) {
  if (!m || typeof m !== 'object') return null
  const id = String(m.id || '').trim()
  if (!id) return null
  const cat = catalogRow
    ? normCatalogCategory(catalogRow)
    : /image|dall|flux|seedream|grok-imagine-image/i.test(id)
      ? 'image'
      : /veo|video|seedance|kling|sora|wan-|hailuo/i.test(id)
        ? 'video'
        : 'text'
  const category = cat === 'image' ? 'image' : cat === 'video' ? 'video' : 'text'
  let entry = isValidOpenclawModelDefinition(m)
    ? { ...m }
    : buildMinimalModelDefinition(id, m.name || id, category, {
        visionText: category === 'text' && rowSupportsVisionInput(catalogRow || { id, category: 'text' }),
      })
  if (catalogRow) entry = applyVisionInputToProviderEntry(entry, catalogRow)
  else if (category === 'text' && rowSupportsVisionInput({ id, category: 'text' })) {
    entry = applyVisionInputToProviderEntry(entry, { id, category: 'text' })
  }
  return entry
}

/**
 * @param {Record<string, unknown>} providers
 * @param {{ apiKey?: string, openrouterMediaModels?: unknown[] }} [opts]
 */
export function sanitizeOpenclawProviders(providers, opts = {}) {
  const catalogById = new Map()
  for (const row of opts.catalogRows || []) {
    const id = String(row?.id || '').trim()
    if (id) catalogById.set(id, row)
  }
  if (!providers || typeof providers !== 'object') return false
  let changed = false
  const key = opts.apiKey || API_KEY

  for (const providerKey of ['clawbba', 'openrouter']) {
    const provider = providers[providerKey]
    if (provider && typeof provider === 'object' && Object.prototype.hasOwnProperty.call(provider, 'label')) {
      delete provider.label
      changed = true
    }
  }

  const mediaModels =
    opts.openrouterMediaModels ||
    (Array.isArray(providers.openrouter?.models) &&
    !openrouterModelsNeedRebuild(providers.openrouter.models)
      ? providers.openrouter.models
      : null)

  if (providers.openrouter && typeof providers.openrouter === 'object') {
    const needRebuild =
      openrouterModelsNeedRebuild(providers.openrouter.models) ||
      !Array.isArray(mediaModels)
    const nextModels = needRebuild
      ? buildStaticOpenrouterMediaModels()
      : mediaModels
    const next = key.startsWith('cbb_sk_live_')
      ? buildOpenrouterProviderBlock(key, { models: nextModels })
      : buildOpenrouterProviderBlock('', { models: nextModels })
    if (JSON.stringify(providers.openrouter) !== JSON.stringify(next)) {
      providers.openrouter = next
      changed = true
    }
  }

  const clawbba = providers.clawbba
  if (clawbba && Array.isArray(clawbba.models)) {
    const cleaned = clawbba.models
      .map((m) => sanitizeClawbbaModelEntry(m, catalogById.get(String(m?.id || '').trim())))
      .filter(Boolean)
    const invalid = clawbba.models.some((m) => !isValidOpenclawModelDefinition(m))
    const visionStale = clawbba.models.some((m, i) => {
      const row = catalogById.get(String(m?.id || '').trim())
      if (!row || !rowSupportsVisionInput(row)) return false
      const next = cleaned[i]
      return next && !(Array.isArray(next.input) && next.input.includes('image'))
    })
    if (invalid || visionStale || cleaned.length !== clawbba.models.length) {
      if (key.startsWith('cbb_sk_live_')) {
        providers.clawbba = buildClawbbaProviderBlock(key, { models: cleaned })
      } else {
        clawbba.models = cleaned
      }
      changed = true
    }
  }

  return changed
}

function patchFile(filePath, openrouterMediaModels, catalogRows = []) {
  let parsed
  try {
    parsed = JSON.parse(fs.readFileSync(filePath, 'utf8'))
  } catch (e) {
    process.stderr.write(`[clawbba-api] 跳过 ${filePath}: ${e.message || e}\n`)
    return false
  }
  const isAgentModelsJson = Boolean(parsed.providers && typeof parsed.providers === 'object')
  const providers = parsed.providers || parsed.models?.providers
  if (!providers) return false
  let changed = sanitizeOpenclawProviders(providers, {
    openrouterMediaModels,
    catalogRows,
    apiKey: API_KEY,
  })
  if (isAgentModelsJson) {
    for (const key of ['clawbba', 'openrouter']) {
      if (!providers[key]) continue
      const next = enrichAgentModelsProviderBlock(key, providers[key])
      if (next !== providers[key]) {
        providers[key] = next
        changed = true
      }
    }
  }
  if (!changed) return false
  fs.writeFileSync(filePath, `${JSON.stringify(parsed, null, 2)}\n`, { mode: 0o600 })
  return true
}

async function main() {
  const { mediaModels: apiMedia, rows: catalogRows } = await fetchCatalogFromApi()
  const openrouterMediaModels = apiMedia || buildStaticOpenrouterMediaModels()
  process.stderr.write(
    `[clawbba-api] ClawBBA 生图/生视频模型 ${openrouterMediaModels.length} 个（${apiMedia ? '来自 API' : '静态表'}）\n`,
  )

  const home = getOpenclawHome()
  let n = 0
  const openclawJson = getOpenclawJsonPath(home)
  if (fs.existsSync(openclawJson) && patchFile(openclawJson, openrouterMediaModels, catalogRows)) {
    n += 1
    process.stderr.write('[clawbba-api] 已修复 openclaw.json（ClawBBA 媒体模型表）\n')
  }
  for (const p of discoverAgentModelPaths(home)) {
    if (patchFile(p, openrouterMediaModels, catalogRows)) {
      n += 1
      const rel = p.startsWith(home) ? p.slice(home.length + 1) : p
      process.stderr.write(`[clawbba-api] 已修复 ${rel}\n`)
    }
  }
  if (!n) {
    process.stderr.write('[clawbba-api] provider schema 无需修复\n')
  } else {
    process.stderr.write('[clawbba-api] 请执行: openclaw config validate && openclaw gateway restart\n')
  }
}

main().catch((e) => {
  process.stderr.write(`[clawbba-api] ${e.message || e}\n`)
  process.exit(1)
})
