#!/usr/bin/env node
import assert from 'node:assert/strict'
import {
  buildOpenclawVideoPrompt,
  buildOpenclawVideoPromptEn,
  buildOpenclawVideoPromptForModel,
  VIDEO_PROMPT_CHINESE_MODEL_IDS,
} from './clawbba-openclaw-media-catalog.mjs'

const zh = buildOpenclawVideoPromptForModel({ id: 'bytedance/seedance-2.0', ratio: '9:16', duration: 5 })
assert.ok(zh.startsWith('请使用 ClawBBA 生成视频能力'), 'seedance chinese')
assert.ok(zh.includes('模型 bytedance/seedance-2.0'), 'seedance model id')

const en = buildOpenclawVideoPromptForModel({ id: 'google/veo-3.1-fast', ratio: '16:9', duration: 8 })
assert.ok(en.startsWith('Use ClawBBA video generation'), 'veo english')
assert.ok(en.includes('model google/veo-3.1-fast'), 'veo model id')

for (const id of VIDEO_PROMPT_CHINESE_MODEL_IDS) {
  const p = buildOpenclawVideoPromptForModel({ id, ratio: '16:9', duration: 5 })
  assert.ok(p.startsWith('请使用 ClawBBA'), `${id} should be chinese`)
}

assert.ok(buildOpenclawVideoPromptEn().includes('Ocean waves'), 'en default desc')
assert.ok(buildOpenclawVideoPrompt().includes('海浪'), 'zh default desc')

console.log('test-openclaw-video-prompt-locale: ok')
