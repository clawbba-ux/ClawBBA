#!/usr/bin/env node
/**
 * 安装末尾：强制 clawbba 默认对话模型 + 同步各 Agent models.json（新建会话 from ClawBBA）。
 *
 * 用法: node scripts/ensure-clawbba-session-branding.mjs [clawbba-openclaw.patch.json]
 */
import fs from 'fs'
import { getOpenclawJsonPath } from './openclaw-paths.mjs'
import {
  applyClawbbaSessionBranding,
  syncAgentModelsFromOpenclawCfg,
} from './clawbba-openclaw-config-branding.mjs'

const patchFile = process.argv[2]
let patch = null
if (patchFile && fs.existsSync(patchFile)) {
  try {
    patch = JSON.parse(fs.readFileSync(patchFile, 'utf8'))
  } catch (e) {
    process.stderr.write(`[clawbba-api] 无法读取 patch: ${e.message || e}\n`)
    process.exit(1)
  }
}

const cfgPath = getOpenclawJsonPath()
if (!fs.existsSync(cfgPath)) {
  process.stderr.write(`[clawbba-api] ✗ 未找到 ${cfgPath}\n`)
  process.exit(1)
}

const cfg = JSON.parse(fs.readFileSync(cfgPath, 'utf8'))
const { changed, chatPrimary } = applyClawbbaSessionBranding(cfg, { patch })

if (!chatPrimary.startsWith('clawbba/')) {
  process.stderr.write(
    `[clawbba-api] ✗ agents.defaults.model.primary 不是 clawbba/…（当前 ${chatPrimary || '(空)'}）。请重跑 generate-openclaw-patch + apply-openclaw-config\n`,
  )
  process.exit(1)
}

if (changed) {
  fs.writeFileSync(cfgPath, `${JSON.stringify(cfg, null, 2)}\n`, { mode: 0o600 })
  process.stderr.write(
    `[clawbba-api] ✓ session branding: chatPrimary=${chatPrimary}, agents.list + clawbba-api skill\n`,
  )
} else {
  process.stderr.write(`[clawbba-api] ✓ session branding ok: chatPrimary=${chatPrimary}\n`)
}

const sync = syncAgentModelsFromOpenclawCfg(cfg)
process.stderr.write(
  `[clawbba-api] agent models.json: checked=${sync.checked} updated=${sync.updated} expected=${sync.expected}\n`,
)
