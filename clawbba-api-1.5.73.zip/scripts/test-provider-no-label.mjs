#!/usr/bin/env node
import assert from 'node:assert/strict'
import {
  buildClawbbaProviderBlock,
  buildOpenrouterProviderBlock,
} from './openclaw-provider-block.mjs'
import { sanitizeOpenclawProviders } from './fix-openclaw-provider-schema.mjs'

const clawbba = buildClawbbaProviderBlock('cbb_sk_live_test', {
  models: [{ id: 'google/gemini-2.0-flash-001', name: 'x', reasoning: false, input: ['text'], cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 }, contextWindow: 128000, maxTokens: 8192 }],
})
const openrouter = buildOpenrouterProviderBlock('cbb_sk_live_test')
assert.equal('label' in clawbba, false)
assert.equal('label' in openrouter, false)

const providers = {
  clawbba: { ...clawbba, label: 'ClawBBA' },
  openrouter: { ...openrouter, label: 'ClawBBA' },
}
assert.equal(sanitizeOpenclawProviders(providers, { apiKey: 'cbb_sk_live_test' }), true)
assert.equal('label' in providers.clawbba, false)
assert.equal('label' in providers.openrouter, false)
console.log('test-provider-no-label: ok')
