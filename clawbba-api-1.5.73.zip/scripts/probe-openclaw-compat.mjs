#!/usr/bin/env node
/**
 * 探测本机 OpenClaw dist 的 announce / wake 模式（升级后自检）
 * 用法: node scripts/probe-openclaw-compat.mjs
 */
import fs from 'fs'
import { ANNOUNCE_PATCHES_ORDERED } from './openclaw-announce-patch.mjs'
import { findAllOpenclawDists, findDistJsFile, formatOpenclawDistDiscoveryReport } from './openclaw-dist-paths.mjs'
import { formatOpenClawCompatReport, resolveOpenClawCompatProfile } from './openclaw-compat-profiles.mjs'

function findDistFile(dist, prefix) {
  return findDistJsFile(dist, prefix)
}

function detectAnnounce(filePath) {
  const src = fs.readFileSync(filePath, 'utf8')
  if (src.includes('clawbbaLocalMediaWebChatCompletion')) return 'already-patched'
  for (const p of ANNOUNCE_PATCHES_ORDERED) {
    if (src.includes(p.needle)) return p.id
  }
  return 'unknown'
}

function detectWake(toolsPath) {
  const src = fs.readFileSync(toolsPath, 'utf8')
  if (src.includes('localMedia = mediaUrls.filter')) return 'patched'
  if (src.includes('buildMediaGenerationReplyInstruction')) return 'patchable'
  return 'unknown'
}

const dists = findAllOpenclawDists()
if (!dists.length) {
  console.error('[clawbba-api] 未找到 OpenClaw dist')
  process.exit(1)
}

console.log(formatOpenClawCompatReport(resolveOpenClawCompatProfile()))
console.log(formatOpenclawDistDiscoveryReport(dists))
for (const dist of dists) {
  const announce = findDistFile(dist, 'subagent-announce-delivery-')
  const tools = findDistFile(dist, 'openclaw-tools-')
  console.log(`\n[dist] ${dist}`)
  if (announce) {
    console.log(`  announce: ${detectAnnounce(`${dist}/${announce}`)} (${announce})`)
  } else {
    console.log('  announce: no file')
  }
  if (tools) {
    console.log(`  wake: ${detectWake(`${dist}/${tools}`)} (${tools})`)
  }
}
