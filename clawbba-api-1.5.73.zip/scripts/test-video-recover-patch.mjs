#!/usr/bin/env node
/**
 * Smoke test: recover + WebChat live inject patch on openclaw@2026.5.27.
 */
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { execSync } from 'node:child_process'
import {
  patchVideoGenerateRecoverAction,
  upgradeVideoRecoverChatRunId,
  VIDEO_RECOVER_WEBCHAT_LIVE_MARKER,
} from './clawbba-video-recover-patch.mjs'
import { listTasksFnHasSessionKeyParam } from './clawbba-image-recover-patch.mjs'
import { patchReadOnlyToolTextReplyDist } from './clawbba-readonly-tool-reply-patch.mjs'
import { patchExternalRecoverMediaDelivery } from './clawbba-external-recover-delivery.mjs'
import { patchWebChatLiveInjectHelperInToolsFile } from './clawbba-webchat-live-inject.mjs'

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'clawbba-vid-recover-'))
const tgz = path.join(tmp, 'openclaw.tgz')
execSync(`npm pack openclaw@2026.5.27 --silent`, { cwd: tmp, stdio: 'pipe' })
const packed = fs.readdirSync(tmp).find((n) => n.endsWith('.tgz'))
fs.renameSync(path.join(tmp, packed), tgz)
execSync(`tar -xzf ${JSON.stringify(path.basename(tgz))}`, { cwd: tmp })

const dist = path.join(tmp, 'package', 'dist')
const toolsFile = fs.readdirSync(dist).find((n) => n.startsWith('openclaw-tools-'))
const pluginsFile = fs.readdirSync(dist).find((n) => n.startsWith('server-plugins-'))
const gatewayFile = fs.readdirSync(dist).find((n) => n.startsWith('gateway-request-scope-'))
const globalSingletonFile = fs.readdirSync(dist).find((n) => n.startsWith('global-singleton-'))
assert.ok(toolsFile, 'openclaw-tools bundle missing')
assert.ok(pluginsFile, 'server-plugins bundle missing')
assert.ok(gatewayFile, 'gateway-request-scope bundle missing')
assert.ok(globalSingletonFile, 'global-singleton bundle missing')
const toolsPath = path.join(dist, toolsFile)

assert.equal(
  patchWebChatLiveInjectHelperInToolsFile(toolsPath, pluginsFile, globalSingletonFile, gatewayFile),
  'patched',
)
assert.equal(patchVideoGenerateRecoverAction(toolsPath), 'patched')
const readonly = patchReadOnlyToolTextReplyDist(dist, (d, prefix) => fs.readdirSync(d).find((n) => n.startsWith(prefix)))
assert.equal(readonly.tools, 'patched')
assert.ok(['patched', 'upgraded-v3-no-compress', 'skip'].includes(patchExternalRecoverMediaDelivery(dist, (d, prefix) => fs.readdirSync(d).find((n) => n.startsWith(prefix)))))

const src = fs.readFileSync(toolsPath, 'utf8')
assert.ok(src.includes('clawbbaRecoverVideoTask'))
assert.ok(src.includes('clawbbaListVideoTasks'))
assert.ok(listTasksFnHasSessionKeyParam(src, 'video'))
assert.ok(src.includes('clawbbaBuildRecoveredVideoToolResult'))
assert.ok(src.includes('clawbbaResolveOpenRouterApiKey'))
assert.ok(src.includes('clawbbaDispatchRecoverMediaDelivery'))
assert.ok(src.includes('clawbba-video-recover-external-delivery'))
assert.ok(src.includes('clawbba-video-recover-strict-job'))
assert.ok(src.includes('clawbbaResolveVideoRecoverJobId'))
assert.ok(src.includes('clawbba-recover-job-kind'))
assert.ok(src.includes('clawbbaAssertRecoverJobMatchesTool'))
assert.ok(src.includes('expectedKind: "video"'))
assert.ok(src.includes('[video]'))
assert.ok(!src.includes('pick.video_job_id'))
assert.ok(!src.includes('clawbbaResolveRecoverJobId'))
assert.ok(src.includes('clawbbaBroadcastWebChatSessionReload'))
assert.ok(src.includes('clawbbaResolveGatewayBroadcastContext'))
assert.ok(src.includes('chatRunId: options?.runId'))
assert.ok(src.includes('chatRunId,'))
assert.ok(!src.includes('clawbbaPromptWebChatHistoryReload'))
assert.ok(!src.includes('resolveApiKeyForProvider({ provider: "openrouter"'))

const upgraded = upgradeVideoRecoverChatRunId(src)
assert.equal(upgraded, src)

assert.equal(patchVideoGenerateRecoverAction(toolsPath), 'skip')

console.log('test-video-recover-patch: ok')
