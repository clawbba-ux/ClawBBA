/**
 * Sanitize agents.defaults for OpenClaw config schema (version-aware).
 */
import { openClawSupportsSystemPromptOverride } from './openclaw-version.mjs'

export function sanitizeAgentsDefaultsObject(defaults, { supportsSystemPromptOverride } = {}) {
  if (!defaults || typeof defaults !== 'object') return { defaults, changed: false }
  const out = { ...defaults }
  let changed = false
  const supportsOverride =
    typeof supportsSystemPromptOverride === 'boolean'
      ? supportsSystemPromptOverride
      : openClawSupportsSystemPromptOverride()

  if (typeof out.systemPrompt === 'string' && out.systemPrompt.trim()) {
    if (supportsOverride && !out.systemPromptOverride?.trim()) {
      out.systemPromptOverride = out.systemPrompt
    }
    delete out.systemPrompt
    changed = true
  }

  if (!supportsOverride && Object.prototype.hasOwnProperty.call(out, 'systemPromptOverride')) {
    delete out.systemPromptOverride
    changed = true
  }

  return { defaults: out, changed }
}

export function sanitizeAgentsConfig(agents, opts) {
  if (!agents || typeof agents !== 'object') return { agents, changed: false }
  let changed = false
  const out = { ...agents }

  const defaultsResult = sanitizeAgentsDefaultsObject(out.defaults, opts)
  if (defaultsResult.changed) {
    out.defaults = defaultsResult.defaults
    changed = true
  }

  if (Array.isArray(out.list)) {
    const supportsOverride =
      typeof opts?.supportsSystemPromptOverride === 'boolean'
        ? opts.supportsSystemPromptOverride
        : openClawSupportsSystemPromptOverride()
    if (!supportsOverride) {
      const list = out.list.map((agent) => {
        if (!agent || typeof agent !== 'object') return agent
        if (!Object.prototype.hasOwnProperty.call(agent, 'systemPromptOverride')) return agent
        changed = true
        const next = { ...agent }
        delete next.systemPromptOverride
        return next
      })
      out.list = list
    }
  }

  return { agents: out, changed }
}
