#!/usr/bin/env node
import assert from 'node:assert/strict'
import {
  CLAWBBA_PROVIDER_DISPLAY_NAME,
  enrichAgentModelsProviderBlock,
} from './openclaw-provider-block.mjs'

const base = { baseUrl: 'https://www.clawbba.com/api/v1', apiKey: 'cbb_sk_live_x' }
const clawbba = enrichAgentModelsProviderBlock('clawbba', base)
assert.equal(clawbba.name, CLAWBBA_PROVIDER_DISPLAY_NAME)
assert.equal('label' in clawbba, false)

const again = enrichAgentModelsProviderBlock('clawbba', clawbba)
assert.equal(again, clawbba)

const other = enrichAgentModelsProviderBlock('anthropic', base)
assert.equal(other.name, undefined)

console.log('test-provider-display-name: ok')
