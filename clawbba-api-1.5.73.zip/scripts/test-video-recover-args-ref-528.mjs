#!/usr/bin/env node
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import {
  buildVideoRecoverExecutePrefix,
  resolveVideoGenerateExecuteArgsIdent,
  upgradeVideoRecoverExecuteArgsRef,
} from './openclaw-tools-compat.mjs'
import { patchVideoGenerateRecoverAction } from './clawbba-video-recover-patch.mjs'

const sourceTools = process.argv[2] || '/tmp/oc528/package/dist/openclaw-tools-C1FG9NMc.js'
const src = fs.readFileSync(sourceTools, 'utf8')

assert.equal(resolveVideoGenerateExecuteArgsIdent(src), 'args')
assert.ok(buildVideoRecoverExecutePrefix(src).includes('args: args,'))
assert.ok(!buildVideoRecoverExecutePrefix(src).includes('args: params'))

const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'clawbba-vid-args-'))
const toolsPath = path.join(tmpDir, path.basename(sourceTools))
fs.copyFileSync(sourceTools, toolsPath)

assert.equal(patchVideoGenerateRecoverAction(toolsPath), 'patched')
let patched = fs.readFileSync(toolsPath, 'utf8')
assert.ok(patched.includes('action === "tasks") return await clawbbaListVideoTasks'))
assert.ok(patched.includes('args: args, agentSessionKey'))
assert.ok(!patched.includes('args: params, agentSessionKey'))

// simulate 1.5.52 broken inject and upgrade
patched = patched.replace(/args: args,/g, 'args: params,')
fs.writeFileSync(toolsPath, patched)
assert.equal(patchVideoGenerateRecoverAction(toolsPath), 'patched')
patched = fs.readFileSync(toolsPath, 'utf8')
assert.ok(patched.includes('args: args, agentSessionKey'))
assert.ok(!patched.includes('args: params, agentSessionKey'))
assert.ok(!patched.match(/clawbbaRecoverVideoTask\(\{ cfg, args: params,/))

const brokenRecover =
  'if (action === "recover") return await clawbbaRecoverVideoTask({ cfg, args: params, agentDir: options?.agentDir,'
const fixedRecover = upgradeVideoRecoverExecuteArgsRef(brokenRecover + src)
assert.ok(fixedRecover.includes('args: args,'))

console.log('test-video-recover-args-ref-528: ok')
