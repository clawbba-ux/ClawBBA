/**
 * OpenClaw 新建会话 ClawBBA 品牌：默认对话模型须 clawbba/*，并同步 agent models.json。
 * WebChat「Assistant from ClawBBA」：openclaw.json ui.assistant.name（agent.identity.get）。
 * 模型注册表展示名：agent models.json providers.*.name = ClawBBA。
 */
import fs from 'fs'
import path from 'path'
import { discoverAgentModelPaths, getOpenclawHome, getOpenclawJsonPath } from './openclaw-paths.mjs'
import {
  CLAWBBA_WEBCHAT_ASSISTANT_NAME,
  enrichAgentModelsProviderBlock,
} from './openclaw-provider-block.mjs'

const PROVIDERS = ['clawbba', 'openrouter']

function isRecord(v) {
  return v && typeof v === 'object' && !Array.isArray(v)
}

function clone(value) {
  return JSON.parse(JSON.stringify(value))
}

/**
 * @param {object} cfg openclaw.json root
 * @param {{ chatPrimary?: string, patch?: object }} [opts]
 * @returns {{ changed: boolean, chatPrimary: string }}
 */
export function applyClawbbaSessionBranding(cfg, opts = {}) {
  let changed = false
  if (!cfg || typeof cfg !== 'object') return { changed: false, chatPrimary: '' }

  const patchPrimary = String(
    opts.chatPrimary || opts.patch?.agents?.defaults?.model?.primary || '',
  ).trim()
  const chatPrimary =
    patchPrimary ||
    String(cfg.agents?.defaults?.model?.primary || '').trim()

  if (!chatPrimary.startsWith('clawbba/')) {
    return { changed: false, chatPrimary }
  }

  if (!cfg.agents || typeof cfg.agents !== 'object') {
    cfg.agents = {}
    changed = true
  }
  if (!cfg.agents.defaults || typeof cfg.agents.defaults !== 'object') {
    cfg.agents.defaults = {}
    changed = true
  }

  const d = cfg.agents.defaults
  const curDefault = String(d.model?.primary || '').trim()
  if (curDefault !== chatPrimary) {
    d.model = { ...(isRecord(d.model) ? d.model : {}), primary: chatPrimary }
    changed = true
  }

  const patchDefaults = opts.patch?.agents?.defaults
  if (patchDefaults && typeof patchDefaults === 'object') {
    for (const key of ['imageGenerationModel', 'videoGenerationModel', 'imageModel']) {
      const primary = patchDefaults[key]?.primary
      if (!primary) continue
      const cur = String(d[key]?.primary || '').trim()
      const next = String(primary).trim()
      if (cur !== next) {
        d[key] = { ...(isRecord(d[key]) ? d[key] : {}), ...patchDefaults[key], primary: next }
        changed = true
      }
    }
    if (isRecord(patchDefaults.models)) {
      d.models = { ...(isRecord(d.models) ? d.models : {}), ...patchDefaults.models }
      changed = true
    }
  }

  if (Array.isArray(cfg.agents.list)) {
    for (const agent of cfg.agents.list) {
      if (!agent || typeof agent !== 'object') continue
      const cur = String(agent.model?.primary || '').trim()
      if (cur.startsWith('clawbba/')) continue
      agent.model = { ...(isRecord(agent.model) ? agent.model : {}), primary: chatPrimary }
      changed = true
    }
  }

  if (!cfg.skills || typeof cfg.skills !== 'object') {
    cfg.skills = {}
    changed = true
  }
  if (!cfg.skills.entries || typeof cfg.skills.entries !== 'object') {
    cfg.skills.entries = {}
    changed = true
  }
  const skill = cfg.skills.entries['clawbba-api'] || {}
  if (skill.enabled !== true) {
    cfg.skills.entries['clawbba-api'] = { ...skill, enabled: true }
    changed = true
  }

  if (cfg.messages?.visibleReplies !== 'automatic') {
    cfg.messages = { ...(cfg.messages || {}), visibleReplies: 'automatic' }
    changed = true
  }

  if (!cfg.ui || typeof cfg.ui !== 'object') {
    cfg.ui = {}
    changed = true
  }
  if (!cfg.ui.assistant || typeof cfg.ui.assistant !== 'object') {
    cfg.ui.assistant = {}
    changed = true
  }
  const uiAssistantName = String(cfg.ui.assistant.name || '').trim()
  if (uiAssistantName !== CLAWBBA_WEBCHAT_ASSISTANT_NAME) {
    cfg.ui.assistant.name = CLAWBBA_WEBCHAT_ASSISTANT_NAME
    changed = true
  }

  return { changed, chatPrimary }
}

function agentModelsPath(openclawHome, agentId) {
  const id = String(agentId || '').trim()
  if (!id) return null
  return path.join(openclawHome, 'agents', id, 'agent', 'models.json')
}

function listAgentIdsFromCfg(cfg, openclawHome) {
  const ids = new Set()
  for (const p of discoverAgentModelPaths(openclawHome)) {
    const m = p.match(/[/\\]agents[/\\]([^/\\]+)[/\\]agent[/\\]models\.json$/)
    if (m?.[1]) ids.add(m[1])
  }
  const list = cfg?.agents?.list
  if (Array.isArray(list)) {
    for (const agent of list) {
      const id = String(agent?.id || '').trim()
      if (id) ids.add(id)
    }
  }
  if (!ids.size) ids.add('main')
  return [...ids]
}

/**
 * @param {object} cfg
 * @param {string} [openclawHome]
 */
export function syncAgentModelsFromOpenclawCfg(cfg, openclawHome = getOpenclawHome()) {
  const sourceProviders = cfg?.models?.providers
  if (!sourceProviders?.clawbba?.models?.length) {
    return { updated: 0, checked: 0, expected: 0 }
  }

  const expected = sourceProviders.clawbba.models.length
  let updated = 0
  const checkedPaths = new Set()

  for (const agentId of listAgentIdsFromCfg(cfg, openclawHome)) {
    const modelPath = agentModelsPath(openclawHome, agentId)
    if (!modelPath || checkedPaths.has(modelPath)) continue
    checkedPaths.add(modelPath)

    let parsed = { providers: {} }
    try {
      if (fs.existsSync(modelPath)) {
        parsed = JSON.parse(fs.readFileSync(modelPath, 'utf8'))
      }
    } catch (e) {
      process.stderr.write(
        `[clawbba-api] 跳过无效 agent models.json ${modelPath}: ${e.message || e}\n`,
      )
      continue
    }

    if (!parsed.providers || typeof parsed.providers !== 'object') parsed.providers = {}
    const before = parsed.providers.clawbba?.models?.length ?? 0
    for (const key of PROVIDERS) {
      if (sourceProviders[key]) {
        parsed.providers[key] = enrichAgentModelsProviderBlock(
          key,
          clone(sourceProviders[key]),
        )
      }
    }
    const after = parsed.providers.clawbba?.models?.length ?? 0
    const nextContents = `${JSON.stringify(parsed, null, 2)}\n`

    fs.mkdirSync(path.dirname(modelPath), { recursive: true })
    const prev = fs.existsSync(modelPath) ? fs.readFileSync(modelPath, 'utf8') : ''
    if (prev !== nextContents) {
      fs.writeFileSync(modelPath, nextContents, { mode: 0o600 })
      updated += 1
      const rel = modelPath.startsWith(openclawHome)
        ? modelPath.slice(openclawHome.length + 1)
        : modelPath
      process.stderr.write(
        `[clawbba-api] synced ${rel}: clawbba.models ${before} → ${after} (expected ${expected})\n`,
      )
    }
  }

  return { updated, checked: checkedPaths.size, expected }
}
