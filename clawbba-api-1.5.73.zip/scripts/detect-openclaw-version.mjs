#!/usr/bin/env node
/**
 * 安装前 OpenClaw 版本检测（供 install-clawbba-api.sh / one-shot-setup.sh 调用）
 *
 * 用法:
 *   node scripts/detect-openclaw-version.mjs              # 人类可读报告
 *   node scripts/detect-openclaw-version.mjs --json       # JSON（CI / 诊断）
 *   node scripts/detect-openclaw-version.mjs --shell      # bash eval 环境变量
 *   node scripts/detect-openclaw-version.mjs --strict     # blocked / unknown 时 exit 1
 */
import { getOpenClawVersion } from './openclaw-calver.mjs'
import {
  OPENCLAW_COMPAT_MIN_VERSION,
  formatOpenClawCompatReport,
  formatOpenClawUnsupportedUpgradeMessage,
  resolveOpenClawCompatProfile,
} from './openclaw-compat-profiles.mjs'
import { isOpenClawVersionNewerThanTested, OPENCLAW_COMPAT_TESTED_MAX_VERSION } from './openclaw-patch-context.mjs'

const args = new Set(process.argv.slice(2))
const asJson = args.has('--json')
const asShell = args.has('--shell')
const strict = args.has('--strict')
const quiet = args.has('--quiet')

const version = getOpenClawVersion()
const profile = resolveOpenClawCompatProfile(version)

const payload = {
  openclawVersion: profile.version,
  openclawVersionRaw: version ? `OpenClaw ${version}` : null,
  compatMinVersion: OPENCLAW_COMPAT_MIN_VERSION,
  profileId: profile.profileId,
  profileLabel: profile.label,
  profileTier: profile.tier,
  blocked: profile.blocked,
  config: profile.config,
  patch: profile.patch,
  installNotes: profile.installNotes,
  testedMaxVersion: OPENCLAW_COMPAT_TESTED_MAX_VERSION,
  newerThanTested: isOpenClawVersionNewerThanTested(profile.version),
}

function shellEscape(value) {
  return `'${String(value ?? '').replace(/'/g, `'\\''`)}'`
}

if (asShell) {
  const entries = {
    OPENCLAW_VERSION: profile.version ?? '',
    OPENCLAW_COMPAT_MIN_VERSION: OPENCLAW_COMPAT_MIN_VERSION,
    OPENCLAW_COMPAT_PROFILE_ID: profile.profileId,
    OPENCLAW_COMPAT_PROFILE_LABEL: profile.label,
    OPENCLAW_COMPAT_PROFILE_TIER: profile.tier,
    OPENCLAW_COMPAT_BLOCKED: profile.blocked ? '1' : '0',
    OPENCLAW_COMPAT_SUPPORTS_SYSTEM_PROMPT_OVERRIDE: profile.config.systemPromptOverride ? '1' : '0',
    OPENCLAW_COMPAT_TOOLS_BUNDLE: profile.patch.toolsBundle,
    OPENCLAW_COMPAT_VIDEO_EXECUTE_ARGS: profile.patch.videoExecuteArgsIdent ?? '',
    OPENCLAW_COMPAT_IMAGE_EXECUTE_ARGS: profile.patch.imageExecuteArgsIdent ?? '',
    OPENCLAW_COMPAT_READ_STRING_PARAM_SUFFIX: profile.patch.readStringParamSuffix ? '1' : '',
    OPENCLAW_COMPAT_NEWER_THAN_TESTED: isOpenClawVersionNewerThanTested(profile.version) ? '1' : '0',
  }
  for (const [key, value] of Object.entries(entries)) {
    process.stdout.write(`export ${key}=${shellEscape(value)}\n`)
  }
} else if (asJson) {
  process.stdout.write(`${JSON.stringify(payload, null, 2)}\n`)
} else if (!quiet) {
  process.stdout.write(`${formatOpenClawCompatReport(profile)}\n`)
  if (isOpenClawVersionNewerThanTested(profile.version)) {
    process.stderr.write(
      `[clawbba-api] ⚠ OpenClaw ${profile.version} 高于已专项测试版本 ${OPENCLAW_COMPAT_TESTED_MAX_VERSION}；将沿用 ${profile.profileId} patch 分支\n`,
    )
  }
}

if (strict) {
  if (profile.blocked) {
    if (!quiet && !asJson && !asShell) {
      process.stderr.write(formatOpenClawUnsupportedUpgradeMessage(profile.version))
    } else if (!quiet && asShell) {
      process.stderr.write(formatOpenClawUnsupportedUpgradeMessage(profile.version))
    }
    process.exit(2)
  }
  if (profile.profileId === 'unknown') {
    if (!quiet && !asJson && !asShell) {
      process.stderr.write('[clawbba-api] ✗ 无法识别 OpenClaw 版本，请确认 openclaw --version 可执行\n')
    }
    process.exit(3)
  }
}

process.exit(0)
