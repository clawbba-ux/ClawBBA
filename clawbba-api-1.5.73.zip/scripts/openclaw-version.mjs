/**
 * OpenClaw version helpers + compat profile re-exports.
 */
import { getOpenClawVersion } from './openclaw-calver.mjs'
import { openClawCompatProfileSupportsSystemPromptOverride, resolveOpenClawCompatProfile } from './openclaw-compat-profiles.mjs'

export { getOpenClawVersion, parseCalVer, compareCalVer } from './openclaw-calver.mjs'
export {
  OPENCLAW_COMPAT_MIN_VERSION,
  OPENCLAW_COMPAT_PROFILES,
  resolveOpenClawCompatProfile,
  formatOpenClawCompatReport,
} from './openclaw-compat-profiles.mjs'

/** OpenClaw 2026.5.28+ removed agents.defaults.systemPromptOverride */
export function openClawSupportsSystemPromptOverride(version = getOpenClawVersion()) {
  return openClawCompatProfileSupportsSystemPromptOverride(resolveOpenClawCompatProfile(version))
}
