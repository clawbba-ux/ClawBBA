#!/usr/bin/env node
import assert from 'node:assert/strict'
import Database from 'better-sqlite3'
import { buildPlatformOpenclawGuide } from '../../../server/platform-openclaw-guide.js'

const db = new Database(':memory:')
db.exec(
  `CREATE TABLE openrouter_models_catalog (model_id TEXT, name TEXT, model_category TEXT, enabled INTEGER)`,
)
for (const id of ['google/veo-3.1-fast', 'bytedance/seedance-2.0', 'kwaivgi/kling-video-o1']) {
  db.prepare('INSERT INTO openrouter_models_catalog VALUES (?,?,?,1)').run(id, id, 'video')
}
const g = buildPlatformOpenclawGuide(db)
assert.equal(g.video_recover.user_message, 'video_generate action=tasks 根据指令恢复我生成的视频')
assert.equal(g.video_recover.image_user_message, 'image_generate action=tasks 根据指令恢复我生成的图片')
assert.equal(g.media_recover.image.user_message, 'image_generate action=tasks 根据指令恢复我生成的图片')
assert.equal(g.media_recover.image.tool_tasks, '/tool image_generate action=tasks')
assert.equal(
  g.media_recover.image.tool_recover,
  '/tool image_generate action=recover jobId=<image_job_id> timeoutMs=600000',
)
const veo = g.video_models.find((m) => m.id === 'google/veo-3.1-fast')
const sd = g.video_models.find((m) => m.id === 'bytedance/seedance-2.0')
assert.ok(veo?.example_prompt?.startsWith('Use ClawBBA'))
assert.ok(sd?.example_prompt?.startsWith('请使用 ClawBBA'))
console.log('test-platform-openclaw-guide-recover: ok')
