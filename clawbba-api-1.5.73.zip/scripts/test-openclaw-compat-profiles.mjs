#!/usr/bin/env node
import assert from 'node:assert/strict'
import {
  OPENCLAW_COMPAT_MIN_VERSION,
  formatOpenClawUnsupportedUpgradeMessage,
  resolveOpenClawCompatProfile,
} from './openclaw-compat-profiles.mjs'
import { openClawSupportsSystemPromptOverride } from './openclaw-version.mjs'

assert.equal(OPENCLAW_COMPAT_MIN_VERSION, '2026.5.12')

const p528 = resolveOpenClawCompatProfile('2026.5.28')
assert.equal(p528.profileId, '2026.5.28')
assert.equal(p528.blocked, false)
assert.equal(p528.config.systemPromptOverride, false)
assert.equal(p528.patch.toolsBundle, '2026.5.28')

const p527 = resolveOpenClawCompatProfile('2026.5.27')
assert.equal(p527.profileId, '2026.5.12')
assert.equal(p527.config.systemPromptOverride, true)
assert.equal(p527.patch.readStringParamSuffix, true)

const p512 = resolveOpenClawCompatProfile('2026.5.12')
assert.equal(p512.profileId, '2026.5.12')
assert.equal(p512.blocked, false)

const old = resolveOpenClawCompatProfile('2026.5.2')
assert.equal(old.profileId, 'unsupported')
assert.equal(old.blocked, true)

const msg = formatOpenClawUnsupportedUpgradeMessage('2026.5.2')
assert.ok(msg.includes('2026.5.2'))
assert.ok(msg.includes(OPENCLAW_COMPAT_MIN_VERSION))
assert.ok(msg.includes('npm i -g openclaw@latest'))
assert.ok(msg.includes('install-clawbba-api.sh'))

assert.equal(openClawSupportsSystemPromptOverride('2026.5.28'), false)
assert.equal(openClawSupportsSystemPromptOverride('2026.5.27'), true)

console.log('test-openclaw-compat-profiles: ok')
