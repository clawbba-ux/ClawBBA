#!/usr/bin/env node
import assert from 'node:assert/strict'
import fs from 'node:fs'
import { upgradeImageRecoverStrictJobId } from './clawbba-image-recover-patch.mjs'
import { upgradeRecoverJobKindValidation } from './clawbba-recover-job-kind.mjs'

const distPath = '/var/www/crypto-payment-demo/server/package/dist/openclaw-tools-wLbjLILX.js'
if (!fs.existsSync(distPath)) {
  console.log('test-legacy-recover-upgrade: skip (no bundled dist)')
  process.exit(0)
}

const src = fs.readFileSync(distPath, 'utf8')
assert.ok(src.includes('pick.image_job_id || pick.job_id'), 'fixture should have legacy auto-pick')

let out = upgradeImageRecoverStrictJobId(src)
out = upgradeRecoverJobKindValidation(out)

assert.ok(!out.includes('pick.image_job_id || pick.job_id'), 'auto-pick must be removed')
assert.ok(out.includes('clawbba-image-recover-strict-job'), 'strict marker required')
assert.ok(out.includes('clawbbaResolveImageRecoverJobId'), 'multi-key resolver required')
assert.ok(out.includes('action=recover requires jobId'), 'must throw when jobId missing')
assert.ok(out.includes('clawbbaAssertPollJobIdMatches'), 'poll job id guard required')

console.log('test-legacy-recover-upgrade: ok')
