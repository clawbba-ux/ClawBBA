/**
 * OpenClaw 2026.5.28+ bundles import readStringParam without $1 suffix.
 * ClawBBA injects must match the dist alias or recover/tasks throw ReferenceError.
 */

export function resolveReadStringParamIdent(toolsSrc) {
  return /\breadStringParam\$1\b/.test(toolsSrc) ? 'readStringParam$1' : 'readStringParam'
}

/** @param {string} block injected helper / recover source */
export function adaptInjectedReadStringParam(block, toolsSrc) {
  const ident = resolveReadStringParamIdent(toolsSrc)
  if (ident === 'readStringParam$1') return block
  return block.replace(/readStringParam\$1/g, ident)
}

/** Fix partial upgrades: injected clawbba code still says readStringParam$1 on new OpenClaw */
export function upgradeOpenClawBundledReadStringParamAlias(src) {
  if (!src.includes('readStringParam$1(')) return src
  if (/[\s,{]readStringParam\$1[,}\s]/.test(src) || src.includes('as readStringParam$1')) return src
  return src.replace(/readStringParam\$1/g, 'readStringParam')
}

/**
 * OpenClaw 2026.5.28 video_generate execute: `const args = rawArgs` (no `params` alias).
 * image_generate still uses `const params = args`.
 */
export function resolveVideoGenerateExecuteArgsIdent(toolsSrc) {
  const idx = toolsSrc.indexOf('function createVideoGenerateTool(options)')
  if (idx < 0) return 'params'
  const chunk = toolsSrc.slice(idx, idx + 2500)
  if (chunk.includes('const params = args') || chunk.includes('const params = rawArgs')) return 'params'
  if (chunk.includes('const args = rawArgs')) return 'args'
  return 'params'
}

/** @param {string} toolsSrc */
export function buildVideoRecoverExecutePrefix(toolsSrc) {
  const ident = resolveVideoGenerateExecuteArgsIdent(toolsSrc)
  return `\t\t\tif (action === "tasks") return await clawbbaListVideoTasks({ cfg, agentDir: options?.agentDir, authStore: options?.authProfileStore, args: ${ident}, agentSessionKey: options?.agentSessionKey, chatRunId: options?.runId });
\t\t\tif (action === "recover") return await clawbbaRecoverVideoTask({ cfg, args: ${ident}, agentDir: options?.agentDir, authStore: options?.authProfileStore, agentSessionKey: options?.agentSessionKey, chatRunId: options?.runId });
`
}

/** @param {string} src */
export function upgradeVideoRecoverExecuteArgsRef(src) {
  const ident = resolveVideoGenerateExecuteArgsIdent(src)
  if (ident === 'params') return src
  let out = src.replace(
    /if \(action === "tasks"\) return await clawbbaListVideoTasks\(\{ cfg, agentDir: options\?\.agentDir, authStore: options\?\.authProfileStore, args: params,/g,
    `if (action === "tasks") return await clawbbaListVideoTasks({ cfg, agentDir: options?.agentDir, authStore: options?.authProfileStore, args: ${ident},`,
  )
  out = out.replace(
    /if \(action === "recover"\) return await clawbbaRecoverVideoTask\(\{ cfg, args: params,/g,
    `if (action === "recover") return await clawbbaRecoverVideoTask({ cfg, args: ${ident},`,
  )
  return out
}
