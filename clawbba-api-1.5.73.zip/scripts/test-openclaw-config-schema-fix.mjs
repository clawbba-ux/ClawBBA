#!/usr/bin/env node
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { sanitizeAgentsConfig } from './openclaw-config-sanitize.mjs'

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'clawbba-cfg-'))
const cfgPath = path.join(tmp, 'openclaw.json')

function writeCfg(agents) {
  fs.writeFileSync(cfgPath, JSON.stringify({ agents }, null, 2))
}

writeCfg({
  defaults: {
    model: { primary: 'clawbba/google/gemini-2.0-flash-001' },
    systemPromptOverride: 'ClawBBA rules',
  },
})
let cfg = JSON.parse(fs.readFileSync(cfgPath, 'utf8'))
let r = sanitizeAgentsConfig(cfg.agents, { supportsSystemPromptOverride: false })
assert.equal(r.changed, true)
assert.equal(r.agents.defaults.systemPromptOverride, undefined)

writeCfg({
  defaults: {
    systemPrompt: 'legacy prompt',
  },
})
cfg = JSON.parse(fs.readFileSync(cfgPath, 'utf8'))
r = sanitizeAgentsConfig(cfg.agents, { supportsSystemPromptOverride: true })
assert.equal(r.changed, true)
assert.equal(r.agents.defaults.systemPromptOverride, 'legacy prompt')
assert.equal(r.agents.defaults.systemPrompt, undefined)

writeCfg({
  defaults: {
    systemPrompt: 'legacy prompt',
  },
})
cfg = JSON.parse(fs.readFileSync(cfgPath, 'utf8'))
r = sanitizeAgentsConfig(cfg.agents, { supportsSystemPromptOverride: false })
assert.equal(r.changed, true)
assert.equal(r.agents.defaults.systemPrompt, undefined)
assert.equal(r.agents.defaults.systemPromptOverride, undefined)

writeCfg({
  list: [{ id: 'main', systemPromptOverride: 'x' }],
  defaults: {},
})
cfg = JSON.parse(fs.readFileSync(cfgPath, 'utf8'))
r = sanitizeAgentsConfig(cfg.agents, { supportsSystemPromptOverride: false })
assert.equal(r.changed, true)
assert.equal(r.agents.list[0].systemPromptOverride, undefined)

console.log('test-openclaw-config-schema-fix: ok')
