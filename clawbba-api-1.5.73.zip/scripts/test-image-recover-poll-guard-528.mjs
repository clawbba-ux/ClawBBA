#!/usr/bin/env node
/**
 * Regression: partial upgrade injects clawbbaAssertPollJobIdMatches call but not the function
 * (ReferenceError: clawbbaAssertPollJobIdMatches is not defined).
 */
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { patchVideoGenerateRecoverAction } from './clawbba-video-recover-patch.mjs'
import {
  patchImageGenerateRecoverAction,
  ensureImageRecoverPollJobIdHelper,
  imageRecoverPollJobIdHelperIsHealthy,
  IMAGE_RECOVER_STRICT_JOB_MARKER,
} from './clawbba-image-recover-patch.mjs'
import { RECOVER_JOB_KIND_MARKER } from './clawbba-recover-job-kind.mjs'
import { fresh528ToolsPath } from './test-528-fixture.mjs'

const toolsPath = fresh528ToolsPath(process.argv[2] ? path.basename(process.argv[2]) : undefined)

assert.equal(patchVideoGenerateRecoverAction(toolsPath), 'patched')
assert.equal(patchImageGenerateRecoverAction(toolsPath), 'patched')

let src = fs.readFileSync(toolsPath, 'utf8')
assert.ok(imageRecoverPollJobIdHelperIsHealthy(src), 'fresh patch must define poll guard')

// Simulate broken partial upgrade: call site kept, function body removed
src = src.replace(/\/\* clawbba-poll-job-id-match \*\/\nfunction clawbbaAssertPollJobIdMatches[\s\S]*?\n\}\n/, '')
assert.ok(src.includes('clawbbaAssertPollJobIdMatches(jobId, pollBody)'), 'fixture must keep call site')
assert.ok(src.includes(IMAGE_RECOVER_STRICT_JOB_MARKER), 'fixture must keep strict marker')
assert.ok(src.includes(RECOVER_JOB_KIND_MARKER), 'fixture must keep job kind helpers')
assert.ok(!imageRecoverPollJobIdHelperIsHealthy(src), 'broken fixture must be unhealthy')

const fixed = ensureImageRecoverPollJobIdHelper(src)
assert.ok(imageRecoverPollJobIdHelperIsHealthy(fixed), 'ensure must restore poll guard fn')
assert.ok(fixed.includes('/* clawbba-poll-job-id-match */'))

fs.writeFileSync(toolsPath, fixed)
assert.equal(patchImageGenerateRecoverAction(toolsPath), 'skip')

console.log('test-image-recover-poll-guard-528: ok')
