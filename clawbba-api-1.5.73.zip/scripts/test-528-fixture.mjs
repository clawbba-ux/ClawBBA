import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { execSync } from 'node:child_process'

const TGZ = path.join('/var/www/crypto-payment-demo/packages/clawbba-api', 'openclaw-2026.5.28.tgz')
const TOOLS_NAME = 'openclaw-tools-C1FG9NMc.js'

export function fresh528ToolsPath(toolsName = TOOLS_NAME) {
  assert.ok(fs.existsSync(TGZ), 'openclaw-2026.5.28.tgz required')
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'clawbba-528-'))
  execSync(`tar -xzf ${JSON.stringify(TGZ)} -C ${JSON.stringify(tmpDir)} package/dist/${toolsName}`, { stdio: 'pipe' })
  const toolsPath = path.join(tmpDir, 'package', 'dist', toolsName)
  assert.ok(fs.existsSync(toolsPath), `missing ${toolsPath}`)
  return toolsPath
}
