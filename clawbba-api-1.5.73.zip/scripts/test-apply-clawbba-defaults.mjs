#!/usr/bin/env node
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { spawnSync } from 'node:child_process'

const tmpHome = fs.mkdtempSync(path.join(os.tmpdir(), 'clawbba-apply-defaults-'))
const cfgPath = path.join(tmpHome, 'openclaw.json')
const patchPath = path.join(tmpHome, 'patch.json')

fs.writeFileSync(
  cfgPath,
  JSON.stringify(
    {
      agents: {
        defaults: {
          model: { primary: 'anthropic/claude-opus-4' },
        },
      },
    },
    null,
    2,
  ),
)

fs.writeFileSync(
  patchPath,
  JSON.stringify(
    {
      agents: {
        defaults: {
          model: { primary: 'clawbba/google/gemini-2.5-flash' },
          imageGenerationModel: { primary: 'openrouter/google/gemini-3.1-flash-image-preview' },
        },
      },
    },
    null,
    2,
  ),
)

const script = new URL('./apply-openclaw-config.mjs', import.meta.url).pathname
const r = spawnSync(process.execPath, [script, patchPath], {
  env: { ...process.env, OPENCLAW_HOME: tmpHome },
  encoding: 'utf8',
})
assert.equal(r.status, 0, r.stderr || r.stdout)

const merged = JSON.parse(fs.readFileSync(cfgPath, 'utf8'))
assert.equal(merged.agents.defaults.model.primary, 'clawbba/google/gemini-2.5-flash')
assert.equal(
  merged.agents.defaults.imageGenerationModel.primary,
  'openrouter/google/gemini-3.1-flash-image-preview',
)
console.log('test-apply-clawbba-defaults: ok')
