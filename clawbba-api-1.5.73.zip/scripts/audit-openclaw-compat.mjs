#!/usr/bin/env node
/**
 * Post-patch compat audit: profile-aware needle checks on installed OpenClaw dist.
 * 用法: node scripts/audit-openclaw-compat.mjs [--strict]
 */
import fs from 'node:fs'
import path from 'node:path'
import { findAllOpenclawDists, findDistJsFile, formatOpenclawDistDiscoveryReport } from './openclaw-dist-paths.mjs'
import { resolveOpenClawPatchContext } from './openclaw-patch-context.mjs'
import { formatOpenClawCompatReport } from './openclaw-compat-profiles.mjs'

const strict = process.argv.includes('--strict')

function pick(dist, prefix) {
  return findDistJsFile(dist, prefix)
}

function read(dist, file) {
  if (!file) return ''
  return fs.readFileSync(path.join(dist, file), 'utf8')
}

/** @param {ReturnType<typeof resolveOpenClawPatchContext>} ctx */
function buildChecks(ctx) {
  const dist = ctx.dist
  if (!dist) return [{ id: 'dist', label: 'OpenClaw dist', ok: false, critical: true, detail: 'not found' }]

  const tools = pick(dist, 'openclaw-tools-')
  const announce = pick(dist, 'subagent-announce-delivery-')
  const toolsSrc = read(dist, tools)
  const announceSrc = read(dist, announce)
  const checks = []

  const need = (id, label, ok, critical, detail = '') => {
    checks.push({ id, label, ok, critical, detail })
  }

  need('profile', `compat profile ${ctx.profileId}`, !!ctx.profileId && ctx.profileId !== 'unsupported', true)
  if (ctx.newerThanTested) {
    need(
      'version-untested',
      `OpenClaw ${ctx.version} > tested ${ctx.testedMaxVersion}`,
      !strict,
      false,
      '将沿用最新 profile patch 分支；若异常请上报 OpenClaw 版本',
    )
  }

  need('readStringParam', `readStringParam ident (${ctx.readStringParamIdent})`, toolsSrc.includes(ctx.readStringParamIdent + '(') || !toolsSrc.includes('readStringParam$1('), true)
  need('video-args', `video execute args (${ctx.videoExecuteArgsIdent})`, !toolsSrc.includes('clawbbaListVideoTasks') || toolsSrc.includes(`args: ${ctx.videoExecuteArgsIdent}, agentSessionKey`), true)
  need('image-params', 'image execute params alias', !toolsSrc.includes('clawbbaListImageTasks') || toolsSrc.includes('args: params,'), true)

  need('announce-policy', 'announce clawbbaLocalMediaWebChatCompletion', announceSrc.includes('clawbbaLocalMediaWebChatCompletion'), true)
  need('announce-live', 'announce chat.inject helper', announceSrc.includes('export async function clawbbaInjectWebChatGeneratedMediaLive'), true)
  need('wake-live', 'wake completion live inject', toolsSrc.includes('clawbba-webchat-live-wake'), true)
  need('img-dispatch', 'image_generate media dispatch', toolsSrc.includes('clawbbaToOpenClawMediaModel'), true)
  need('vid-dispatch', 'video_generate media dispatch', toolsSrc.includes('clawbba-media-dispatch'), true)
  need('img-recover', 'image_generate recover/tasks', toolsSrc.includes('clawbbaRecoverImageTask') && toolsSrc.includes('clawbbaListImageTasks'), true)
  need('vid-recover', 'video_generate recover/tasks', toolsSrc.includes('clawbbaRecoverVideoTask') && toolsSrc.includes('clawbbaListVideoTasks'), true)
  need('img-schema', 'image schema jobId/limit/status', toolsSrc.includes('ClawBBA image job_id'), false)
  need('img-resolve', 'image resolveAction tasks/recover', /resolveAction\$2[\s\S]*?"tasks"/.test(toolsSrc), true)

  if (ctx.profileId === '2026.5.28') {
    need('528-announce-route', 'announce 2026.5.28 completion-route', announceSrc.includes('completionRouteRequiresMessageToolDelivery'), true)
    need('528-no-override', 'no readStringParam$1 in patched tools', !toolsSrc.includes('readStringParam$1('), true)
  }

  if (ctx.profileId === '2026.5.12') {
    need('legacy-readString', 'readStringParam$1 or adapted inject', toolsSrc.includes('readStringParam$1(') || !toolsSrc.includes('readStringParam$1('), false)
  }

  return checks
}

const ctx = resolveOpenClawPatchContext()
console.log(formatOpenClawCompatReport(ctx.profile))
if (ctx.dist) {
  console.log(formatOpenclawDistDiscoveryReport([ctx.dist]))
  console.log(`[clawbba-api] patch context: videoExecuteArgs=${ctx.videoExecuteArgsIdent} imageExecuteArgs=${ctx.imageExecuteArgsIdent} readStringParam=${ctx.readStringParamIdent}`)
}

const checks = buildChecks(ctx)
let criticalFail = 0
let warnFail = 0
for (const c of checks) {
  const tag = c.ok ? '✓' : c.critical ? '✗' : '○'
  console.log(`[clawbba-api] ${tag} ${c.label}${c.detail ? ` — ${c.detail}` : ''}`)
  if (!c.ok) {
    if (c.critical) criticalFail += 1
    else warnFail += 1
  }
}

if (criticalFail) {
  console.error(`[clawbba-api] ✗ compat audit: ${criticalFail} critical check(s) failed`)
  process.exit(1)
}
if (warnFail) {
  console.log(`[clawbba-api] ○ compat audit: ${warnFail} non-critical warning(s)`)
}
console.log('[clawbba-api] ✓ compat audit passed')
process.exit(0)
