#!/usr/bin/env node
/**
 * OpenClaw 2026.5.28 announce + wake WebChat live patch smoke test.
 */
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { patchSubagentAnnounceDeliveryDist } from './openclaw-announce-patch.mjs'
import { patchWebChatLiveWakeDist } from './clawbba-webchat-live-wake-patch.mjs'
import { findDistJsFile } from './openclaw-dist-paths.mjs'

const sourceDist = process.argv[2] || '/tmp/oc528/package/dist'
const findDistFile = (d, prefix) => findDistJsFile(d, prefix)

const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'clawbba-oc528-announce-'))
for (const name of fs.readdirSync(sourceDist)) {
  if (!name.endsWith('.js')) continue
  fs.copyFileSync(path.join(sourceDist, name), path.join(tmpDir, name))
}

const announceResult = patchSubagentAnnounceDeliveryDist(tmpDir, findDistFile)
assert.match(String(announceResult), /patched-2026\.5\.28|upgraded-routes|skip|deduped|live-helper/)

const announceFile = findDistFile(tmpDir, 'subagent-announce-delivery-')
const toolsFile = findDistFile(tmpDir, 'openclaw-tools-')
const announceSrc = fs.readFileSync(path.join(tmpDir, announceFile), 'utf8')
assert.ok(announceSrc.includes('clawbbaLocalMediaWebChatCompletion'), 'policy patch')
assert.ok(announceSrc.includes('export async function clawbbaInjectWebChatGeneratedMediaLive'), 'live helper')

const wakeResult = patchWebChatLiveWakeDist(tmpDir, findDistFile)
assert.notEqual(wakeResult, 'announce-live-helper-missing', wakeResult)

const toolsSrc = fs.readFileSync(path.join(tmpDir, toolsFile), 'utf8')
assert.ok(toolsSrc.includes('clawbba-webchat-live-wake'), 'wake live inject')

console.log('test-openclaw-2026528-announce-patch: ok', { announceResult, wakeResult })
