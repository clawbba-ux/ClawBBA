#!/usr/bin/env node
/**
 * 将 ClawBBA patch 中的 provider 块同步到各 Agent 的 models.json。
 *
 * OpenClaw 会在 ~/.openclaw/agents/<id>/agent/models.json 缓存 provider catalog；
 * 仅 patch openclaw.json 时，旧的 models.json 可能仍只有 1 个模型，导致切换无效。
 *
 * 用法: node scripts/sync-agent-models.mjs clawbba-openclaw.patch.json
 */
import fs from 'fs'
import path from 'path'
import {
  discoverAgentModelPaths,
  getOpenclawHome,
  getOpenclawJsonPath,
} from './openclaw-paths.mjs'
import { enrichAgentModelsProviderBlock } from './openclaw-provider-block.mjs'

const PROVIDERS = ['clawbba', 'openrouter']

function usage() {
  process.stderr.write(
    '用法: node scripts/sync-agent-models.mjs <patch.json>\n',
  )
}

const patchFile = process.argv[2]
if (!patchFile) {
  usage()
  process.exit(1)
}

let patch
try {
  patch = JSON.parse(fs.readFileSync(patchFile, 'utf8'))
} catch (e) {
  process.stderr.write(`[clawbba-api] 无法读取 patch: ${e.message || e}\n`)
  process.exit(1)
}

const sourceProviders = patch.models?.providers
if (!sourceProviders?.clawbba?.models?.length) {
  process.stderr.write('[clawbba-api] patch 中缺少 models.providers.clawbba，跳过 sync\n')
  process.exit(0)
}

const openclawHome = getOpenclawHome()
const openclawJsonPath = getOpenclawJsonPath(openclawHome)
const expectedCount = sourceProviders.clawbba.models.length

function clone(value) {
  return JSON.parse(JSON.stringify(value))
}

function syncModelsFile(modelPath) {
  let parsed = { providers: {} }
  try {
    parsed = JSON.parse(fs.readFileSync(modelPath, 'utf8'))
  } catch (e) {
    process.stderr.write(
      `[clawbba-api] 跳过无效 JSON ${modelPath}: ${e.message || e}\n`,
    )
    return { updated: false, skipped: true }
  }

  if (!parsed || typeof parsed !== 'object') parsed = {}
  if (!parsed.providers || typeof parsed.providers !== 'object') {
    parsed.providers = {}
  }

  const before = Array.isArray(parsed.providers.clawbba?.models)
    ? parsed.providers.clawbba.models.length
    : 0

  for (const key of PROVIDERS) {
    if (sourceProviders[key]) {
      parsed.providers[key] = enrichAgentModelsProviderBlock(
        key,
        clone(sourceProviders[key]),
      )
    }
  }

  const after = parsed.providers.clawbba?.models?.length ?? 0
  const nextContents = `${JSON.stringify(parsed, null, 2)}\n`
  const prevContents = fs.readFileSync(modelPath, 'utf8')

  if (prevContents === nextContents) {
    return { updated: false, before, after, agent: modelPath }
  }

  fs.writeFileSync(modelPath, nextContents, { mode: 0o600 })
  return { updated: true, before, after, agent: modelPath }
}

const modelPaths = discoverAgentModelPaths(openclawHome)
if (!modelPaths.length) {
  process.stderr.write(
    `[clawbba-api] 未发现 agent models.json（${openclawHome}/agents/*/agent/models.json）；Gateway 启动时会从 openclaw.json 生成\n`,
  )
  process.exit(0)
}

let updated = 0
for (const modelPath of modelPaths) {
  const result = syncModelsFile(modelPath)
  if (result.skipped) continue
  const rel = modelPath.startsWith(openclawHome)
    ? modelPath.slice(openclawHome.length + 1)
    : modelPath
  if (result.updated) {
    updated += 1
    process.stderr.write(
      `[clawbba-api] synced ${rel}: clawbba.models ${result.before} → ${result.after} (expected ${expectedCount})\n`,
    )
  } else {
    process.stderr.write(
      `[clawbba-api] ok ${rel}: clawbba.models=${result.after}\n`,
    )
  }
  if (result.after !== expectedCount) {
    process.stderr.write(
      `[clawbba-api] ⚠ ${rel} 模型数 ${result.after} ≠ patch ${expectedCount}\n`,
    )
  }
}

process.stderr.write(
  `[clawbba-api] agent models.json: checked=${modelPaths.length} updated=${updated}\n`,
)
