#!/usr/bin/env node
/**
 * Partial upgrade: recover fn calls clawbbaDedupeImageBuffers but helper never injected.
 */
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { patchVideoGenerateRecoverAction } from './clawbba-video-recover-patch.mjs'
import {
  patchImageGenerateRecoverAction,
  ensureImageRecoverRuntimeHelpers,
  imageRecoverRuntimeIsHealthy,
} from './clawbba-image-recover-patch.mjs'

import { fresh528ToolsPath } from './test-528-fixture.mjs'

const toolsPath = fresh528ToolsPath()

assert.equal(patchVideoGenerateRecoverAction(toolsPath), 'patched')
assert.equal(patchImageGenerateRecoverAction(toolsPath), 'patched')
assert.ok(imageRecoverRuntimeIsHealthy(fs.readFileSync(toolsPath, 'utf8')))

let src = fs.readFileSync(toolsPath, 'utf8')
src = src.replace(/function clawbbaDedupeImageBuffers\(buffers\) \{[\s\S]*?\n\}\n/, '')
assert.ok(src.includes('clawbbaDedupeImageBuffers(rawBuffers)'), 'call site must remain')
assert.ok(!imageRecoverRuntimeIsHealthy(src), 'broken fixture')

const fixed = ensureImageRecoverRuntimeHelpers(src)
assert.ok(imageRecoverRuntimeIsHealthy(fixed), 'runtime helpers restored')

fs.writeFileSync(toolsPath, fixed)
assert.equal(patchImageGenerateRecoverAction(toolsPath), 'skip')

console.log('test-image-recover-runtime-528: ok')
