/**
 * OpenClaw calendar version parsing (2026.5.28 style).
 */
import { execSync } from 'node:child_process'

export function parseCalVer(version) {
  const m = String(version || '').trim().match(/^(\d{4})\.(\d+)\.(\d+)/)
  if (!m) return null
  return [Number(m[1]), Number(m[2]), Number(m[3])]
}

export function compareCalVer(a, b) {
  const pa = parseCalVer(a)
  const pb = parseCalVer(b)
  if (!pa || !pb) return null
  for (let i = 0; i < 3; i++) {
    if (pa[i] !== pb[i]) return pa[i] - pb[i]
  }
  return 0
}

export function getOpenClawVersion() {
  try {
    const out = execSync('openclaw --version 2>/dev/null', { encoding: 'utf8' }).trim()
    const m = out.match(/OpenClaw\s+(\d{4}\.\d+\.\d+)/i)
    return m ? m[1] : null
  } catch {
    return null
  }
}
