#!/usr/bin/env node
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { patchVideoGenerateRecoverAction } from './clawbba-video-recover-patch.mjs'
import { patchImageGenerateRecoverAction } from './clawbba-image-recover-patch.mjs'
import {
  upgradeImageRecoverDeliveryGuard,
  IMAGE_RECOVER_DELIVERY_GUARD_MARKER,
  buildImageRecoverDeliveryTailBlock,
} from './clawbba-external-recover-delivery.mjs'
import { fresh528ToolsPath } from './test-528-fixture.mjs'

const toolsPath = fresh528ToolsPath(process.argv[2] ? path.basename(process.argv[2]) : undefined)

assert.equal(patchVideoGenerateRecoverAction(toolsPath), 'patched')
assert.equal(patchImageGenerateRecoverAction(toolsPath), 'patched')

const src = fs.readFileSync(toolsPath, 'utf8')
assert.ok(src.includes(IMAGE_RECOVER_DELIVERY_GUARD_MARKER), 'fresh patch must use delivery guard')
assert.ok(src.includes('typeof clawbbaDispatchRecoverMediaDelivery === "function"'))

const legacy = `\tconst built = { lines: ["ok"], details: {} };
\t/* clawbba-image-recover-external-delivery */
\tlet deliveryMode = false;
\tif (agentSessionKey) {
\t\tdeliveryMode = await clawbbaDispatchRecoverMediaDelivery({
\t\t\tcfg, sessionKey: agentSessionKey, chatRunId, mediaPaths: [], caption: "", sourceTool: "image_generate", completionLabel: "image", message: "x", label: "x", mediaKind: "image"
\t\t});
\t}
\tif (deliveryMode === "external") {
\t\treturn { content: [{ type: "text", text: "ok" }], details: { deliveredExternal: true } };
\t}
\treturn { content: built.content, details: built.details };`

const fixed = upgradeImageRecoverDeliveryGuard(legacy)
assert.ok(fixed.includes(IMAGE_RECOVER_DELIVERY_GUARD_MARKER))
assert.ok(fixed.includes('typeof clawbbaDispatchWebChatMediaLiveInject === "function"'))
assert.ok(buildImageRecoverDeliveryTailBlock().includes(IMAGE_RECOVER_DELIVERY_GUARD_MARKER))

console.log('test-image-recover-delivery-guard-528: ok')
