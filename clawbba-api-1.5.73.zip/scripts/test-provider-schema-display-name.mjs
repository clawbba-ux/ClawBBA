#!/usr/bin/env node
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import {
  buildClawbbaProviderBlock,
  CLAWBBA_PROVIDER_DISPLAY_NAME,
  enrichAgentModelsProviderBlock,
} from './openclaw-provider-block.mjs'
import { sanitizeOpenclawProviders } from './fix-openclaw-provider-schema.mjs'

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'clawbba-schema-'))
const modelPath = path.join(tmp, 'models.json')
const models = [
  {
    id: 'google/gemini-2.0-flash-001',
    name: 'Gemini',
    reasoning: false,
    input: ['text'],
    cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 },
    contextWindow: 128000,
    maxTokens: 8192,
  },
]
const clawbba = buildClawbbaProviderBlock('cbb_sk_live_test', { models })
const parsed = {
  providers: {
    clawbba: { ...clawbba, name: CLAWBBA_PROVIDER_DISPLAY_NAME },
  },
}
fs.writeFileSync(modelPath, JSON.stringify(parsed, null, 2))

sanitizeOpenclawProviders(parsed.providers, { apiKey: 'cbb_sk_live_test' })
parsed.providers.clawbba = enrichAgentModelsProviderBlock('clawbba', parsed.providers.clawbba)
assert.equal(
  parsed.providers.clawbba.name,
  CLAWBBA_PROVIDER_DISPLAY_NAME,
  'provider-schema 修复后 agent models.json 须有 ClawBBA 展示名',
)
assert.equal('label' in parsed.providers.clawbba, false)

console.log('test-provider-schema-display-name: ok')
