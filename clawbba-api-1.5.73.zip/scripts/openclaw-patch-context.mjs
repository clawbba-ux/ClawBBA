/**
 * Derive runtime patch context from installed OpenClaw dist + version profile.
 */
import fs from 'node:fs'
import path from 'node:path'
import { findAllOpenclawDists, findDistJsFile } from './openclaw-dist-paths.mjs'
import { resolveOpenClawCompatProfile, OPENCLAW_COMPAT_PROFILES } from './openclaw-compat-profiles.mjs'
import { compareCalVer, getOpenClawVersion } from './openclaw-calver.mjs'
import {
  resolveReadStringParamIdent,
  resolveVideoGenerateExecuteArgsIdent,
} from './openclaw-tools-compat.mjs'

/** 已在 CI / 本地完整 patch 测试过的最高 OpenClaw 版本 */
export const OPENCLAW_COMPAT_TESTED_MAX_VERSION =
  OPENCLAW_COMPAT_PROFILES[0]?.minVersion ?? '2026.5.28'

export function isOpenClawVersionNewerThanTested(version = getOpenClawVersion()) {
  if (!version) return false
  const cmp = compareCalVer(version, OPENCLAW_COMPAT_TESTED_MAX_VERSION)
  return cmp !== null && cmp > 0
}

function readToolsSrc(dist) {
  const file = findDistJsFile(dist, 'openclaw-tools-')
  if (!file) return null
  return fs.readFileSync(path.join(dist, file), 'utf8')
}

/**
 * @param {string | null | undefined} [version]
 * @param {string | null | undefined} [distOverride]
 */
export function resolveOpenClawPatchContext(version = getOpenClawVersion(), distOverride = null) {
  const profile = resolveOpenClawCompatProfile(version)
  const dists = distOverride ? [distOverride] : findAllOpenclawDists()
  const dist = dists[0] ?? null
  const toolsSrc = dist ? readToolsSrc(dist) : null

  const readStringParamIdent = toolsSrc ? resolveReadStringParamIdent(toolsSrc) : profile.patch.readStringParamSuffix ? 'readStringParam$1' : 'readStringParam'
  const videoExecuteArgsIdent = toolsSrc ? resolveVideoGenerateExecuteArgsIdent(toolsSrc) : profile.id === '2026.5.28' ? 'args' : 'params'
  const imageExecuteArgsIdent = toolsSrc?.includes('function createImageGenerateTool(') && toolsSrc.includes('const params = args') ? 'params' : 'params'

  return {
    version: profile.version,
    profileId: profile.profileId,
    profile,
    dist,
    toolsSrc,
    readStringParamIdent,
    videoExecuteArgsIdent,
    imageExecuteArgsIdent,
    newerThanTested: isOpenClawVersionNewerThanTested(profile.version),
    testedMaxVersion: OPENCLAW_COMPAT_TESTED_MAX_VERSION,
  }
}
