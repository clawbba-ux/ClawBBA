/**
 * Shared ClawBBA provider block for openclaw.json / agent models.json.
 * OpenClaw 2026.5+ 要求 models.providers.*.models 为完整 ModelDefinitionConfig（含 reasoning/cost/maxTokens）。
 */
import {
  IMAGE_MODEL_SPECS,
  VIDEO_MODEL_SPECS,
} from './clawbba-openclaw-media-catalog.mjs'

const API_BASE = (process.env.CLAWBBA_API_BASE || 'https://www.clawbba.com/api/v1').replace(
  /\/$/,
  '',
)

/** agent models.json providers.*.name（模型列表/注册表展示） */
export const CLAWBBA_PROVIDER_DISPLAY_NAME = 'ClawBBA'

/** WebChat 消息下方 chat-sender-name（agent.identity.get → ui.assistant.name） */
export const CLAWBBA_WEBCHAT_ASSISTANT_NAME = 'Assistant from ClawBBA'

const AGENT_MODELS_BRANDED_PROVIDER_KEYS = ['clawbba', 'openrouter']

/**
 * @param {string} providerKey
 * @param {Record<string, unknown>} providerBlock
 */
export function enrichAgentModelsProviderBlock(providerKey, providerBlock) {
  if (!providerBlock || typeof providerBlock !== 'object') return providerBlock
  const key = String(providerKey || '').trim().toLowerCase()
  if (!AGENT_MODELS_BRANDED_PROVIDER_KEYS.includes(key)) return providerBlock
  if (providerBlock.name === CLAWBBA_PROVIDER_DISPLAY_NAME) return providerBlock
  return { ...providerBlock, name: CLAWBBA_PROVIDER_DISPLAY_NAME }
}

/** OpenClaw pi 客户端 UA；避免部分 CDN/WAF 拦截非浏览器 UA */
export const CLAWBBA_OPENCLAW_HEADERS = {
  'User-Agent': 'curl/8.4.0 (ClawBBA-OpenClaw)',
  'HTTP-Referer': 'https://www.clawbba.com',
  'X-Title': 'ClawBBA OpenClaw',
}

const ZERO_COST = { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 }

/**
 * OpenClaw ModelDefinitionConfig 最小合法条目
 * @param {string} id
 * @param {string} name
 * @param {'text'|'image'|'video'} category
 */
/**
 * @param {string} id
 * @param {string} name
 * @param {'text'|'image'|'video'} category
 * @param {{ visionText?: boolean }} [opts] — 多模态文本（聊天看图），非生图模型
 */
export function buildMinimalModelDefinition(id, name, category = 'text', opts = {}) {
  const modelId = String(id || '').trim()
  const visionText = opts.visionText === true
  const input =
    category === 'image'
      ? ['text', 'image']
      : category === 'video'
        ? ['text', 'video']
        : visionText
          ? ['text', 'image']
          : ['text']
  const ctx =
    category === 'image' ? 65_536 : category === 'video' ? 32_768 : 128_000
  return {
    id: modelId,
    name: String(name || modelId).trim() || modelId,
    reasoning: false,
    input,
    cost: { ...ZERO_COST },
    contextWindow: ctx,
    maxTokens: 8192,
  }
}

/** 从 ClawBBA /models 列表提取生图/生视频模型（供 openrouter provider） */
export function buildOpenrouterMediaModelsFromCatalogRows(rows) {
  const out = []
  for (const m of rows || []) {
    const cat = String(m.category || '').toLowerCase()
    if (cat !== 'image' && cat !== 'video') continue
    const id = String(m.id || '').trim()
    if (!id) continue
    out.push(buildMinimalModelDefinition(id, m.name || id, cat))
  }
  return out
}

/** 无 API 时的静态生图/生视频模型表 */
export function buildStaticOpenrouterMediaModels() {
  return [
    ...IMAGE_MODEL_SPECS.map((s) => buildMinimalModelDefinition(s.id, s.label, 'image')),
    ...VIDEO_MODEL_SPECS.map((s) => buildMinimalModelDefinition(s.id, s.label, 'video')),
  ]
}

export function isValidOpenclawModelDefinition(m) {
  return (
    m &&
    typeof m === 'object' &&
    typeof m.id === 'string' &&
    m.id.trim() &&
    typeof m.name === 'string' &&
    typeof m.reasoning === 'boolean' &&
    m.cost &&
    typeof m.cost.input === 'number' &&
    typeof m.contextWindow === 'number' &&
    typeof m.maxTokens === 'number' &&
    Array.isArray(m.input) &&
    m.input.length > 0
  )
}

export function openrouterModelsNeedRebuild(models) {
  if (!Array.isArray(models) || models.length === 0) return true
  return models.some((m) => !isValidOpenclawModelDefinition(m))
}

/**
 * @param {string} apiKey
 * @param {{ models?: unknown[] }} [opts]
 */
export function buildClawbbaProviderBlock(apiKey, opts = {}) {
  const key = String(apiKey || '').trim()
  const block = {
    baseUrl: API_BASE,
    apiKey: key,
    api: 'openai-completions',
    auth: 'api-key',
    headers: { ...CLAWBBA_OPENCLAW_HEADERS },
  }
  if (Array.isArray(opts.models) && opts.models.length) {
    block.models = opts.models
  }
  return block
}

/** openrouter → ClawBBA API（生图/生视频）；须带合法 models 数组 */
export function buildOpenrouterProviderBlock(apiKey, opts = {}) {
  const models = Array.isArray(opts.models) && opts.models.length
    ? opts.models
    : buildStaticOpenrouterMediaModels()
  return {
    baseUrl: API_BASE,
    apiKey: String(apiKey || '').trim(),
    api: 'openai-completions',
    auth: 'api-key',
    headers: { ...CLAWBBA_OPENCLAW_HEADERS },
    models,
  }
}

/** @param {string} apiKey */
export function buildOpenclawEnvBlock(apiKey) {
  const key = String(apiKey || '').trim()
  return {
    CLAWBBA_API_KEY: key,
    OPENROUTER_API_KEY: key,
  }
}
