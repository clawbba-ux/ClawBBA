/**
 * External channel (WeChat / Telegram / …) recover delivery:
 * sequential sendMessage (original quality — no re-encode/compress).
 */
import fs from 'fs'
import path from 'path'

export const EXTERNAL_RECOVER_DELIVERY_MARKER = '/* clawbba-external-recover-delivery */'
export const EXTERNAL_RECOVER_DELIVERY_V2_MARKER = '/* clawbba-external-recover-delivery-v2 */'
export const EXTERNAL_RECOVER_DELIVERY_V3_MARKER = '/* clawbba-external-recover-delivery-v3-no-compress */'
export const IMAGE_RECOVER_EXTERNAL_DELIVERY_MARKER = '/* clawbba-image-recover-external-delivery */'
export const IMAGE_RECOVER_DELIVERY_GUARD_MARKER = '/* clawbba-image-recover-delivery-guard */'
export const VIDEO_RECOVER_EXTERNAL_DELIVERY_MARKER = '/* clawbba-video-recover-external-delivery */'

export function buildClawbbaDedupeImageBuffersFnBlock() {
  return `function clawbbaDedupeImageBuffers(buffers) {
\tconst seen = new Set();
\tconst out = [];
\tfor (const b of buffers) {
\t\tif (!b?.buffer?.length) continue;
\t\tlet key;
\t\ttry {
\t\t\tkey = crypto.createHash("sha256").update(b.buffer).digest("hex");
\t\t} catch (_) {
\t\t\tkey = \`\${b.buffer.length}:\${b.mime}:\${b.buffer.subarray(0, Math.min(32, b.buffer.length)).toString("base64")}\`;
\t\t}
\t\tif (seen.has(key)) continue;
\t\tseen.add(key);
\t\tout.push(b);
\t}
\treturn out;
}`
}

/** @param {string} deliveryRuntimeBasename */
export function buildExternalRecoverMediaDispatchBlock(deliveryRuntimeBasename) {
  return `${EXTERNAL_RECOVER_DELIVERY_MARKER}
${EXTERNAL_RECOVER_DELIVERY_V2_MARKER}
${EXTERNAL_RECOVER_DELIVERY_V3_MARKER}
function clawbbaIsWeixinLikeChannel(channel) {
\tconst ch = String(channel || "").toLowerCase();
\treturn ch.includes("weixin") || ch === "wechat";
}
function clawbbaRecoverExternalSendGapMs(channel) {
\treturn clawbbaIsWeixinLikeChannel(channel) ? 4500 : 1500;
}
async function clawbbaDispatchRecoverMediaToExternalChannel(params) {
\tconst sessionKey = typeof params.sessionKey === "string" ? params.sessionKey.trim() : "";
\tconst mediaPaths = Array.isArray(params.mediaPaths) ? params.mediaPaths.filter((p) => typeof p === "string" && p.trim()) : [];
\tconst chatRunId = typeof params.chatRunId === "string" ? params.chatRunId.trim() : "";
\tif (!sessionKey || mediaPaths.length === 0) return false;
\tlet origin;
\ttry {
\t\tconst delivery = inferDeliveryFromSessionKey(sessionKey);
\t\torigin = normalizeDeliveryContext(delivery);
\t} catch (_) {
\t\treturn false;
\t}
\tif (!origin?.channel || !origin?.to || !isDeliverableMessageChannel(origin.channel)) return false;
\tconst ch = normalizeMessageChannel(origin.channel);
\tif (!ch || ch === "webchat") return false;
\tconst agentId = resolveAgentIdFromSessionKey(sessionKey);
\tconst gapMs = clawbbaRecoverExternalSendGapMs(ch);
\tconst caption = typeof params.caption === "string" ? params.caption.trim() : "";
\tlet delivered = 0;
\ttry {
\t\tconst { sendMessage } = await import("./${deliveryRuntimeBasename}");
\t\tfor (let i = 0; i < mediaPaths.length; i++) {
\t\t\tconst mediaUrl = mediaPaths[i].trim();
\t\t\tconst content = i === 0 && caption ? caption : "";
\t\t\ttry {
\t\t\t\tawait sendMessage({
\t\t\t\t\tcfg: params.cfg,
\t\t\t\t\tchannel: origin.channel,
\t\t\t\t\tto: origin.to,
\t\t\t\t\taccountId: origin.accountId,
\t\t\t\t\tthreadId: origin.threadId,
\t\t\t\t\tcontent,
\t\t\t\t\tmediaUrl,
\t\t\t\t\trequesterSessionKey: sessionKey,
\t\t\t\t\tagentId,
\t\t\t\t\tbestEffort: true,
\t\t\t\t\tmirror: { sessionKey, agentId }
\t\t\t\t});
\t\t\t\tdelivered++;
\t\t\t} catch (err) {
\t\t\t\ttry {
\t\t\t\t\tlog$5.warn("clawbba recover external media send failed", { mediaUrl, channel: ch, error: String(err?.message ?? err) });
\t\t\t\t} catch (_) {}
\t\t\t}
\t\t\tif (i < mediaPaths.length - 1 && gapMs > 0) await new Promise((r) => setTimeout(r, gapMs));
\t\t}
\t} catch (err) {
\t\ttry {
\t\t\tlog$5.warn("clawbba recover external delivery failed", { error: String(err?.message ?? err) });
\t\t} catch (_) {}
\t\treturn false;
\t}
\tif (delivered > 0 && typeof clawbbaMarkReadOnlyToolTextReplyDispatched === "function") {
\t\tclawbbaMarkReadOnlyToolTextReplyDispatched(chatRunId);
\t}
\treturn delivered > 0;
}
async function clawbbaDispatchRecoverMediaDelivery(params) {
\tconst sessionKey = typeof params.sessionKey === "string" ? params.sessionKey.trim() : "";
\tconst mediaPaths = Array.isArray(params.mediaPaths) ? params.mediaPaths.filter((p) => typeof p === "string" && p.trim()) : [];
\tif (!sessionKey || mediaPaths.length === 0) return false;
\tif (typeof clawbbaDispatchRecoverMediaToExternalChannel === "function") {
\t\tconst external = await clawbbaDispatchRecoverMediaToExternalChannel({
\t\t\tcfg: params.cfg,
\t\t\tsessionKey,
\t\t\tchatRunId: params.chatRunId,
\t\t\tmediaPaths,
\t\t\tcaption: params.caption,
\t\t\tlabel: params.label,
\t\t\tmediaKind: params.mediaKind
\t\t});
\t\tif (external) return "external";
\t}
\tif (typeof clawbbaDispatchWebChatMediaLiveInject === "function") {
\t\tconst injected = await clawbbaDispatchWebChatMediaLiveInject({
\t\t\tsessionKey,
\t\t\tchatRunId: params.chatRunId,
\t\t\tmediaUrls: mediaPaths,
\t\t\tsourceTool: params.sourceTool,
\t\t\tcompletionLabel: params.completionLabel,
\t\t\tmessage: params.message
\t\t});
\t\tif (injected) return "webchat";
\t}
\treturn false;
}`
}

export function buildImageRecoverDeliveryTailBlock() {
  return `\t${IMAGE_RECOVER_EXTERNAL_DELIVERY_MARKER}
\t${IMAGE_RECOVER_DELIVERY_GUARD_MARKER}
\tlet deliveryMode = false;
\tif (agentSessionKey) {
\t\tif (typeof clawbbaDispatchRecoverMediaDelivery === "function") {
\t\t\tdeliveryMode = await clawbbaDispatchRecoverMediaDelivery({
\t\t\t\tcfg,
\t\t\t\tsessionKey: agentSessionKey,
\t\t\t\tchatRunId,
\t\t\t\tmediaPaths: savedImages.map((img) => img.path),
\t\t\t\tcaption: built.lines?.[0] || \`Recovered image job \${jobId}\`,
\t\t\t\tsourceTool: "image_generate",
\t\t\t\tcompletionLabel: "image",
\t\t\t\tmessage: built.lines.join("\\n"),
\t\t\t\tlabel: "ClawBBA image recover",
\t\t\t\tmediaKind: "image"
\t\t\t});
\t\t} else if (typeof clawbbaDispatchWebChatMediaLiveInject === "function") {
\t\t\tawait clawbbaDispatchWebChatMediaLiveInject({
\t\t\t\tsessionKey: agentSessionKey,
\t\t\t\tchatRunId,
\t\t\t\tmediaUrls: savedImages.map((img) => img.path),
\t\t\t\tsourceTool: "image_generate",
\t\t\t\tcompletionLabel: "image",
\t\t\t\tmessage: built.lines.join("\\n")
\t\t\t});
\t\t}
\t}
\tif (deliveryMode === "external") {
\t\tconst confirm = [
\t\t\t\`Recovered image job \${jobId} — delivered to your chat channel.\`,
\t\t\t"Reply with ONE short confirmation only; do NOT paste MEDIA: lines or call message tool (avoids duplicate WeChat CDN uploads)."
\t\t].join("\\n");
\t\treturn { content: [{ type: "text", text: confirm }], details: { ...built.details, deliveredExternal: true } };
\t}
\treturn { content: built.content, details: built.details };`
}

/** @param {string} src */
export function upgradeImageRecoverDeliveryGuard(src) {
  if (src.includes(IMAGE_RECOVER_DELIVERY_GUARD_MARKER)) return src
  if (!src.includes(IMAGE_RECOVER_EXTERNAL_DELIVERY_MARKER)) return src
  const unguardedRe =
    /\t\/\* clawbba-image-recover-external-delivery \*\/\n\tlet deliveryMode = false;\n\tif \(agentSessionKey\) \{\n\t\tdeliveryMode = await clawbbaDispatchRecoverMediaDelivery\(\{[\s\S]*?\t\}\);\n\t\}\n\tif \(deliveryMode === "external"\) \{[\s\S]*?\treturn \{ content: built\.content, details: built\.details \};/
  if (!unguardedRe.test(src)) return src
  return src.replace(unguardedRe, buildImageRecoverDeliveryTailBlock())
}

/** @param {string} dist @param {string} toolsSrc */
export function findDeliveryRuntimeBasename(dist, toolsSrc) {
  const fromTools = toolsSrc.match(/import\("\.\/(task-registry-delivery-runtime-[^"]+\.js)"\)/)
  if (fromTools) return fromTools[1]
  return fs.readdirSync(dist).find(
    (n) => n.startsWith('task-registry-delivery-runtime-') && n.endsWith('.js'),
  )
}

/** @param {string} src @param {string} fnName */
export function countFunctionDefinitions(src, fnName) {
  const escaped = fnName.replace(/\$/g, '\\$')
  const fnRe = new RegExp(`(?:async )?function ${escaped}\\s*\\(`, 'g')
  return (src.match(fnRe) || []).length
}

const RECOVER_HELPER_FN_NAMES = [
  'clawbbaDedupeImageBuffers',
  'clawbbaAssertPollJobIdMatches',
  'clawbbaPollClawbbaImageJob',
]

/** Remove duplicate recover helper fn bodies (keep first). Fixes partial-upgrade SyntaxError. */
export function stripDuplicateRecoverHelperDefinitions(src) {
  let out = src
  for (const fnName of RECOVER_HELPER_FN_NAMES) {
    if (countFunctionDefinitions(out, fnName) <= 1) continue
    let seen = 0
    const escaped = fnName.replace(/\$/g, '\\$')
    const paramPat = fnName === 'clawbbaDedupeImageBuffers' ? 'buffers' : '[^)]*'
    const re = new RegExp(`(?:async )?function ${escaped}\\(${paramPat}\\) \\{[\\s\\S]*?\\n\\}`, 'g')
    out = out.replace(re, (m) => {
      seen++
      return seen === 1 ? m : ''
    })
  }
  return out.replace(/\n{3,}/g, '\n\n')
}

/** @param {string} src @param {string} fnName */
export function imageRecoverRuntimeFnDefined(src, fnName) {
  return countFunctionDefinitions(src, fnName) > 0
}

/** @param {string} src */
export function stripRecoverImageCompressionSteps(src) {
  return src.replace(
    /\n\tif \(typeof clawbbaCompressLargeRecoveredImageBuffers === "function"\) \{\n\t\tbuffers = await clawbbaCompressLargeRecoveredImageBuffers\(buffers\);\n\t\} else if \(agentSessionKey && typeof clawbbaMaybeOptimizeImageBuffersForWeixin === "function"\) \{\n\t\ttry \{\n\t\t\tconst delivery = inferDeliveryFromSessionKey\(agentSessionKey\);\n\t\t\tconst origin = normalizeDeliveryContext\(delivery\);\n\t\t\tconst ch = normalizeMessageChannel\(origin\?\.channel ?? ""\);\n\t\t\tif \(clawbbaIsWeixinLikeChannel\(ch\)\) buffers = await clawbbaMaybeOptimizeImageBuffersForWeixin\(buffers\);\n\t\t\} catch \(_\) \{\}\n\t\}/,
    '',
  )
}

/** @param {string} toolsPath @param {string} deliveryRuntimeBasename */
export function ensureExternalRecoverMediaDispatchInTools(toolsPath, deliveryRuntimeBasename) {
  let src = fs.readFileSync(toolsPath, 'utf8')
  if (src.includes(EXTERNAL_RECOVER_DELIVERY_V3_MARKER)) {
    const stripped = stripRecoverImageCompressionSteps(src)
    if (stripped !== src) fs.writeFileSync(toolsPath, stripped)
    return stripped
  }
  const block = buildExternalRecoverMediaDispatchBlock(deliveryRuntimeBasename)
  if (src.includes(EXTERNAL_RECOVER_DELIVERY_MARKER)) {
    src = src.replace(
      /\/\* clawbba-external-recover-delivery \*\/[\s\S]*?(?=async function clawbbaDispatchWebChatMediaLiveInject\(params\) \{)/,
      `${block}\n`,
    )
  } else {
    const anchors = [
      'async function clawbbaDispatchWebChatMediaLiveInject(params) {',
      'async function clawbbaDispatchReadOnlyToolTextReply(params) {',
      'async function clawbbaRecoverVideoTask({',
      'function createImageGenerateTool(options) {',
    ]
    const anchor = anchors.find((a) => src.includes(a))
    if (!anchor) return src
    src = src.replace(anchor, `${block}\n${anchor}`)
  }
  src = stripRecoverImageCompressionSteps(src)
  fs.writeFileSync(toolsPath, src)
  return src
}

/** @param {string} toolsPath @param {string} distDir */
export function ensureImageRecoverDeliveryInTools(toolsPath, distDir) {
  let src = fs.readFileSync(toolsPath, 'utf8')
  src = upgradeImageRecoverDeliveryGuard(src)
  if (
    !imageRecoverRuntimeFnDefined(src, 'clawbbaDispatchRecoverMediaDelivery') &&
    src.includes('async function clawbbaRecoverImageTask')
  ) {
    const deliveryRuntime = findDeliveryRuntimeBasename(distDir, src)
    if (deliveryRuntime) {
      ensureExternalRecoverMediaDispatchInTools(toolsPath, deliveryRuntime)
      src = fs.readFileSync(toolsPath, 'utf8')
      src = upgradeImageRecoverDeliveryGuard(src)
    }
  }
  const onDisk = fs.readFileSync(toolsPath, 'utf8')
  if (src !== onDisk) fs.writeFileSync(toolsPath, src)
  return src
}

/**
 * @param {string} dist
 * @param {(dist: string, prefix: string, exportName?: string) => string | undefined} findDistFile
 */
export function patchExternalRecoverMediaDelivery(dist, findDistFile) {
  const toolsFile = findDistFile(dist, 'openclaw-tools-')
  if (!toolsFile) return 'missing-tools'
  const toolsPath = path.join(dist, toolsFile)
  const toolsSrc = fs.readFileSync(toolsPath, 'utf8')
  const deliveryRuntime = findDeliveryRuntimeBasename(dist, toolsSrc)
  if (!deliveryRuntime) return 'missing-deps'
  const before = toolsSrc
  ensureExternalRecoverMediaDispatchInTools(toolsPath, deliveryRuntime)
  ensureImageRecoverDeliveryInTools(toolsPath, dist)
  const after = fs.readFileSync(toolsPath, 'utf8')
  if (!after.includes(EXTERNAL_RECOVER_DELIVERY_V3_MARKER)) return 'pattern-missing'
  if (after === before) return 'skip'
  if (before.includes(EXTERNAL_RECOVER_DELIVERY_V3_MARKER)) return 'skip'
  if (before.includes(EXTERNAL_RECOVER_DELIVERY_V2_MARKER)) return 'upgraded-v3-no-compress'
  if (before.includes(EXTERNAL_RECOVER_DELIVERY_MARKER)) return 'upgraded-v3-no-compress'
  return 'patched'
}

/** @param {string} src */
export function imageRecoverHasExternalDelivery(src) {
  return src.includes(IMAGE_RECOVER_EXTERNAL_DELIVERY_MARKER)
}

/** @param {string} src */
export function upgradeImageRecoverExternalDelivery(src) {
  if (imageRecoverHasExternalDelivery(src)) return upgradeImageRecoverDeliveryGuard(src)
  const oldBlock =
    /\tconst \{ pollBody, buffers \} = await clawbbaPollClawbbaImageJob\(\{ baseUrl, hdrs, jobId, maxWaitMs \}\);\n\tconst savedImages = await clawbbaSaveRecoveredImageBuffers\(\{ cfg, buffers, filename \}\);\n\tconst built = clawbbaBuildRecoveredImageToolResult\(\{ jobId, pollBody, savedImages \}\);\n\tif \(agentSessionKey\) \{\n\t\tawait clawbbaDispatchWebChatMediaLiveInject\(\{[\s\S]*?\t\}\);\n\t\}\n\treturn \{ content: built\.content, details: built\.details \};/
  if (!oldBlock.test(src)) return src
  const replacement = `\tconst { pollBody, buffers: rawBuffers } = await clawbbaPollClawbbaImageJob({ baseUrl, hdrs, jobId, maxWaitMs });
\tclawbbaAssertPollJobIdMatches(jobId, pollBody);
\tconst buffers = clawbbaDedupeImageBuffers(rawBuffers);
\tconst savedImages = await clawbbaSaveRecoveredImageBuffers({ cfg, buffers, filename });
\tconst built = clawbbaBuildRecoveredImageToolResult({ jobId, pollBody, savedImages });
${buildImageRecoverDeliveryTailBlock()}`
  return src.replace(oldBlock, replacement)
}

/** @param {string} src */
export function upgradeVideoRecoverExternalDelivery(src) {
  if (src.includes(VIDEO_RECOVER_EXTERNAL_DELIVERY_MARKER)) return src
  const oldBlock =
    /\tconst built = clawbbaBuildRecoveredVideoToolResult\(\{ jobId, statusPayload, saved \}\);[\s\S]*?return \{\n\t\tcontent: built\.content,\n\t\tdetails: built\.details,\n\t\};/
  if (!oldBlock.test(src)) return src
  const replacement = `\tconst built = clawbbaBuildRecoveredVideoToolResult({ jobId, statusPayload, saved });
\t${VIDEO_RECOVER_EXTERNAL_DELIVERY_MARKER}
\tlet deliveryMode = false;
\tif (agentSessionKey) {
\t\tif (typeof clawbbaDispatchRecoverMediaDelivery === "function") {
\t\t\tdeliveryMode = await clawbbaDispatchRecoverMediaDelivery({
\t\t\t\tcfg,
\t\t\t\tsessionKey: agentSessionKey,
\t\t\t\tchatRunId,
\t\t\t\tmediaPaths: [saved.path],
\t\t\t\tcaption: built.lines?.[0] || \`Recovered video job \${jobId}\`,
\t\t\t\tsourceTool: "video_generate",
\t\t\t\tcompletionLabel: "video",
\t\t\t\tmessage: built.lines.join("\\n"),
\t\t\t\tlabel: "ClawBBA video recover",
\t\t\t\tmediaKind: "video"
\t\t\t});
\t\t} else if (typeof clawbbaDispatchWebChatMediaLiveInject === "function") {
\t\t\tawait clawbbaDispatchWebChatMediaLiveInject({
\t\t\t\tsessionKey: agentSessionKey,
\t\t\t\tchatRunId,
\t\t\t\tmediaUrls: [saved.path],
\t\t\t\tsourceTool: "video_generate",
\t\t\t\tcompletionLabel: "video",
\t\t\t\tmessage: built.lines.join("\\n")
\t\t\t});
\t\t}
\t}
\tif (deliveryMode === "external") {
\t\tconst confirm = [
\t\t\t\`Recovered video job \${jobId} — delivered to your chat channel.\`,
\t\t\t"Reply with ONE short confirmation only; do NOT paste MEDIA: lines or call message tool."
\t\t].join("\\n");
\t\treturn { content: [{ type: "text", text: confirm }], details: { ...built.details, deliveredExternal: true } };
\t}
\treturn {
\t\tcontent: built.content,
\t\tdetails: built.details,
\t};`
  return src.replace(oldBlock, replacement)
}
