#!/usr/bin/env node
import assert from 'node:assert/strict'
import {
  buildRecoverJobKindHelpersBlock,
  upgradeRecoverJobKindValidation,
  stripLegacyRecoverAutoPick,
  RECOVER_JOB_KIND_MARKER,
} from './clawbba-recover-job-kind.mjs'

const block = buildRecoverJobKindHelpersBlock()
assert.ok(block.includes(RECOVER_JOB_KIND_MARKER))
assert.ok(block.includes('clawbbaResolveImageRecoverJobId'))
assert.ok(block.includes('clawbbaResolveVideoRecoverJobId'))
assert.ok(block.includes('clawbbaReadRecoverJobIdField'))
assert.ok(block.includes('clawbbaDetectRecoverJobMediaKind'))

const legacy = `
async function clawbbaRecoverImageTask() {}
function clawbbaResolveRecoverJobId(args) { return ""; }
async function clawbbaRecoverVideoTask({ cfg, args, agentDir, authStore, agentSessionKey, chatRunId }) {
\t/* clawbba-video-recover-strict-job */
\tlet jobId = clawbbaResolveRecoverJobId(args);
\tconst maxWaitMs = 1;
\tconst orCfg = cfg?.models?.providers?.openrouter;
\tconst baseUrl = String(orCfg?.baseUrl || "").replace(/\\/$/, "");
\tif (!baseUrl) throw new ToolInputError("No openrouter provider baseUrl configured.");
\tconst apiKey = await clawbbaResolveOpenRouterApiKey({ cfg, agentDir, authStore });
\tconst hdrs = { Authorization: \`Bearer \${apiKey}\`, Accept: "application/json" };
\tif (!jobId) {
\t\tthrow new ToolInputError("video_generate action=recover requires jobId=<uuid>. Run video_generate action=tasks first, then recover the exact job id from that list (timeoutMs=600000).");
\t}
\tconst pollIntervalMs = 5000;
}
`

const upgraded = upgradeRecoverJobKindValidation(legacy)
assert.ok(upgraded.includes('clawbbaResolveVideoRecoverJobId'))
assert.ok(upgraded.includes('expectedKind: "video"'))
assert.ok(!upgraded.includes('let jobId = clawbbaResolveRecoverJobId(args)'))

const autoPick = `\tif (!jobId) {
\t\tconst listRes = await fetch(\`\${baseUrl}/images/tasks?limit=10\`, { method: "GET", headers: hdrs });
\t\tconst pick = rows.find((r) => String(r?.status || "").toLowerCase() === "completed");
\t\tjobId = String(pick.image_job_id || pick.job_id).trim();
\t}
`
assert.ok(!stripLegacyRecoverAutoPick(autoPick).includes('pick.image_job_id || pick.job_id'))

console.log('test-recover-job-kind: ok')
