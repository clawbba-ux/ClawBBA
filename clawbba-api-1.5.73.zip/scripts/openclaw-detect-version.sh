#!/usr/bin/env bash
# 解析 openclaw --version（安装脚本解压 skill 前可用的轻量探测）
set -euo pipefail

OPENCLAW_COMPAT_MIN_VERSION="${OPENCLAW_COMPAT_MIN_VERSION:-2026.5.12}"

openclaw_detect_version_quick() {
  local raw=""
  raw="$(openclaw --version 2>/dev/null || true)"
  printf '%s\n' "$raw" | sed -n 's/.*OpenClaw \([0-9]\{4\}\.[0-9]\+\.[0-9]\+\).*/\1/p' | head -n1
}

# 日历版本比较：当前版本 >= min 返回 0
openclaw_version_meets_min() {
  local current="${1:?current version required}"
  local min="${2:-$OPENCLAW_COMPAT_MIN_VERSION}"
  node -e "
const current = process.argv[1];
const min = process.argv[2];
function parse(v) {
  const m = String(v || '').trim().match(/^(\\d+)\\.(\\d+)\\.(\\d+)/);
  return m ? [Number(m[1]), Number(m[2]), Number(m[3])] : null;
}
function cmp(a, b) {
  for (let i = 0; i < 3; i++) if (a[i] !== b[i]) return a[i] - b[i];
  return 0;
}
const pa = parse(current);
const pb = parse(min);
if (!pa || !pb) process.exit(3);
process.exit(cmp(pa, pb) >= 0 ? 0 : 2);
" "$current" "$min"
}

openclaw_print_unsupported_upgrade_hint() {
  local version="${1:-unknown}"
  cat >&2 <<EOF

══════════════════════════════════════════
 OpenClaw 版本过低，暂不支持安装 ClawBBA
══════════════════════════════════════════

  当前 OpenClaw 版本：${version}
  ClawBBA 最低要求：  OpenClaw ${OPENCLAW_COMPAT_MIN_VERSION} 或更高
  推荐做法：          升级到 OpenClaw 最新稳定版

请先升级 OpenClaw，然后重新运行安装脚本：

  npm i -g openclaw@latest
  openclaw --version

  export CLAWBBA_API_KEY='cbb_sk_live_你的完整密钥'
  curl -fsSL https://www.clawbba.com/downloads/install-clawbba-api.sh | bash
  openclaw gateway restart

OpenClaw 文档：https://docs.openclaw.ai

EOF
}

openclaw_assert_min_version_or_exit() {
  local version="${1:?version required}"
  if openclaw_version_meets_min "$version"; then
    return 0
  fi
  openclaw_print_unsupported_upgrade_hint "$version"
  return 2
}

openclaw_detect_version_from_skill() {
  local skill_root="${1:?skill root required}"
  local strict="${2:-0}"
  local detect_js="${skill_root}/scripts/detect-openclaw-version.mjs"
  if [[ ! -f "$detect_js" ]]; then
    echo "[clawbba-api] ✗ 未找到 ${detect_js}" >&2
    return 1
  fi
  local args=(--shell)
  if [[ "$strict" == "1" ]]; then
    args+=(--strict)
  fi
  eval "$(node "$detect_js" "${args[@]}")"
}

openclaw_print_compat_banner() {
  local version="${1:-unknown}"
  local profile_id="${2:-pending}"
  local profile_label="${3:-完整 profile 将在解压 clawbba-api 后确认}"
  echo "  OpenClaw 版本: ${version}"
  echo "  安装 profile:  ${profile_id} — ${profile_label}"
}
