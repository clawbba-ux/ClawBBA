/**
 * OpenClaw × ClawBBA 兼容 profile（安装 / patch / config 的唯一版本矩阵）
 *
 * 新增 OpenClaw 版本时：在此追加 profile（minVersion 从新到旧排序），并补充 patch / 测试。
 */
import { compareCalVer, getOpenClawVersion, parseCalVer } from './openclaw-calver.mjs'

/** 低于此版本拒绝安装（clawbba-api 未验证） */
export const OPENCLAW_COMPAT_MIN_VERSION = '2026.5.12'

/** 推荐用户执行的 OpenClaw 升级命令 */
export const OPENCLAW_UPGRADE_COMMAND = 'npm i -g openclaw@latest'

export const OPENCLAW_DOCS_URL = 'https://docs.openclaw.ai'

export const CLAWBBA_INSTALL_SCRIPT_URL = 'https://www.clawbba.com/downloads/install-clawbba-api.sh'

/**
 * @param {string | null | undefined} [version]
 * @returns {string}
 */
export function formatOpenClawUnsupportedUpgradeMessage(version) {
  const current = version?.trim() || '(无法识别)'
  return [
    '',
    '══════════════════════════════════════════',
    ' OpenClaw 版本过低，暂不支持安装 ClawBBA',
    '══════════════════════════════════════════',
    '',
    `  当前 OpenClaw 版本：${current}`,
    `  ClawBBA 最低要求：  OpenClaw ${OPENCLAW_COMPAT_MIN_VERSION} 或更高`,
    '  推荐做法：          升级到 OpenClaw 最新稳定版',
    '',
    'ClawBBA 依赖 OpenClaw 内置 image_generate / video_generate 与 WebChat 交付能力。',
    '版本过旧时无法正确写入 runtime patch，继续安装会导致生图/生视频或模型加载异常。',
    '',
    '请按顺序执行：',
    '',
    '  1. 升级 OpenClaw 到最新版',
    `     ${OPENCLAW_UPGRADE_COMMAND}`,
    '     openclaw --version    # 确认 ≥ ' + OPENCLAW_COMPAT_MIN_VERSION,
    '',
    '  2. 重新安装 ClawBBA',
    "     export CLAWBBA_API_KEY='cbb_sk_live_你的完整密钥'",
    `     curl -fsSL ${CLAWBBA_INSTALL_SCRIPT_URL} | bash`,
    '',
    '  3. 重启 Gateway',
    '     openclaw gateway restart',
    '',
    `OpenClaw 文档：${OPENCLAW_DOCS_URL}`,
    '',
  ].join('\n')
}

/** @typedef {'current' | 'stable' | 'unsupported' | 'unknown'} OpenClawCompatTier */

/**
 * @type {Array<{
 *   id: string
 *   minVersion: string
 *   label: string
 *   tier: OpenClawCompatTier
 *   blocked: boolean
 *   config: { systemPromptOverride: boolean, agentRulesViaSkillAlways: boolean }
 *   patch: { toolsBundle: string, readStringParamSuffix: boolean, announcePatchOptional: boolean }
 *   installNotes: string[]
 * }>}
 */
export const OPENCLAW_COMPAT_PROFILES = [
  {
    id: '2026.5.28',
    minVersion: '2026.5.28',
    label: 'OpenClaw 2026.5.28 及更新',
    tier: 'current',
    blocked: false,
    config: {
      systemPromptOverride: false,
      agentRulesViaSkillAlways: true,
    },
    patch: {
      toolsBundle: '2026.5.28',
      readStringParamSuffix: false,
      videoExecuteArgsIdent: 'args',
      imageExecuteArgsIdent: 'params',
      announcePatchOptional: false,
    },
    installNotes: [
      'openclaw.json 不写 agents.defaults.systemPromptOverride（已由 OpenClaw 移除）',
      'Agent 规则由 clawbba-api skill metadata.always:true 注入',
      'runtime patch：readStringParam（无 $1）；video_generate execute 用 args；image_generate 用 params',
      'subagent announce 使用 2026.5.28-completion-route + WebChat live 路由 patch',
    ],
  },
  {
    id: '2026.5.12',
    minVersion: '2026.5.12',
    label: 'OpenClaw 2026.5.12 – 2026.5.27',
    tier: 'stable',
    blocked: false,
    config: {
      systemPromptOverride: true,
      agentRulesViaSkillAlways: true,
    },
    patch: {
      toolsBundle: '2026.5.27',
      readStringParamSuffix: true,
      videoExecuteArgsIdent: 'params',
      imageExecuteArgsIdent: 'params',
      announcePatchOptional: false,
    },
    installNotes: [
      'openclaw.json 写入 agents.defaults.systemPromptOverride（ClawBBA Agent 规则）',
      'runtime patch 匹配 readStringParam$1 与 2026.5.18/2026.5.27 announce 模式',
      'WebChat 生图/生视频完成后建议启用 wake + announce patch',
    ],
  },
]

const UNSUPPORTED_PROFILE = {
  id: 'unsupported',
  minVersion: null,
  label: `OpenClaw < ${OPENCLAW_COMPAT_MIN_VERSION}（不受支持）`,
  tier: 'unsupported',
  blocked: true,
  config: {
    systemPromptOverride: false,
    agentRulesViaSkillAlways: true,
  },
  patch: {
    toolsBundle: 'legacy',
    readStringParamSuffix: true,
    videoExecuteArgsIdent: 'params',
    imageExecuteArgsIdent: 'params',
    announcePatchOptional: true,
  },
  installNotes: [
    `当前 OpenClaw 低于 ${OPENCLAW_COMPAT_MIN_VERSION}，请先升级到最新版再安装 ClawBBA`,
    OPENCLAW_UPGRADE_COMMAND,
    '升级后执行: curl -fsSL https://www.clawbba.com/downloads/install-clawbba-api.sh | bash',
  ],
}

const UNKNOWN_PROFILE = {
  id: 'unknown',
  minVersion: null,
  label: 'OpenClaw 版本无法识别',
  tier: 'unknown',
  blocked: false,
  config: {
    systemPromptOverride: true,
    agentRulesViaSkillAlways: true,
  },
  patch: {
    toolsBundle: 'unknown',
    readStringParamSuffix: true,
    videoExecuteArgsIdent: 'params',
    imageExecuteArgsIdent: 'params',
    announcePatchOptional: true,
  },
  installNotes: [
    '未能解析 openclaw --version；将按保守策略安装，请安装后执行 openclaw config validate',
  ],
}

/**
 * @param {string | null | undefined} [version]
 * @returns {typeof OPENCLAW_COMPAT_PROFILES[number] & { version: string | null, profileId: string }}
 */
export function resolveOpenClawCompatProfile(version = getOpenClawVersion()) {
  const v = version ? String(version).trim() : getOpenClawVersion()
  if (!v || !parseCalVer(v)) {
    return { ...UNKNOWN_PROFILE, version: v || null, profileId: UNKNOWN_PROFILE.id }
  }

  const belowMin = compareCalVer(v, OPENCLAW_COMPAT_MIN_VERSION)
  if (belowMin !== null && belowMin < 0) {
    return { ...UNSUPPORTED_PROFILE, version: v, profileId: UNSUPPORTED_PROFILE.id }
  }

  for (const profile of OPENCLAW_COMPAT_PROFILES) {
    const cmp = compareCalVer(v, profile.minVersion)
    if (cmp !== null && cmp >= 0) {
      return { ...profile, version: v, profileId: profile.id }
    }
  }

  return { ...UNSUPPORTED_PROFILE, version: v, profileId: UNSUPPORTED_PROFILE.id }
}

export function openClawCompatProfileSupportsSystemPromptOverride(profile = resolveOpenClawCompatProfile()) {
  return profile.config?.systemPromptOverride === true
}

export function formatOpenClawCompatReport(profile = resolveOpenClawCompatProfile()) {
  const lines = [
    `[clawbba-api] OpenClaw compat profile: ${profile.profileId}`,
    `[clawbba-api]   detected version: ${profile.version ?? '(unknown)'}`,
    `[clawbba-api]   label: ${profile.label}`,
    `[clawbba-api]   tier: ${profile.tier}`,
    `[clawbba-api]   blocked: ${profile.blocked ? 'yes' : 'no'}`,
    `[clawbba-api]   config.systemPromptOverride: ${profile.config.systemPromptOverride ? 'yes' : 'no'}`,
    `[clawbba-api]   patch.toolsBundle: ${profile.patch.toolsBundle}`,
  ]
  for (const note of profile.installNotes) {
    lines.push(`[clawbba-api]   · ${note}`)
  }
  return lines.join('\n')
}
