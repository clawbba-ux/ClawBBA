#!/usr/bin/env node
/**
 * Fix agents.defaults schema for installed OpenClaw version:
 * - < 2026.5.28: systemPrompt → systemPromptOverride
 * - ≥ 2026.5.28: remove systemPromptOverride (skill always:true carries rules)
 */
import fs from 'fs'
import { getOpenclawJsonPath } from './openclaw-paths.mjs'
import { sanitizeAgentsConfig } from './openclaw-config-sanitize.mjs'
import { getOpenClawVersion, openClawSupportsSystemPromptOverride } from './openclaw-version.mjs'

const cfgPath = getOpenclawJsonPath()
if (!fs.existsSync(cfgPath)) {
  console.error(`[clawbba-api] ✗ 未找到 ${cfgPath}`)
  process.exit(1)
}

const cfg = JSON.parse(fs.readFileSync(cfgPath, 'utf8'))
const version = getOpenClawVersion()
const supportsOverride = openClawSupportsSystemPromptOverride(version)
const { agents, changed } = sanitizeAgentsConfig(cfg.agents, { supportsSystemPromptOverride: supportsOverride })

if (!changed) {
  if (version && !supportsOverride) {
    console.log(`[clawbba-api] 无需修复（OpenClaw ${version}，无 legacy systemPrompt 字段）`)
  } else {
    console.log('[clawbba-api] 无需修复（无 systemPrompt / systemPromptOverride 冲突）')
  }
  process.exit(0)
}

cfg.agents = agents
const backup = `${cfgPath}.bak-schema-fix-${Date.now()}`
fs.copyFileSync(cfgPath, backup)
fs.writeFileSync(cfgPath, `${JSON.stringify(cfg, null, 2)}\n`, { mode: 0o600 })

if (supportsOverride) {
  console.log('[clawbba-api] ✓ 已修复 systemPrompt → systemPromptOverride')
} else {
  console.log(
    `[clawbba-api] ✓ 已移除 agents.defaults.systemPromptOverride（OpenClaw ${version || '2026.5.28+'} 不再支持）`,
  )
  console.log('[clawbba-api]   Agent 规则由 clawbba-api skill（always:true）提供')
}
console.log(`[clawbba-api]   backup: ${backup}`)
console.log('[clawbba-api] 请执行: openclaw config validate && openclaw gateway restart')
