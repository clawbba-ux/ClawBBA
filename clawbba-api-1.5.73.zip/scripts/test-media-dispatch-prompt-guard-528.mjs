#!/usr/bin/env node
/** OpenClaw 2026.5.28: prompt guard must run AFTER media-dispatch session parse. */
import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import {
  patchImageGenerateMediaDispatch,
  patchVideoGenerateMediaDispatch,
  MEDIA_DISPATCH_PROMPT_GUARD_MARKER,
  MEDIA_DISPATCH_PROMPT_GUARD_VIDEO_MARKER,
} from './clawbba-media-dispatch-patch.mjs'
import { fresh528ToolsPath } from './test-528-fixture.mjs'

const toolsPath = fresh528ToolsPath()
assert.equal(patchImageGenerateMediaDispatch(toolsPath), 'patched')
assert.equal(patchVideoGenerateMediaDispatch(toolsPath), 'patched')

let src = fs.readFileSync(toolsPath, 'utf8')
assert.ok(src.includes(MEDIA_DISPATCH_PROMPT_GUARD_MARKER), 'image prompt guard')
assert.ok(src.includes(MEDIA_DISPATCH_PROMPT_GUARD_VIDEO_MARKER), 'video prompt guard')
assert.ok(!src.includes('readStringParam(params, "prompt", { required: true })'), 'image prompt not required early')
const imageGuardIdx = src.indexOf(MEDIA_DISPATCH_PROMPT_GUARD_MARKER)
const imageDupIdx = src.indexOf('createImageGenerateDuplicateGuardResult(options?.agentSessionKey')
assert.ok(imageGuardIdx > 0 && imageDupIdx > imageGuardIdx, 'image duplicate guard after dispatch')

const videoGuardIdx = src.indexOf(MEDIA_DISPATCH_PROMPT_GUARD_VIDEO_MARKER)
const videoDupIdx = src.indexOf('createVideoGenerateDuplicateGuardResult(options?.agentSessionKey')
assert.ok(videoGuardIdx > 0 && videoDupIdx > videoGuardIdx, 'video duplicate guard after dispatch')
const videoPromptEarly = src.slice(Math.max(0, videoDupIdx - 600), videoDupIdx)
assert.ok(!/readStringParam\(args, "prompt", \{ required: true \}\)/.test(videoPromptEarly), 'video prompt not required early')

console.log('test-media-dispatch-prompt-guard-528: ok')
