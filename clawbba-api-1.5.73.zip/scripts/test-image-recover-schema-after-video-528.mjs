#!/usr/bin/env node
/**
 * Regression: video recover schema patch runs first; image jobId must land in
 * ImageGenerateToolSchema (not VideoGenerateToolProperties), or Value.Convert strips jobId.
 */
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { patchVideoGenerateRecoverAction } from './clawbba-video-recover-patch.mjs'
import {
  ensureImageRecoverSchemaProps,
  extractImageGenerateToolSchemaBlock,
  imageGenerateSchemaHasRecoverJobId,
  patchImageGenerateRecoverAction,
  upgradeMisplacedImageRecoverSchemaProps,
} from './clawbba-image-recover-patch.mjs'

const sourceTools = process.argv[2] || '/tmp/oc528/package/dist/openclaw-tools-C1FG9NMc.js'
assert.ok(fs.existsSync(sourceTools), `missing ${sourceTools}`)

const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'clawbba-img-schema-vid-'))
const toolsPath = path.join(tmpDir, path.basename(sourceTools))
fs.copyFileSync(sourceTools, toolsPath)

assert.equal(patchVideoGenerateRecoverAction(toolsPath), 'patched')
let src = fs.readFileSync(toolsPath, 'utf8')
assert.ok(src.includes('ClawBBA video_job_id'), 'video schema should have video jobId')
assert.ok(!imageGenerateSchemaHasRecoverJobId(src), 'image schema should still lack jobId after video-only patch')

assert.equal(patchImageGenerateRecoverAction(toolsPath), 'patched')
src = fs.readFileSync(toolsPath, 'utf8')

const { block: imageBlock } = extractImageGenerateToolSchemaBlock(src)
assert.ok(imageGenerateSchemaHasRecoverJobId(src), 'image schema must include jobId')
assert.ok(imageBlock.includes('action=tasks'), 'image action desc updated')
assert.ok(imageBlock.includes('ClawBBA image job_id'), 'jobId prop in image schema block')

const videoStart = src.indexOf('const VideoGenerateToolProperties = {')
const videoEnd = src.indexOf('\nfunction createVideoGenerateToolSchema', videoStart)
const videoBlock = src.slice(videoStart, videoEnd)
assert.ok(videoBlock.includes('ClawBBA video_job_id'), 'video jobId description must stay video-specific')
assert.ok(!videoBlock.includes('ClawBBA image job_id'), 'image jobId must not remain in video schema')

// upgrade path for broken installs (image jobId wrongly in video block)
const broken = upgradeMisplacedImageRecoverSchemaProps(
  src.replace(
    'ClawBBA video_job_id for action=recover',
    'ClawBBA image job_id for action=recover',
  ),
)
assert.ok(broken.includes('ClawBBA video_job_id for action=recover'))
assert.ok(!broken.includes('ClawBBA image job_id for action=recover') || imageGenerateSchemaHasRecoverJobId(broken))

assert.equal(patchImageGenerateRecoverAction(toolsPath), 'skip')

console.log('test-image-recover-schema-after-video-528: ok')
