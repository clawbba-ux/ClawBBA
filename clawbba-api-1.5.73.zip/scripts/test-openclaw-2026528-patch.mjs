#!/usr/bin/env node
import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import { patchImageGenerateMediaDispatch, patchVideoGenerateMediaDispatch } from './clawbba-media-dispatch-patch.mjs'
import { patchReferenceImagesInToolsFile } from './clawbba-reference-images.mjs'
import { patchImageGenerateRecoverAction, imageGenerateSchemaHasRecoverJobId, imageRecoverRuntimeIsHealthy } from './clawbba-image-recover-patch.mjs'
import { patchVideoGenerateRecoverAction, videoGenerateSchemaHasRecoverJobId } from './clawbba-video-recover-patch.mjs'
import { upgradeOpenClawBundledReadStringParamAlias } from './openclaw-tools-compat.mjs'

const srcPath = process.argv[2] || '/tmp/package/dist/openclaw-tools-C1FG9NMc.js'
if (!fs.existsSync(srcPath)) {
  console.error('missing sample tools file:', srcPath)
  process.exit(1)
}

const tmpDir = fs.mkdtempSync('/tmp/clawbba-oc528-')
const toolsPath = path.join(tmpDir, path.basename(srcPath))
fs.copyFileSync(srcPath, toolsPath)

assert.equal(patchImageGenerateMediaDispatch(toolsPath), 'patched')
assert.equal(patchVideoGenerateMediaDispatch(toolsPath), 'patched')
assert.equal(patchReferenceImagesInToolsFile(toolsPath), 'patched')

let src = fs.readFileSync(toolsPath, 'utf8')
assert.ok(src.includes('clawbba-media-dispatch'))
assert.ok(src.includes('readStringParam(params, "prompt"'))
assert.ok(!src.includes('readStringParam$1('), 'fresh inject must not use $1 alias')

assert.equal(patchVideoGenerateRecoverAction(toolsPath), 'patched')
assert.equal(patchImageGenerateRecoverAction(toolsPath), 'patched')

src = fs.readFileSync(toolsPath, 'utf8')
src = upgradeOpenClawBundledReadStringParamAlias(src)
assert.ok(!src.includes('readStringParam$1('))
assert.ok(src.includes('clawbbaResolveImageRecoverJobId'))
assert.ok(imageGenerateSchemaHasRecoverJobId(src))
assert.ok(videoGenerateSchemaHasRecoverJobId(src))
assert.ok(imageRecoverRuntimeIsHealthy(src))

console.log('test-openclaw-2026528-patch: ok')
