#!/usr/bin/env node
/**
 * Partial upgrade left duplicate clawbbaDedupeImageBuffers — strip + full patch must pass node --check.
 */
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { execSync } from 'node:child_process'
import {
  buildClawbbaDedupeImageBuffersFnBlock,
  countFunctionDefinitions,
  stripDuplicateRecoverHelperDefinitions,
} from './clawbba-external-recover-delivery.mjs'
import { patchImageGenerateRecoverAction } from './clawbba-image-recover-patch.mjs'
import { fresh528ToolsPath } from './test-528-fixture.mjs'

const toolsPath = fresh528ToolsPath()
const toolsName = path.basename(toolsPath)

assert.equal(patchImageGenerateRecoverAction(toolsPath), 'patched')
let src = fs.readFileSync(toolsPath, 'utf8')
assert.equal(countFunctionDefinitions(src, 'clawbbaDedupeImageBuffers'), 1, 'single dedupe after image patch')

const dup = buildClawbbaDedupeImageBuffersFnBlock()
const anchor = 'async function clawbbaPollClawbbaImageJob'
assert.ok(src.includes(anchor), 'anchor for duplicate fixture')
src = src.replace(anchor, `${dup}\n${anchor}`)
assert.equal(countFunctionDefinitions(src, 'clawbbaDedupeImageBuffers'), 2, 'duplicate injected')

const fixed = stripDuplicateRecoverHelperDefinitions(src)
assert.equal(countFunctionDefinitions(fixed, 'clawbbaDedupeImageBuffers'), 1, 'strip keeps first')
fs.writeFileSync(toolsPath, fixed)
execSync(`node --check ${JSON.stringify(toolsName)}`, { cwd: path.dirname(toolsPath), stdio: 'pipe' })

console.log('test-image-recover-dedupe-528: ok')
