#!/usr/bin/env node
import assert from 'node:assert/strict'
import { applyClawbbaSessionBranding } from './clawbba-openclaw-config-branding.mjs'
import { CLAWBBA_WEBCHAT_ASSISTANT_NAME } from './openclaw-provider-block.mjs'

const patch = {
  agents: {
    defaults: {
      model: { primary: 'clawbba/deepseek/deepseek-v3.2' },
      imageGenerationModel: { primary: 'openrouter/google/gemini-3.1-flash-image-preview' },
    },
  },
}

const cfg = {
  agents: {
    defaults: { model: { primary: 'anthropic/claude-opus-4' } },
    list: [{ id: 'main', model: { primary: 'anthropic/claude-opus-4' } }],
  },
  skills: { entries: { 'clawbba-api': { enabled: false } } },
}

const { changed, chatPrimary } = applyClawbbaSessionBranding(cfg, { patch })
assert.equal(changed, true)
assert.equal(chatPrimary, 'clawbba/deepseek/deepseek-v3.2')
assert.equal(cfg.agents.defaults.model.primary, 'clawbba/deepseek/deepseek-v3.2')
assert.equal(cfg.agents.list[0].model.primary, 'clawbba/deepseek/deepseek-v3.2')
assert.equal(cfg.skills.entries['clawbba-api'].enabled, true)
assert.equal(cfg.messages.visibleReplies, 'automatic')
assert.equal(cfg.ui.assistant.name, CLAWBBA_WEBCHAT_ASSISTANT_NAME)
console.log('test-clawbba-session-branding: ok')
