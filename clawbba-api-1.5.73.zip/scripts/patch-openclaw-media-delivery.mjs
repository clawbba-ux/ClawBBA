#!/usr/bin/env node
/**
 * Patch OpenClaw image_generate / video_generate completion so assets stay on the
 * user's OpenClaw machine (~/.openclaw/media/...) and the completion agent delivers
 * them with MEDIA: lines in the assistant reply (WebChat-native), NOT message tool
 * (breaks on Feishu-bound sessions) and NOT ClawBBA public URLs as primary.
 *
 * Idempotent marker: clawbba-local-media-delivery
 * Upgrades installs that still have clawbba-image-delivery (v1.1.5).
 */
import fs from 'fs'
import path from 'path'
import { execSync } from 'node:child_process'
import {
  patchImageGenerateMediaDispatch,
  patchVideoGenerateMediaDispatch,
  patchOpenRouterImageProviderAspect,
  patchOpenRouterImageProviderHeaders,
} from './clawbba-media-dispatch-patch.mjs'
import { buildModelRefVendorRoutingBlock, buildClawbbaUserMediaModelDisplayFnBlock, USER_MEDIA_MODEL_DISPLAY_FN } from './clawbba-media-model-ref.mjs'
import { patchSubagentAnnounceDeliveryDist } from './openclaw-announce-patch.mjs'
import { patchWebChatLiveWakeDist } from './clawbba-webchat-live-wake-patch.mjs'
import { patchWebChatLiveInjectHelperDist } from './clawbba-webchat-live-inject.mjs'
import { patchOpenRouterVideoProvider } from './clawbba-video-provider-patch.mjs'
import { patchOpenRouterImageProvider } from './clawbba-image-provider-patch.mjs'
import { patchMediaGenerationProgress } from './clawbba-media-progress-patch.mjs'
import { patchVideoGenerateRecoverAction } from './clawbba-video-recover-patch.mjs'
import { patchImageGenerateRecoverAction, ensureImageRecoverRuntimeHelpers } from './clawbba-image-recover-patch.mjs'
import { patchMediaTaskChatRunIdRouting } from './clawbba-media-task-chat-runid-patch.mjs'
import { patchReadOnlyToolTextReplyDist } from './clawbba-readonly-tool-reply-patch.mjs'
import {
  patchExternalRecoverMediaDelivery,
  ensureImageRecoverDeliveryInTools,
  stripDuplicateRecoverHelperDefinitions,
} from './clawbba-external-recover-delivery.mjs'
import { upgradeOpenClawBundledReadStringParamAlias } from './openclaw-tools-compat.mjs'
import { upgradeRecoverJobKindValidation } from './clawbba-recover-job-kind.mjs'
import { patchReferenceImagesInToolsFile } from './clawbba-reference-images.mjs'
import {
  findAllOpenclawDists,
  findDistJsFile,
  formatOpenclawDistDiscoveryReport,
} from './openclaw-dist-paths.mjs'

const MARKER = '/* clawbba-local-media-delivery */'
const MODEL_REF_MARKER = '/* clawbba-model-ref */'
const VENDOR_MODEL_REF_MARKER = '/* clawbba-openrouter-vendor-id */'
const OLD_MARKER = '/* clawbba-image-delivery */'
const OLD_WAKE = '/* clawbba-wake-reply */'

const IMAGE_GENERATED_LINE_OLD =
  '\t\t`Generated ${savedImages.length} image${savedImages.length === 1 ? "" : "s"} with ${displayProvider}/${displayModel}.`,'
const IMAGE_GENERATED_LINE_NEW =
  '\t\t`Generated ${savedImages.length} image${savedImages.length === 1 ? "" : "s"} with ${clawbbaFormatUserMediaModel(displayProvider, displayModel)}.`,'
const VIDEO_GENERATED_LINE_OLD =
  '\t\t`Generated ${totalCount} video${totalCount === 1 ? "" : "s"} with ${result.provider}/${result.model}.`,'
const VIDEO_GENERATED_LINE_NEW =
  '\t\t`Generated ${totalCount} video${totalCount === 1 ? "" : "s"} with ${clawbbaFormatUserMediaModel(result.provider, result.model)}.`,'

function ensureClawbbaUserMediaModelDisplayFn(src) {
  if (src.includes(`function ${USER_MEDIA_MODEL_DISPLAY_FN}(`)) return src
  const block = `${buildClawbbaUserMediaModelDisplayFnBlock()}\n`
  const anchor = src.includes('/* clawbba-video-recover */')
    ? '/* clawbba-video-recover */'
    : 'async function executeVideoGenerationJob(params) {'
  if (!src.includes(anchor)) {
    const idx = src.indexOf(MARKER)
    if (idx >= 0) return `${src.slice(0, idx)}${block}${src.slice(idx)}`
    return `${block}${src}`
  }
  return src.replace(anchor, `${block}${anchor}`)
}

function upgradeUserMediaModelDisplayLines(src) {
  let out = src
  if (out.includes(IMAGE_GENERATED_LINE_OLD)) {
    out = out.replace(IMAGE_GENERATED_LINE_OLD, IMAGE_GENERATED_LINE_NEW)
  }
  if (out.includes(VIDEO_GENERATED_LINE_OLD)) {
    out = out.replace(VIDEO_GENERATED_LINE_OLD, VIDEO_GENERATED_LINE_NEW)
  }
  return out
}

const LOCAL_WAKE_REPLY = `${MARKER}
\t\treplyInstruction: (() => {
\t\t\tconst localMedia = mediaUrls.filter((u) => typeof u === "string" && u.trim().length > 0);
\t\t\tif (localMedia.length > 0 && params.status === "ok") {
\t\t\t\treturn [
\t\t\t\t\t\`The \${params.completionLabel} is ready — files are saved locally on this OpenClaw machine (user-owned asset).\`,
\t\t\t\t\t"Generation already succeeded. Do NOT call image_generate or video_generate again for this task.",
\t\t\t\t\t"If the user did not see the media, REDELIVER only: short caption + MEDIA: lines using the paths below — never regenerate.",
\t\t\t\t\t"For video timeout or billed-but-missing: video_generate action=tasks then action=recover jobId=<id> timeoutMs=600000 — never generate again.",
\t\t\t\t\t"Reply in your normal assistant message: short caption, then one MEDIA: line per file using path= from Attachments or the Local delivery block in Child result.",
\t\t\t\t\t"Example: MEDIA:/root/.openclaw/media/tool-image-generation/image-1.png",
\t\t\t\t\t"If the user asks which model was used, answer ONLY from this Child result provider/model line — never from aliases or earlier chat.",
\t\t\t\t\t"Do NOT call the message tool on WebChat/dashboard completion (Feishu routing: Action send requires a target).",
\t\t\t\t\t"Do NOT tell the user to rely on ClawBBA/public HTTPS URLs; local MEDIA delivery is primary.",
\t\t\t\t\t\`After all MEDIA lines are in the user-visible reply, you may reply only \${SILENT_REPLY_TOKEN}.\`
\t\t\t\t].join(" ");
\t\t\t}
\t\t\treturn buildMediaGenerationReplyInstruction({
\t\t\t\tstatus: params.status,
\t\t\t\tcompletionLabel: params.completionLabel
\t\t\t});
\t\t})()`

function findDistFile(dist, prefix) {
  const needles = {
    'server-plugins-': 'dispatchGatewayMethodInProcess',
    'global-singleton-': 'resolveGlobalSingleton',
    'gateway-request-scope-': 'getPluginRuntimeGatewayRequestScope',
  }
  return findDistJsFile(dist, prefix, needles[prefix])
}

function patchWakeReplyInstruction(filePath) {
  let src = fs.readFileSync(filePath, 'utf8')
  if (src.includes(MARKER) && src.includes('localMedia = mediaUrls.filter')) return 'skip'

  const vanillaNeedle = `\t\treplyInstruction: buildMediaGenerationReplyInstruction({
\t\t\tstatus: params.status,
\t\t\tcompletionLabel: params.completionLabel
\t\t})`

  if (src.includes(OLD_WAKE)) {
    const oldBlockRe =
      /\/\* clawbba-wake-reply \*\/[\s\S]*?completionLabel: params\.completionLabel\s*\}\);\s*\}\)\(\)/
    if (!oldBlockRe.test(src)) {
      throw new Error(`old wake reply block not found in ${path.basename(filePath)}`)
    }
    src = src.replace(oldBlockRe, LOCAL_WAKE_REPLY.trim())
    fs.writeFileSync(filePath, src)
    return 'patched'
  }

  if (!src.includes(vanillaNeedle)) {
    process.stderr.write(
      `[clawbba-api] warn: wake replyInstruction pattern not found in ${path.basename(filePath)}\n`,
    )
    return 'pattern-missing'
  }
  src = src.replace(vanillaNeedle, LOCAL_WAKE_REPLY)
  fs.writeFileSync(filePath, src)
  return 'patched'
}

function buildImageExecuteBlock() {
  return `${MARKER}
\tconst attachments = savedImages.map((image) => ({
\t\ttype: "image",
\t\tpath: image.path,
\t\tmimeType: image.contentType,
\t\tname: image.id
\t}));
\tconst lines = [
\t\t\`Generated \${savedImages.length} image\${savedImages.length === 1 ? "" : "s"} with \${clawbbaFormatUserMediaModel(displayProvider, displayModel)}.\`,
\t\t...warning ? [\`Warning: \${warning}\`] : [],
\t\t...formatGeneratedAttachmentLines(attachments)
\t];
\tif (savedImages.length > 0) {
\t\tlines.push("", "Local delivery (user asset on this OpenClaw machine — reply with MEDIA lines):");
\t\tfor (const image of savedImages) lines.push(\`MEDIA:\${image.path}\`);
\t}
\treturn {
\t\tprovider: result.provider,
\t\tmodel: result.model,
\t\tsavedPaths: savedImages.map((image) => image.path),
\t\tcount: savedImages.length,
\t\tpaths: savedImages.map((image) => image.path),
\t\tattachments,
\t\tmediaUrls: savedImages.map((image) => image.path),
\t\tcontentText: lines.join("\\n"),
\t\twakeResult: lines.join("\\n"),
\t\tdetails: {
\t\t\tprovider: result.provider,
\t\t\tmodel: result.model,
\t\t\tcount: savedImages.length,
\t\t\tmedia: {
\t\t\t\tmediaUrls: savedImages.map((image) => image.path),
\t\t\t\tattachments
\t\t\t},
\t\t\tattachments,
\t\t\tpaths: savedImages.map((image) => image.path),`
}

function patchImageExecuteJob(filePath) {
  let src = fs.readFileSync(filePath, 'utf8')
  const before = src
  src = ensureClawbbaUserMediaModelDisplayFn(src)
  src = upgradeUserMediaModelDisplayLines(src)
  if (
    src.includes(MARKER) &&
    src.includes('Local delivery (user asset on this OpenClaw machine') &&
    src.includes(`function ${USER_MEDIA_MODEL_DISPLAY_FN}(`) &&
    src.includes('clawbbaFormatUserMediaModel(displayProvider, displayModel)')
  ) {
    if (src !== before) fs.writeFileSync(filePath, src)
    return src !== before ? 'upgraded' : 'skip'
  }

  if (src.includes(OLD_MARKER)) {
    const oldRe =
      /\/\* clawbba-image-delivery \*\/[\s\S]*?paths: savedImages\.map\(\(image\) => image\.path\),\n\t\t\t\.\.\.buildTaskRunDetails/
    const replacement = `${buildImageExecuteBlock()}\n\t\t\t...buildTaskRunDetails`
    if (!oldRe.test(src)) {
      throw new Error(`old image execute block not found in ${path.basename(filePath)}`)
    }
    src = src.replace(oldRe, replacement)
    fs.writeFileSync(filePath, src)
    return 'upgraded'
  }

  const vanillaNeedle = `\tconst attachments = savedImages.map((image) => ({
\t\ttype: "image",
\t\tpath: image.path,
\t\tmimeType: image.contentType,
\t\tname: image.id
\t}));
\tconst lines = [
\t\t\`Generated \${savedImages.length} image\${savedImages.length === 1 ? "" : "s"} with \${displayProvider}/\${displayModel}.\`,
\t\t...warning ? [\`Warning: \${warning}\`] : [],
\t\t...formatGeneratedAttachmentLines(attachments)
\t];
\treturn {
\t\tprovider: result.provider,
\t\tmodel: result.model,
\t\tsavedPaths: savedImages.map((image) => image.path),
\t\tcount: savedImages.length,
\t\tpaths: savedImages.map((image) => image.path),
\t\tattachments,
\t\tcontentText: lines.join("\\n"),
\t\twakeResult: lines.join("\\n"),
\t\tdetails: {
\t\t\tprovider: result.provider,
\t\t\tmodel: result.model,
\t\t\tcount: savedImages.length,
\t\t\tmedia: {
\t\t\t\tmediaUrls: savedImages.map((image) => image.path),
\t\t\t\tattachments
\t\t\t},
\t\t\tattachments,
\t\t\tpaths: savedImages.map((image) => image.path),`

  const vanillaReplacement = buildImageExecuteBlock()
  if (!src.includes(vanillaNeedle)) {
    return 'pattern-missing'
  }
  src = src.replace(vanillaNeedle, vanillaReplacement)
  fs.writeFileSync(filePath, src)
  return 'patched'
}

function patchVideoExecuteJob(filePath) {
  let src = fs.readFileSync(filePath, 'utf8')
  const before = src
  src = ensureClawbbaUserMediaModelDisplayFn(src)
  src = upgradeUserMediaModelDisplayLines(src)
  if (
    src.includes(MARKER) &&
    src.includes('for (const video of urlOnlyVideos)') &&
    src.includes(`function ${USER_MEDIA_MODEL_DISPLAY_FN}(`) &&
    src.includes('clawbbaFormatUserMediaModel(result.provider, result.model)')
  ) {
    if (src !== before) fs.writeFileSync(filePath, src)
    return src !== before ? 'upgraded' : 'skip'
  }

  const needle = `\tconst lines = [
\t\t\`Generated \${totalCount} video\${totalCount === 1 ? "" : "s"} with \${result.provider}/\${result.model}.\`,
\t\t...warning ? [\`Warning: \${warning}\`] : [],
\t\ttypeof requestedDurationSeconds === "number" && typeof normalizedDurationSeconds === "number" && requestedDurationSeconds !== normalizedDurationSeconds ? \`Duration normalized: requested \${requestedDurationSeconds}s; used \${normalizedDurationSeconds}s.\` : null,
\t\t...formatGeneratedAttachmentLines(attachments)
\t].filter((entry) => Boolean(entry));
\treturn {`

  const replacement = `\tconst lines = [
\t\t\`Generated \${totalCount} video\${totalCount === 1 ? "" : "s"} with \${clawbbaFormatUserMediaModel(result.provider, result.model)}.\`,
\t\t...warning ? [\`Warning: \${warning}\`] : [],
\t\ttypeof requestedDurationSeconds === "number" && typeof normalizedDurationSeconds === "number" && requestedDurationSeconds !== normalizedDurationSeconds ? \`Duration normalized: requested \${requestedDurationSeconds}s; used \${normalizedDurationSeconds}s.\` : null,
\t\t...formatGeneratedAttachmentLines(attachments)
\t].filter((entry) => Boolean(entry));
\t${MARKER}
\tif (savedVideos.length > 0 || urlOnlyVideos.length > 0) {
\t\tlines.push("", "Local delivery (user asset on this OpenClaw machine — reply with MEDIA lines):");
\t\tfor (const video of savedVideos) lines.push(\`MEDIA:\${video.path}\`);
\t\tfor (const video of urlOnlyVideos) {
\t\t\tif (video.url) lines.push(\`MEDIA:\${video.url}\`);
\t\t}
\t}
\treturn {`

  if (!src.includes(needle)) {
    if (src !== before) fs.writeFileSync(filePath, src)
    return src !== before ? 'upgraded' : 'pattern-missing'
  }
  src = src.replace(needle, replacement)
  fs.writeFileSync(filePath, src)
  return 'patched'
}

function revertOldProviderPatch(filePath) {
  let src = fs.readFileSync(filePath, 'utf8')
  if (!src.includes(OLD_MARKER)) return 'skip'
  const vanilla =
    'const images = extractOpenRouterImagesFromResponse(await response.json(), { malformedResponseError: OPENROUTER_IMAGE_MALFORMED_RESPONSE });'
  if (!src.includes(vanilla)) {
    src = src.replace(
      /const body = await response\.json\(\);\s*const images = extractOpenRouterImagesFromResponse\(body[\s\S]*?\}\)\(\);/,
      vanilla,
    )
    src = src.replace(
      /return \{\s*images,\s*model,\s*\.\.\.\(clawbbaPublicUrls\.length[\s\S]*?\}\s*\};/,
      `return {
\t\t\t\t\timages,
\t\t\t\t\tmodel
\t\t\t\t};`,
    )
    fs.writeFileSync(filePath, src)
    return 'reverted'
  }
  return 'skip'
}

/** clawbba/foo/bar → openrouter/foo/bar for image_generate / video_generate (ClawBBA text models use clawbba/ prefix). */
/**
 * OpenClaw sets requiresMessageToolDelivery=true for image_generate/video_generate
 * when expectedMediaUrls.length > 0 (agentMediatedCompletion). That forces
 * sourceReplyDeliveryMode=message_tool_only, which suppresses assistant MEDIA:
 * replies on WebChat — while message tool fails with "Action send requires a target"
 * on dashboard/Feishu-bound sessions.
 */
function patchSubagentAnnounceDelivery(dist) {
  return patchSubagentAnnounceDeliveryDist(dist, findDistFile)
}

function patchClawbbaModelRef(dist) {
  const files = fs.readdirSync(dist).filter((name) => name.startsWith('model-ref-') && name.endsWith('.js'))
  const file = files.find((name) => {
    const src = fs.readFileSync(path.join(dist, name), 'utf8')
    return src.includes('function parseGenerationModelRef') || src.includes('function parseGenerationModelRef(')
  }) || files.find((name) => fs.readFileSync(path.join(dist, name), 'utf8').includes('parseGenerationModelRef(raw)'))
  if (!file) return 'missing'
  const filePath = path.join(dist, file)
  let src = fs.readFileSync(filePath, 'utf8')
  if (src.includes('__clawbbaImgProviders')) return 'skip'

  const vendorRouting = buildModelRefVendorRoutingBlock()

  if (src.includes(MODEL_REF_MARKER)) {
    const oldPatch = `\t${MODEL_REF_MARKER}
\tif (provider === "clawbba") provider = "openrouter";
\treturn {
\t\tprovider,
\t\tmodel
\t};`
    const newPatch = `\t${MODEL_REF_MARKER}
\tif (provider === "clawbba") provider = "openrouter";
${vendorRouting}
\treturn {
\t\tprovider,
\t\tmodel
\t};`
    if (src.includes(oldPatch)) {
      src = src.replace(oldPatch, newPatch)
      fs.writeFileSync(filePath, src)
      return 'patched'
    }
    const looseNeedle = `\tif (provider === "clawbba") provider = "openrouter";
\treturn {
\t\tprovider,
\t\tmodel
\t};`
    if (src.includes(looseNeedle) && !src.includes('__clawbbaImgProviders')) {
      src = src.replace(
        looseNeedle,
        `\tif (provider === "clawbba") provider = "openrouter";
${vendorRouting}
\treturn {
\t\tprovider,
\t\tmodel
\t};`,
      )
      fs.writeFileSync(filePath, src)
      return 'patched'
    }
    if (!src.includes('__clawbbaImgProviders')) {
      src = src.replace(
        '\treturn {\n\t\tprovider,\n\t\tmodel\n\t};',
        `${vendorRouting}\n\treturn {\n\t\tprovider,\n\t\tmodel\n\t};`,
      )
      fs.writeFileSync(filePath, src)
      return 'patched'
    }
    return 'skip'
  }

  const needle = `\tif (!provider || !model) return null;
\treturn {
\t\tprovider,
\t\tmodel
\t};`
  const replacement = `\tif (!provider || !model) return null;
\t${MODEL_REF_MARKER}
\tif (provider === "clawbba") provider = "openrouter";
${vendorRouting}
\treturn {
\t\tprovider,
\t\tmodel
\t};`
  if (!src.includes(needle)) {
    return 'missing'
  }
  src = src.replace(needle, replacement)
  fs.writeFileSync(filePath, src)
  return 'patched'
}

function verifyOpenclawToolsSyntax(dist, toolsFile) {
  const toolsPath = path.join(dist, toolsFile)
  try {
    execSync(`node --check ${JSON.stringify(toolsFile)}`, { cwd: dist, stdio: 'pipe' })
  } catch (error) {
    const stderr = String(error?.stderr ?? error?.message ?? error)
    throw new Error(`openclaw-tools syntax check failed after patch (${path.basename(toolsPath)}): ${stderr.trim()}`)
  }
}

function patchOneDist(dist) {
  const providerFile = findDistFile(dist, 'image-generation-provider-')
  const toolsFile = findDistFile(dist, 'openclaw-tools-')
  if (!toolsFile) {
    throw new Error(`未找到 openclaw-tools-*.js in ${dist}`)
  }

  const toolsPath = path.join(dist, toolsFile)
  let providerResult = 'n/a'
  if (providerFile) {
    providerResult = revertOldProviderPatch(path.join(dist, providerFile))
  }
  // Flux 修复依赖 model-ref + media dispatch；单步失败不中断其余 patch（兼容多版本 dist）
  const safe = (label, fn) => {
    try {
      return fn()
    } catch (e) {
      return `warn:${label}:${e.message}`
    }
  }
  const p4 = safe('modelRef', () => patchClawbbaModelRef(dist))
  const p6 = safe('imgDispatch', () => patchImageGenerateMediaDispatch(toolsPath))
  const p7 = safe('vidDispatch', () => patchVideoGenerateMediaDispatch(toolsPath))
  const p12 = safe('refImages', () => patchReferenceImagesInToolsFile(toolsPath))
  const p5 = safe('announce', () => patchSubagentAnnounceDelivery(dist))
  const p13 = safe('webchatLiveWake', () => patchWebChatLiveWakeDist(dist, findDistFile))
  const p14 = safe('webchatLiveInjectHelper', () => patchWebChatLiveInjectHelperDist(dist, findDistFile))
  const p3 = safe('wake', () => patchWakeReplyInstruction(toolsPath))
  const p1 = safe('image', () => patchImageExecuteJob(toolsPath))
  const p2 = safe('video', () => patchVideoExecuteJob(toolsPath))
  let p8 = 'skip'
  let p9 = 'skip'
  try {
    p8 = patchOpenRouterImageProviderAspect(dist)
  } catch (e) {
    p8 = `warn:${e.message}`
  }
  try {
    p9 = patchOpenRouterImageProviderHeaders(dist)
  } catch (e) {
    p9 = `warn:${e.message}`
  }
  let p10 = 'skip'
  let p15 = 'skip'
  try {
    p10 = patchOpenRouterVideoProvider(dist)
  } catch (e) {
    p10 = `warn:${e.message}`
  }
  try {
    p15 = patchOpenRouterImageProvider(dist)
  } catch (e) {
    p15 = `warn:${e.message}`
  }
  let p11 = 'skip'
  let p17 = 'skip'
  try {
    const toolsPath = path.join(dist, toolsFile)
    p11 = patchVideoGenerateRecoverAction(toolsPath)
  } catch (e) {
    p11 = `warn:${e.message}`
  }
  try {
    const toolsPath = path.join(dist, toolsFile)
    p17 = patchImageGenerateRecoverAction(toolsPath)
  } catch (e) {
    p17 = `warn:${e.message}`
  }
  let p16 = 'skip'
  try {
    p16 = patchMediaGenerationProgress(dist)
  } catch (e) {
    p16 = `warn:${e.message}`
  }
  let p18 = 'skip'
  try {
    const toolsPath = path.join(dist, toolsFile)
    p18 = patchMediaTaskChatRunIdRouting(toolsPath)
  } catch (e) {
    p18 = `warn:${e.message}`
  }
  let p19 = 'skip'
  try {
    p19 = patchReadOnlyToolTextReplyDist(dist, findDistFile)
  } catch (e) {
    p19 = `warn:${e.message}`
  }

  let p20 = 'skip'
  try {
    p20 = patchExternalRecoverMediaDelivery(dist, findDistFile)
  } catch (e) {
    p20 = `warn:${e.message}`
  }

  try {
    const toolsPath = path.join(dist, toolsFile)
    let toolsSrc = fs.readFileSync(toolsPath, 'utf8')
    const withRecover = upgradeRecoverJobKindValidation(toolsSrc)
    if (withRecover !== toolsSrc) {
      fs.writeFileSync(toolsPath, withRecover)
      p19 = `${p19}+recoverJobKind`
      toolsSrc = withRecover
    }
    const withRuntime = ensureImageRecoverRuntimeHelpers(toolsSrc)
    if (withRuntime !== toolsSrc) {
      fs.writeFileSync(toolsPath, withRuntime)
      p19 = `${p19}+recoverRuntime`
      toolsSrc = withRuntime
    }
    ensureImageRecoverDeliveryInTools(toolsPath, dist)
    toolsSrc = fs.readFileSync(toolsPath, 'utf8')
    const deduped = stripDuplicateRecoverHelperDefinitions(toolsSrc)
    if (deduped !== toolsSrc) {
      fs.writeFileSync(toolsPath, deduped)
      p19 = `${p19}+dedupeRecoverHelpers`
      toolsSrc = deduped
    }
    const compat = upgradeOpenClawBundledReadStringParamAlias(toolsSrc)
    if (compat !== toolsSrc) {
      fs.writeFileSync(toolsPath, compat)
      p19 = `${p19}+readStringCompat`
    }
  } catch (e) {
    p19 = `${p19}+compatWarn:${e.message}`
  }

  verifyOpenclawToolsSyntax(dist, toolsFile)

  return { providerResult, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18, p19, p20 }
}

const SKILL_VERSION = '1.5.73'

function main() {
  process.stdout.write(`[clawbba-api] patch-openclaw-media-delivery v${SKILL_VERSION}\n`)
  const dists = findAllOpenclawDists()
  if (!dists.length) {
    process.stderr.write(
      '[clawbba-api] ✗ 未找到 OpenClaw dist。\n' +
        '  设置 OPENCLAW_DIST=/path/to/openclaw/dist 或确保 openclaw 已全局安装且在 PATH 中。\n',
    )
    process.exit(1)
  }

  process.stdout.write(`${formatOpenclawDistDiscoveryReport(dists)}\n`)

  for (const dist of dists) {
    const r = patchOneDist(dist)
    process.stdout.write(
      `[clawbba-api] patched ${dist}: provider=${r.providerResult} image=${r.p1} video=${r.p2} wake=${r.p3} modelRef=${r.p4} announce=${r.p5} imgDispatch=${r.p6} vidDispatch=${r.p7} imgAspect=${r.p8} imgHeaders=${r.p9} videoProv=${r.p10} vidRecover=${r.p11} refImages=${r.p12} webchatLiveWake=${r.p13} webchatLiveInjectHelper=${r.p14} imgProv=${r.p15} imgRecover=${r.p17} taskChatRunId=${r.p18} readonlyToolReply=${JSON.stringify(r.p19)} externalRecover=${r.p20}\n`,
    )
  }
}

main()
