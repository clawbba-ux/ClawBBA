/**
 * OpenClaw video_generate: action=recover | tasks — poll ClawBBA until complete, download locally (no re-bill).
 */
import fs from 'fs'
import path from 'path'
import {
  upgradeListTasksFixTextVarCollision,
  ensureListTasksSessionKeyParams,
  listTasksFnHasSessionKeyParam,
  ensureListTasksTaskListTextDeclared,
  listTasksBlockIsHealthy,
} from './clawbba-image-recover-patch.mjs'
import {
  recoverWebChatInjectNeedsUpgrade,
  stripLegacyRecoverWebChatInject,
  recoverFnHasWebChatDispatchInject,
  recoverFnHasVideoRecoverDelivery,
} from './clawbba-webchat-live-inject.mjs'
import { adaptInjectedReadStringParam, upgradeOpenClawBundledReadStringParamAlias, buildVideoRecoverExecutePrefix, upgradeVideoRecoverExecuteArgsRef } from './openclaw-tools-compat.mjs'
import { upgradeVideoRecoverExternalDelivery } from './clawbba-external-recover-delivery.mjs'
import { upgradeRecoverJobKindValidation } from './clawbba-recover-job-kind.mjs'

export { recoverFnHasVideoRecoverDelivery } from './clawbba-webchat-live-inject.mjs'

export const VIDEO_RECOVER_MARKER = '/* clawbba-video-recover */'
export const VIDEO_RECOVER_AUTH_MARKER = '/* clawbba-video-recover-auth */'
export const VIDEO_RECOVER_WEBCHAT_LIVE_MARKER = '/* clawbba-video-recover-webchat-live */'

export function buildRecoverWebChatInjectBlock(sourceTool = 'video_generate', completionLabel = 'video', mediaExpr = '[saved.path]') {
  return `\t${VIDEO_RECOVER_WEBCHAT_LIVE_MARKER}
\tif (agentSessionKey) {
\t\tawait clawbbaDispatchWebChatMediaLiveInject({
\t\t\tsessionKey: agentSessionKey,
\t\t\tchatRunId,
\t\t\tmediaUrls: ${mediaExpr},
\t\t\tsourceTool: "${sourceTool}",
\t\t\tcompletionLabel: "${completionLabel}",
\t\t\tmessage: built.lines.join("\\n")
\t\t});
\t}`
}

const RECOVER_RETURN_NEEDLE = `\treturn {
\t\tcontent: built.content,
\t\tdetails: built.details,
\t};`

const RECOVER_RETURN_LEGACY = `\treturn {
\t\tcontent: [{ type: "text", text: lines.join("\\n") }],
\t\tdetails: {
\t\t\tjobId,
\t\t\trecovered: true,
\t\t\tpath: saved.path,`

const RECOVER_EXECUTE_LEGACY =
  /\t\t\tif \(action === "recover"\) return await clawbbaRecoverVideoTask\(\{ cfg, args, agentDir: options\?\.agentDir, authStore: options\?\.authProfileStore \}\);/

const RECOVER_EXECUTE_WITH_SESSION =
  '\t\t\tif (action === "recover") return await clawbbaRecoverVideoTask({ cfg, args, agentDir: options?.agentDir, authStore: options?.authProfileStore, agentSessionKey: options?.agentSessionKey, chatRunId: options?.runId });'

const RECOVER_FN_SIG_RE = /async function clawbbaRecoverVideoTask\(\{([^}]*)\}\)/

/**
 * @param {string} src
 */
export function recoverFnSignatureParams(src) {
  const m = src.match(RECOVER_FN_SIG_RE)
  return m ? m[1] : ''
}

/**
 * @param {string} src
 */
export function recoverFnHasAgentSessionKeyParam(src) {
  return recoverFnSignatureParams(src).includes('agentSessionKey')
}

/**
 * @param {string} src
 */
export function recoverFnHasChatRunIdParam(src) {
  return recoverFnSignatureParams(src).includes('chatRunId')
}

/**
 * @param {string} src
 */
export function ensureRecoverFnParams(src) {
  let out = src
  if (!out.includes('async function clawbbaRecoverVideoTask')) return out

  if (!recoverFnHasAgentSessionKeyParam(out)) {
    out = out.replace(
      'async function clawbbaRecoverVideoTask({ cfg, args, agentDir, authStore }) {',
      'async function clawbbaRecoverVideoTask({ cfg, args, agentDir, authStore, agentSessionKey, chatRunId }) {',
    )
  }
  if (!recoverFnHasChatRunIdParam(out)) {
    out = out.replace(
      'async function clawbbaRecoverVideoTask({ cfg, args, agentDir, authStore, agentSessionKey }) {',
      'async function clawbbaRecoverVideoTask({ cfg, args, agentDir, authStore, agentSessionKey, chatRunId }) {',
    )
  }
  return out
}

export function upgradeVideoRecoverChatRunId(src) {
  if (!src.includes('clawbbaRecoverVideoTask')) return src
  let out = ensureRecoverFnParams(src)
  if (out.includes('agentSessionKey: options?.agentSessionKey') && !out.includes('chatRunId: options?.runId')) {
    out = out.replaceAll(
      'agentSessionKey: options?.agentSessionKey',
      'agentSessionKey: options?.agentSessionKey, chatRunId: options?.runId',
    )
  }
  if (recoverFnHasWebChatDispatchInject(out) && !out.includes('chatRunId,')) {
    out = out.replace(
      'sessionKey: agentSessionKey,\n\t\tmediaUrls:',
      'sessionKey: agentSessionKey,\n\t\tchatRunId,\n\t\tmediaUrls:',
    )
  }
  return out
}

/**
 * @param {string} src
 */
export function upgradeVideoRecoverWebChatLive(src) {
  if (!src.includes('clawbbaRecoverVideoTask')) return src
  if (src.includes('clawbba-video-recover-external-delivery')) return upgradeVideoRecoverChatRunId(src)
  let out = src

  if (recoverWebChatInjectNeedsUpgrade(out)) {
    out = stripLegacyRecoverWebChatInject(out)
    out = ensureRecoverFnParams(out)
    out = out.replace(RECOVER_EXECUTE_LEGACY, RECOVER_EXECUTE_WITH_SESSION)
    const returnNeedle = out.includes(RECOVER_RETURN_NEEDLE) ? RECOVER_RETURN_NEEDLE : RECOVER_RETURN_LEGACY
    if (out.includes(returnNeedle) && !recoverFnHasWebChatDispatchInject(out)) {
      out = out.replace(returnNeedle, `${buildRecoverWebChatInjectBlock()}\n${returnNeedle}`)
    }
  }

  return upgradeVideoRecoverChatRunId(out)
}

export function buildClawbbaResolveOpenRouterApiKeyHelper() {
  return `${VIDEO_RECOVER_AUTH_MARKER}
async function clawbbaResolveOpenRouterApiKey({ cfg, agentDir, authStore }) {
\tconst custom = getCustomProviderApiKey(cfg, "openrouter");
\tif (typeof custom === "string") {
\t\tconst key = custom.trim();
\t\tif (key && !key.includes("secretref") && key !== "secretref-managed") return key;
\t}
\tconst cfgKey = String(cfg?.models?.providers?.openrouter?.apiKey || "").trim();
\tif (cfgKey) return cfgKey;
\tif (authStore) {
\t\tfor (const profileId of resolveAuthProfileOrder({ cfg, store: authStore, provider: "openrouter" }) ?? []) {
\t\t\tconst resolved = await resolveApiKeyForProfile({ cfg, store: authStore, profileId, agentDir });
\t\t\tif (resolved?.apiKey) return resolved.apiKey;
\t\t}
\t}
\tthrow new ToolInputError("ClawBBA Platform Key missing. Re-run install-clawbba-api.sh and openclaw gateway restart.");
}`
}

const CLAWBBA_AUTH_HEADERS = `\tconst apiKey = await clawbbaResolveOpenRouterApiKey({ cfg, agentDir, authStore });
\tconst hdrs = { Authorization: \`Bearer \${apiKey}\`, Accept: "application/json" };`

const LEGACY_AUTH_HEADERS = `\tconst auth = await resolveApiKeyForProvider({ provider: "openrouter", cfg, agentDir, store: authStore });
\tif (!auth.apiKey) throw new ToolInputError("OpenRouter API key missing.");
\tconst hdrs = { Authorization: \`Bearer \${auth.apiKey}\`, Accept: "application/json" };`

export function buildClawbbaVideoRecoverFnBlock() {
  return `${VIDEO_RECOVER_MARKER}
${buildClawbbaResolveOpenRouterApiKeyHelper()}
function clawbbaBuildRecoveredVideoToolResult({ jobId, statusPayload, saved }) {
\tconst attachments = [{ type: "video", path: saved.path, mimeType: saved.contentType, name: saved.id }];
\tconst lines = [
\t\t\`Recovered video job \${jobId} from ClawBBA (no re-generation; user digital asset).\`,
\t\t\`Model: \${statusPayload.model || "unknown"}; already billed on platform when completed.\`,
\t\t"Do NOT call the message tool on WebChat/dashboard — video is injected into the chat transcript automatically.",
\t\t"Do NOT paste https download links or ~/.openclaw paths — WebChat renders MEDIA: local files inline.",
\t\t"",
\t\t"Local delivery (reply with MEDIA lines — do NOT call video_generate generate again):",
\t\t\`MEDIA:\${saved.path}\`
\t];
\treturn {
\t\tcontent: [{ type: "text", text: lines.join("\\n") }],
\t\tprovider: "openrouter",
\t\tmodel: statusPayload.model || "unknown",
\t\tcount: 1,
\t\tpaths: [saved.path],
\t\tattachments,
\t\tcontentText: lines.join("\\n"),
\t\twakeResult: lines.join("\\n"),
\t\tmediaUrls: [saved.path],
\t\tdetails: {
\t\t\tjobId,
\t\t\trecovered: true,
\t\t\tpath: saved.path,
\t\t\tmodel: statusPayload.model,
\t\t\tcount: 1,
\t\t\tmedia: { mediaUrls: [saved.path], attachments },
\t\t\tattachments
\t\t},
\t\tlines
\t};
}
async function clawbbaRecoverVideoTask({ cfg, args, agentDir, authStore, agentSessionKey, chatRunId }) {
\t/* clawbba-video-recover-strict-job */
\tlet jobId = clawbbaResolveVideoRecoverJobId(args);
\tconst maxWaitMs = readNumberParam(args, "timeoutMs", { integer: true, strict: true }) ?? 600000;
\tconst orCfg = cfg?.models?.providers?.openrouter;
\tconst baseUrl = String(orCfg?.baseUrl || "").replace(/\\/$/, "");
\tif (!baseUrl) throw new ToolInputError("No openrouter provider baseUrl configured.");
${CLAWBBA_AUTH_HEADERS}
\tif (orCfg?.headers && typeof orCfg.headers === "object") {
\t\tfor (const [k, v] of Object.entries(orCfg.headers)) {
\t\t\tif (typeof v === "string" && v.trim()) hdrs[k] = v.trim();
\t\t}
\t}
\tif (!jobId) {
\t\tthrow new ToolInputError("video_generate action=recover requires jobId=<uuid>. Run video_generate action=tasks first, then recover the exact job id from that list (timeoutMs=600000).");
\t}
\tawait clawbbaAssertRecoverJobMatchesTool({ expectedKind: "video", baseUrl, hdrs, jobId });
\tconst pollIntervalMs = 5000;
\tconst deadline = Date.now() + maxWaitMs;
\tlet statusPayload = null;
\tconst completedStatuses = new Set(["completed", "complete", "succeeded", "success", "done"]);
\tconst failedStatuses = new Set(["failed", "cancelled", "expired", "error"]);
\twhile (Date.now() < deadline) {
\t\tconst pollRes = await fetch(\`\${baseUrl}/videos/\${encodeURIComponent(jobId)}\`, { method: "GET", headers: hdrs });
\t\tconst text = await pollRes.text();
\t\tlet body;
\t\ttry { body = JSON.parse(text); } catch { throw new Error(\`ClawBBA video poll invalid JSON: \${text.slice(0, 200)}\`); }
\t\tif (!pollRes.ok) throw new Error(body?.message || body?.error || \`Poll HTTP \${pollRes.status}\`);
\t\tstatusPayload = body?.clawbba_recovery ? { ...body, ...body.clawbba_recovery } : body;
\t\tconst st = String(statusPayload.status || statusPayload.upstream_status || "").toLowerCase();
\t\tif (completedStatuses.has(st) || statusPayload.completed === true) break;
\t\tif (failedStatuses.has(st) || statusPayload.failed === true) {
\t\t\tthrow new Error(String(statusPayload.error || body?.error || \`Video job \${st}\`));
\t\t}
\t\tawait new Promise((r) => setTimeout(r, pollIntervalMs));
\t}
\tif (!statusPayload) throw new Error("Video recover poll timed out.");
\tconst stFinal = String(statusPayload.status || statusPayload.upstream_status || "").toLowerCase();
\tif (!completedStatuses.has(stFinal) && statusPayload.completed !== true) {
\t\tthrow new Error(\`Video job not completed after \${maxWaitMs}ms (status=\${statusPayload.status || "unknown"}). Retry: video_generate action=recover jobId=\${jobId} timeoutMs=600000\`);
\t}
\tlet downloadUrl = null;
\tconst dlList = statusPayload.download_urls || statusPayload.clawbba_recovery?.download_urls;
\tif (Array.isArray(dlList)) downloadUrl = dlList.find((u) => typeof u === "string" && u.trim());
\tif (!downloadUrl && Array.isArray(statusPayload.unsigned_urls)) {
\t\tdownloadUrl = statusPayload.unsigned_urls.find((u) => typeof u === "string" && u.trim());
\t}
\tif (!downloadUrl) downloadUrl = \`\${baseUrl}/videos/\${encodeURIComponent(jobId)}/content?index=0\`;
\tif (downloadUrl && !/^https?:\\/\\//i.test(downloadUrl)) {
\t\tdownloadUrl = new URL(downloadUrl, \`\${baseUrl}/\`).href;
\t}
\tconst dlRes = await fetch(downloadUrl, { method: "GET", headers: hdrs });
\tif (!dlRes.ok) throw new Error(\`Video download failed HTTP \${dlRes.status}\`);
\tconst mimeType = dlRes.headers.get("content-type") || "video/mp4";
\tconst buffer = Buffer.from(await dlRes.arrayBuffer());
\tconst filename = readStringParam$1(args, "filename");
\tconst mediaMaxBytes = resolveGeneratedMediaMaxBytes(cfg, "video");
\tconst saved = await saveMediaBuffer(buffer, mimeType, "tool-video-generation", mediaMaxBytes, filename);
\tconst built = clawbbaBuildRecoveredVideoToolResult({ jobId, statusPayload, saved });
\t/* clawbba-video-recover-external-delivery */
\tlet deliveryMode = false;
\tif (agentSessionKey) {
\t\tdeliveryMode = await clawbbaDispatchRecoverMediaDelivery({
\t\t\tcfg,
\t\t\tsessionKey: agentSessionKey,
\t\t\tchatRunId,
\t\t\tmediaPaths: [saved.path],
\t\t\tcaption: built.lines?.[0] || \`Recovered video job \${jobId}\`,
\t\t\tsourceTool: "video_generate",
\t\t\tcompletionLabel: "video",
\t\t\tmessage: built.lines.join("\\n"),
\t\t\tlabel: "ClawBBA video recover",
\t\t\tmediaKind: "video"
\t\t});
\t}
\tif (deliveryMode === "external") {
\t\tconst confirm = [
\t\t\t\`Recovered video job \${jobId} — delivered to your chat channel.\`,
\t\t\t"Reply with ONE short confirmation only; do NOT paste MEDIA: lines or call message tool."
\t\t].join("\\n");
\t\treturn { content: [{ type: "text", text: confirm }], details: { ...built.details, deliveredExternal: true } };
\t}
\treturn {
\t\tcontent: built.content,
\t\tdetails: built.details,
\t};
}
async function clawbbaListVideoTasks({ cfg, agentDir, authStore, args, agentSessionKey, chatRunId }) {
\tconst orCfg = cfg?.models?.providers?.openrouter;
\tconst baseUrl = String(orCfg?.baseUrl || "").replace(/\\/$/, "");
\tif (!baseUrl) throw new ToolInputError("No openrouter provider baseUrl configured.");
${CLAWBBA_AUTH_HEADERS}
\tif (orCfg?.headers && typeof orCfg.headers === "object") {
\t\tfor (const [k, v] of Object.entries(orCfg.headers)) {
\t\t\tif (typeof v === "string" && v.trim()) hdrs[k] = v.trim();
\t\t}
\t}
\tconst limit = readNumberParam(args, "limit", { integer: true, strict: true }) ?? 10;
\tconst status = readStringParam$1(args, "status");
\tconst qs = new URLSearchParams({ limit: String(Math.min(50, Math.max(1, limit))) });
\tif (status) qs.set("status", status);
\tconst res = await fetch(\`\${baseUrl}/videos/tasks?\${qs}\`, { method: "GET", headers: hdrs });
\tconst responseText = await res.text();
\tlet body;
\ttry { body = JSON.parse(responseText); } catch { throw new Error(\`ClawBBA video tasks invalid JSON: \${responseText.slice(0, 200)}\`); }
\tif (!res.ok) throw new Error(body?.message || body?.error || \`Tasks HTTP \${res.status}\`);
\tconst rows = Array.isArray(body?.data) ? body.data : [];
\tconst lines = [
\t\t\`ClawBBA video tasks (\${rows.length}):\`,
\t\t...rows.map((r) => \`- [video] \${r.video_job_id} status=\${r.status} model=\${r.model} submitted=\${r.submitted_at}\${r.charge_usd != null ? \` charge=$\${r.charge_usd}\` : ""}\`),
\t\t"",
\t\t"To fetch completed asset without re-billing: video_generate action=recover jobId=<id> timeoutMs=600000"
\t];
\tconst taskListText = lines.join("\\n");
\tif (agentSessionKey && typeof clawbbaDispatchReadOnlyToolTextReply === "function") {
\t\tawait clawbbaDispatchReadOnlyToolTextReply({
\t\t\tcfg,
\t\t\tsessionKey: agentSessionKey,
\t\t\tchatRunId,
\t\t\tmessage: taskListText,
\t\t\tlabel: "ClawBBA video tasks"
\t\t});
\t}
\treturn {
\t\tcontent: [{ type: "text", text: taskListText }],
\t\tdetails: { tasks: rows }
\t};
}`
}

export const VIDEO_RECOVER_STRICT_JOB_MARKER = '/* clawbba-video-recover-strict-job */'

/** @param {string} src */
export function upgradeVideoRecoverStrictJobId(src) {
  if (src.includes(VIDEO_RECOVER_STRICT_JOB_MARKER) && !src.includes('pick.video_job_id')) return src
  if (!src.includes('async function clawbbaRecoverVideoTask')) return src
  if (!src.includes('function clawbbaResolveRecoverJobId(args)') && !src.includes('function clawbbaResolveVideoRecoverJobId(args)') && !src.includes('clawbba-recover-job-kind')) return src
  let out = src.replace(
    /async function clawbbaRecoverVideoTask\(\{ cfg, args, agentDir, authStore, agentSessionKey, chatRunId \}\) \{\n\tconst jobIdRaw = readStringParam\$1\(args, "jobId"\);[\s\S]*?\tif \(!jobId\) \{\n\t\tconst listRes = await fetch[\s\S]*?\t\tjobId = String\(pick\.video_job_id\)\.trim\(\);\n\t\}/,
    `async function clawbbaRecoverVideoTask({ cfg, args, agentDir, authStore, agentSessionKey, chatRunId }) {
\t${VIDEO_RECOVER_STRICT_JOB_MARKER}
\tlet jobId = clawbbaResolveVideoRecoverJobId(args);`,
  )
  if (!out.includes('video_generate action=recover requires jobId')) {
    out = out.replace(
      /(\tlet jobId = clawbbaResolveVideoRecoverJobId\(args\);)\n(\tconst maxWaitMs)/,
      `$1
\tif (!jobId) {
\t\tthrow new ToolInputError("video_generate action=recover requires jobId=<uuid>. Run video_generate action=tasks first, then recover the exact job id from that list (timeoutMs=600000).");
\t}
\tawait clawbbaAssertRecoverJobMatchesTool({ expectedKind: "video", baseUrl, hdrs, jobId });
$2`,
    )
  }
  return out
}

const RESOLVE_ACTION_RE =
  /function resolveAction\(args\) \{\n\treturn resolveGenerateAction\(\{\n\t\targs,\n\t\tallowed: \[\n\t\t\t"generate",\n\t\t\t"status",\n\t\t\t"list"\n\t\t\],/

const RESOLVE_ACTION_REPLACEMENT = `function resolveAction(args) {
\treturn resolveGenerateAction({
\t\targs,
\t\tallowed: [
\t\t\t"generate",
\t\t\t"status",
\t\t\t"list",
\t\t\t"recover",
\t\t\t"tasks"
\t\t],`

const ACTION_DESC_RE =
  /const VideoGenerateToolProperties = \{\n\taction: Type\.Optional\(Type\.String\(\{ description: "\\"generate\\" default, \\"status\\" active task, \\"list\\" providers\/models\." \}\)\),/

const ACTION_DESC_REPLACEMENT = `const VideoGenerateToolProperties = {
\taction: Type.Optional(Type.String({ description: "\\"generate\\" default; \\"status\\" session task; \\"list\\" providers; \\"tasks\\" ClawBBA job list; \\"recover\\" poll+download completed job (no re-bill)." })),`

const JOB_ID_PROP = `\tjobId: Type.Optional(Type.String({ description: "ClawBBA video_job_id for action=recover." })),
\tlimit: Type.Optional(Type.Number({ description: "Max rows for action=tasks.", minimum: 1 })),
\tstatus: Type.Optional(Type.String({ description: "Filter for action=tasks: pending|completed|all." })),`

const VIDEO_SCHEMA_BLOCK_START = 'const VideoGenerateToolProperties = {'
const VIDEO_SCHEMA_BLOCK_END = '\nfunction createVideoGenerateToolSchema'

/** @param {string} src */
export function extractVideoGenerateToolPropertiesBlock(src) {
  const start = src.indexOf(VIDEO_SCHEMA_BLOCK_START)
  if (start < 0) return { start: -1, end: -1, block: '' }
  const fnAnchor = src.indexOf(VIDEO_SCHEMA_BLOCK_END, start)
  if (fnAnchor < 0) return { start: -1, end: -1, block: '' }
  const end = src.lastIndexOf('};', fnAnchor)
  if (end < start) return { start: -1, end: -1, block: '' }
  return { start, end: end + 3, block: src.slice(start, end + 3) }
}

/** @param {string} src */
export function videoGenerateSchemaHasRecoverJobId(src) {
  const { block } = extractVideoGenerateToolPropertiesBlock(src)
  return block.includes('ClawBBA video_job_id')
}

/** @param {string} src */
export function ensureVideoRecoverSchemaProps(src) {
  let out = src
  const { start, end, block } = extractVideoGenerateToolPropertiesBlock(out)
  if (start < 0 || !block) return out

  let newBlock = block
  if (ACTION_DESC_RE.test(newBlock)) {
    newBlock = newBlock.replace(ACTION_DESC_RE, ACTION_DESC_REPLACEMENT)
  }
  if (!newBlock.includes('ClawBBA video_job_id')) {
    newBlock = newBlock.replace(
      '\tprompt: Type.Optional(Type.String({ description: "Video prompt." })),',
      `${JOB_ID_PROP}\n\tprompt: Type.Optional(Type.String({ description: "Video prompt." })),`,
    )
  }
  if (newBlock === block) return out
  return out.slice(0, start) + newBlock + out.slice(end)
}

const EXECUTE_RE =
  /(\t\t\tconst action = resolveAction\(args\);\n)(\t\t\tif \(action === "list"\) return createVideoGenerateListActionResult\(cfg, \{\n(?:\t\t\t\t[^\n]+\n)+\t\t\t\}\);\n\t\t\tif \(action === "status"\) return createVideoGenerateStatusActionResult\(options\?\.agentSessionKey\);)/

/** @param {string} src */
export function upgradeListVideoTasksDirectReply(src) {
  let out = upgradeListTasksFixTextVarCollision(src, 'video')
  out = ensureListTasksTaskListTextDeclared(out, 'video')
  if (!out.includes('async function clawbbaListVideoTasks')) return out
  out = ensureListTasksSessionKeyParams(out, 'video')
  if (
    out.includes('clawbbaDispatchReadOnlyToolTextReply') &&
    listTasksBlockIsHealthy(out, 'video') &&
    listTasksFnHasSessionKeyParam(out, 'video') &&
    out.includes('agentSessionKey: options?.agentSessionKey, chatRunId: options?.runId') &&
    out.includes('label: "ClawBBA video tasks"')
  ) {
    return out
  }
  if (!out.includes('label: "ClawBBA video tasks"')) {
    out = out.replace(
      /\treturn \{\n\t\tcontent: \[\{ type: "text", text: lines\.join\("\\n"\) \}\],\n\t\tdetails: \{ tasks: rows \}\n\t\};\n\}/,
      `\tconst taskListText = lines.join("\\\\n");
\tif (agentSessionKey && typeof clawbbaDispatchReadOnlyToolTextReply === "function") {
\t\tawait clawbbaDispatchReadOnlyToolTextReply({
\t\t\tcfg,
\t\t\tsessionKey: agentSessionKey,
\t\t\tchatRunId,
\t\t\tmessage: taskListText,
\t\t\tlabel: "ClawBBA video tasks"
\t\t});
\t}
\treturn {
\t\tcontent: [{ type: "text", text: taskListText }],
\t\tdetails: { tasks: rows }
\t};
}`,
    )
  }
  return ensureListTasksTaskListTextDeclared(ensureListTasksSessionKeyParams(out, 'video'), 'video')
}

/**
 * Upgrade recover patch that incorrectly called resolveApiKeyForProvider (not in openclaw-tools scope).
 * @param {string} src
 */
export function upgradeClawbbaVideoRecoverAuth(src) {
  if (!src.includes('resolveApiKeyForProvider({ provider: "openrouter"')) {
    return src
  }
  let out = src
  if (!out.includes('clawbbaResolveOpenRouterApiKey')) {
    out = out.replace(VIDEO_RECOVER_MARKER, `${VIDEO_RECOVER_MARKER}\n${buildClawbbaResolveOpenRouterApiKeyHelper()}`)
  }
  return out.replaceAll(LEGACY_AUTH_HEADERS, CLAWBBA_AUTH_HEADERS)
}

/**
 * @param {string} filePath
 * @returns {'patched'|'skip'|'pattern-missing'}
 */
export function patchVideoGenerateRecoverAction(filePath) {
  let src = fs.readFileSync(filePath, 'utf8')
  if (src.includes(VIDEO_RECOVER_MARKER) && src.includes('clawbbaRecoverVideoTask')) {
    let changed = false
    if (src.includes('resolveApiKeyForProvider({ provider: "openrouter"')) {
      src = upgradeClawbbaVideoRecoverAuth(src)
      changed = true
    }
    const upgradedLive = upgradeVideoRecoverWebChatLive(src)
    let upgradedRun = upgradeVideoRecoverChatRunId(upgradedLive)
    upgradedRun = ensureRecoverFnParams(upgradedRun)
    let next = upgradeListVideoTasksDirectReply(upgradedRun)
    next = upgradeVideoRecoverExecuteArgsRef(next)
    next = upgradeVideoRecoverExternalDelivery(next)
    next = upgradeVideoRecoverStrictJobId(next)
    next = upgradeRecoverJobKindValidation(next)
    next = ensureVideoRecoverSchemaProps(next)
    if (next !== upgradedRun) {
      upgradedRun = next
      changed = true
    }
    if (upgradedRun !== src) {
      src = upgradedRun
      changed = true
    }
    if (!recoverFnHasVideoRecoverDelivery(src) && !recoverFnHasWebChatDispatchInject(src)) {
      throw new Error(`video recover delivery patch missing in ${path.basename(filePath)}`)
    }
    if (!recoverFnHasAgentSessionKeyParam(src)) {
      throw new Error(`video recover missing agentSessionKey param in ${path.basename(filePath)}`)
    }
    if (!listTasksFnHasSessionKeyParam(src, 'video')) {
      throw new Error(`video list tasks missing agentSessionKey param in ${path.basename(filePath)}`)
    }
    if (src.includes('clawbbaListVideoTasks') && !listTasksBlockIsHealthy(src, 'video')) {
      throw new Error(`video list tasks taskListText not declared in ${path.basename(filePath)}`)
    }
    if (!videoGenerateSchemaHasRecoverJobId(src)) {
      throw new Error(`VideoGenerateToolProperties missing jobId in ${path.basename(filePath)} (re-run install-clawbba-api.sh)`)
    }
    if (changed) {
      fs.writeFileSync(filePath, src)
      return 'patched'
    }
    return 'skip'
  }

  if (!src.includes('async function executeVideoGenerationJob')) {
    return 'pattern-missing'
  }

  if (!RESOLVE_ACTION_RE.test(src)) {
    return 'pattern-missing'
  }
  src = src.replace(RESOLVE_ACTION_RE, RESOLVE_ACTION_REPLACEMENT)

  if (ACTION_DESC_RE.test(src)) {
    src = src.replace(ACTION_DESC_RE, ACTION_DESC_REPLACEMENT)
  }

  src = ensureVideoRecoverSchemaProps(src)

  const fnBlock = adaptInjectedReadStringParam(buildClawbbaVideoRecoverFnBlock(), src)
  src = src.replace('async function executeVideoGenerationJob(params) {', `${fnBlock}\nasync function executeVideoGenerationJob(params) {`)

  const executeMatch = src.match(EXECUTE_RE)
  if (!executeMatch) {
    return 'pattern-missing'
  }
  src = src.replace(EXECUTE_RE, `$1${buildVideoRecoverExecutePrefix(src)}$2`)

  if (!src.includes('clawbbaRecoverVideoTask')) {
    throw new Error(`video recover not injected in ${path.basename(filePath)}`)
  }

  if (!videoGenerateSchemaHasRecoverJobId(src)) {
    throw new Error(`VideoGenerateToolProperties missing jobId after patch in ${path.basename(filePath)}`)
  }

  src = upgradeOpenClawBundledReadStringParamAlias(src)
  src = upgradeRecoverJobKindValidation(src)
  fs.writeFileSync(filePath, src)
  return 'patched'
}
