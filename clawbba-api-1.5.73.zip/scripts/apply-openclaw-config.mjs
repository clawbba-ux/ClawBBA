#!/usr/bin/env node
/**
 * 将 ClawBBA patch 合并进 ~/.openclaw/openclaw.json（不依赖 openclaw config patch --merge）
 *
 * - models.providers.*.models：按 model id 合并（保留用户本地额外模型如 owl-alpha）
 * - agents.defaults.models：按键合并（不删除已有条目）
 * - 其余字段：深合并
 */
import fs from 'fs'
import { getOpenclawJsonPath } from './openclaw-paths.mjs'
import { sanitizeOpenclawProviders } from './fix-openclaw-provider-schema.mjs'
import { sanitizeAgentsConfig } from './openclaw-config-sanitize.mjs'
import { applyClawbbaSessionBranding } from './clawbba-openclaw-config-branding.mjs'

function isRecord(v) {
  return v && typeof v === 'object' && !Array.isArray(v)
}

function mergeModelArrays(existing, patch) {
  const merged = Array.isArray(existing) ? [...existing] : []
  const indexById = new Map()
  for (let i = 0; i < merged.length; i++) {
    const entry = merged[i]
    if (isRecord(entry) && typeof entry.id === 'string' && entry.id.trim()) {
      indexById.set(entry.id.trim(), i)
    }
  }
  for (const entry of patch || []) {
    if (!isRecord(entry) || typeof entry.id !== 'string' || !entry.id.trim()) {
      merged.push(entry)
      continue
    }
    const id = entry.id.trim()
    const idx = indexById.get(id)
    if (idx === undefined) {
      indexById.set(id, merged.length)
      merged.push(entry)
      continue
    }
    merged[idx] = isRecord(merged[idx]) ? { ...merged[idx], ...entry } : entry
  }
  return merged
}

function isProviderModelsPath(path) {
  return path.length === 4 && path[0] === 'models' && path[1] === 'providers' && path[3] === 'models'
}

function mergeAtPath(target, path, value) {
  if (path.length === 0) return value
  const [head, ...rest] = path
  if (rest.length === 0) {
    if (isProviderModelsPath(path) && Array.isArray(target) && Array.isArray(value)) {
      return mergeModelArrays(target, value)
    }
    if (path.join('.') === 'agents.defaults.models' && isRecord(target) && isRecord(value)) {
      return { ...target, ...value }
    }
    return value
  }
  const base = isRecord(target) ? { ...target } : {}
  const child = base[head]
  base[head] = mergeAtPath(child, rest, value)
  return base
}

function deepMerge(existing, patch, path = []) {
  if (isProviderModelsPath(path) && Array.isArray(existing) && Array.isArray(patch)) {
    return mergeModelArrays(existing, patch)
  }
  if (path.join('.') === 'agents.defaults.models' && isRecord(existing) && isRecord(patch)) {
    return { ...existing, ...patch }
  }
  if (Array.isArray(patch)) return patch
  if (!isRecord(patch)) return patch
  const out = isRecord(existing) ? { ...existing } : {}
  for (const [key, val] of Object.entries(patch)) {
    const nextPath = [...path, key]
    if (isRecord(out[key]) && isRecord(val)) out[key] = deepMerge(out[key], val, nextPath)
    else if (Array.isArray(val) && isProviderModelsPath(nextPath) && Array.isArray(out[key])) {
      out[key] = mergeModelArrays(out[key], val)
    } else out[key] = val
  }
  return out
}

function main() {
  const patchFile = process.argv[2]
  if (!patchFile) {
    console.error('用法: node scripts/apply-openclaw-config.mjs <patch.json>')
    process.exit(1)
  }
  const patch = JSON.parse(fs.readFileSync(patchFile, 'utf8'))
  const cfgPath = getOpenclawJsonPath()
  let cfg = {}
  if (fs.existsSync(cfgPath)) {
    cfg = JSON.parse(fs.readFileSync(cfgPath, 'utf8'))
  }
  const backup = `${cfgPath}.bak-clawbba-${Date.now()}`
  if (fs.existsSync(cfgPath)) fs.copyFileSync(cfgPath, backup)

  const merged = deepMerge(cfg, patch)
  applyClawbbaSessionBranding(merged, { patch })
  const agentsResult = sanitizeAgentsConfig(merged.agents)
  if (agentsResult.changed) merged.agents = agentsResult.agents
  if (merged.models?.providers) {
    sanitizeOpenclawProviders(merged.models.providers)
  }
  fs.writeFileSync(cfgPath, `${JSON.stringify(merged, null, 2)}\n`, { mode: 0o600 })

  const n = merged.models?.providers?.clawbba?.models?.length ?? 0
  const chatPrimary = String(merged.agents?.defaults?.model?.primary || '').trim()
  process.stderr.write(
    `[clawbba-api] merged openclaw.json → ${cfgPath} (clawbba.models=${n}, chatPrimary=${chatPrimary || '(unset)'}, backup=${backup})\n`,
  )
}

main()
