/**
 * Strict image vs video recover routing — jobId must match the tool invoked.
 */
import { adaptInjectedReadStringParam } from './openclaw-tools-compat.mjs'

export const RECOVER_JOB_KIND_MARKER = '/* clawbba-recover-job-kind */'

export function ensureRecoverJobKindHelpersOnce(src) {
  if (src.includes(RECOVER_JOB_KIND_MARKER)) return src
  if (!src.includes('clawbbaRecoverImageTask') && !src.includes('clawbbaRecoverVideoTask')) return src
  const block = adaptInjectedReadStringParam(buildRecoverJobKindHelpersBlock(), src)
  const anchors = [
    '/* clawbba-image-recover */',
    '/* clawbba-video-recover */',
    'async function clawbbaRecoverImageTask',
    'async function clawbbaRecoverVideoTask',
  ]
  for (const anchor of anchors) {
    if (src.includes(anchor)) return src.replace(anchor, `${block}\n${anchor}`)
  }
  return src
}

export function buildRecoverJobKindHelpersBlock() {
  return `${RECOVER_JOB_KIND_MARKER}
function clawbbaReadRecoverJobIdField(args, key) {
\ttry {
\t\tconst v = readStringParam$1(args, key);
\t\tif (typeof v === "string" && v.trim()) return v.trim();
\t} catch (_) {}
\tif (args && typeof args === "object" && !Array.isArray(args)) {
\t\tconst direct = args[key];
\t\tif (typeof direct === "string" && direct.trim()) return direct.trim();
\t}
\treturn "";
}
function clawbbaResolveImageRecoverJobId(args) {
\tconst keys = ["jobId", "job_id", "image_job_id"];
\tfor (const k of keys) {
\t\tconst v = clawbbaReadRecoverJobIdField(args, k);
\t\tif (v) return v;
\t}
\tif (args && typeof args === "object" && !Array.isArray(args)) {
\t\tfor (const v of Object.values(args)) {
\t\t\tif (typeof v !== "string") continue;
\t\t\tconst m = v.match(/(?:jobId|job_id|image_job_id)\\s*[=:]\\s*([0-9a-f-]{36})/i);
\t\t\tif (m?.[1]) return m[1];
\t\t}
\t}
\treturn "";
}
function clawbbaResolveVideoRecoverJobId(args) {
\tconst keys = ["jobId", "job_id", "video_job_id"];
\tfor (const k of keys) {
\t\tconst v = clawbbaReadRecoverJobIdField(args, k);
\t\tif (v) return v;
\t}
\tif (args && typeof args === "object" && !Array.isArray(args)) {
\t\tfor (const v of Object.values(args)) {
\t\t\tif (typeof v !== "string") continue;
\t\t\tconst m = v.match(/(?:jobId|job_id|video_job_id)\\s*[=:]\\s*([0-9a-f-]{36})/i);
\t\t\tif (m?.[1]) return m[1];
\t\t}
\t}
\treturn "";
}
function clawbbaRecoverJobIdLooksLikeImageTask(jobId) {
\treturn /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(String(jobId || "").trim());
}
function clawbbaRecoverJobIdLooksLikeVideoTask(jobId) {
\tconst s = String(jobId || "").trim();
\treturn /^gen_/i.test(s) || /^video_/i.test(s);
}
async function clawbbaDetectRecoverJobMediaKind({ baseUrl, hdrs, jobId }) {
\tconst enc = encodeURIComponent(jobId);
\tlet imageOk = false;
\tlet videoOk = false;
\ttry {
\t\tconst res = await fetch(\`\${baseUrl}/images/generations/\${enc}\`, { method: "GET", headers: hdrs, signal: AbortSignal.timeout(45000) });
\t\tif (res.ok) imageOk = true;
\t\telse if (res.status !== 404) {
\t\t\ttry {
\t\t\t\tconst body = JSON.parse(await res.text());
\t\t\t\tif (body?.job_id || body?.status) imageOk = true;
\t\t\t} catch (_) {}
\t\t}
\t} catch (_) {}
\ttry {
\t\tconst res = await fetch(\`\${baseUrl}/videos/\${enc}\`, { method: "GET", headers: hdrs, signal: AbortSignal.timeout(45000) });
\t\tif (res.ok) videoOk = true;
\t\telse if (res.status !== 404) {
\t\t\ttry {
\t\t\t\tconst body = JSON.parse(await res.text());
\t\t\t\tif (body?.status || body?.id || body?.video_job_id) videoOk = true;
\t\t\t} catch (_) {}
\t\t}
\t} catch (_) {}
\tif (imageOk && !videoOk) return "image";
\tif (videoOk && !imageOk) return "video";
\tif (imageOk && videoOk) return "ambiguous";
\treturn null;
}
async function clawbbaAssertRecoverJobMatchesTool({ expectedKind, baseUrl, hdrs, jobId }) {
\tif (expectedKind === "video" && clawbbaRecoverJobIdLooksLikeImageTask(jobId) && !clawbbaRecoverJobIdLooksLikeVideoTask(jobId)) {
\t\tconst kind = await clawbbaDetectRecoverJobMediaKind({ baseUrl, hdrs, jobId });
\t\tif (kind === "image" || kind === "ambiguous") {
\t\t\tthrow new ToolInputError(\`Job \${jobId} is an image task. Use image_generate action=recover jobId=\${jobId} timeoutMs=600000 — NOT video_generate.\`);
\t\t}
\t}
\tif (expectedKind === "image" && clawbbaRecoverJobIdLooksLikeVideoTask(jobId)) {
\t\tconst kind = await clawbbaDetectRecoverJobMediaKind({ baseUrl, hdrs, jobId });
\t\tif (kind === "video" || kind === "ambiguous") {
\t\t\tthrow new ToolInputError(\`Job \${jobId} is a video task. Use video_generate action=recover jobId=\${jobId} timeoutMs=600000 — NOT image_generate.\`);
\t\t}
\t}
\tconst detected = await clawbbaDetectRecoverJobMediaKind({ baseUrl, hdrs, jobId });
\tif (detected === "image" && expectedKind === "video") {
\t\tthrow new ToolInputError(\`Job \${jobId} not found for video_generate — it is an image task. Use image_generate action=recover jobId=\${jobId} timeoutMs=600000.\`);
\t}
\tif (detected === "video" && expectedKind === "image") {
\t\tthrow new ToolInputError(\`Job \${jobId} not found for image_generate — it is a video task. Use video_generate action=recover jobId=\${jobId} timeoutMs=600000.\`);
\t}
}`
}

const IMAGE_ASSERT_NEEDLE = `\tif (!jobId) {
\t\tthrow new ToolInputError("image_generate action=recover requires jobId=<uuid>. Run image_generate action=tasks first, then recover the exact job id from that list (timeoutMs=600000).");
\t}
\tconst filename = readStringParam$1(args, "filename");
\tconst { pollBody, buffers: rawBuffers } = await clawbbaPollClawbbaImageJob`

const IMAGE_ASSERT_REPLACEMENT = `\tif (!jobId) {
\t\tthrow new ToolInputError("image_generate action=recover requires jobId=<uuid>. Run image_generate action=tasks first, then recover the exact job id from that list (timeoutMs=600000).");
\t}
\tawait clawbbaAssertRecoverJobMatchesTool({ expectedKind: "image", baseUrl, hdrs, jobId });
\tconst filename = readStringParam$1(args, "filename");
\tconst { pollBody, buffers: rawBuffers } = await clawbbaPollClawbbaImageJob`

const VIDEO_ASSERT_NEEDLE = `\tif (!jobId) {
\t\tthrow new ToolInputError("video_generate action=recover requires jobId=<uuid>. Run video_generate action=tasks first, then recover the exact job id from that list (timeoutMs=600000).");
\t}
\tconst pollIntervalMs = 5000;`

const VIDEO_ASSERT_REPLACEMENT = `\tif (!jobId) {
\t\tthrow new ToolInputError("video_generate action=recover requires jobId=<uuid>. Run video_generate action=tasks first, then recover the exact job id from that list (timeoutMs=600000).");
\t}
\tawait clawbbaAssertRecoverJobMatchesTool({ expectedKind: "video", baseUrl, hdrs, jobId });
\tconst pollIntervalMs = 5000;`

const IMAGE_LEGACY_AUTO_PICK_RE =
  /\tif \(!jobId\) \{\n\t\tconst listRes = await fetch\(\`\$\{baseUrl\}\/images\/tasks[\s\S]*?\t\tjobId = String\(pick\.image_job_id \|\| pick\.job_id\)\.trim\(\);\n\t\}\n/

const VIDEO_LEGACY_AUTO_PICK_RE =
  /\tif \(!jobId\) \{\n\t\tconst listRes = await fetch\(\`\$\{baseUrl\}\/videos\/tasks[\s\S]*?\t\tjobId = String\(pick\.video_job_id\)\.trim\(\);\n\t\}\n/

const LEGACY_RECOVER_JOB_ID_MISSING_THROW = `\tif (!jobId) {
\t\tconst argKeys = args && typeof args === "object" && !Array.isArray(args) ? Object.keys(args).join(", ") : "";
\t\tthrow new ToolInputError(\`image_generate action=recover requires jobId=<uuid> (jobId, job_id, or image_job_id). Run image_generate action=tasks first. Args seen: \${argKeys || "none"}\`);
\t}
`

const LEGACY_VIDEO_RECOVER_JOB_ID_MISSING_THROW = `\tif (!jobId) {
\t\tthrow new ToolInputError("video_generate action=recover requires jobId=<uuid>. Run video_generate action=tasks first, then recover the exact job id from that list (timeoutMs=600000).");
\t}
`

/** Strip legacy auto-pick-first-completed-task recover (wrong jobId when caller omits jobId). */
export function stripLegacyRecoverAutoPick(src) {
  let out = src
  if (IMAGE_LEGACY_AUTO_PICK_RE.test(out)) {
    out = out.replace(IMAGE_LEGACY_AUTO_PICK_RE, LEGACY_RECOVER_JOB_ID_MISSING_THROW)
  }
  if (VIDEO_LEGACY_AUTO_PICK_RE.test(out)) {
    out = out.replace(VIDEO_LEGACY_AUTO_PICK_RE, LEGACY_VIDEO_RECOVER_JOB_ID_MISSING_THROW)
  }
  return out
}

/** @param {string} src */
export function upgradeRecoverJobKindValidation(src) {
  if (!src.includes('clawbbaRecoverImageTask') && !src.includes('clawbbaRecoverVideoTask')) return src
  let out = ensureRecoverJobKindHelpersOnce(stripLegacyRecoverAutoPick(src))

  if (out.includes('const jobIdRaw = readStringParam')) {
    out = out.replace(
      /async function clawbbaRecoverImageTask\(\{ cfg, args, agentDir, authStore, agentSessionKey, chatRunId \}\) \{\n\tconst jobIdRaw = readStringParam(\$1)?\(args, "jobId"\);\n\tlet jobId = typeof jobIdRaw === "string" \? jobIdRaw\.trim\(\) : "";/,
      'async function clawbbaRecoverImageTask({ cfg, args, agentDir, authStore, agentSessionKey, chatRunId }) {\n\t/* clawbba-image-recover-strict-job */\n\tlet jobId = clawbbaResolveImageRecoverJobId(args);',
    )
    out = out.replace(
      /async function clawbbaRecoverVideoTask\(\{ cfg, args, agentDir, authStore, agentSessionKey, chatRunId \}\) \{\n\tconst jobIdRaw = readStringParam(\$1)?\(args, "jobId"\);\n\tlet jobId = typeof jobIdRaw === "string" \? jobIdRaw\.trim\(\) : "";/,
      'async function clawbbaRecoverVideoTask({ cfg, args, agentDir, authStore, agentSessionKey, chatRunId }) {\n\t/* clawbba-video-recover-strict-job */\n\tlet jobId = clawbbaResolveVideoRecoverJobId(args);',
    )
  }

  if (out.includes('let jobId = clawbbaResolveRecoverJobId(args);')) {
    out = out.replace(
      /async function clawbbaRecoverImageTask\([\s\S]*?\n\tlet jobId = clawbbaResolveRecoverJobId\(args\);/,
      (m) => m.replace('clawbbaResolveRecoverJobId', 'clawbbaResolveImageRecoverJobId'),
    )
    out = out.replace(
      /async function clawbbaRecoverVideoTask\([\s\S]*?\n\tlet jobId = clawbbaResolveRecoverJobId\(args\);/,
      (m) => m.replace('clawbbaResolveRecoverJobId', 'clawbbaResolveVideoRecoverJobId'),
    )
  }

  if (out.includes('function clawbbaResolveRecoverJobId(args)') && out.includes('clawbbaResolveImageRecoverJobId')) {
    out = out.replace(/\nfunction clawbbaResolveRecoverJobId\(args\) \{[\s\S]*?\n\}\n(?=function clawbbaAssertPollJobIdMatches|function clawbbaExtractImageJobIdFromError|async function clawbbaPollClawbbaImageJob|async function clawbbaRecoverVideoTask)/, '\n')
  }

  if (out.includes('globalThis.__clawbbaLastImageJobId') && out.includes('clawbbaExtractImageJobIdFromError')) {
    out = out.replace(
      /function clawbbaExtractImageJobIdFromError\(error\) \{[\s\S]*?\n\}\n(?=function clawbbaImageRecoverLooksLikeTimeout|async function clawbbaPollClawbbaImageJob|async function clawbbaTryAutoRecoverImageFromGenerationError)/,
      `function clawbbaExtractImageJobIdFromError(error) {
\tconst msg = String(error?.message || error || "");
\tconst m = msg.match(/job_id=([0-9a-f-]{36})/i) || msg.match(/images\\/generations\\/([0-9a-f-]{36})/i);
\treturn m?.[1] ? String(m[1]).trim() : "";
}
`,
    )
  }

  if (out.includes(IMAGE_ASSERT_NEEDLE) && !out.includes('expectedKind: "image"')) {
    out = out.replace(IMAGE_ASSERT_NEEDLE, IMAGE_ASSERT_REPLACEMENT)
  }
  if (out.includes(VIDEO_ASSERT_NEEDLE) && !out.includes('expectedKind: "video"')) {
    out = out.replace(VIDEO_ASSERT_NEEDLE, VIDEO_ASSERT_REPLACEMENT)
  }

  const imageTasksLine =
    /`- \[image\] \$\{r\.image_job_id \|\| r\.job_id\} status=\$\{r\.status\} model=\$\{r\.model \|\| "\?"\} created=\$\{r\.created_at \|\| r\.submitted_at \|\| "\?"\}`/
  if (out.includes('ClawBBA image tasks') && !imageTasksLine.test(out)) {
    out = out.replace(
      /`- \$\{r\.image_job_id \|\| r\.job_id\} status=\$\{r\.status\} model=\$\{r\.model \|\| "\?"\} created=\$\{r\.created_at \|\| r\.submitted_at \|\| "\?"\}`/,
      '`- [image] ${r.image_job_id || r.job_id} status=${r.status} model=${r.model || "?"} created=${r.created_at || r.submitted_at || "?"}`',
    )
  }
  if (out.includes('ClawBBA video tasks') && !out.includes('`- [video] ${r.video_job_id}')) {
    out = out.replace(
      /`- \$\{r\.video_job_id\} status=\$\{r\.status\} model=\$\{r\.model\} submitted=\$\{r\.submitted_at\}/,
      '`- [video] ${r.video_job_id} status=${r.status} model=${r.model} submitted=${r.submitted_at}',
    )
  }

  return out
}
