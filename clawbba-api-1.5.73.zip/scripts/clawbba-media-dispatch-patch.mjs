/**
 * OpenClaw runtime patches: ClawBBA 话术 → image_generate / video_generate 工具参数
 * 模型 id 规范：references/media-model-ref.md（平台 id → openrouter/<id>）
 */
import fs from 'fs'
import path from 'path'
import { buildOpenClawNormalizeModelFnBlock } from './clawbba-media-model-ref.mjs'
import { resolveReadStringParamIdent } from './openclaw-tools-compat.mjs'

export const MEDIA_DISPATCH_MARKER = '/* clawbba-media-dispatch */'
export const MEDIA_DISPATCH_INTENT_FILTER_MARKER = '/* clawbba-media-dispatch-intent-filter-v2 */'
export const MEDIA_DISPATCH_PROMPT_GUARD_MARKER = '/* clawbba-media-dispatch-prompt-guard */'
export const MEDIA_DISPATCH_PROMPT_GUARD_VIDEO_MARKER = '/* clawbba-media-dispatch-prompt-guard-video */'
const NORMALIZE_FN_MARKER = 'clawbbaToOpenClawMediaModel'

/** image_generate 只匹配「生成图片」；video_generate 只匹配「生成视频」（避免视频话术误触生图） */
export function upgradeMediaDispatchIntentFilters(src) {
  if (src.includes(MEDIA_DISPATCH_INTENT_FILTER_MARKER)) return src
  if (src.includes('生成图片/i.test(t)') && src.includes('生成视频/i.test(t)')) return src
  const re = /if \(\/请使用\\s\*ClawBBA\\s\*生成\(图片\|视频\)\/i\.test\(t\)\)/g
  let n = 0
  const out = src.replace(re, () => {
    n += 1
    const intent = n === 1 ? '生成图片' : '生成视频'
    return `if (/请使用\\\\s*ClawBBA\\\\s*${intent}/i.test(t))`
  })
  if (n < 2 || out === src) return src
  if (out.includes(MEDIA_DISPATCH_INTENT_FILTER_MARKER)) return out
  return out.replace(MEDIA_DISPATCH_MARKER, `${MEDIA_DISPATCH_MARKER}\n\t\t\t${MEDIA_DISPATCH_INTENT_FILTER_MARKER}`)
}

/** 注入到 openclaw-tools image_generate：从 session 最近用户消息解析 ClawBBA 模板 */
export function buildImageGenerateDispatchBlock() {
  return `${buildOpenClawNormalizeModelFnBlock()}
${MEDIA_DISPATCH_MARKER}
\t\t\tawait (async () => {
\t\t\t\tlet mediaText = prompt;
\t\t\t\ttry {
\t\t\t\t\tconst sk = typeof options?.agentSessionKey === "string" ? options.agentSessionKey.trim() : "";
\t\t\t\t\tif (sk) {
\t\t\t\t\t\tconst rt = await getRuntime();
\t\t\t\t\t\tconst { storePath, entry } = rt.loadSessionEntry(sk);
\t\t\t\t\t\tconst sessionId = entry?.sessionId;
\t\t\t\t\t\tif (sessionId && storePath) {
\t\t\t\t\t\t\tconst msgs = await rt.readSessionMessagesAsync(sessionId, storePath, entry?.sessionFile, { mode: "recent", maxMessages: 24, maxBytes: 512000 });
\t\t\t\t\t\t\tfor (let i = msgs.length - 1; i >= 0; i--) {
\t\t\t\t\t\t\t\tconst m = msgs[i];
\t\t\t\t\t\t\t\tif (m?.role !== "user") continue;
\t\t\t\t\t\t\t\tconst t = typeof m.content === "string" ? m.content : Array.isArray(m.content) ? m.content.map((p) => typeof p?.text === "string" ? p.text : typeof p === "string" ? p : "").join("") : "";
\t\t\t\t\t\t\t\tif (/请使用\\s*ClawBBA\\s*生成图片/i.test(t) || /Use\\s+ClawBBA\\s+image\\s+generation/i.test(t)) { mediaText = t; break; }
\t\t\t\t\t\t\t}
\t\t\t\t\t\t}
\t\t\t\t\t}
\t\t\t\t} catch (_) {}
\t\t\t\tconst stripPref = (id) => String(id || "").trim().replace(/^(clawbba|openrouter)\\//i, "");
\t\t\t\tconst mModel = mediaText.match(/模型\\s+([a-z0-9][a-z0-9._\\-\\/]*)/i) || mediaText.match(/\\bmodel\\s+([a-z0-9][a-z0-9._-]+\\/[a-z0-9][a-z0-9._-]+)/i);
\t\t\t\tconst parsedModelRaw = mModel ? mModel[1].replace(/^(clawbba|openrouter)\\//i, "") : null;
\t\t\t\tconst parsedModel = parsedModelRaw && /^[a-z0-9][a-z0-9._-]*\\/[a-z0-9][a-z0-9._-]+$/i.test(parsedModelRaw) ? parsedModelRaw : null;
\t\t\t\tlet parsedAspect = null;
\t\t\t\tif (/16\\s*[:：]\\s*9|横图|横屏/i.test(mediaText) && !/竖图|竖屏/i.test(mediaText)) parsedAspect = "16:9";
\t\t\t\telse if (/9\\s*[:：]\\s*16|竖图|竖屏/i.test(mediaText) && !/横图|横屏/i.test(mediaText)) parsedAspect = "9:16";
\t\t\t\telse for (const pair of [["21:9", /21\\s*[:：]\\s*9/], ["16:9", /16\\s*[:：]\\s*9/], ["9:16", /9\\s*[:：]\\s*16/], ["4:3", /4\\s*[:：]\\s*3/], ["3:4", /3\\s*[:：]\\s*4/], ["1:1", /1\\s*[:：]\\s*1/]]) if (pair[1].test(mediaText)) { parsedAspect = pair[0]; break; }
\t\t\t\tlet parsedPrompt = mediaText.replace(/^请使用\\s*ClawBBA\\s*生成图片能力[,，]?\\s*/i, "").replace(/^Use\\s+ClawBBA\\s+image\\s+generation[,，]?\\s*/i, "").replace(/^(?:模型\\s+[^，,]+[,，]?\\s*)?(?:model\\s+[^,]+,\\s*)?(?:为我生成\\s*)?(?:generate\\s+a\\s*)?(?:(?:\\d{1,2}\\s*[:：]\\s*\\d{1,2})|(?:横图|竖图)|(?:\\dK))[^：:]*[:：]\\s*/i, "").trim();
\t\t\t\tif (!parsedPrompt) parsedPrompt = prompt;
\t\t\t\tif (!model && parsedModel) model = clawbbaToOpenClawMediaModel(parsedModel);
\t\t\t\telse if (model) { const __nm = clawbbaToOpenClawMediaModel(model); if (__nm) model = __nm; }
\t\t\t\tif (!aspectRatio && parsedAspect) aspectRatio = normalizeAspectRatio$1(parsedAspect);
\t\t\t\tif (parsedPrompt && parsedPrompt !== prompt) prompt = parsedPrompt;
\t\t\t})();`
}

/** 注入到 openclaw-tools video_generate */
export function buildVideoGenerateDispatchBlock() {
  return `${buildOpenClawNormalizeModelFnBlock()}
${MEDIA_DISPATCH_MARKER}
\t\t\tawait (async () => {
\t\t\t\tlet mediaText = prompt;
\t\t\t\ttry {
\t\t\t\t\tconst sk = typeof options?.agentSessionKey === "string" ? options.agentSessionKey.trim() : "";
\t\t\t\t\tif (sk) {
\t\t\t\t\t\tconst rt = await getRuntime();
\t\t\t\t\t\tconst { storePath, entry } = rt.loadSessionEntry(sk);
\t\t\t\t\t\tconst sessionId = entry?.sessionId;
\t\t\t\t\t\tif (sessionId && storePath) {
\t\t\t\t\t\t\tconst msgs = await rt.readSessionMessagesAsync(sessionId, storePath, entry?.sessionFile, { mode: "recent", maxMessages: 24, maxBytes: 512000 });
\t\t\t\t\t\t\tfor (let i = msgs.length - 1; i >= 0; i--) {
\t\t\t\t\t\t\t\tconst m = msgs[i];
\t\t\t\t\t\t\t\tif (m?.role !== "user") continue;
\t\t\t\t\t\t\t\tconst t = typeof m.content === "string" ? m.content : Array.isArray(m.content) ? m.content.map((p) => typeof p?.text === "string" ? p.text : typeof p === "string" ? p : "").join("") : "";
\t\t\t\t\t\t\t\tif (/请使用\\s*ClawBBA\\s*生成视频/i.test(t) || /Use\\s+ClawBBA\\s+video\\s+generation/i.test(t)) { mediaText = t; break; }
\t\t\t\t\t\t\t}
\t\t\t\t\t\t}
\t\t\t\t\t}
\t\t\t\t} catch (_) {}
\t\t\t\tconst stripPref = (id) => String(id || "").trim().replace(/^(clawbba|openrouter)\\//i, "");
\t\t\t\tconst mModel = mediaText.match(/模型\\s+([a-z0-9][a-z0-9._\\-\\/]*)/i) || mediaText.match(/\\bmodel\\s+([a-z0-9][a-z0-9._-]+\\/[a-z0-9][a-z0-9._-]+)/i);
\t\t\t\tconst parsedModelRaw = mModel ? mModel[1].replace(/^(clawbba|openrouter)\\//i, "") : null;
\t\t\t\tconst parsedModel = parsedModelRaw && /^[a-z0-9][a-z0-9._-]*\\/[a-z0-9][a-z0-9._-]+$/i.test(parsedModelRaw) ? parsedModelRaw : null;
\t\t\t\tlet parsedAspect = null;
\t\t\t\tif (/16\\s*[:：]\\s*9|横图|横屏/i.test(mediaText) && !/竖图|竖屏/i.test(mediaText)) parsedAspect = "16:9";
\t\t\t\telse if (/9\\s*[:：]\\s*16|竖图|竖屏/i.test(mediaText) && !/横图|横屏/i.test(mediaText)) parsedAspect = "9:16";
\t\t\t\telse for (const pair of [["21:9", /21\\s*[:：]\\s*9/], ["16:9", /16\\s*[:：]\\s*9/], ["9:16", /9\\s*[:：]\\s*16/]]) if (pair[1].test(mediaText)) { parsedAspect = pair[0]; break; }
\t\t\t\tconst mDur = mediaText.match(/(\\d+)\\s*秒/) || mediaText.match(/(\\d+)\\s*s(?:ec(?:ond)?s?)?(?:\\s*video)?/i);
\t\t\t\tconst parsedDur = mDur ? Math.max(1, parseInt(mDur[1], 10)) : null;
\t\t\t\tlet parsedPrompt = mediaText.replace(/^请使用\\s*ClawBBA\\s*生成视频能力[,，]?\\s*/i, "").replace(/^Use\\s+ClawBBA\\s+video\\s+generation[,，]?\\s*/i, "").replace(/^(?:模型\\s+[^，,]+[,，]?\\s*)?(?:model\\s+[^,]+,\\s*)?(?:为我生成\\s*)?(?:generate\\s+a\\s*)?(?:(?:\\d{1,2}\\s*[:：]\\s*\\d{1,2})|(?:横图|竖图)|(?:\\d+\\s*秒)|(?:\\d+\\s*s(?:ec(?:ond)?s?)?(?:\\s*video)?))[^：:，,]*[：:,，]?\\s*/i, "").trim();
\t\t\t\tif (!parsedPrompt) parsedPrompt = prompt;
\t\t\t\tif (!model && parsedModel) model = clawbbaToOpenClawMediaModel(parsedModel);
\t\t\t\telse if (model) { const __nm = clawbbaToOpenClawMediaModel(model); if (__nm) model = __nm; }
\t\t\t\tif (!aspectRatio && parsedAspect) aspectRatio = normalizeAspectRatio(parsedAspect);
\t\t\t\tif (durationSeconds == null && parsedDur != null) durationSeconds = parsedDur;
\t\t\t\tif (parsedPrompt && parsedPrompt !== prompt) prompt = parsedPrompt;
\t\t\t\tawait clawbbaMaybeMergeSessionReferenceImages({ args, options, tool: "video_generate", maxCount: 5 });
\t\t\t})();`
}

const MODEL_ASSIGN_UPGRADE =
  'if (!model && parsedModel) model = clawbbaToOpenClawMediaModel(parsedModel);\n\t\t\t\telse if (model) { const __nm = clawbbaToOpenClawMediaModel(model); if (__nm) model = __nm; }'

function upgradeMediaDispatchModelAssign(src) {
  let out = src
  const patterns = [
    /if \(!model && parsedModel\) model = parsedModel;/g,
    /if \(!model && parsedModel\) model = `openrouter\/\$\{parsedModel\}`;/g,
  ]
  for (const re of patterns) {
    if (re.test(out)) {
      out = out.replace(re, MODEL_ASSIGN_UPGRADE)
      return out
    }
  }
  return out
}

function injectNormalizeFnBeforeMediaDispatch(src) {
  if (src.includes(NORMALIZE_FN_MARKER)) return src
  const block = buildOpenClawNormalizeModelFnBlock()
  const idx = src.indexOf(MEDIA_DISPATCH_MARKER)
  if (idx < 0) return src
  return `${src.slice(0, idx)}${block}\n${src.slice(idx)}`
}

/** OpenClaw 2026.5.28+：readStringParam$1 → readStringParam；video durationSeconds 用 positiveInteger */
function readStringParamCall(suffix) {
  return suffix ? 'readStringParam$1' : 'readStringParam'
}

function readStringParamCallForFile(suffix, toolsSrc) {
  const ident = resolveReadStringParamIdent(toolsSrc)
  if (ident === 'readStringParam') return 'readStringParam'
  return readStringParamCall(suffix)
}

function buildImagePromptGuardTail() {
  return `\t\t\t${MEDIA_DISPATCH_PROMPT_GUARD_MARKER}
\t\t\tif (!String(prompt ?? "").trim()) throw new ToolInputError("prompt required");
\t\t\tconst activeDuplicateGuardResult = createImageGenerateDuplicateGuardResult(options?.agentSessionKey, { prompt });
\t\t\tif (activeDuplicateGuardResult) return activeDuplicateGuardResult;`
}

function buildVideoPromptGuardTail() {
  return `\t\t\t${MEDIA_DISPATCH_PROMPT_GUARD_VIDEO_MARKER}
\t\t\tif (!String(prompt ?? "").trim()) throw new ToolInputError("prompt required");
\t\t\tconst activeDuplicateGuardResult = createVideoGenerateDuplicateGuardResult(options?.agentSessionKey);
\t\t\tif (activeDuplicateGuardResult) return activeDuplicateGuardResult;`
}

/** OpenClaw 2026.5.28: agent may omit prompt; fill from session ClawBBA template before required check. */
export function upgradeMediaDispatchPromptGuardOrder(src) {
  if (!src.includes(MEDIA_DISPATCH_MARKER)) return src
  let out = src

  if (!out.includes(MEDIA_DISPATCH_PROMPT_GUARD_MARKER) && out.includes('createImageGenerateDuplicateGuardResult')) {
    out = out.replace(/\t\t\tlet prompt = readStringParam\$1\(params, "prompt", \{ required: true \}\);/, '\t\t\tlet prompt = readStringParam$1(params, "prompt");')
    out = out.replace(/\t\t\tlet prompt = readStringParam\(params, "prompt", \{ required: true \}\);/, '\t\t\tlet prompt = readStringParam(params, "prompt");')
    const dupRe =
      /\t\t\tconst activeDuplicateGuardResult = createImageGenerateDuplicateGuardResult\(options\?\.agentSessionKey, \{ prompt \}\);\n\t\t\tif \(activeDuplicateGuardResult\) return activeDuplicateGuardResult;\n/
    const dupIdx = out.search(dupRe)
    const dispatchIdx = out.indexOf(MEDIA_DISPATCH_MARKER)
    if (dupIdx >= 0 && dispatchIdx >= 0 && dupIdx < dispatchIdx) {
      out = out.replace(dupRe, '')
      out = out.replace(
        /if \(parsedPrompt && parsedPrompt !== prompt\) prompt = parsedPrompt;\n\t\t\t\}\)\(\);/,
        `if (parsedPrompt && parsedPrompt !== prompt) prompt = parsedPrompt;\n\t\t\t})();\n${buildImagePromptGuardTail()}`,
      )
    }
  }

  if (!out.includes(MEDIA_DISPATCH_PROMPT_GUARD_VIDEO_MARKER) && out.includes('createVideoGenerateDuplicateGuardResult')) {
    out = out.replace(/\t\t\tlet prompt = readStringParam\$1\(args, "prompt", \{ required: true \}\);/, '\t\t\tlet prompt = readStringParam$1(args, "prompt");')
    out = out.replace(/\t\t\tlet prompt = readStringParam\(args, "prompt", \{ required: true \}\);/, '\t\t\tlet prompt = readStringParam(args, "prompt");')
    const dupRe =
      /\t\t\tconst activeDuplicateGuardResult = createVideoGenerateDuplicateGuardResult\(options\?\.agentSessionKey\);\n\t\t\tif \(activeDuplicateGuardResult\) return activeDuplicateGuardResult;\n/
    const dupIdx = out.search(dupRe)
    const videoDispatchIdx = out.indexOf('tool: "video_generate"')
    if (dupIdx >= 0 && videoDispatchIdx >= 0 && dupIdx < videoDispatchIdx) {
      out = out.replace(dupRe, '')
      out = out.replace(
        /if \(parsedPrompt && parsedPrompt !== prompt\) prompt = parsedPrompt;\n\t\t\t\tawait clawbbaMaybeMergeSessionReferenceImages\(\{ args, options, tool: "video_generate"[\s\S]*?\n\t\t\t\}\)\(\);/,
        (m) => `${m}\n${buildVideoPromptGuardTail()}`,
      )
    }
  }

  return out
}

function patchImageGenerateMediaDispatchNeedles(src, toolsSrc = src) {
  let out = src
  let changed = false

  const freshBlockRe =
    /\t\t\tconst prompt = readStringParam(\$1)?\(params, "prompt", \{ required: true \}\);\n\t\t\tconst activeDuplicateGuardResult = createImageGenerateDuplicateGuardResult\(options\?\.agentSessionKey, \{ prompt \}\);\n\t\t\tif \(activeDuplicateGuardResult\) return activeDuplicateGuardResult;\n\t\t\tconst imageInputs = normalizeReferenceImages\(params\);\n\t\t\tconst model = readStringParam(\$1)?\(params, "model"\);\n\t\t\tconst filename = readStringParam(\$1)?\(params, "filename"\);\n\t\t\tconst size = readStringParam(\$1)?\(params, "size"\);\n\t\t\tconst aspectRatio = normalizeAspectRatio\$1\(readStringParam(\$1)?\(params, "aspectRatio"\)\);/

  if (freshBlockRe.test(out) && !out.includes(MEDIA_DISPATCH_MARKER)) {
    out = out.replace(freshBlockRe, (_m, suffix) => {
      changed = true
      const rs = readStringParamCallForFile(suffix, toolsSrc)
      return `\t\t\tlet prompt = ${rs}(params, "prompt");
\t\t\tlet model = ${rs}(params, "model");
\t\t\tconst filename = ${rs}(params, "filename");
\t\t\tconst size = ${rs}(params, "size");
\t\t\tlet aspectRatio = normalizeAspectRatio$1(${rs}(params, "aspectRatio"));
${buildImageGenerateDispatchBlock()}
${buildImagePromptGuardTail()}
\t\t\tconst imageInputs = normalizeReferenceImages(params);`
    })
    return { src: out, changed }
  }

  out = out.replace(
    /\t\t\tconst prompt = readStringParam(\$1)?\(params, "prompt", \{ required: true \}\);/,
    (_m, suffix) => {
      changed = true
      return `\t\t\tlet prompt = ${readStringParamCallForFile(suffix, toolsSrc)}(params, "prompt");`
    },
  )
  out = out.replace(/\t\t\tconst model = readStringParam(\$1)?\(params, "model"\);/, (_m, suffix) => {
    changed = true
    return `\t\t\tlet model = ${readStringParamCallForFile(suffix, toolsSrc)}(params, "model");`
  })

  const aspectNeedle =
    /\t\t\tconst aspectRatio = normalizeAspectRatio\$1\(readStringParam(\$1)?\(params, "aspectRatio"\)\);/
  if (aspectNeedle.test(out) && !out.includes(MEDIA_DISPATCH_MARKER)) {
    out = out.replace(aspectNeedle, (_m, suffix) => {
      changed = true
      return `\t\t\tlet aspectRatio = normalizeAspectRatio$1(${readStringParamCallForFile(suffix, toolsSrc)}(params, "aspectRatio"));
${buildImageGenerateDispatchBlock()}
${buildImagePromptGuardTail()}`
    })
  }

  return { src: out, changed }
}

function patchVideoGenerateMediaDispatchNeedles(src, toolsSrc = src) {
  let out = src
  let changed = false

  const freshVideoRe =
    /\t\t\tconst prompt = readStringParam(\$1)?\(args, "prompt", \{ required: true \}\);\n\t\t\tconst activeDuplicateGuardResult = createVideoGenerateDuplicateGuardResult\(options\?\.agentSessionKey\);\n\t\t\tif \(activeDuplicateGuardResult\) return activeDuplicateGuardResult;\n\t\t\tconst model = readStringParam(\$1)?\(args, "model"\);\n\t\t\tconst filename = readStringParam(\$1)?\(args, "filename"\);\n\t\t\tconst size = readStringParam(\$1)?\(args, "size"\);\n\t\t\tconst aspectRatio = normalizeAspectRatio\(readStringParam(\$1)?\(args, "aspectRatio"\)\);\n\t\t\tconst resolution = normalizeResolution\(readStringParam(\$1)?\(args, "resolution"\)\);\n\t\t\tconst durationSeconds = readNumberParam\(args, "durationSeconds", \{\n\t\t\t\tpositiveInteger: true,\n\t\t\t\tstrict: true\n\t\t\t\}\);\n\t\t\tif \(durationSeconds === void 0 && readSnakeCaseParamRaw\(args, "durationSeconds"\) !== void 0\) throw new ToolInputError\("durationSeconds must be a positive integer"\);/

  if (freshVideoRe.test(out) && !out.includes('durationSeconds == null && parsedDur')) {
    out = out.replace(freshVideoRe, (_m, suffix) => {
      changed = true
      const rs = readStringParamCallForFile(suffix, toolsSrc)
      return `\t\t\tlet prompt = ${rs}(args, "prompt");
\t\t\tlet model = ${rs}(args, "model");
\t\t\tconst filename = ${rs}(args, "filename");
\t\t\tconst size = ${rs}(args, "size");
\t\t\tlet aspectRatio = normalizeAspectRatio(${rs}(args, "aspectRatio"));
\t\t\tconst resolution = normalizeResolution(${rs}(args, "resolution"));
\t\t\tlet durationSeconds = readNumberParam(args, "durationSeconds", {
\t\t\t\tpositiveInteger: true,
\t\t\t\tstrict: true
\t\t\t});
\t\t\tif (durationSeconds === void 0 && readSnakeCaseParamRaw(args, "durationSeconds") !== void 0) throw new ToolInputError("durationSeconds must be a positive integer");
${buildVideoGenerateDispatchBlock()}
${buildVideoPromptGuardTail()}`
    })
    return { src: out, changed }
  }

  out = out.replace(
    /\t\t\tconst prompt = readStringParam(\$1)?\(args, "prompt", \{ required: true \}\);/,
    (_m, suffix) => {
      changed = true
      return `\t\t\tlet prompt = ${readStringParamCallForFile(suffix, toolsSrc)}(args, "prompt");`
    },
  )
  out = out.replace(/\t\t\tconst model = readStringParam(\$1)?\(args, "model"\);/, (_m, suffix) => {
    changed = true
    return `\t\t\tlet model = ${readStringParamCallForFile(suffix, toolsSrc)}(args, "model");`
  })
  out = out.replace(
    /\t\t\tconst aspectRatio = normalizeAspectRatio\(readStringParam(\$1)?\(args, "aspectRatio"\)\);/,
    (_m, suffix) => {
      changed = true
      return `\t\t\tlet aspectRatio = normalizeAspectRatio(${readStringParamCallForFile(suffix, toolsSrc)}(args, "aspectRatio"));`
    },
  )

  const durationBlock = `${buildVideoGenerateDispatchBlock()}\n${buildVideoPromptGuardTail()}`
  const durationPatterns = [
    /\t\t\tconst durationSeconds = readNumberParam\(args, "durationSeconds", \{\n\t\t\t\tinteger: true,\n\t\t\t\tstrict: true\n\t\t\t\}\);/,
    /\t\t\tconst durationSeconds = readNumberParam\(args, "durationSeconds", \{\n\t\t\t\tpositiveInteger: true,\n\t\t\t\tstrict: true\n\t\t\t\}\);\n\t\t\tif \(durationSeconds === void 0 && readSnakeCaseParamRaw\(args, "durationSeconds"\) !== void 0\) throw new ToolInputError\("durationSeconds must be a positive integer"\);/,
  ]
  for (const re of durationPatterns) {
    if (re.test(out) && !out.includes('durationSeconds == null && parsedDur')) {
      out = out.replace(re, (m) => {
        changed = true
        return `${m.replace('const durationSeconds', 'let durationSeconds')}
${durationBlock}`
      })
      break
    }
  }

  return { src: out, changed }
}

export function patchImageGenerateMediaDispatch(filePath) {
  let src = fs.readFileSync(filePath, 'utf8')
  if (src.includes(MEDIA_DISPATCH_MARKER)) {
    let upgraded = upgradeMediaDispatchPromptGuardOrder(src)
    upgraded = upgradeMediaDispatchIntentFilters(upgraded)
    upgraded = upgradeMediaDispatchModelAssign(injectNormalizeFnBeforeMediaDispatch(upgraded))
    if (upgraded !== src) {
      fs.writeFileSync(filePath, upgraded)
      return upgraded.includes(MEDIA_DISPATCH_PROMPT_GUARD_MARKER) && !src.includes(MEDIA_DISPATCH_PROMPT_GUARD_MARKER)
        ? 'upgraded-prompt-guard'
        : 'patched'
    }
    if (src.includes(MEDIA_DISPATCH_PROMPT_GUARD_MARKER) && src.includes('clawbbaToOpenClawMediaModel(parsedModel)')) return 'skip'
    if (src.includes('clawbbaToOpenClawMediaModel(parsedModel)')) return 'skip'
    return 'skip'
  }

  const { src: patched, changed } = patchImageGenerateMediaDispatchNeedles(src, src)
  src = patched

  if (!src.includes(MEDIA_DISPATCH_MARKER)) {
    throw new Error(`image_generate media dispatch not injected in ${path.basename(filePath)}`)
  }
  if (changed) {
    fs.writeFileSync(filePath, src)
    return 'patched'
  }
  throw new Error(`image_generate media dispatch not injected in ${path.basename(filePath)}`)
}

export function patchVideoGenerateMediaDispatch(filePath) {
  let src = fs.readFileSync(filePath, 'utf8')
  if (src.includes(MEDIA_DISPATCH_MARKER) && src.includes('durationSeconds == null && parsedDur')) {
    let upgraded = upgradeMediaDispatchPromptGuardOrder(src)
    upgraded = upgradeMediaDispatchIntentFilters(upgraded)
    upgraded = upgradeMediaDispatchModelAssign(injectNormalizeFnBeforeMediaDispatch(upgraded))
    if (upgraded !== src) {
      fs.writeFileSync(filePath, upgraded)
      return upgraded.includes(MEDIA_DISPATCH_PROMPT_GUARD_VIDEO_MARKER) && !src.includes(MEDIA_DISPATCH_PROMPT_GUARD_VIDEO_MARKER)
        ? 'upgraded-prompt-guard'
        : 'patched'
    }
    if (src.includes(MEDIA_DISPATCH_PROMPT_GUARD_VIDEO_MARKER) && src.includes('clawbbaToOpenClawMediaModel(parsedModel)')) return 'skip'
    if (src.includes('clawbbaToOpenClawMediaModel(parsedModel)')) return 'skip'
    return 'skip'
  }

  const { src: patched, changed } = patchVideoGenerateMediaDispatchNeedles(src, src)
  src = patched

  if (!src.includes('durationSeconds == null && parsedDur')) {
    throw new Error(`video_generate media dispatch not injected in ${path.basename(filePath)}`)
  }
  if (changed) {
    fs.writeFileSync(filePath, src)
    return 'patched'
  }
  throw new Error(`video_generate media dispatch not injected in ${path.basename(filePath)}`)
}

export function patchOpenRouterImageProviderAspect(dist) {
  const files = fs.readdirSync(dist).filter((name) => name.startsWith('image-generation-provider-') && name.endsWith('.js'))
  const file = files.find((name) => {
    const src = fs.readFileSync(path.join(dist, name), 'utf8')
    return src.includes('function buildImageConfig(req, model)') && src.includes('`${baseUrl}/chat/completions`')
  })
  if (!file) return 'missing'
  const filePath = path.join(dist, file)
  let src = fs.readFileSync(filePath, 'utf8')
  if (src.includes(MEDIA_DISPATCH_MARKER)) return 'skip'

  const needle = `function buildImageConfig(req, model) {
\tif (!isGeminiImageModel(model)) return {};
\tconst imageConfig = {};`
  const replacement = `function buildImageConfig(req, model) {
\t${MEDIA_DISPATCH_MARKER}
\tconst imageConfig = {};`

  if (!src.includes(needle)) {
    if (src.includes('function buildImageConfig(req, model)')) return 'skip'
    return 'missing'
  }
  src = src.replace(needle, replacement)
  fs.writeFileSync(filePath, src)
  return 'patched'
}

const MEDIA_DISPATCH_HEADERS_MARKER = '/* clawbba-media-dispatch-headers */'
const MEDIA_DISPATCH_HEADERS_FIX_MARKER = '/* clawbba-media-dispatch-headers-v2 */'

const CLAWBBA_IMAGE_HEADER_MERGE_BLOCK = `\t\t\t${MEDIA_DISPATCH_HEADERS_MARKER}
\t\t\t${MEDIA_DISPATCH_HEADERS_FIX_MARKER}
\t\t\tconst clawbbaAspectHdr = normalizeOptionalString(req.aspectRatio);
\t\t\tconst clawbbaResHdr = normalizeOptionalString(req.resolution);
\t\t\tconst __clawbbaMergedImgHeaders = new Headers(headers);
\t\t\t__clawbbaMergedImgHeaders.set("Content-Type", "application/json");
\t\t\tif (model) __clawbbaMergedImgHeaders.set("X-ClawBBA-Image-Model", model);
\t\t\tif (clawbbaAspectHdr) __clawbbaMergedImgHeaders.set("X-ClawBBA-Image-Aspect", clawbbaAspectHdr);
\t\t\tif (clawbbaResHdr) __clawbbaMergedImgHeaders.set("X-ClawBBA-Image-Resolution", clawbbaResHdr);
\t\t\tconst __clawbbaOrHdr = req.cfg?.models?.providers?.openrouter?.headers;
\t\t\tif (__clawbbaOrHdr && typeof __clawbbaOrHdr === "object") {
\t\t\t\tfor (const [__k, __v] of Object.entries(__clawbbaOrHdr)) {
\t\t\t\t\tif (typeof __v === "string" && __v.trim()) __clawbbaMergedImgHeaders.set(__k, __v.trim());
\t\t\t\t}
\t\t\t}`

const BROKEN_HEADERS_SPREAD = 'headers: { ...headers, ...clawbbaMediaHeaders }'

/** ClawBBA Platform API：undici 空 body 恢复时从 HTTP 头读取 model / aspect */
export function patchOpenRouterImageProviderHeaders(dist) {
  const files = fs.readdirSync(dist).filter((name) => name.startsWith('image-generation-provider-') && name.endsWith('.js'))
  const file = files.find((name) => {
    const src = fs.readFileSync(path.join(dist, name), 'utf8')
    return (
      src.includes('async generateImage(req)') &&
      src.includes('postJsonRequest') &&
      src.includes('`${baseUrl}/chat/completions`')
    )
  })
  if (!file) return 'missing'
  const filePath = path.join(dist, file)
  let src = fs.readFileSync(filePath, 'utf8')

  if (src.includes(MEDIA_DISPATCH_HEADERS_FIX_MARKER)) {
    return 'skip'
  }

  const upgradeBrokenHeadersSpread = () => {
    if (!src.includes(BROKEN_HEADERS_SPREAD) && !(src.includes(MEDIA_DISPATCH_HEADERS_MARKER) && src.includes('clawbbaMediaHeaders'))) {
      return false
    }
    src = src.replace(
      /\t\t\t\/\* clawbba-media-dispatch-headers \*\/[\s\S]*?headers: \{ \.\.\.headers, \.\.\.clawbbaMediaHeaders \},/,
      `${CLAWBBA_IMAGE_HEADER_MERGE_BLOCK}
\t\t\tconst { response, release } = await postJsonRequest({
\t\t\t\turl: \`\${baseUrl}/chat/completions\`,
\t\t\t\theaders: __clawbbaMergedImgHeaders,`,
    )
    if (src.includes(BROKEN_HEADERS_SPREAD)) {
      const postNeedle = `\t\t\tconst { response, release } = await postJsonRequest({
\t\t\t\turl: \`\${baseUrl}/chat/completions\`,
\t\t\t\theaders: __clawbbaMergedImgHeaders,`
      if (!src.includes('__clawbbaMergedImgHeaders')) {
        src = src.replace(BROKEN_HEADERS_SPREAD, 'headers: __clawbbaMergedImgHeaders')
        src = src.replace(
          postNeedle,
          `${CLAWBBA_IMAGE_HEADER_MERGE_BLOCK}
${postNeedle}`,
        )
      } else {
        src = src.replace(BROKEN_HEADERS_SPREAD, 'headers: __clawbbaMergedImgHeaders')
      }
    }
    return src.includes(MEDIA_DISPATCH_HEADERS_FIX_MARKER) && !src.includes(BROKEN_HEADERS_SPREAD)
  }

  if (upgradeBrokenHeadersSpread()) {
    fs.writeFileSync(filePath, src)
    return 'fixed-broken-spread'
  }
  if (src.includes(BROKEN_HEADERS_SPREAD) || (src.includes(MEDIA_DISPATCH_HEADERS_MARKER) && src.includes('clawbbaMediaHeaders'))) {
    return 'broken-spread-unfixed'
  }

  const needle = `\t\t\t});
\t\t\tconst { response, release } = await postJsonRequest({
\t\t\t\turl: \`\${baseUrl}/chat/completions\`,
\t\t\t\theaders,`
  const replacement = `\t\t\t});
${CLAWBBA_IMAGE_HEADER_MERGE_BLOCK}
\t\t\tconst { response, release } = await postJsonRequest({
\t\t\t\turl: \`\${baseUrl}/chat/completions\`,
\t\t\t\theaders: __clawbbaMergedImgHeaders,`

  if (!src.includes(needle)) return 'missing'
  src = src.replace(needle, replacement)
  fs.writeFileSync(filePath, src)
  return 'patched'
}
