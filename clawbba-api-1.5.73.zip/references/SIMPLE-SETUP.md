# ClawBBA 生图 / 生视频 — 简明对接（唯一操作指南）

## 架构（三层，各管一件事）

```
用户话术（模型 + 16:9 + 描述）
    ↓
OpenClaw  image_generate / video_generate  →  models.providers.openrouter → ClawBBA API
    ↓
ClawBBA 服务端从话术解析 model / aspect_ratio（即使用户未传 tool 参数也会纠正）
```

| 层 | 职责 |
|----|------|
| **OpenClaw** | 工具 `image_generate` / `video_generate`；`model` 必须是 **`openrouter/<平台模型id>`** |
| **clawbba-api** | 配置 Platform Key、openrouter baseUrl 指向 clawbba.com、**一次** runtime patch |
| **ClawBBA 服务端** | `POST /api/v1/chat/completions`（图）、`POST /api/v1/videos`（视频）；解析「请使用 ClawBBA 生成图片…」 |

文本对话只用 **`/model clawbba/<id>`**，不要用 clawbba/ 前缀调用生图工具。

---

## 一次性安装（OpenClaw 机器）

```bash
export CLAWBBA_API_KEY='cbb_sk_live_你的完整密钥'
curl -fsSL https://www.clawbba.com/downloads/install-clawbba-api.sh | bash
# 或已安装 skill 后：
cd ~/.openclaw/skills/clawbba-api && ./scripts/one-shot-setup.sh
openclaw gateway restart
```

验证 Flux patch（必须有输出）：

```bash
grep __clawbbaImgProviders ~/.local/share/pnpm/global/5/.pnpm/openclaw@*/node_modules/openclaw/dist/model-ref-*.js
```

验证配置：

```bash
openclaw config validate
```

---

## 生图标准话术（复制即用）

```
请使用 ClawBBA 生成图片能力，模型 black-forest-labs/flux.2-pro，为我生成 16:9 横图：（画面描述）
```

OpenClaw 内部应等价于：

- `model`: `openrouter/black-forest-labs/flux.2-pro`
- `aspectRatio`: `16:9`
- `prompt`: 仅画面描述

若日志出现 **`No image-generation provider registered for black-forest-labs`**：未打 runtime patch → 重新执行 `one-shot-setup.sh` 并 `gateway restart`。

若日志出现 **`agents.defaults: Invalid input`**（OpenClaw 2026.5.28+）：执行 `node scripts/fix-openclaw-config-schema.mjs` 后 `openclaw gateway restart`。

---

## 生视频标准话术

```
请使用 ClawBBA 生成视频能力，模型 google/veo-3.1-lite，为我生成 9:16、5 秒视频：（画面描述）

（视频提交经 ClawBBA 代理可能超过 60 秒，需 **clawbba-api 1.5.0+** patch，见 `error-translation.md`。）
```

---

## 不要做的事

- 不要用 `openclaw config patch` 覆盖整表 models（会删本地模型；已改用 `apply-openclaw-config.mjs`）
- 不要在生图 tool 里写 `clawbba/…` 或裸 `black-forest-labs/…`（无 patch 时 OpenClaw 会报错）
- 不要重复跑多套 patch 脚本；**只需** `one-shot-setup.sh` + `patch-flux-critical.mjs`（已包含在 one-shot 内）

更细的参数表见 `media-model-ref.md`。
