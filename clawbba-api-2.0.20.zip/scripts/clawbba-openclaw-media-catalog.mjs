/**
 * ClawBBA × OpenClaw 生图/生视频 — 唯一配置源（安装脚本 + 官网 API Keys 页）
 * @see references/clawbba-media-models.md
 */

export const CLAWBBA_SKILL_VERSION = '2.0.20'

export const CLAWBBA_INSTALL_BASE = 'https://www.clawbba.com/downloads'

export const DEFAULT_IMAGE_MODEL_ID = 'google/gemini-3.1-flash-image-preview'
export const DEFAULT_IMAGE_MODEL_LABEL = 'Nano Banana 2'

export const DEFAULT_VIDEO_MODEL_ID = 'google/veo-3.1-fast'
export const DEFAULT_VIDEO_MODEL_LABEL = 'Veo 3.1 Fast'

/** generate-openclaw-patch.mjs 选默认生图/生视频时的优先级 */
export const PATCH_IMAGE_MODEL_PREFER = [
  'google/gemini-3.1-flash-image-preview',
  'google/gemini-3-pro-image-preview',
  'google/gemini-2.5-flash-image',
  'openai/gpt-5.4-image-2',
]

export const PATCH_VIDEO_MODEL_PREFER = [
  'google/veo-3.1-fast',
  'google/veo-3.1',
  'alibaba/wan-2.6',
  'openai/sora-2-pro',
]

/** API Keys 页 · 用户怎么说 → Agent 填什么（自然语言，无固定话术前缀） */
export const IMAGE_PARAM_ROWS = [
  ['画面描述', '写入 image_generate 的 prompt（须保留你在对话里说的原意）'],
  ['比例 / 清晰度', '如「9:16 竖图」「16:9 横图 2K」→ aspectRatio、resolution'],
  ['指定模型（可选）', '如「用 flux.2-pro」→ model: openrouter/black-forest-labs/flux.2-pro；不写则用默认'],
  ['参考图（图生图）', 'WebChat 先上传图片，再说「按参考图…」→ images[] / image'],
]

export const VIDEO_PARAM_ROWS = [
  ['画面描述', '写入 video_generate 的 prompt（须保留你的原意）'],
  ['时长', '如「8 秒」→ durationSeconds（必填）'],
  ['比例 / 分辨率', '如「16:9」「1080p」→ aspectRatio、resolution'],
  ['指定模型（可选）', '如「用 veo-3.1-fast」→ model: openrouter/google/veo-3.1-fast'],
  ['参考图（图生视频）', '上传后说「用这张图做 5 秒视频」→ image + imageRoles'],
]

/**
 * 生图模型示例（与站内目录一致；未上架的 id 会在 API 指南里自动过滤）
 * ratio / resolution 为推荐示例参数
 */
export const IMAGE_MODEL_SPECS = [
  {
    id: 'google/gemini-3.1-flash-image-preview',
    label: 'Nano Banana 2',
    note: '默认 · 速度快',
    ratio: '9:16',
    resolution: '',
    featured: true,
  },
  {
    id: 'google/gemini-3-pro-image-preview',
    label: 'Nano Banana Pro',
    note: '高质量 · 支持 2K',
    ratio: '9:16',
    resolution: '2K',
  },
  {
    id: 'google/gemini-2.5-flash-image',
    label: 'Nano Banana',
    note: '经济型',
    ratio: '1:1',
    resolution: '',
  },
  {
    id: 'black-forest-labs/flux.2-pro',
    label: 'FLUX.2 Pro',
    note: '写实风格',
    ratio: '16:9',
    resolution: '',
    featured: true,
  },
  {
    id: 'black-forest-labs/flux.2-max',
    label: 'FLUX.2 Max',
    note: '旗舰 FLUX',
    ratio: '16:9',
    resolution: '',
  },
  {
    id: 'black-forest-labs/flux.2-flex',
    label: 'FLUX.2 Flex',
    note: '灵活构图',
    ratio: '16:9',
    resolution: '',
  },
  {
    id: 'black-forest-labs/flux.2-klein-4b',
    label: 'FLUX.2 Klein',
    note: '轻量',
    ratio: '1:1',
    resolution: '',
  },
  {
    id: 'bytedance-seed/seedream-4.5',
    label: 'Seedream 4.5',
    note: '字节 Seedream',
    ratio: '9:16',
    resolution: '',
  },
  {
    id: 'openai/gpt-5.4-image-2',
    label: 'GPT-5.4 Image',
    note: 'OpenAI 生图',
    ratio: '1:1',
    resolution: '',
  },
  {
    id: 'openai/gpt-5-image',
    label: 'GPT-5 Image',
    note: 'OpenAI',
    ratio: '1:1',
    resolution: '',
  },
  {
    id: 'openai/gpt-5-image-mini',
    label: 'GPT-5 Image Mini',
    note: '经济',
    ratio: '1:1',
    resolution: '',
  },
  {
    id: 'x-ai/grok-imagine-image-quality',
    label: 'Grok Imagine',
    note: 'xAI 高质量',
    ratio: '9:16',
    resolution: '',
  },
  {
    id: 'sourceful/riverflow-v2-pro',
    label: 'Riverflow Pro',
    note: 'Sourceful',
    ratio: '16:9',
    resolution: '',
  },
]

export const VIDEO_MODEL_SPECS = [
  {
    id: 'google/veo-3.1-fast',
    label: 'Veo 3.1 Fast',
    note: '默认 · 速度快',
    ratio: '16:9',
    duration: 8,
    featured: true,
  },
  {
    id: 'google/veo-3.1',
    label: 'Veo 3.1',
    note: '高质量',
    ratio: '16:9',
    duration: 8,
    featured: true,
  },
  {
    id: 'google/veo-3.1-lite',
    label: 'Veo 3.1 Lite',
    note: '经济',
    ratio: '9:16',
    duration: 5,
  },
  {
    id: 'bytedance/seedance-2.0',
    label: 'Seedance 2.0',
    note: '字节 Seedance',
    ratio: '9:16',
    duration: 5,
    featured: true,
  },
  {
    id: 'bytedance/seedance-2.0-fast',
    label: 'Seedance 2.0 Fast',
    note: '快速',
    ratio: '9:16',
    duration: 5,
  },
  {
    id: 'bytedance/seedance-1-5-pro',
    label: 'Seedance 1.5 Pro',
    note: '上一代 Pro',
    ratio: '16:9',
    duration: 8,
  },
  {
    id: 'kwaivgi/kling-v3.0-pro',
    label: 'Kling 3.0 Pro',
    note: '可灵 Pro',
    ratio: '16:9',
    duration: 8,
    featured: true,
  },
  {
    id: 'kwaivgi/kling-v3.0-std',
    label: 'Kling 3.0 Standard',
    note: '可灵标准',
    ratio: '16:9',
    duration: 8,
  },
  {
    id: 'kwaivgi/kling-video-o1',
    label: 'Kling Video O1',
    note: '可灵 O1',
    ratio: '16:9',
    duration: 5,
  },
  {
    id: 'openai/sora-2-pro',
    label: 'Sora 2 Pro',
    note: 'OpenAI 视频',
    ratio: '16:9',
    duration: 8,
  },
  {
    id: 'alibaba/wan-2.7',
    label: 'Wan 2.7',
    note: '阿里万相',
    ratio: '16:9',
    duration: 8,
  },
  {
    id: 'alibaba/wan-2.6',
    label: 'Wan 2.6',
    note: '阿里',
    ratio: '16:9',
    duration: 8,
  },
  {
    id: 'minimax/hailuo-2.3',
    label: 'Hailuo 2.3',
    note: 'MiniMax',
    ratio: '9:16',
    duration: 5,
  },
  {
    id: 'x-ai/grok-imagine-video',
    label: 'Grok Imagine Video',
    note: 'xAI',
    ratio: '16:9',
    duration: 8,
  },
]

export const OPENCLAW_IMAGE_EXAMPLE_DESC =
  '赛博朋克城市夜景，霓虹灯与雨雾，电影感构图'

export const OPENCLAW_VIDEO_EXAMPLE_DESC = '海浪拍打礁石，电影感航拍，慢镜头'

export const OPENCLAW_VIDEO_EXAMPLE_DESC_EN =
  'Ocean waves crashing on rocks, cinematic aerial shot, slow motion'

/** 生视频 · 全部模型：这些 id 复制中文话术，其余用英文模板 */
export const VIDEO_PROMPT_CHINESE_MODEL_IDS = new Set([
  'bytedance/seedance-2.0',
  'bytedance/seedance-2.0-fast',
  'bytedance/seedance-1-5-pro',
  'alibaba/wan-2.7',
  'alibaba/wan-2.6',
  'kwaivgi/kling-video-o1',
  'kwaivgi/kling-v3.0-pro',
  'kwaivgi/kling-v3.0-std',
  'minimax/hailuo-2.3',
])

export function toOpenClawMediaPrimary(platformModelId) {
  return `openrouter/${String(platformModelId || '').trim()}`
}

function formatRatioPhrase(ratio) {
  if (ratio === '9:16') return '9:16 竖图'
  if (ratio === '16:9') return '16:9 横图'
  if (ratio === '1:1') return '1:1 方图'
  return ratio ? String(ratio) : ''
}

/**
 * v2.5+ 自然语言生图示例（官网 / platform-openclaw-guide 唯一来源）
 * @param {object} [opts]
 */
export function buildNaturalLanguageImagePrompt(opts = {}) {
  const {
    modelId,
    modelLabel,
    description = OPENCLAW_IMAGE_EXAMPLE_DESC,
    ratio = '9:16',
    resolution,
    referenceImage = false,
  } = opts
  const parts = []
  if (referenceImage) parts.push('我上传了参考图，请按参考图')
  else parts.push('帮我生成一张')
  if (modelId) {
    const name = modelLabel ? `${modelLabel}（${modelId}）` : modelId
    parts.push(`，用 ${name}`)
  }
  const geo = [formatRatioPhrase(ratio), resolution].filter(Boolean).join(' ')
  if (geo) parts.push(geo)
  return `${parts.join(' ')}：${description}`
}

/**
 * v2.5+ 自然语言生视频示例
 * @param {object} [opts]
 */
export function buildNaturalLanguageVideoPrompt(opts = {}) {
  const {
    modelId,
    modelLabel,
    description = OPENCLAW_VIDEO_EXAMPLE_DESC,
    ratio = '16:9',
    duration = 8,
    resolution,
    audio,
    firstFrame = false,
  } = opts
  const parts = []
  if (firstFrame) parts.push('我上传了图片作为首帧，请')
  else parts.push('帮我生成一段')
  if (modelId) {
    const name = modelLabel ? `${modelLabel}（${modelId}）` : modelId
    parts.push(`用 ${name}`)
  }
  const geo = [
    formatRatioPhrase(ratio),
    duration != null ? `${duration} 秒` : '',
    resolution,
    audio === true ? '带音频' : audio === false ? '不要音频' : '',
  ]
    .filter(Boolean)
    .join('、')
  if (geo) parts.push(geo)
  parts.push(`的视频：${description}`)
  return parts.join(' ')
}

/** @deprecated 别名；请用 buildNaturalLanguageImagePrompt */
export function buildOpenclawImagePrompt(opts = {}) {
  return buildNaturalLanguageImagePrompt(opts)
}

/** @deprecated 别名；请用 buildNaturalLanguageVideoPrompt */
export function buildOpenclawVideoPrompt(opts = {}) {
  return buildNaturalLanguageVideoPrompt(opts)
}

/** @deprecated 统一中文自然语言 */
export function buildOpenclawVideoPromptEn(opts = {}) {
  return buildNaturalLanguageVideoPrompt({
    ...opts,
    description: opts.description ?? OPENCLAW_VIDEO_EXAMPLE_DESC_EN,
  })
}

/** @param {{ id?: string, label?: string, ratio?: string, duration?: number, resolution?: string, audio?: boolean }} spec */
export function buildOpenclawVideoPromptForModel(spec, opts = {}) {
  return buildNaturalLanguageVideoPrompt({
    modelId: spec?.id || opts.modelId,
    modelLabel: spec?.label,
    ratio: spec?.ratio ?? opts.ratio ?? '16:9',
    duration: spec?.duration ?? opts.duration ?? 8,
    resolution: spec?.resolution ?? opts.resolution,
    audio: spec?.audio ?? opts.audio,
    description: opts.description ?? OPENCLAW_VIDEO_EXAMPLE_DESC,
  })
}

export function mergeMediaSpecsWithCatalogRows(specs, catalogRows, category) {
  const enabled = new Set(
    catalogRows
      .filter((r) => String(r.model_category || '').toLowerCase() === category)
      .map((r) => String(r.model_id || '').trim())
      .filter(Boolean),
  )
  const specById = new Map(specs.map((s) => [s.id, s]))
  const out = []
  for (const spec of specs) {
    if (enabled.size && !enabled.has(spec.id)) continue
    const row = catalogRows.find((r) => r.model_id === spec.id)
    out.push({
      ...spec,
      name: row?.name || spec.label,
      openclaw_model_ref: toOpenClawMediaPrimary(spec.id),
    })
  }
  for (const row of catalogRows) {
    if (String(row.model_category || '').toLowerCase() !== category) continue
    const id = String(row.model_id || '').trim()
    if (!id || specById.has(id)) continue
    out.push({
      id,
      label: row.name || id.split('/').pop(),
      note: '站内可用',
      ratio: category === 'image' ? '9:16' : '16:9',
      duration: category === 'video' ? 8 : undefined,
      resolution: '',
      name: row.name || id,
      openclaw_model_ref: toOpenClawMediaPrimary(id),
    })
  }
  return out
}
