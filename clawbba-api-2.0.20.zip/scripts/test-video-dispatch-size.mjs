#!/usr/bin/env node
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { execSync } from 'node:child_process'
import {
  MEDIA_DISPATCH_VIDEO_MARKER,
  upgradeVideoDispatchMissingSizeFilename,
} from './clawbba-media-dispatch-patch.mjs'

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'vid-size-'))
execSync(`tar -xzf ${JSON.stringify(path.join('/var/www/crypto-payment-demo/packages/clawbba-api', 'openclaw-2026.5.28.tgz'))} -C ${JSON.stringify(tmp)}`, {
  stdio: 'pipe',
})
const dist = path.join(tmp, 'package/dist')
process.env.OPENCLAW_DIST = dist
execSync(`node ${JSON.stringify(path.join('/var/www/crypto-payment-demo/packages/clawbba-api/scripts/patch-openclaw-media-delivery.mjs'))}`, {
  stdio: 'pipe',
})
const toolsPath = path.join(dist, fs.readdirSync(dist).find((f) => f.startsWith('openclaw-tools-')))
let src = fs.readFileSync(toolsPath, 'utf8')
assert.ok(src.includes(MEDIA_DISPATCH_VIDEO_MARKER))

// simulate broken 2.0.13 patch (size/filename lines removed)
src = src.replace(/\t\t\tconst filename = readStringParam\(args, "filename"\);\n\t\t\tconst size = readStringParam\(args, "size"\);\n/, '')
assert.ok(!/\bconst size = readStringParam\(args, "size"\)/.test(src.slice(src.indexOf(MEDIA_DISPATCH_VIDEO_MARKER), src.indexOf('buildMediaGenerationRequestKey', src.indexOf(MEDIA_DISPATCH_VIDEO_MARKER)))))

const fixed = upgradeVideoDispatchMissingSizeFilename(src)
assert.ok(/\bconst size = readStringParam\(args, "size"\)/.test(fixed))
fs.writeFileSync(toolsPath, fixed)
execSync(`node --check ${JSON.stringify(path.basename(toolsPath))}`, { cwd: dist, stdio: 'pipe' })

console.log('test-video-dispatch-size: ok')
