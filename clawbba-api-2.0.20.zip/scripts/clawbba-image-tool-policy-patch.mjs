/**
 * ClawBBA：禁止 OpenClaw `image` 工具自动用 Gemini 等 vision 模型「描述参考图」。
 * 图生图只走 image_generate + 用户话术中的 openrouter/<生图模型>；对话模型（如 deepseek-chat）不被替换。
 */
import fs from 'fs'
import path from 'path'
import { findDistJsFile } from './openclaw-dist-paths.mjs'

export const IMAGE_TOOL_POLICY_MARKER = '/* clawbba-image-tool-policy-v1 */'

const RUN_IMAGE_PROMPT_NEEDLE = `async function runImagePrompt(params) {
	const effectiveCfg = applyImageModelConfigDefaults(params.cfg, params.imageModelConfig);`

const RUN_IMAGE_PROMPT_REPLACEMENT = `async function runImagePrompt(params) {
	${IMAGE_TOOL_POLICY_MARKER}
	const __clawbbaChat = resolveDefaultModelRef(params.cfg);
	if (__clawbbaChat?.provider === "clawbba") {
		return {
			text: "[ClawBBA] 已收到图片附件。图生图请发送完整 ClawBBA 生图话术并调用 image_generate（参考图用 inbound 路径）；不要单独用 vision 模型描述图片，计费仅按话术中的生图/生视频模型。",
			provider: __clawbbaChat.provider,
			model: __clawbbaChat.model,
			attempts: []
		};
	}
	const effectiveCfg = applyImageModelConfigDefaults(params.cfg, params.imageModelConfig);`

const RESOLVE_IMAGE_MODEL_NEEDLE = `function resolveImageModelConfigForTool(params) {
	const explicit = coerceImageModelConfig(params.cfg);
	if (hasToolModelConfig$1(explicit)) return resolveConfiguredImageModelRefs({
		cfg: params.cfg,
		imageModelConfig: explicit
	});
	const primary = resolveDefaultModelRef(params.cfg);`

const RESOLVE_IMAGE_MODEL_REPLACEMENT = `function resolveImageModelConfigForTool(params) {
	${IMAGE_TOOL_POLICY_MARKER}
	const explicit = coerceImageModelConfig(params.cfg);
	const __clawbbaChat = resolveDefaultModelRef(params.cfg);
	if (__clawbbaChat?.provider === "clawbba") {
		const __chatPrimary = \`\${__clawbbaChat.provider}/\${__clawbbaChat.model}\`;
		const __imgPrimary = hasToolModelConfig$1(explicit)
			? String(explicit?.primary ?? explicit?.model ?? "").trim()
			: String(params.cfg?.agents?.defaults?.imageModel?.primary ?? "").trim();
		const __use = __imgPrimary.startsWith("clawbba/") && __imgPrimary === __chatPrimary ? __imgPrimary : __chatPrimary;
		return resolveConfiguredImageModelRefs({
			cfg: params.cfg,
			imageModelConfig: { primary: __use }
		});
	}
	if (hasToolModelConfig$1(explicit)) return resolveConfiguredImageModelRefs({
		cfg: params.cfg,
		imageModelConfig: explicit
	});
	const primary = resolveDefaultModelRef(params.cfg);`

/** @param {string} dist */
export function patchImageToolClawbbaPolicyDist(dist) {
  const file = findDistJsFile(dist, 'openclaw-tools-', 'createImageTool')
  if (!file) return 'missing-file'
  const filePath = path.join(dist, file)
  let src = fs.readFileSync(filePath, 'utf8')
  let changed = false
  if (!src.includes(IMAGE_TOOL_POLICY_MARKER)) {
    if (src.includes(RUN_IMAGE_PROMPT_NEEDLE)) {
      src = src.replace(RUN_IMAGE_PROMPT_NEEDLE, RUN_IMAGE_PROMPT_REPLACEMENT)
      changed = true
    }
    if (src.includes(RESOLVE_IMAGE_MODEL_NEEDLE)) {
      src = src.replace(RESOLVE_IMAGE_MODEL_NEEDLE, RESOLVE_IMAGE_MODEL_REPLACEMENT)
      changed = true
    }
  }
  if (!changed) return src.includes(IMAGE_TOOL_POLICY_MARKER) ? 'skip' : 'pattern-missing'
  fs.writeFileSync(filePath, src)
  return 'patched'
}
