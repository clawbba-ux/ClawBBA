#!/usr/bin/env node
import assert from 'node:assert/strict'
import fs from 'fs'
import os from 'os'
import path from 'path'
import {
  EXTERNAL_WAKE_DELIVERY_MARKER,
  EXTERNAL_WAKE_ANNOUNCE_CONTINUE_MARKER,
  patchWebChatLiveWakeInToolsFile,
  upgradeWakeExternalDelivery,
} from './clawbba-webchat-live-wake-patch.mjs'

const minimalWake = `async function wakeMediaGenerationTaskCompletion(params) {
\tif (!params.handle) return true;
\tconst announceId = \`\${params.toolName}:\${params.handle.taskId}:\${params.status}\`;
\tconst mediaUrls = Array.from(new Set([...params.mediaUrls ?? [], ...mediaUrlsFromGeneratedAttachments(params.attachments)]));
\tconst internalEvents = [];
\tconst triggerMessage = "done";
\tconst delivery = await deliverSubagentAnnouncement({
\t\trequesterSessionKey: params.handle.requesterSessionKey,
\t});
\treturn delivery.delivered;
}
`

const upgraded = upgradeWakeExternalDelivery(minimalWake)
assert.ok(upgraded.includes(EXTERNAL_WAKE_DELIVERY_MARKER))
assert.ok(upgraded.includes(EXTERNAL_WAKE_ANNOUNCE_CONTINUE_MARKER))
assert.ok(upgraded.includes('clawbbaDispatchRecoverMediaDelivery'))
assert.ok(upgraded.includes('requesterOrigin: params.handle?.requesterOrigin'))
assert.ok(upgraded.includes('clawbbaWakeDeliveredExternal'))
assert.ok(upgraded.includes('__clawbbaExternalMediaAlreadyDelivered'))
assert.ok(!upgraded.includes('if (clawbbaWakeDeliveredExternal) return true'))

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'clawbba-wake-'))
const toolsPath = path.join(tmp, 'openclaw-tools-test.js')
fs.writeFileSync(toolsPath, `${minimalWake}
export async function clawbbaInjectWebChatGeneratedMediaLive() {}
`)
const announcePath = path.join(tmp, 'subagent-announce-delivery-test.js')
fs.writeFileSync(
  announcePath,
  'export async function clawbbaInjectWebChatGeneratedMediaLive() {}\nexport async function clawbbaDispatchRecoverMediaDelivery() {}\n',
)

const patchedSrc = fs.readFileSync(toolsPath, 'utf8')
const withHelpers = `${patchedSrc}
function clawbbaDispatchRecoverMediaDelivery() {}
`
fs.writeFileSync(toolsPath, withHelpers)

const result = patchWebChatLiveWakeInToolsFile(toolsPath, 'subagent-announce-delivery-test.js')
assert.ok(result === 'patched-wake' || result === 'upgraded' || result === 'upgraded-external-wake')
const out = fs.readFileSync(toolsPath, 'utf8')
assert.ok(out.includes('requesterChatRunId'))
assert.ok(out.includes('__clawbbaCh !== "webchat"'))

console.log('test-external-wake-delivery: ok')
