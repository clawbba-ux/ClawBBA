#!/usr/bin/env node
import assert from 'node:assert/strict'
import {
  MEDIA_PARAMS_V2_MARKER,
  buildClawbbaMediaToolValidateRuntimeBlock,
  injectMediaParamsRuntimeBlock,
  toolsSrcHasMediaParamsV2,
} from './clawbba-media-params.mjs'
import { buildImageGenerateDispatchBlock } from './clawbba-media-dispatch-patch.mjs'
import { MEDIA_DISPATCH_V2_MARKER } from './clawbba-media-tool-validate.mjs'

const block = buildClawbbaMediaToolValidateRuntimeBlock()
assert.ok(block.includes(MEDIA_PARAMS_V2_MARKER))
assert.ok(block.includes('clawbbaValidateImageGenerateParams'))
assert.ok(block.includes('clawbbaValidateVideoGenerateParams'))
assert.ok(!block.includes('clawbbaResolveMediaTemplateText'))
assert.ok(!block.includes('确认生成'))

const dispatch = buildImageGenerateDispatchBlock()
assert.ok(dispatch.includes(MEDIA_DISPATCH_V2_MARKER))
assert.ok(dispatch.includes('clawbbaValidateImageGenerateParams'))
assert.ok(!dispatch.includes('clawbbaPreflightImageGenerateAllowed'))

const injected = injectMediaParamsRuntimeBlock(`function createImageGenerateTool() {\nreturn id;\n}`)
assert.equal(toolsSrcHasMediaParamsV2(injected), true)

console.log('test-media-params: ok')
