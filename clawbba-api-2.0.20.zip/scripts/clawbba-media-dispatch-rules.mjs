/**
 * ClawBBA v2 媒体规则 — OpenClaw 工具参数 + 能力表
 */
import { CLAWBBA_MEDIA_MODEL_CANON } from './clawbba-media-model-ref.mjs'
import { OPENCLAW_IMAGE_ASPECT_RATIOS, OPENCLAW_IMAGE_RESOLUTIONS } from './clawbba-media-params-enums.mjs'

export const CLAWBBA_MEDIA_DISPATCH_RULES = [
  CLAWBBA_MEDIA_MODEL_CANON,
  '',
  '=== OpenClaw media tools (v2) ===',
  'Capabilities: references/media-capabilities.json',
  `Image aspectRatio: ${OPENCLAW_IMAGE_ASPECT_RATIOS.join(', ')}`,
  `Image resolution: ${OPENCLAW_IMAGE_RESOLUTIONS.join(', ')}`,
  'Video imageRoles: first_frame, last_frame, reference_image',
  'Runtime validates prompt/model/aspectRatio/resolution; merges session reference images. No session template parsing.',
  'Help user fill params in natural language; call tool when complete (no 确认生成 gate).',
].join('\n')
