#!/usr/bin/env bash
# ClawBBA clawbba-api 一键安装 + 配置（OpenClaw 机器上运行）
# 公网: curl -fsSL https://www.clawbba.com/downloads/install-clawbba-api.sh | bash
set -euo pipefail

VERSION="${CLAWBBA_SKILL_VERSION:-2.0.16}"
INSTALL_BASE="${CLAWBBA_INSTALL_BASE:-https://www.clawbba.com/downloads}"
ZIP_NAME="clawbba-api-${VERSION}.zip"
ZIP_URL="${CLAWBBA_SKILL_ZIP_URL:-${INSTALL_BASE}/${ZIP_NAME}}"
SKILL_DIR="${OPENCLAW_SKILL_DIR:-${HOME}/.openclaw/skills/clawbba-api}"
KEY="${CLAWBBA_API_KEY:-}"

echo "══════════════════════════════════════════"
echo " ClawBBA clawbba-api ${VERSION} 一键安装"
echo "══════════════════════════════════════════"

if [[ -z "$KEY" ]]; then
  echo "" >&2
  echo "请先创建 Platform API Key：https://www.clawbba.com/agent/api-keys" >&2
  echo "" >&2
  echo "然后执行：" >&2
  echo "  export CLAWBBA_API_KEY='cbb_sk_live_你的完整密钥'" >&2
  echo "  curl -fsSL ${INSTALL_BASE}/install-clawbba-api.sh | bash" >&2
  exit 1
fi

if [[ "$KEY" != cbb_sk_live_* ]]; then
  echo "错误: CLAWBBA_API_KEY 须以 cbb_sk_live_ 开头" >&2
  exit 1
fi

for bin in node curl unzip openclaw; do
  if ! command -v "$bin" >/dev/null 2>&1; then
    echo "错误: 未找到 $bin，请先安装 OpenClaw CLI / Node.js / curl / unzip" >&2
    exit 1
  fi
done

OPENCLAW_COMPAT_MIN_VERSION="${OPENCLAW_COMPAT_MIN_VERSION:-2026.5.12}"

openclaw_version_meets_min() {
  local current="${1:?}"
  local min="${2:-$OPENCLAW_COMPAT_MIN_VERSION}"
  node -e "
const current = process.argv[1];
const min = process.argv[2];
function parse(v) {
  const m = String(v || '').trim().match(/^(\\d+)\\.(\\d+)\\.(\\d+)/);
  return m ? [Number(m[1]), Number(m[2]), Number(m[3])] : null;
}
function cmp(a, b) {
  for (let i = 0; i < 3; i++) if (a[i] !== b[i]) return a[i] - b[i];
  return 0;
}
const pa = parse(current);
const pb = parse(min);
if (!pa || !pb) process.exit(3);
process.exit(cmp(pa, pb) >= 0 ? 0 : 2);
" "$current" "$min"
}

openclaw_print_unsupported_upgrade_hint() {
  local version="${1:-unknown}"
  cat >&2 <<EOF

══════════════════════════════════════════
 OpenClaw 版本过低，暂不支持安装 ClawBBA
══════════════════════════════════════════

  当前 OpenClaw 版本：${version}
  ClawBBA 最低要求：  OpenClaw ${OPENCLAW_COMPAT_MIN_VERSION} 或更高
  推荐做法：          升级到 OpenClaw 最新稳定版

ClawBBA 依赖 OpenClaw 内置 image_generate / video_generate 与 WebChat 交付能力。
版本过旧时无法正确写入 runtime patch，继续安装会导致生图/生视频或模型加载异常。

请按顺序执行：

  1. 升级 OpenClaw 到最新版
     npm i -g openclaw@latest
     openclaw --version

  2. 重新安装 ClawBBA
     export CLAWBBA_API_KEY='cbb_sk_live_你的完整密钥'
     curl -fsSL ${INSTALL_BASE}/install-clawbba-api.sh | bash

  3. 重启 Gateway
     openclaw gateway restart

OpenClaw 文档：https://docs.openclaw.ai

EOF
}

# ── Phase 1: 轻量版本探测（解压 skill 前）────────────────────────────
OPENCLAW_VERSION_PREVIEW="$(openclaw --version 2>/dev/null | sed -n 's/.*OpenClaw \([0-9]\{4\}\.[0-9]\+\.[0-9]\+\).*/\1/p' | head -n1 || true)"
if [[ -z "$OPENCLAW_VERSION_PREVIEW" ]]; then
  echo "错误: 无法解析 OpenClaw 版本，请执行 openclaw --version 确认 CLI 可用" >&2
  exit 1
fi
echo "→ OpenClaw 预检: ${OPENCLAW_VERSION_PREVIEW}（完整 compat profile 解压后确认）"
if ! openclaw_version_meets_min "$OPENCLAW_VERSION_PREVIEW"; then
  openclaw_print_unsupported_upgrade_hint "$OPENCLAW_VERSION_PREVIEW"
  exit 1
fi

STAGE="$(mktemp -d)"
cleanup() { rm -rf "$STAGE"; }
trap cleanup EXIT

echo "→ 下载 ${ZIP_URL} …"
curl -fsSL "$ZIP_URL" -o "${STAGE}/${ZIP_NAME}"

if [[ ! -s "${STAGE}/${ZIP_NAME}" ]]; then
  echo "错误: 下载为空文件: ${ZIP_URL}" >&2
  exit 1
fi
if ! unzip -tq "${STAGE}/${ZIP_NAME}" >/dev/null 2>&1; then
  echo "错误: ${ZIP_NAME} 不是有效的 zip（常见原因：官网尚未发布该版本，下载到的是 HTML 错误页）" >&2
  echo "  URL: ${ZIP_URL}" >&2
  echo "  请确认 clawbba.com 已部署 public/downloads/clawbba-api-${VERSION}.zip，或稍后重试。" >&2
  echo "  运维可在仓库执行: packages/clawbba-api/scripts/pack-release-zip.sh" >&2
  exit 1
fi

echo "→ 解压 …"
unzip -qo "${STAGE}/${ZIP_NAME}" -d "$STAGE/extract"
if [[ ! -f "${STAGE}/extract/SKILL.md" ]]; then
  echo "错误: zip 结构无效（根目录须含 SKILL.md）" >&2
  exit 1
fi

# ── Phase 2: 严谨 compat profile（决定 config / patch 分支）──────────
echo "→ OpenClaw 版本检测与 compat profile …"
# shellcheck disable=SC1091
source "${STAGE}/extract/scripts/openclaw-detect-version.sh"
if ! openclaw_detect_version_from_skill "${STAGE}/extract" 1; then
  exit 1
fi
echo "  OpenClaw 版本:     ${OPENCLAW_VERSION}"
echo "  安装 profile:      ${OPENCLAW_COMPAT_PROFILE_ID}"
echo "  profile 说明:      ${OPENCLAW_COMPAT_PROFILE_LABEL}"
echo "  patch.toolsBundle: ${OPENCLAW_COMPAT_TOOLS_BUNDLE}"
if [[ "${OPENCLAW_COMPAT_SUPPORTS_SYSTEM_PROMPT_OVERRIDE}" == "1" ]]; then
  echo "  配置策略:          写入 agents.defaults.systemPromptOverride"
else
  echo "  配置策略:          不写 systemPromptOverride（skill always:true）"
fi
if [[ "${OPENCLAW_COMPAT_NEWER_THAN_TESTED:-0}" == "1" ]]; then
  echo "  ⚠ OpenClaw 高于 clawbba-api 已专项测试版本，将沿用 profile ${OPENCLAW_COMPAT_PROFILE_ID} patch 分支"
fi
node "${STAGE}/extract/scripts/detect-openclaw-version.mjs"

echo "→ 安装到 ${SKILL_DIR} …"
mkdir -p "$(dirname "$SKILL_DIR")"
rm -rf "$SKILL_DIR"
mkdir -p "$SKILL_DIR"
cp -a "${STAGE}/extract/." "$SKILL_DIR/"
if [[ ! -f "${SKILL_DIR}/references/media-capabilities.json" ]]; then
  echo "错误: zip 缺少 references/media-capabilities.json（请使用 clawbba-api 2.0.0+）" >&2
  exit 1
fi

export CLAWBBA_API_BASE="${CLAWBBA_API_BASE:-https://www.clawbba.com/api/v1}"
export CLAWBBA_API_KEY="$KEY"
export OPENROUTER_API_KEY="${OPENROUTER_API_KEY:-$CLAWBBA_API_KEY}"
export OPENCLAW_VERSION
export OPENCLAW_COMPAT_PROFILE_ID
export OPENCLAW_COMPAT_PROFILE_TIER
export OPENCLAW_COMPAT_TOOLS_BUNDLE
export OPENCLAW_COMPAT_SUPPORTS_SYSTEM_PROMPT_OVERRIDE
export OPENCLAW_COMPAT_VIDEO_EXECUTE_ARGS
export OPENCLAW_COMPAT_NEWER_THAN_TESTED

echo "→ 校验 Key …"
"$SKILL_DIR/scripts/verify-key.sh"

echo "→ 写入 OpenClaw 配置（profile=${OPENCLAW_COMPAT_PROFILE_ID}）…"
"$SKILL_DIR/scripts/one-shot-setup.sh"

echo "→ 验证 ClawBBA runtime patch（profile=${OPENCLAW_COMPAT_PROFILE_ID}）…"
bash "$SKILL_DIR/scripts/ensure-openclaw-patches.sh" --install

echo "→ 验证 provider 配置 …"
node "$SKILL_DIR/scripts/verify-openclaw-runtime.mjs" || true

if [[ "${SKIP_GATEWAY_RESTART:-}" != "1" ]]; then
  echo "→ 重启 Gateway …"
  if ! openclaw gateway restart; then
    echo "[clawbba-api] ✗ Gateway 重启失败；请执行 openclaw config validate" >&2
    exit 1
  fi
fi

echo ""
echo "✓ 安装完成（OpenClaw ${OPENCLAW_VERSION} · profile ${OPENCLAW_COMPAT_PROFILE_ID}）"
echo "  skill: ${SKILL_DIR}"
echo "  模型:  openclaw models list | grep clawbba"
echo "  验证:  新开对话后执行 /model status（应显示 clawbba/…）"
echo "  诊断:  node ${SKILL_DIR}/scripts/detect-openclaw-version.mjs"
echo "  诊断:  node ${SKILL_DIR}/scripts/verify-openclaw-runtime.mjs"
echo ""
echo "若 Gateway 由 systemd 管理，可写入 CLAWBBA_API_KEY 后 restart，例如："
echo "  sudo mkdir -p /etc/systemd/system/openclaw-gateway.service.d"
echo "  sudo tee /etc/systemd/system/openclaw-gateway.service.d/clawbba.conf <<EOF"
echo "[Service]"
echo "Environment=CLAWBBA_API_KEY=${CLAWBBA_API_KEY}"
echo "EOF"
echo "  sudo systemctl daemon-reload && openclaw gateway restart"
