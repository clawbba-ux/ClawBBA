#!/usr/bin/env node
/**
 * OpenClaw tools 完整性 + 安全 strip/in-place upgrade（防止误删 buildActiveMusicGeneration…）
 */
import { buildClawbbaMediaToolValidateRuntimeBlock } from './clawbba-media-tool-validate.mjs'

export const MODULE_LEVEL_MEDIA_RUNTIME_MARKER = '/* clawbba-module-media-runtime-v1 */'
export const CLAWBBA_VALIDATE_VIDEO_FN = 'async function clawbbaValidateVideoGenerateParams'

/** strip 允许的最大字节（ClawBBA module block 通常 < 20KB） */
export const MAX_SAFE_MODULE_RUNTIME_STRIP_BYTES = 32_000

const OPENCLAW_STRIP_GUARD_RE =
  /function buildActive(?:Music|Image|Video)GenerationTaskPromptContextForSession|function createOpenClawTools\(/

/** export 声明存在但函数体被误删时，继续 patch 会雪上加霜 */
const INTEGRITY_SYMBOLS = [
  'buildActiveMusicGenerationTaskPromptContextForSession',
  'buildActiveImageGenerationTaskPromptContextForSession',
  'buildActiveVideoGenerationTaskPromptContextForSession',
  'createOpenClawTools',
]

/** @param {string} src */
export function openclawToolsSrcIntegrityOk(src) {
  if (!src || typeof src !== 'string') return false
  for (const sym of INTEGRITY_SYMBOLS) {
    if (!src.includes(`function ${sym}(`)) return false
  }
  return true
}

/** @param {string} src */
export function moduleRuntimeChunkIsSafeToStrip(src, markerIdx, endIdx) {
  if (markerIdx < 0 || endIdx <= markerIdx) return false
  const chunk = src.slice(markerIdx, endIdx)
  if (chunk.length > MAX_SAFE_MODULE_RUNTIME_STRIP_BYTES) return false
  if (OPENCLAW_STRIP_GUARD_RE.test(chunk)) return false
  if (
    !chunk.includes('clawbbaValidateVideoGenerateParams') &&
    !chunk.includes('clawbbaValidateImageGenerateParams')
  ) {
    return false
  }
  return true
}

/** 移除远离 createImageGenerateTool 的误放 module marker 块 */
export function removeMisplacedModuleRuntimeMarkers(src) {
  const imgToolIdx = src.indexOf('function createImageGenerateTool(')
  if (imgToolIdx < 0) return src
  let out = src
  let from = 0
  while (from < out.length) {
    const markerIdx = out.indexOf(MODULE_LEVEL_MEDIA_RUNTIME_MARKER, from)
    if (markerIdx < 0) break
    if (moduleRuntimeChunkIsSafeToStrip(out, markerIdx, imgToolIdx)) {
      from = markerIdx + MODULE_LEVEL_MEDIA_RUNTIME_MARKER.length
      continue
    }
    const nextFn = out.indexOf('\nfunction ', markerIdx + MODULE_LEVEL_MEDIA_RUNTIME_MARKER.length)
    const nextAsync = out.indexOf('\nasync function ', markerIdx + MODULE_LEVEL_MEDIA_RUNTIME_MARKER.length)
    let cutEnd = -1
    for (const c of [nextFn, nextAsync, imgToolIdx]) {
      if (c > markerIdx && (cutEnd < 0 || c < cutEnd)) cutEnd = c
    }
    if (cutEnd < 0) break
    out = `${out.slice(0, markerIdx)}${out.slice(cutEnd + 1)}`
    from = markerIdx
  }
  return out
}

/** @param {string} src */
export function stripModuleLevelMediaRuntimeBlockSafe(src) {
  const markerIdx = src.indexOf(MODULE_LEVEL_MEDIA_RUNTIME_MARKER)
  if (markerIdx < 0) return src
  const insertAt = src.indexOf('function createImageGenerateTool(')
  if (insertAt < 0 || insertAt <= markerIdx) return src
  if (!moduleRuntimeChunkIsSafeToStrip(src, markerIdx, insertAt)) return src
  return `${src.slice(0, markerIdx)}${src.slice(insertAt)}`
}

function extractVideoValidateUpgradeSlice() {
  const block = buildClawbbaMediaToolValidateRuntimeBlock()
  const start = block.indexOf('function clawbbaResolveVideoDurationSeconds')
  if (start < 0) return ''
  return `${block.slice(start).trimEnd()}\n`
}

/** 已有 module-scoped validate，仅缺 duration resolve / 旧 validate 体 */
export function upgradeVideoValidateRuntimeInPlace(src) {
  const slice = extractVideoValidateUpgradeSlice()
  if (!slice) return src
  let out = src
  if (!out.includes('function clawbbaResolveVideoDurationSeconds')) {
    const vIdx = out.indexOf(CLAWBBA_VALIDATE_VIDEO_FN)
    if (vIdx < 0) return src
    const resolveOnly = slice.slice(0, slice.indexOf(CLAWBBA_VALIDATE_VIDEO_FN))
    out = `${out.slice(0, vIdx)}${resolveOnly}${out.slice(vIdx)}`
  }
  const validateRe = /async function clawbbaValidateVideoGenerateParams\(ctx\) \{[\s\S]*?\n\}/
  const validateSlice = slice.slice(slice.indexOf(CLAWBBA_VALIDATE_VIDEO_FN)).trimEnd()
  if (validateRe.test(out)) {
    out = out.replace(validateRe, validateSlice)
  }
  return out
}

export function videoValidateNeedsInPlaceUpgrade(src) {
  if (!src.includes(CLAWBBA_VALIDATE_VIDEO_FN)) return false
  const imgToolIdx = src.indexOf('function createImageGenerateTool(')
  const videoFnIdx = src.indexOf(CLAWBBA_VALIDATE_VIDEO_FN)
  if (imgToolIdx < 0 || videoFnIdx < 0 || videoFnIdx >= imgToolIdx) return false
  return !src.includes('function clawbbaResolveVideoDurationSeconds')
}
