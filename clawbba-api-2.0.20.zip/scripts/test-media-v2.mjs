#!/usr/bin/env node
import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import {
  buildMediaCapabilitiesFromStaticSpecs,
  MEDIA_WORKFLOWS,
} from './clawbba-media-capabilities-core.mjs'
import {
  buildClawbbaMediaToolValidateRuntimeBlock,
  toolsSrcHasMediaParamsV2,
  injectMediaToolValidateRuntime,
} from './clawbba-media-tool-validate.mjs'
import { upgradeMediaDispatchToV2 } from './clawbba-media-dispatch-patch.mjs'

const cap = buildMediaCapabilitiesFromStaticSpecs()
assert.equal(cap.version, '2.1')
assert.ok(cap.workflows.text_to_image)
assert.ok(cap.models[cap.defaults.image])

const seedance = cap.models['bytedance/seedance-2.0']
assert.ok(seedance?.generation_params, 'seedance generation_params')
assert.ok(seedance.generation_params.parameters.durationSeconds.allowed.includes(5))
assert.equal(seedance.generation_params.parameters.aspectRatio.default, '9:16')
assert.ok(seedance.generation_params.workflows.image_to_video_reference)

const veo = cap.models['google/veo-3.1-fast']
assert.ok(veo?.generation_params?.parameters?.audio, 'veo audio param')
assert.ok(veo.aspect_ratios?.includes('16:9'))

const block = buildClawbbaMediaToolValidateRuntimeBlock()
assert.ok(block.includes('clawbbaValidateImageGenerateParams'))
assert.ok(!block.includes('clawbbaResolveMediaTemplateText'))

const injected = injectMediaToolValidateRuntime('function createImageGenerateTool() {}')
assert.equal(toolsSrcHasMediaParamsV2(injected), true)

const dist = '/var/www/crypto-payment-demo/server/package/dist'
const tools = fs.readdirSync(dist).find((n) => n.startsWith('openclaw-tools-') && n.endsWith('.js'))
if (tools) {
  const src = fs.readFileSync(path.join(dist, tools), 'utf8')
  const upgraded = upgradeMediaDispatchToV2(src)
  assert.ok(upgraded.includes('clawbbaValidateImageGenerateParams'))
}

assert.ok(Object.keys(MEDIA_WORKFLOWS).includes('image_to_video_first_frame'))
console.log('test-media-v2: ok')
