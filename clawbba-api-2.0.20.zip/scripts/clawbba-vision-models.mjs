/**
 * ClawBBA × OpenClaw — imageModel 与对话模型对齐（不自作主张切到 Gemini）。
 * 生图/生视频仅 image_generate / video_generate + 话术中的 openrouter/<id>。
 * 图生图参考图走 inbound 路径合并，不另调「看图」模型描述图片。
 */

/** 仅用于替换已废弃的 vision id（如 gemini-2.0-flash-001） */
export const PATCH_VISION_TEXT_MODEL_PREFER = [
  'google/gemini-2.5-flash-preview',
  'google/gemini-2.5-flash',
  'openai/gpt-4o',
  'openai/gpt-4o-mini',
  'anthropic/claude-sonnet-4',
  'anthropic/claude-3.5-sonnet',
]

/** 无 text_options 时的保守启发（与 server buildTextOptionsPayload 对齐） */
const VISION_TEXT_ID_RE =
  /gemini-(2\.[05]|3\.|3-)|gpt-4o|gpt-4\.1|gpt-5|claude-3\.5|claude-sonnet-4|claude-opus-4|qwen.*vl|llava|pixtral|glm-4v/i

/** 生图专用 id — 不可作 imageModel / 聊天 vision */
const IMAGE_GEN_ONLY_ID_RE =
  /flux\.|seedream|dall-e|gpt-.*image|gemini-.*-image|imagen|grok-imagine-image|stable-diffusion/i

/** 上游 404 / 已下架 — 禁止作 imageModel 与 vision 自动选择 */
export const DEPRECATED_VISION_MODEL_RE =
  /gemini-2\.0-flash-001|gemini-2\.0-flash-lite-001|gemini-2\.0-flash(?!-preview)/i

export function isDeprecatedVisionModelId(modelId) {
  const bare = String(modelId || '')
    .trim()
    .replace(/^clawbba\//i, '')
  if (!bare) return false
  return DEPRECATED_VISION_MODEL_RE.test(bare)
}

export function normCatalogCategory(m) {
  return String(m?.category || '').toLowerCase()
}

export function rowSupportsVisionInput(m) {
  if (!m || normCatalogCategory(m) !== 'text') return false
  const id = String(m.id || '').trim()
  if (!id || IMAGE_GEN_ONLY_ID_RE.test(id)) return false
  if (isDeprecatedVisionModelId(id)) return false
  const to = m.text_options
  if (to && typeof to === 'object') {
    if (to.supports_image_input === true) return true
    if (to.supports_image_input === false) return false
    const mods = to.input_modalities
    if (Array.isArray(mods) && mods.some((x) => String(x).toLowerCase().includes('image'))) {
      return true
    }
  }
  return VISION_TEXT_ID_RE.test(id)
}

export function providerModelAcceptsImageInput(entry) {
  return Array.isArray(entry?.input) && entry.input.some((x) => String(x).toLowerCase() === 'image')
}

export function applyVisionInputToProviderEntry(entry, catalogRow) {
  if (!entry || !catalogRow) return entry
  if (normCatalogCategory(catalogRow) !== 'text') return entry
  if (!rowSupportsVisionInput(catalogRow)) return entry
  if (providerModelAcceptsImageInput(entry)) return entry
  entry.input = ['text', 'image']
  return entry
}

export function pickVisionTextModelId(rows) {
  const textRows = (rows || []).filter((m) => normCatalogCategory(m) === 'text' && rowSupportsVisionInput(m))
  const ids = new Set(textRows.map((m) => String(m.id || '').trim()).filter(Boolean))
  for (const p of PATCH_VISION_TEXT_MODEL_PREFER) {
    if (ids.has(p)) return p
  }
  return textRows[0]?.id ? String(textRows[0].id).trim() : null
}

/** imageModel 须 clawbba/<text-vision>；禁止 openrouter 生图模型 */
export function isValidClawbbaImageModelRef(ref) {
  const s = String(ref || '').trim()
  if (!s.startsWith('clawbba/')) return false
  const id = s.slice('clawbba/'.length)
  return Boolean(id) && !IMAGE_GEN_ONLY_ID_RE.test(id)
}

/**
 * imageModel 与 agents.defaults.model 使用同一文本模型，避免 DeepSeek 对话却扣 Gemini 看图。
 * @returns {string|null} clawbba/<text-id>
 */
export function resolveImageModelPrimary(rows, defaultTextId) {
  const textId = String(defaultTextId || '').trim()
  if (!textId) return null
  if (IMAGE_GEN_ONLY_ID_RE.test(textId)) return null
  if (isDeprecatedVisionModelId(textId)) {
    return null
  }
  return `clawbba/${textId}`
}

/**
 * OpenClaw image 工具 / 代理：废弃 vision id 仅 remap 到用户对话模型，禁止默认 Gemini。
 * @param {string} modelId
 * @param {Array<{id?: string}>} rows
 * @param {string} [preferredTextId] agents.defaults.model 的 platform id
 */
/** verify-openclaw-runtime 在线 smoke：优先用户对话模型，再 catalog / 偏好列表 */
export function buildSmokeChatModelCandidates(configuredPrimary, catalogRows) {
  const seen = new Set()
  /** @param {string} [id] */
  const add = (id) => {
    const bare = String(id || '')
      .trim()
      .replace(/^clawbba\//i, '')
    if (!bare || isDeprecatedVisionModelId(bare) || seen.has(bare)) return
    seen.add(bare)
    out.push(bare)
  }
  const out = []
  add(configuredPrimary)
  add(pickVisionTextModelId(catalogRows))
  for (const p of PATCH_VISION_TEXT_MODEL_PREFER) add(p)
  for (const m of catalogRows || []) {
    if (normCatalogCategory(m) === 'text') add(m.id)
  }
  return out
}

export function remapDeprecatedVisionModelId(modelId, rows, preferredTextId) {
  const raw = String(modelId || '').trim()
  if (!isDeprecatedVisionModelId(raw)) return raw
  const pref = String(preferredTextId || '')
    .trim()
    .replace(/^clawbba\//i, '')
  if (pref && !isDeprecatedVisionModelId(pref) && !IMAGE_GEN_ONLY_ID_RE.test(pref)) {
    return raw.startsWith('clawbba/') ? `clawbba/${pref}` : pref
  }
  const replacement = pickVisionTextModelId(rows)
  if (!replacement) return raw
  return raw.startsWith('clawbba/') ? `clawbba/${replacement}` : replacement
}
