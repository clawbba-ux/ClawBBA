#!/usr/bin/env node
import assert from 'node:assert/strict'
import {
  buildStrictOpenclawImagePrompt,
  isMediaGenerationConfirmPhrase,
  mediaJobFingerprint,
} from './clawbba-media-prompt-standards.mjs'
import { aspectTemplateConflictMessage } from './clawbba-aspect-template.mjs'

assert.ok(isMediaGenerationConfirmPhrase('确认生成'))
assert.ok(!isMediaGenerationConfirmPhrase('生成图片'))
assert.ok(buildStrictOpenclawImagePrompt({ ratio: '9:16' }).includes('9:16 竖图'))
assert.ok(aspectTemplateConflictMessage('9:16 横图'))
assert.ok(mediaJobFingerprint({ tool: 'image_generate', model: 'a', prompt: 'b' }).includes('image_generate'))

console.log('test-media-prompt-standards: ok')
