#!/usr/bin/env node
import assert from 'node:assert/strict'
import {
  incompleteClawbbaMediaTemplateMessage,
  isBareClawbbaMediaTemplateOnly,
} from './clawbba-media-prompt-standards.mjs'
import { parseAspectFromTemplate } from './clawbba-aspect-template.mjs'

function extractScene(mediaText, tool) {
  let t = String(mediaText ?? '').trim()
  if (tool === 'image_generate') {
    t = t.replace(/^请使用\s*ClawBBA\s*生成图片能力[,，]?\s*/i, '')
  }
  t = t.replace(
    /^(?:模型\s+[^，,]+[,，]?\s*)?(?:为我生成\s*)?(?:(?:\d{1,2}\s*[:：]\s*\d{1,2})|(?:横图|竖图)|(?:\dK))[^：:，,]*[：:,，]?\s*/i,
    '',
  )
  return t.trim()
}

assert.equal(isBareClawbbaMediaTemplateOnly('请使用 ClawBBA 生成图片能力', 'image_generate'), true)
assert.ok(
  incompleteClawbbaMediaTemplateMessage(
    '请使用 ClawBBA 生成图片能力',
    'image_generate',
    extractScene,
    parseAspectFromTemplate,
  ),
)
assert.equal(
  incompleteClawbbaMediaTemplateMessage(
    '请使用 ClawBBA 生成图片能力，为我生成 9:16 竖图：夕阳海滩',
    'image_generate',
    extractScene,
    parseAspectFromTemplate,
  ),
  null,
)

console.log('test-incomplete-template: ok')
