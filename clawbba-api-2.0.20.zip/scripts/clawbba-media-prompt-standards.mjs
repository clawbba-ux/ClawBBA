/**
 * ClawBBA × OpenClaw 标准话术与生成前确认文案（与官网 Agent / API Keys 一致）
 */
import {
  DEFAULT_IMAGE_MODEL_ID,
  DEFAULT_IMAGE_MODEL_LABEL,
  DEFAULT_VIDEO_MODEL_ID,
  DEFAULT_VIDEO_MODEL_LABEL,
  OPENCLAW_IMAGE_EXAMPLE_DESC,
  OPENCLAW_VIDEO_EXAMPLE_DESC,
  buildNaturalLanguageImagePrompt,
  buildNaturalLanguageVideoPrompt,
} from './clawbba-openclaw-media-catalog.mjs'

export const CLAWBBA_MEDIA_CONFIRM_PHRASE = '确认生成'

export const OPENCLAW_PROMPT_STANDARDS = {
  version: 2,
  rules: [
    '使用自然语言收集 image_generate / video_generate 参数；无需固定中文话术前缀。',
    'image_generate.prompt / video_generate.prompt 必须写入用户在本轮对话里说的画面意图（产品、主体、风格、场景、相对参考图的修改），禁止用大模型自编一套与用户无关的英文套话。',
    '可把用户中文译成英文并补充光影细节，但不得删掉用户明确提到的品牌、品类、风格词；图生图时 prompt 要写清相对参考图要改什么、保留什么。',
    '参数齐全后直接调用工具（无「确认生成」门禁）。',
    '读 references/media-capabilities.json 或官网 API Keys 页能力表：工作流、模型、aspectRatio、resolution、durationSeconds、imageRoles。',
    'model 工具参数格式：openrouter/<platform-id>；对话模型仍为 clawbba/<text-id>。',
    '图生图/图生视频：上传参考图后写入 image 或 images[]；视频首帧/尾帧用 imageRoles。',
    '缺参时 ToolInputError 会说明缺哪个字段；向用户追问缺项即可。',
  ],
  defaults: {
    image: {
      platform_model_id: DEFAULT_IMAGE_MODEL_ID,
      label: DEFAULT_IMAGE_MODEL_LABEL,
    },
    video: {
      platform_model_id: DEFAULT_VIDEO_MODEL_ID,
      label: DEFAULT_VIDEO_MODEL_LABEL,
    },
  },
}

/** @param {string} text @param {'image_generate'|'video_generate'} tool */
export function isBareClawbbaMediaTemplateOnly(text, tool) {
  const t = String(text ?? '').trim()
  if (!t) return false
  if (tool === 'video_generate') {
    return /^请使用\s*ClawBBA\s*生成视频能力[,，]?\s*$/i.test(t)
  }
  return /^请使用\s*ClawBBA\s*生成图片能力[,，]?\s*$/i.test(t)
}

/**
 * @param {string} mediaText
 * @param {'image_generate'|'video_generate'} tool
 * @param {(t: string, tool: string) => string} extractSceneFn
 * @param {(t: string) => string|null} parseAspectFn
 * @returns {string|null} error message
 */
export function incompleteClawbbaMediaTemplateMessage(
  mediaText,
  tool,
  extractSceneFn,
  parseAspectFn,
) {
  const t = String(mediaText ?? '').trim()
  if (!t) return null
  const isImage = tool === 'image_generate'
  const templateRe = isImage ? /请使用\s*ClawBBA\s*生成图片/i : /请使用\s*ClawBBA\s*生成视频/i
  if (!templateRe.test(t)) return null

  const guide = isImage
    ? '请使用标准话术，例如：请使用 ClawBBA 生成图片能力，为我生成 9:16 竖图：（画面描述）'
    : '请使用标准话术，例如：请使用 ClawBBA 生成视频能力，为我生成 16:9、8 秒视频：（画面描述）'

  if (isBareClawbbaMediaTemplateOnly(t, tool)) {
    return `话术不完整：仅有开头「请使用 ClawBBA 生成${isImage ? '图片' : '视频'}能力」，缺少「为我生成」、${isImage ? '比例（如 9:16 竖图）与' : '时长与'}画面描述。${guide}`
  }
  if (!/为我生成/i.test(t)) {
    return `话术不完整：须包含「为我生成」及${isImage ? '比例' : '时长'}。${guide}`
  }
  const scene = extractSceneFn(t, tool)
  if (!scene || scene.length < 2) {
    return `话术缺少画面描述：请在冒号后写场景，例如「…竖图：（描述）」。${guide}`
  }
  if (isImage) {
    const aspect = parseAspectFn(t)
    if (!aspect && !/竖图|横图|方图|landscape|portrait/i.test(t)) {
      return `话术须写明比例，例如 9:16 竖图 或 16:9 横图。${guide}`
    }
  } else if (!/(\d+)\s*秒/i.test(t)) {
    return `视频话术须写时长，例如「8 秒视频」。${guide}`
  }
  return null
}

/** @param {string} text */
export function isMediaGenerationConfirmPhrase(text) {
  const t = String(text ?? '').trim()
  if (!t) return false
  return /^(确认生成|确认开始|开始生成|confirm|yes\s*generate)\s*$/i.test(t)
}

/**
 * @param {object} opts
 * @param {string} [opts.modelId]
 * @param {string} [opts.ratio] e.g. 9:16
 * @param {string} [opts.resolution] 1K|2K|4K
 * @param {string} [opts.description]
 * @param {boolean} [opts.referenceImage]
 */
/** @deprecated 请用 buildNaturalLanguageImagePrompt */
export function buildStrictOpenclawImagePrompt(opts = {}) {
  return buildNaturalLanguageImagePrompt(opts)
}

/** @deprecated 请用 buildNaturalLanguageVideoPrompt */
export function buildStrictOpenclawVideoPrompt(opts = {}) {
  return buildNaturalLanguageVideoPrompt(opts)
}

/**
 * @param {object|null|undefined} imageOptions from buildImageOptionsPayload (sanitized)
 */
export function formatImageModelConstraints(imageOptions) {
  if (!imageOptions || typeof imageOptions !== 'object') {
    return '比例：1:1–21:9（OpenClaw 枚举）；分辨率：1K/2K/4K'
  }
  const lines = []
  if (Array.isArray(imageOptions.aspect_ratios) && imageOptions.aspect_ratios.length) {
    lines.push(`支持比例：${imageOptions.aspect_ratios.join('、')}`)
  }
  if (Array.isArray(imageOptions.image_sizes) && imageOptions.image_sizes.length) {
    lines.push(`支持分辨率：${imageOptions.image_sizes.join('、')}`)
  }
  if (imageOptions.supports_image_input === false) {
    lines.push('不支持参考图/图生图')
  } else if (imageOptions.supports_image_input) {
    lines.push('支持参考图（图生图）')
  }
  if (imageOptions.default_aspect_ratio) {
    lines.push(`默认比例：${imageOptions.default_aspect_ratio}`)
  }
  if (imageOptions.default_image_size) {
    lines.push(`默认分辨率：${imageOptions.default_image_size}`)
  }
  return lines.length ? lines.join('；') : '见 /api/v1/models image_options'
}

/**
 * @param {object|null|undefined} videoOptions
 */
export function formatVideoModelConstraints(videoOptions) {
  if (!videoOptions || typeof videoOptions !== 'object') {
    return '比例 16:9/9:16；时长写在话术（如 8 秒）；分辨率 720p/1080p 视模型'
  }
  const lines = []
  const ar = videoOptions.supported_aspect_ratios || videoOptions.aspect_ratios
  if (Array.isArray(ar) && ar.length) lines.push(`支持比例：${ar.join('、')}`)
  const dur = videoOptions.supported_durations || videoOptions.durations
  if (Array.isArray(dur) && dur.length) lines.push(`支持时长(秒)：${dur.join('、')}`)
  const res = videoOptions.supported_resolutions || videoOptions.resolutions
  if (Array.isArray(res) && res.length) lines.push(`支持分辨率：${res.join('、')}`)
  if (videoOptions.supports_image_to_video) lines.push('支持图生视频（首帧/参考图）')
  if (videoOptions.show_audio_toggle) lines.push('可选带音频/静音')
  return lines.length ? lines.join('；') : '见 /api/v1/models video_options'
}

/**
 * @param {object} p
 */
export function buildMediaConfirmationMessage(p) {
  const {
    tool,
    modelDisplay,
    aspectRatio,
    resolution,
    durationSeconds,
    mode,
    prompt,
    modelConstraints,
    usedDefaultModel,
    defaultModelId,
    defaultModelLabel,
  } = p

  const lines = [
    '【ClawBBA 生成参数确认单】',
    `任务类型：${tool === 'video_generate' ? '生视频' : '生图'}`,
    `模型：${modelDisplay}${usedDefaultModel ? `（未在话术指定，使用默认 ${defaultModelId} · ${defaultModelLabel}）` : ''}`,
    `比例：${aspectRatio || '（未指定，将用模型默认）'}`,
  ]
  if (tool === 'image_generate') {
    lines.push(`分辨率：${resolution || '（未指定）'}`)
  } else {
    lines.push(`时长：${durationSeconds != null ? `${durationSeconds} 秒` : '（未指定）'}`)
  }
  if (mode) lines.push(`模式：${mode}`)
  if (prompt) lines.push(`画面描述：${String(prompt).slice(0, 200)}${String(prompt).length > 200 ? '…' : ''}`)
  if (modelConstraints) lines.push(`模型参数要求：${modelConstraints}`)
  lines.push(
    '',
    '请核对以上参数。无误后请回复「确认生成」开始任务（将扣费）。',
    '若要修改，请重新发送自然语言描述；格式见 https://www.clawbba.com/agent/api-keys',
    `或回复「确认生成」前让 Agent 说明：GET /api/v1/models 中对应模型的 image_options / video_options。`,
  )
  return lines.join('\n')
}

/** @param {Record<string, unknown>} fields */
export function mediaJobFingerprint(fields) {
  return [
    fields.tool || '',
    fields.model || '',
    fields.aspectRatio || '',
    fields.resolution || '',
    fields.durationSeconds ?? '',
    fields.mode || '',
    fields.prompt || '',
    fields.refCount ?? 0,
  ].join('|')
}
