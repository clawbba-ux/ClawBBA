/**
 * 各视频模型静态生成参数（无 API 时 bundled 能力表 + API 同步时的缺省补全）
 * 与 server/openrouter-video-pricing.js DEFAULT_VIDEO_PRICING_BY_MODEL 及 OpenRouter 文档对齐
 */

/** @typedef {import('./clawbba-openclaw-media-catalog.mjs').VIDEO_MODEL_SPECS} */

export const OPENCLAW_VIDEO_RESOLUTIONS = ['480P', '720P', '768P', '1080P', '4K']

export const OPENCLAW_VIDEO_ASPECT_RATIOS = ['1:1', '16:9', '9:16', '4:3', '3:4', '3:2', '2:3', '21:9', 'adaptive']

/** @type {Record<string, object>} */
export const STATIC_VIDEO_OPTIONS_BY_MODEL = {
  'google/veo-3.1-fast': {
    duration_presets: [4, 6, 8],
    default_duration: 8,
    aspect_ratios: ['16:9', '9:16'],
    default_aspect_ratio: '16:9',
    resolutions: ['720P', '1080P'],
    default_resolution: '720P',
    supports_image_to_video: true,
    supported_frame_types: ['first_frame', 'last_frame'],
    show_audio_toggle: true,
    default_generate_audio: true,
  },
  'google/veo-3.1': {
    duration_presets: [4, 6, 8],
    default_duration: 8,
    aspect_ratios: ['16:9', '9:16'],
    default_aspect_ratio: '16:9',
    resolutions: ['720P', '1080P', '4K'],
    default_resolution: '1080P',
    supports_image_to_video: true,
    supported_frame_types: ['first_frame', 'last_frame'],
    show_audio_toggle: true,
    default_generate_audio: true,
  },
  'google/veo-3.1-lite': {
    duration_presets: [4, 5, 6, 8],
    default_duration: 5,
    aspect_ratios: ['16:9', '9:16'],
    default_aspect_ratio: '9:16',
    resolutions: ['720P', '1080P'],
    default_resolution: '720P',
    supports_image_to_video: true,
    supported_frame_types: ['first_frame'],
    show_audio_toggle: true,
    default_generate_audio: true,
  },
  'bytedance/seedance-2.0': {
    duration_presets: [4, 5, 8, 10, 12],
    default_duration: 5,
    aspect_ratios: ['9:16', '16:9', '1:1', '4:3', '3:4'],
    default_aspect_ratio: '9:16',
    resolutions: ['480P', '720P', '1080P'],
    default_resolution: '720P',
    supports_image_to_video: true,
    supported_frame_types: ['first_frame', 'last_frame', 'reference_image'],
    show_audio_toggle: false,
  },
  'bytedance/seedance-2.0-fast': {
    duration_presets: [4, 5, 8, 10],
    default_duration: 5,
    aspect_ratios: ['9:16', '16:9', '1:1'],
    default_aspect_ratio: '9:16',
    resolutions: ['480P', '720P', '1080P'],
    default_resolution: '720P',
    supports_image_to_video: true,
    supported_frame_types: ['first_frame', 'last_frame', 'reference_image'],
    show_audio_toggle: false,
  },
  'bytedance/seedance-1-5-pro': {
    duration_presets: [5, 8, 10],
    default_duration: 8,
    aspect_ratios: ['16:9', '9:16', '1:1'],
    default_aspect_ratio: '16:9',
    resolutions: ['720P', '1080P'],
    default_resolution: '720P',
    supports_image_to_video: true,
    supported_frame_types: ['first_frame', 'last_frame'],
    show_audio_toggle: true,
    default_generate_audio: true,
  },
  'kwaivgi/kling-v3.0-pro': {
    duration_presets: [5, 10, 15],
    default_duration: 8,
    aspect_ratios: ['16:9', '9:16', '1:1'],
    default_aspect_ratio: '16:9',
    resolutions: ['720P', '1080P'],
    default_resolution: '1080P',
    supports_image_to_video: true,
    supported_frame_types: ['first_frame', 'last_frame', 'reference_image'],
    show_audio_toggle: false,
  },
  'kwaivgi/kling-v3.0-std': {
    duration_presets: [5, 10],
    default_duration: 8,
    aspect_ratios: ['16:9', '9:16', '1:1'],
    default_aspect_ratio: '16:9',
    resolutions: ['720P', '1080P'],
    default_resolution: '720P',
    supports_image_to_video: true,
    supported_frame_types: ['first_frame', 'last_frame'],
    show_audio_toggle: false,
  },
  'kwaivgi/kling-video-o1': {
    duration_presets: [5, 10],
    default_duration: 5,
    aspect_ratios: ['16:9', '9:16'],
    default_aspect_ratio: '16:9',
    resolutions: ['720P'],
    default_resolution: '720P',
    supports_image_to_video: true,
    supported_frame_types: ['first_frame', 'last_frame', 'reference_image'],
    show_audio_toggle: false,
  },
  'openai/sora-2-pro': {
    duration_presets: [5, 10, 15, 20],
    default_duration: 8,
    aspect_ratios: ['16:9', '9:16'],
    default_aspect_ratio: '16:9',
    resolutions: ['720P', '768P', '1080P'],
    default_resolution: '1080P',
    supports_image_to_video: true,
    supported_frame_types: ['first_frame'],
    show_audio_toggle: false,
  },
  'alibaba/wan-2.7': {
    duration_presets: [5, 8, 10],
    default_duration: 8,
    aspect_ratios: ['16:9', '9:16', '1:1'],
    default_aspect_ratio: '16:9',
    resolutions: ['480P', '720P', '1080P'],
    default_resolution: '720P',
    supports_image_to_video: true,
    supported_frame_types: ['first_frame', 'last_frame'],
    show_audio_toggle: false,
  },
  'alibaba/wan-2.6': {
    duration_presets: [5, 8, 10],
    default_duration: 8,
    aspect_ratios: ['16:9', '9:16', '1:1'],
    default_aspect_ratio: '16:9',
    resolutions: ['480P', '720P', '1080P'],
    default_resolution: '720P',
    supports_image_to_video: true,
    supported_frame_types: ['first_frame', 'last_frame'],
    show_audio_toggle: false,
  },
  'minimax/hailuo-2.3': {
    duration_presets: [5, 8],
    default_duration: 5,
    aspect_ratios: ['9:16', '16:9', '1:1'],
    default_aspect_ratio: '9:16',
    resolutions: ['720P', '1080P'],
    default_resolution: '720P',
    supports_image_to_video: true,
    supported_frame_types: ['first_frame'],
    show_audio_toggle: false,
  },
  'x-ai/grok-imagine-video': {
    duration_presets: [5, 8],
    default_duration: 8,
    aspect_ratios: ['16:9', '9:16'],
    default_aspect_ratio: '16:9',
    resolutions: ['720P', '1080P'],
    default_resolution: '720P',
    supports_image_to_video: true,
    supported_frame_types: ['first_frame'],
    show_audio_toggle: false,
  },
}

const GENERIC_VIDEO_OPTIONS = {
  duration_presets: [5, 8],
  default_duration: 5,
  aspect_ratios: ['16:9', '9:16'],
  default_aspect_ratio: '16:9',
  resolutions: ['720P', '1080P'],
  default_resolution: '720P',
  supports_image_to_video: true,
  supported_frame_types: ['first_frame', 'last_frame'],
  show_audio_toggle: false,
}

/**
 * @param {string} modelId
 * @param {{ ratio?: string, duration?: number, resolution?: string, audio?: boolean }} [catalogSpec]
 */
export function resolveStaticVideoOptions(modelId, catalogSpec = {}) {
  const id = String(modelId || '').trim()
  const base = STATIC_VIDEO_OPTIONS_BY_MODEL[id]
    ? { ...STATIC_VIDEO_OPTIONS_BY_MODEL[id] }
    : { ...GENERIC_VIDEO_OPTIONS }
  if (catalogSpec.ratio && !base.default_aspect_ratio) {
    base.default_aspect_ratio = catalogSpec.ratio
  } else if (catalogSpec.ratio && base.aspect_ratios?.includes(catalogSpec.ratio)) {
    base.default_aspect_ratio = catalogSpec.ratio
  }
  if (catalogSpec.duration != null && base.duration_presets?.includes(catalogSpec.duration)) {
    base.default_duration = catalogSpec.duration
  } else if (catalogSpec.duration != null && !base.default_duration) {
    base.default_duration = catalogSpec.duration
  }
  if (catalogSpec.resolution) {
    const r = String(catalogSpec.resolution).toUpperCase()
    if (base.resolutions?.includes(r)) base.default_resolution = r
  }
  if (catalogSpec.audio != null && base.show_audio_toggle) {
    base.default_generate_audio = catalogSpec.audio
  }
  return base
}

/** API video_options 优先，静态表补全缺失字段 */
export function mergeVideoOptions(apiVo, staticVo) {
  const api = apiVo && typeof apiVo === 'object' ? apiVo : {}
  const st = staticVo && typeof staticVo === 'object' ? staticVo : {}
  const pick = (key) => {
    const v = api[key]
    if (v !== undefined && v !== null && !(Array.isArray(v) && v.length === 0)) return v
    return st[key]
  }
  return {
    duration_presets: pick('duration_presets'),
    default_duration: pick('default_duration'),
    duration_min: pick('duration_min'),
    duration_max: pick('duration_max'),
    aspect_ratios: pick('aspect_ratios'),
    default_aspect_ratio: pick('default_aspect_ratio'),
    resolutions: pick('resolutions') ?? pick('resolutions_text') ?? pick('resolutions_image'),
    default_resolution: pick('default_resolution'),
    supports_image_to_video: pick('supports_image_to_video'),
    supported_frame_types: pick('supported_frame_types'),
    show_audio_toggle: pick('show_audio_toggle'),
    default_generate_audio: pick('default_generate_audio'),
    supports_seed: pick('supports_seed'),
  }
}
