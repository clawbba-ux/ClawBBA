/**
 * ClawBBA × OpenClaw 媒体参数 v2 — 枚举 + runtime 注入（无话术 / 无确认生成）
 * @see references/media-capabilities.json
 */
export {
  OPENCLAW_IMAGE_RESOLUTIONS,
  OPENCLAW_IMAGE_ASPECT_RATIOS,
  IMAGE_RESOLUTION_ALIASES,
} from './clawbba-media-params-enums.mjs'

export {
  MEDIA_PARAMS_V2_MARKER,
  MEDIA_DISPATCH_V2_MARKER,
  buildClawbbaMediaToolValidateRuntimeBlock,
  toolsSrcHasMediaParamsV2,
  injectMediaToolValidateRuntime,
  injectMediaToolValidateRuntime as injectMediaParamsRuntimeBlock,
} from './clawbba-media-tool-validate.mjs'

/** 兼容旧 verify / 升级检测 */
export const MEDIA_PARAMS_V1_MARKER = '/* clawbba-media-params-v1 */'

import { toolsSrcHasMediaParamsV2 } from './clawbba-media-tool-validate.mjs'

/** @param {string} src */
export function toolsSrcHasMediaParamsV1(src) {
  return toolsSrcHasMediaParamsV2(src)
}
