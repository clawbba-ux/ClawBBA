#!/usr/bin/env node
/**
 * 修复 agents.defaults.imageModel：与 agents.defaults.model 对齐（clawbba/<同一文本模型>），
 * 禁止误用 openrouter 生图模型；禁止自动切到与对话无关的 Gemini 看图。
 */
import fs from 'fs'
import {
  isDeprecatedVisionModelId,
  isValidClawbbaImageModelRef,
  resolveImageModelPrimary,
} from './clawbba-vision-models.mjs'
import { getOpenclawHome, getOpenclawJsonPath } from './openclaw-paths.mjs'

const API_BASE = (process.env.CLAWBBA_API_BASE || 'https://www.clawbba.com/api/v1').replace(
  /\/$/,
  '',
)
const API_KEY = String(process.env.CLAWBBA_API_KEY || '').trim()

async function fetchCatalogRows() {
  if (!API_KEY.startsWith('cbb_sk_live_')) return []
  const res = await fetch(`${API_BASE}/models`, {
    headers: { Authorization: `Bearer ${API_KEY}`, Accept: 'application/json' },
  })
  if (!res.ok) return []
  const body = await res.json()
  return Array.isArray(body.data) ? body.data : []
}

function defaultTextModelId(cfg) {
  const primary = String(cfg?.agents?.defaults?.model?.primary || '').trim()
  if (primary.startsWith('clawbba/')) return primary.slice('clawbba/'.length)
  return ''
}

function needsImageModelFix(current) {
  const s = String(current || '').trim()
  if (!s) return true
  if (!isValidClawbbaImageModelRef(s)) return true
  if (s.startsWith('openrouter/')) return true
  const id = s.startsWith('clawbba/') ? s.slice('clawbba/'.length) : s
  if (isDeprecatedVisionModelId(id)) return true
  return false
}

function sanitizeImageModelBlock(imageModel, nextPrimary) {
  if (!imageModel || typeof imageModel !== 'object') {
    return { primary: nextPrimary }
  }
  const out = { ...imageModel, primary: nextPrimary }
  const fallbacks = Array.isArray(out.fallbacks) ? out.fallbacks : []
  out.fallbacks = fallbacks.filter((fb) => {
    const id = String(typeof fb === 'string' ? fb : fb?.id || fb?.model || '').trim()
    if (!id) return false
    const bare = id.startsWith('clawbba/') ? id.slice('clawbba/'.length) : id
    return !isDeprecatedVisionModelId(bare)
  })
  return out
}

export function patchOpenclawVisionAgents(cfg, rows) {
  if (!cfg || typeof cfg !== 'object') return false
  const defaults = cfg.agents?.defaults
  if (!defaults || typeof defaults !== 'object') return false

  const textId = defaultTextModelId(cfg)
  const nextPrimary = resolveImageModelPrimary(rows, textId)
  if (!nextPrimary) return false

  const current = String(defaults.imageModel?.primary || '').trim()
  if (!needsImageModelFix(current)) return false

  defaults.imageModel = sanitizeImageModelBlock(defaults.imageModel, nextPrimary)
  return true
}

async function main() {
  const home = getOpenclawHome()
  const jsonPath = getOpenclawJsonPath(home)
  if (!fs.existsSync(jsonPath)) {
    process.stderr.write('[clawbba-api] 未找到 openclaw.json，跳过 vision imageModel 修复\n')
    return
  }
  const rows = await fetchCatalogRows()
  const cfg = JSON.parse(fs.readFileSync(jsonPath, 'utf8'))
  if (!patchOpenclawVisionAgents(cfg, rows)) {
    process.stderr.write('[clawbba-api] imageModel 已正确或为 clawbba vision 文本模型\n')
    return
  }
  fs.writeFileSync(jsonPath, `${JSON.stringify(cfg, null, 2)}\n`, { mode: 0o600 })
  const primary = cfg.agents?.defaults?.imageModel?.primary
  process.stderr.write(`[clawbba-api] 已设置 agents.defaults.imageModel.primary = ${primary}\n`)
}

main().catch((e) => {
  process.stderr.write(`[clawbba-api] ${e.message || e}\n`)
  process.exit(1)
})
