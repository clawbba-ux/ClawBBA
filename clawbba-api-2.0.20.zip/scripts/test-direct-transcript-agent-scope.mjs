#!/usr/bin/env node
import assert from 'node:assert/strict'
import {
  WEBCHAT_DIRECT_TRANSCRIPT_AGENT_SCOPE_MARKER,
  upgradeDirectTranscriptAgentScopeResolve,
} from './clawbba-webchat-live-inject.mjs'

const broken = `\t\tconst sessionUtilsModule = await import("./session-utils-A.js");
\t\tconst loadSessionEntry = clawbbaPickModuleExport(sessionUtilsModule, "loadSessionEntry", ["c"]);
\t\tconst resolveSessionAgentId = clawbbaPickModuleExport(sessionUtilsModule, "resolveSessionAgentId", []);`

const fixed = upgradeDirectTranscriptAgentScopeResolve(broken, 'agent-scope-B.js')
assert.ok(fixed.includes(WEBCHAT_DIRECT_TRANSCRIPT_AGENT_SCOPE_MARKER))
assert.ok(fixed.includes('agent-scope-B.js'))
assert.ok(fixed.includes('resolveSessionAgentId", ["_"]'))
assert.ok(!fixed.includes('sessionUtilsModule, "resolveSessionAgentId"'))

console.log('test-direct-transcript-agent-scope: ok')
