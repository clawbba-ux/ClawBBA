/**
 * OpenClaw reference-image helpers for image_generate / video_generate.
 * Injected into openclaw-tools-*.js (see patchReferenceImagesInToolsFile).
 * @see references/media-dispatch-spec.md §3.3
 */
import fs from 'fs'
import path from 'path'

export const REFERENCE_IMAGES_MARKER = '/* clawbba-reference-images */'
export const REFERENCE_REQUIRED_GUARD_MARKER = '/* clawbba-reference-required-guard */'
export const REFERENCE_PROMPT_ENGLISH_MARKER = '/* clawbba-reference-prompt-en */'
export const REFERENCE_PLAUSIBLE_MARKER = '/* clawbba-reference-plausible */'
export const REFERENCE_WAIT_WINDOW_MARKER = '/* clawbba-reference-wait-window */'

export const IMAGE_REFERENCE_SANITIZE_CALL = `\t\t\t${REFERENCE_PLAUSIBLE_MARKER}
\t\t\tclawbbaSanitizeReferenceImageParams(params);`

/** User text implies图生图 / reference upload required */
export function promptRequiresReferenceImages(text) {
  const s = String(text ?? '').trim()
  if (!s) return false
  return /参考图|根据参考图|根据图|图生图|垫图|按上传|按参考|同款|以图生/i.test(s)
}

/** 仅在这些话术下才从会话相邻消息合并参考图，避免误绑历史图片 */
export function sessionMergeRequiresStrongReferenceIntent(text) {
  const s = String(text ?? '').trim()
  if (!s) return false
  return /参考图|根据参考图|根据图|图生图|垫图|以图生/i.test(s)
}

export const IMAGE_REFERENCE_ASSERT_CALL = `\t\t\t${REFERENCE_REQUIRED_GUARD_MARKER}
\t\t\tawait clawbbaAssertReferenceImagesIfRequired({ params, options, prompt, tool: "image_generate" });`

/** Max reference images (OpenClaw openrouter edit default). */
export const MAX_REFERENCE_IMAGES = 5

/**
 * Extract image reference paths/URLs from an OpenClaw session user message.
 * @param {unknown} msg
 * @returns {string[]}
 */
export function extractImageRefsFromMessage(msg) {
  const out = []
  if (!msg || typeof msg !== 'object') return out
  const record = /** @type {Record<string, unknown>} */ (msg)
  const content = record.content

  const push = (raw) => {
    const v = resolveOpenClawMediaRefSync(String(raw ?? '').trim())
    if (v && looksLikeImageRef(v) && !out.includes(v)) out.push(v)
  }

  if (typeof content === 'string') {
    pushMediaLinesFromText(content, push)
    return out
  }

  if (!Array.isArray(content)) return out

  for (const part of content) {
    if (!part || typeof part !== 'object') continue
    const p = /** @type {Record<string, unknown>} */ (part)
    const type = String(p.type ?? '').toLowerCase()

    if (type === 'image') {
      push(p.path ?? p.filePath ?? p.url)
      const src = p.source
      if (src && typeof src === 'object') {
        const s = /** @type {Record<string, unknown>} */ (src)
        push(s.url ?? s.path)
      }
    }
    if (type === 'image_url') {
      const iu = p.image_url ?? p.imageUrl
      if (iu && typeof iu === 'object') {
        push(/** @type {Record<string, unknown>} */ (iu).url)
      }
    }
    if (type === 'file' || type === 'attachment') {
      const mime = String(p.mimeType ?? p.mime ?? '').toLowerCase()
      if (!mime || mime.startsWith('image/')) {
        push(p.path ?? p.filePath ?? p.url)
        const att = p.attachment
        if (att && typeof att === 'object') {
          const a = /** @type {Record<string, unknown>} */ (att)
          push(a.path ?? a.url)
        }
      }
    }
    if (typeof p.text === 'string') pushMediaLinesFromText(p.text, push)
  }

  const attachments = record.attachments
  if (Array.isArray(attachments)) {
    for (const att of attachments) {
      if (!att || typeof att !== 'object') continue
      const a = /** @type {Record<string, unknown>} */ (att)
      const mime = String(a.mimeType ?? a.mime ?? '').toLowerCase()
      if (!mime || mime.startsWith('image/')) push(a.path ?? a.filePath ?? a.url)
    }
  }

  return out
}

/**
 * @param {string} text
 * @param {(v: string) => void} push
 */
function pushMediaLinesFromText(text, push) {
  for (const m of text.matchAll(/MEDIA:([^\s\n]+)/g)) {
    if (m[1]) push(m[1])
  }
  for (const m of text.matchAll(/\[media attached:\s*([^\]\n]+)\]/gi)) {
    if (m[1]) push(m[1])
  }
}

/**
 * @param {string} value
 * @returns {boolean}
 */
export function looksLikeImageRef(value) {
  const v = String(value ?? '').trim()
  if (!v) return false
  if (/~\/\.openclaw\/media\/?$/i.test(v) || /\/\.openclaw\/media\/?$/i.test(v)) return false
  if (v.startsWith('data:image/')) return true
  if (v.startsWith('file://')) return true
  if (v.includes('.openclaw/media/') || v.includes('.openclaw\\media\\')) return true
  if (v.startsWith('~/')) return true
  if (/\.(png|jpe?g|webp|gif|bmp|svg)(\?|#|$)/i.test(v)) return true
  if (/^media:\/\//i.test(v)) return true
  if (/^https?:\/\//i.test(v)) {
    return (
      /\.(png|jpe?g|webp|gif|bmp|svg)(\?|#|$)/i.test(v) ||
      /\/media\//i.test(v) ||
      /\/uploads\//i.test(v) ||
      /\/inbound\//i.test(v)
    )
  }
  return /^\/[^ \n]+$/.test(v)
}

/**
 * Resolve OpenClaw gateway claim-check URI to local inbound path (sync best-effort).
 * @param {string} value
 * @returns {string}
 */
export function resolveOpenClawMediaRefSync(value) {
  const v = String(value ?? '').trim()
  if (!/^media:\/\//i.test(v)) return v
  try {
    const parsed = new URL(v)
    if (parsed.hostname !== 'inbound') return v
    const id = decodeURIComponent(parsed.pathname.replace(/^\/+/, ''))
    if (!id || id.includes('/') || id.includes('\\')) return v
    const home =
      process.env.OPENCLAW_STATE_DIR?.trim() ||
      process.env.OPENCLAW_HOME?.trim() ||
      path.join(process.env.HOME || '/tmp', '.openclaw')
    return path.join(home, 'media', 'inbound', id)
  } catch {
    return v
  }
}

/**
 * @param {unknown} msg
 * @returns {string}
 */
export function messageTextFromRecord(msg) {
  if (!msg || typeof msg !== 'object') return ''
  const content = /** @type {Record<string, unknown>} */ (msg).content
  if (typeof content === 'string') return content
  if (!Array.isArray(content)) return ''
  return content
    .map((part) => {
      if (!part || typeof part !== 'object') return typeof part === 'string' ? part : ''
      const p = /** @type {Record<string, unknown>} */ (part)
      return typeof p.text === 'string' ? p.text : ''
    })
    .join('')
}

/**
 * Reject Agent placeholders / hallucinated URLs (e.g. 参考图URL, example.com).
 * @param {string} value
 * @returns {boolean}
 */
export function isPlausibleReferenceImageRef(value) {
  const v = String(value ?? '').trim()
  if (!v || !looksLikeImageRef(v)) return false
  if (/^参考图/i.test(v) || /参考图\s*url/i.test(v)) return false
  if (/placeholder|example\.(com|org|net)\b|reference[-_]?image\.(jpg|jpeg|png|webp)/i.test(v)) {
    return false
  }
  return true
}

/**
 * @param {Record<string, unknown>} record
 * @returns {string[]}
 */
export function collectPlausibleReferenceImages(record) {
  const out = []
  const push = (raw) => {
    const v = resolveOpenClawMediaRefSync(String(raw ?? '').trim())
    if (isPlausibleReferenceImageRef(v) && !out.includes(v)) out.push(v)
  }
  if (typeof record?.image === 'string') push(record.image)
  if (Array.isArray(record?.images)) {
    for (const item of record.images) {
      if (typeof item === 'string') push(item)
    }
  }
  return out
}

/**
 * @param {Record<string, unknown>} record
 * @returns {boolean}
 */
export function paramsHaveReferenceImages(record) {
  return collectPlausibleReferenceImages(record).length > 0
}

/**
 * Strip placeholder / invalid image refs so session merge can run.
 * @param {Record<string, unknown>} record
 */
export function sanitizeReferenceImageParams(record) {
  if (!record || typeof record !== 'object') return
  const plausible = collectPlausibleReferenceImages(record)
  if (typeof record.image === 'string' && !isPlausibleReferenceImageRef(record.image)) {
    delete record.image
  }
  if (Array.isArray(record.images)) {
    record.images = record.images.filter(
      (v) => typeof v === 'string' && isPlausibleReferenceImageRef(v),
    )
  }
  if (plausible.length > 0) {
    record.images = plausible.slice(0, MAX_REFERENCE_IMAGES)
    if (plausible.length === 1) record.image = plausible[0]
  }
}

/**
 * @param {Record<string, unknown>} record
 * @returns {boolean}
 */
export function paramsHaveVideoImageRoles(record) {
  const roles = record.imageRoles
  return Array.isArray(roles) && roles.some((r) => typeof r === 'string' && String(r).trim())
}

/**
 * Inline helpers injected once into openclaw-tools bundle.
 */
export function buildReferenceImagesHelperSource() {
  return `${REFERENCE_IMAGES_MARKER}
function clawbbaResolveOpenClawMediaRefSync(value) {
\tconst v = String(value ?? "").trim();
\tif (!/^media:\\/\\//i.test(v)) return v;
\ttry {
\t\tconst parsed = new URL(v);
\t\tif (parsed.hostname !== "inbound") return v;
\t\tconst id = decodeURIComponent(parsed.pathname.replace(/^\\/+/, ""));
\t\tif (!id || id.includes("/") || id.includes("\\\\")) return v;
\t\treturn path.join(resolveUserPath("~/.openclaw"), "media", "inbound", id);
\t} catch (_) {
\t\treturn v;
\t}
}
function clawbbaMessageTextFromRecord(msg) {
\tif (!msg || typeof msg !== "object") return "";
\tconst content = msg.content;
\tif (typeof content === "string") return content;
\tif (!Array.isArray(content)) return "";
\treturn content.map((part) => {
\t\tif (!part || typeof part !== "object") return typeof part === "string" ? part : "";
\t\treturn typeof part.text === "string" ? part.text : "";
\t}).join("");
}
function clawbbaLooksLikeImageRef(value) {
\tconst v = String(value ?? "").trim();
\tif (!v) return false;
\tif (/^media:\\/\\//i.test(v)) return true;
\tif (/~\\/\\.openclaw\\/media\\/?$/i.test(v) || /\\/\\.openclaw\\/media\\/?$/i.test(v)) return false;
\tif (v.startsWith("data:image/")) return true;
\tif (v.startsWith("file://")) return true;
\tif (v.includes(".openclaw/media/") || v.includes(".openclaw\\\\media\\\\")) return true;
\tif (v.startsWith("~/")) return true;
\tif (/\\.(png|jpe?g|webp|gif|bmp|svg)(\\?|#|$)/i.test(v)) return true;
\tif (/^https?:\\/\\//i.test(v)) return /\\.(png|jpe?g|webp|gif|bmp|svg)(\\?|#|$)/i.test(v) || /\\/media\\//i.test(v) || /\\/uploads\\//i.test(v) || /\\/inbound\\//i.test(v);
\treturn /^\\/[^ \\n]+$/.test(v);
}
function clawbbaExtractImageRefsFromMessage(msg) {
\tconst out = [];
\tif (!msg || typeof msg !== "object") return out;
\tconst push = (raw) => {
\t\tconst v = clawbbaResolveOpenClawMediaRefSync(String(raw ?? "").trim());
\t\tif (!v || !clawbbaLooksLikeImageRef(v) || out.includes(v)) return;
\t\tout.push(v);
\t};
\tconst content = msg.content;
\tif (typeof content === "string") {
\t\tfor (const m of content.matchAll(/MEDIA:([^\\s\\n]+)/g)) if (m[1]) push(m[1]);
\t\tfor (const m of content.matchAll(/\\[media attached:\\s*([^\\]\\n]+)\\]/gi)) if (m[1]) push(m[1]);
\t\treturn out;
\t}
\tif (!Array.isArray(content)) return out;
\tfor (const part of content) {
\t\tif (!part || typeof part !== "object") continue;
\t\tconst type = String(part.type ?? "").toLowerCase();
\t\tif (type === "image") {
\t\t\tpush(part.path ?? part.filePath ?? part.url);
\t\t\tif (part.source && typeof part.source === "object") push(part.source.url ?? part.source.path);
\t\t}
\t\tif (type === "image_url" && part.image_url && typeof part.image_url === "object") push(part.image_url.url);
\t\tif (type === "file" || type === "attachment") {
\t\t\tconst mime = String(part.mimeType ?? part.mime ?? "").toLowerCase();
\t\t\tif (!mime || mime.startsWith("image/")) {
\t\t\t\tpush(part.path ?? part.filePath ?? part.url);
\t\t\t\tif (part.attachment && typeof part.attachment === "object") push(part.attachment.path ?? part.attachment.url);
\t\t\t}
\t\t}
\t\tif (typeof part.text === "string") {
\t\t\tfor (const m of part.text.matchAll(/MEDIA:([^\\s\\n]+)/g)) if (m[1]) push(m[1]);
\t\t\tfor (const m of part.text.matchAll(/\\[media attached:\\s*([^\\]\\n]+)\\]/gi)) if (m[1]) push(m[1]);
\t\t}
\t}
\tif (Array.isArray(msg.attachments)) for (const att of msg.attachments) {
\t\tif (!att || typeof att !== "object") continue;
\t\tconst mime = String(att.mimeType ?? att.mime ?? "").toLowerCase();
\t\tif (!mime || mime.startsWith("image/")) push(att.path ?? att.filePath ?? att.url);
\t}
\treturn out;
}
function clawbbaIsPlausibleReferenceImageRef(value) {
\tconst v = String(value ?? "").trim();
\tif (!v || !clawbbaLooksLikeImageRef(v)) return false;
\tif (/^参考图/i.test(v) || /参考图\\s*url/i.test(v)) return false;
\tif (/placeholder|example\\.(com|org|net)\\b|reference[-_]?image\\.(jpg|jpeg|png|webp)/i.test(v)) return false;
\treturn true;
}
function clawbbaCollectPlausibleReferenceImages(record) {
\tconst out = [];
\tconst push = (raw) => {
\t\tconst v = clawbbaResolveOpenClawMediaRefSync(String(raw ?? "").trim());
\t\tif (clawbbaIsPlausibleReferenceImageRef(v) && !out.includes(v)) out.push(v);
\t};
\tif (typeof record?.image === "string") push(record.image);
\tif (Array.isArray(record?.images)) for (const item of record.images) if (typeof item === "string") push(item);
\treturn out;
}
function clawbbaSanitizeReferenceImageParams(record) {
\t${REFERENCE_PLAUSIBLE_MARKER}
\tif (!record || typeof record !== "object") return;
\tconst plausible = clawbbaCollectPlausibleReferenceImages(record);
\tif (typeof record.image === "string" && !clawbbaIsPlausibleReferenceImageRef(record.image)) delete record.image;
\tif (Array.isArray(record.images)) record.images = record.images.filter((v) => typeof v === "string" && clawbbaIsPlausibleReferenceImageRef(v));
\tif (plausible.length > 0) {
\t\trecord.images = plausible.slice(0, ${MAX_REFERENCE_IMAGES});
\t\tif (plausible.length === 1) record.image = plausible[0];
\t}
}
function clawbbaParamsHaveReferenceImages(record) {
\treturn clawbbaCollectPlausibleReferenceImages(record).length > 0;
}
function clawbbaParamsHaveVideoImageRoles(record) {
\treturn Array.isArray(record?.imageRoles) && record.imageRoles.some((r) => typeof r === "string" && String(r).trim());
}
function clawbbaStrongReferenceIntentForSessionMerge(text) {
\tconst s = String(text ?? "").trim();
\tif (!s) return false;
\treturn /参考图|根据参考图|根据图|图生图|垫图|以图生/i.test(s);
}
async function clawbbaMaybeMergeSessionReferenceImages(opts) {
\tconst record = opts.params ?? opts.args;
\tif (!record || typeof record !== "object") return;
\tclawbbaSanitizeReferenceImageParams(record);
\tif (clawbbaParamsHaveReferenceImages(record)) return;
\tconst sk = typeof opts.options?.agentSessionKey === "string" ? opts.options.agentSessionKey.trim() : "";
\tif (!sk) return;
\ttry {
\t\tconst rt = await getRuntime();
\t\tconst { storePath, entry } = rt.loadSessionEntry(sk);
\t\tconst sessionId = entry?.sessionId;
\t\tif (!sessionId || !storePath) return;
\t\tconst msgs = await rt.readSessionMessagesAsync(sessionId, storePath, entry?.sessionFile, { mode: "recent", maxMessages: 24, maxBytes: 512000 });
\t\tconst isVideo = opts.tool === "video_generate";
\t\tconst templateRe = isVideo ? /请使用\\s*ClawBBA\\s*生成视频/i : /请使用\\s*ClawBBA\\s*生成图片/i;
\t\tlet templateIdx = -1;
\t\tlet mediaText = "";
\t\tfor (let i = msgs.length - 1; i >= 0; i--) {
\t\t\tconst m = msgs[i];
\t\t\tif (m?.role !== "user") continue;
\t\t\tconst t = clawbbaMessageTextFromRecord(m);
\t\t\tif (templateRe.test(t)) {
\t\t\t\ttemplateIdx = i;
\t\t\t\tmediaText = t;
\t\t\t\tbreak;
\t\t\t}
\t\t}
\t\tif (templateIdx < 0) return;
\t\tconst refs = [];
\t\tconst seen = new Set();
\t\tconst pushRef = (raw) => {
\t\t\tconst v = clawbbaResolveOpenClawMediaRefSync(String(raw ?? "").trim());
\t\t\tif (!v || seen.has(v) || !clawbbaIsPlausibleReferenceImageRef(v)) return;
\t\t\tseen.add(v);
\t\t\trefs.push(v);
\t\t};
\t\tfor (const r of clawbbaExtractImageRefsFromMessage(msgs[templateIdx])) pushRef(r);
\t\tif (refs.length === 0 && clawbbaStrongReferenceIntentForSessionMerge(mediaText)) {
\t\t\tfor (const off of [-1, 1]) {
\t\t\t\tconst i = templateIdx + off;
\t\t\t\tif (i < 0 || i >= msgs.length) continue;
\t\t\t\tconst m = msgs[i];
\t\t\t\tif (m?.role !== "user") continue;
\t\t\t\tfor (const r of clawbbaExtractImageRefsFromMessage(m)) pushRef(r);
\t\t\t}
\t\t}
\t\tif (refs.length === 0) return;
\t\tconst max = typeof opts.maxCount === "number" && opts.maxCount > 0 ? Math.min(opts.maxCount, ${MAX_REFERENCE_IMAGES}) : ${MAX_REFERENCE_IMAGES};
\t\tconst trimmed = refs.slice(0, max);
\t\tif (trimmed.length === 1) record.image = trimmed[0];
\t\telse record.images = trimmed;
\t\tif (isVideo && !clawbbaParamsHaveVideoImageRoles(record)) {
\t\t\tconst role = /尾帧|last[\\s_-]?frame/i.test(mediaText) ? "last_frame" : /首帧|first[\\s_-]?frame|图生视频/i.test(mediaText) ? "first_frame" : "reference_image";
\t\t\trecord.imageRoles = trimmed.map(() => role);
\t\t}
\t} catch (_) {}
}
function clawbbaPromptRequiresReferenceImages(text) {
\tconst s = String(text ?? "").trim();
\tif (!s) return false;
\t${REFERENCE_PROMPT_ENGLISH_MARKER}
\treturn /参考图|根据参考图|根据图|图生图|垫图|按上传|按参考|同款|以图生|reference\\s+image|based on (the )?reference|from (the )?reference|using (the )?reference/i.test(s);
}
async function clawbbaFindClawbbaImageTemplateText(sessionKey) {
\tconst sk = String(sessionKey ?? "").trim();
\tif (!sk) return "";
\ttry {
\t\tconst rt = await getRuntime();
\t\tconst { storePath, entry } = rt.loadSessionEntry(sk);
\t\tconst sessionId = entry?.sessionId;
\t\tif (!sessionId || !storePath) return "";
\t\tconst msgs = await rt.readSessionMessagesAsync(sessionId, storePath, entry?.sessionFile, { mode: "recent", maxMessages: 24, maxBytes: 512000 });
\t\tfor (let i = msgs.length - 1; i >= 0; i--) {
\t\t\tconst m = msgs[i];
\t\t\tif (m?.role !== "user") continue;
\t\t\tconst t = clawbbaMessageTextFromRecord(m);
\t\t\tif (/请使用\\s*ClawBBA\\s*生成图片/i.test(t)) return t;
\t\t}
\t} catch (_) {}
\treturn "";
}
async function clawbbaWaitAndMergeReferenceImages(opts) {
\t${REFERENCE_WAIT_WINDOW_MARKER}
\tconst record = opts.params ?? opts.args;
\tif (!record || clawbbaParamsHaveReferenceImages(record)) return true;
\tconst sk = typeof opts.options?.agentSessionKey === "string" ? opts.options.agentSessionKey.trim() : "";
\tif (!sk) return false;
\tconst maxWaitMs = Number(opts.maxWaitMs) > 0 ? Math.min(Number(opts.maxWaitMs), 180000) : 90000;
\tconst pollMs = Number(opts.pollMs) > 0 ? Math.max(500, Number(opts.pollMs)) : 1500;
\tconst startedAt = Date.now();
\twhile (Date.now() - startedAt <= maxWaitMs) {
\t\tawait clawbbaMaybeMergeSessionReferenceImages({
\t\t\tparams: record,
\t\t\toptions: opts.options,
\t\t\ttool: opts.tool || "image_generate",
\t\t\tmaxCount: opts.maxCount || ${MAX_REFERENCE_IMAGES}
\t\t});
\t\tif (clawbbaParamsHaveReferenceImages(record)) return true;
\t\tawait new Promise((r) => setTimeout(r, pollMs));
\t}
\treturn clawbbaParamsHaveReferenceImages(record);
}
async function clawbbaAssertReferenceImagesIfRequired(opts) {
\tconst record = opts.params ?? opts.args;
\tif (!record || clawbbaParamsHaveReferenceImages(record)) return;
\tconst probeParts = [String(opts.prompt ?? ""), String(record.prompt ?? "")];
\tconst sk = typeof opts.options?.agentSessionKey === "string" ? opts.options.agentSessionKey.trim() : "";
\tif (sk) {
\t\tconst mediaText = await clawbbaFindClawbbaImageTemplateText(sk);
\t\tif (mediaText) probeParts.push(mediaText);
\t}
\tconst needsRef = probeParts.some((t) => clawbbaPromptRequiresReferenceImages(t));
\tif (!needsRef) return;
\tconst resumed = await clawbbaWaitAndMergeReferenceImages({
\t\tparams: record,
\t\toptions: opts.options,
\t\ttool: opts.tool || "image_generate",
\t\tmaxCount: ${MAX_REFERENCE_IMAGES},
\t\tmaxWaitMs: 90000,
\t\tpollMs: 1500
\t});
\tif (resumed) return;
\tthrow new ToolInputError("ClawBBA 检测到本次是参考图/图生图请求：已等待 90 秒仍未收到可用参考图。请上传图片后再试，或继续使用 image_generate action=recover（同 jobId，避免重复扣费）。");
}`
}

const HELPERS_ANCHOR = 'function normalizeReferenceImages(args) {'

const ASSERT_HELPERS_SNIPPET = `function clawbbaPromptRequiresReferenceImages(text) {
\tconst s = String(text ?? "").trim();
\tif (!s) return false;
\t${REFERENCE_PROMPT_ENGLISH_MARKER}
\treturn /参考图|根据参考图|根据图|图生图|垫图|按上传|按参考|同款|以图生|reference\\s+image|based on (the )?reference|from (the )?reference|using (the )?reference/i.test(s);
}
async function clawbbaFindClawbbaImageTemplateText(sessionKey) {
\tconst sk = String(sessionKey ?? "").trim();
\tif (!sk) return "";
\ttry {
\t\tconst rt = await getRuntime();
\t\tconst { storePath, entry } = rt.loadSessionEntry(sk);
\t\tconst sessionId = entry?.sessionId;
\t\tif (!sessionId || !storePath) return "";
\t\tconst msgs = await rt.readSessionMessagesAsync(sessionId, storePath, entry?.sessionFile, { mode: "recent", maxMessages: 24, maxBytes: 512000 });
\t\tfor (let i = msgs.length - 1; i >= 0; i--) {
\t\t\tconst m = msgs[i];
\t\t\tif (m?.role !== "user") continue;
\t\t\tconst t = clawbbaMessageTextFromRecord(m);
\t\t\tif (/请使用\\s*ClawBBA\\s*生成图片/i.test(t)) return t;
\t\t}
\t} catch (_) {}
\treturn "";
}
async function clawbbaWaitAndMergeReferenceImages(opts) {
\t${REFERENCE_WAIT_WINDOW_MARKER}
\tconst record = opts.params ?? opts.args;
\tif (!record || clawbbaParamsHaveReferenceImages(record)) return true;
\tconst sk = typeof opts.options?.agentSessionKey === "string" ? opts.options.agentSessionKey.trim() : "";
\tif (!sk) return false;
\tconst maxWaitMs = Number(opts.maxWaitMs) > 0 ? Math.min(Number(opts.maxWaitMs), 180000) : 90000;
\tconst pollMs = Number(opts.pollMs) > 0 ? Math.max(500, Number(opts.pollMs)) : 1500;
\tconst startedAt = Date.now();
\twhile (Date.now() - startedAt <= maxWaitMs) {
\t\tawait clawbbaMaybeMergeSessionReferenceImages({
\t\t\tparams: record,
\t\t\toptions: opts.options,
\t\t\ttool: opts.tool || "image_generate",
\t\t\tmaxCount: opts.maxCount || ${MAX_REFERENCE_IMAGES}
\t\t});
\t\tif (clawbbaParamsHaveReferenceImages(record)) return true;
\t\tawait new Promise((r) => setTimeout(r, pollMs));
\t}
\treturn clawbbaParamsHaveReferenceImages(record);
}
async function clawbbaAssertReferenceImagesIfRequired(opts) {
\tconst record = opts.params ?? opts.args;
\tif (!record || clawbbaParamsHaveReferenceImages(record)) return;
\tconst probeParts = [String(opts.prompt ?? ""), String(record.prompt ?? "")];
\tconst sk = typeof opts.options?.agentSessionKey === "string" ? opts.options.agentSessionKey.trim() : "";
\tif (sk) {
\t\tconst mediaText = await clawbbaFindClawbbaImageTemplateText(sk);
\t\tif (mediaText) probeParts.push(mediaText);
\t}
\tconst needsRef = probeParts.some((t) => clawbbaPromptRequiresReferenceImages(t));
\tif (!needsRef) return;
\tconst resumed = await clawbbaWaitAndMergeReferenceImages({
\t\tparams: record,
\t\toptions: opts.options,
\t\ttool: opts.tool || "image_generate",
\t\tmaxCount: ${MAX_REFERENCE_IMAGES},
\t\tmaxWaitMs: 90000,
\t\tpollMs: 1500
\t});
\tif (resumed) return;
\tthrow new ToolInputError("ClawBBA 检测到本次是参考图/图生图请求：已等待 90 秒仍未收到可用参考图。请上传图片后再试，或继续使用 image_generate action=recover（同 jobId，避免重复扣费）。");
}
`

/** @param {string} src */
export function upgradeReferencePromptEnglishGuard(src) {
  if (src.includes(REFERENCE_PROMPT_ENGLISH_MARKER)) return src
  const old = '\treturn /参考图|根据参考图|根据图|图生图|垫图|按上传|按参考|同款|以图生/i.test(s);'
  const neu = `\t${REFERENCE_PROMPT_ENGLISH_MARKER}\n\treturn /参考图|根据参考图|根据图|图生图|垫图|按上传|按参考|同款|以图生|reference\\s+image|based on (the )?reference|from (the )?reference|using (the )?reference/i.test(s);`
  if (!src.includes(old)) return src
  return src.replaceAll(old, neu)
}

/** @param {string} src */
export function upgradeReferenceImagePlausibleValidation(src) {
  if (!src.includes(REFERENCE_IMAGES_MARKER)) return src
  let next = src

  if (!next.includes(REFERENCE_PLAUSIBLE_MARKER)) {
    const plausibleFns = `function clawbbaIsPlausibleReferenceImageRef(value) {
\tconst v = String(value ?? "").trim();
\tif (!v || !clawbbaLooksLikeImageRef(v)) return false;
\tif (/^参考图/i.test(v) || /参考图\\s*url/i.test(v)) return false;
\tif (/placeholder|example\\.(com|org|net)\\b|reference[-_]?image\\.(jpg|jpeg|png|webp)/i.test(v)) return false;
\treturn true;
}
function clawbbaCollectPlausibleReferenceImages(record) {
\tconst out = [];
\tconst push = (raw) => {
\t\tconst v = clawbbaResolveOpenClawMediaRefSync(String(raw ?? "").trim());
\t\tif (clawbbaIsPlausibleReferenceImageRef(v) && !out.includes(v)) out.push(v);
\t};
\tif (typeof record?.image === "string") push(record.image);
\tif (Array.isArray(record?.images)) for (const item of record.images) if (typeof item === "string") push(item);
\treturn out;
}
function clawbbaSanitizeReferenceImageParams(record) {
\t${REFERENCE_PLAUSIBLE_MARKER}
\tif (!record || typeof record !== "object") return;
\tconst plausible = clawbbaCollectPlausibleReferenceImages(record);
\tif (typeof record.image === "string" && !clawbbaIsPlausibleReferenceImageRef(record.image)) delete record.image;
\tif (Array.isArray(record.images)) record.images = record.images.filter((v) => typeof v === "string" && clawbbaIsPlausibleReferenceImageRef(v));
\tif (plausible.length > 0) {
\t\trecord.images = plausible.slice(0, ${MAX_REFERENCE_IMAGES});
\t\tif (plausible.length === 1) record.image = plausible[0];
\t}
}
`
    if (!next.includes('function clawbbaIsPlausibleReferenceImageRef')) {
      next = next.replace(
        /function clawbbaParamsHaveReferenceImages\(record\) \{/,
        `${plausibleFns}function clawbbaParamsHaveReferenceImages(record) {`,
      )
    }
    next = next.replace(
      /function clawbbaParamsHaveReferenceImages\(record\) \{\n\tif \(!record \|\| typeof record !== "object"\) return false;\n\tif \(typeof record\.image === "string" && record\.image\.trim\(\)\) return true;\n\treturn Array\.isArray\(record\.images\) && record\.images\.some\(\(v\) => typeof v === "string" && String\(v\)\.trim\(\)\);\n\}/,
      `function clawbbaParamsHaveReferenceImages(record) {
\treturn clawbbaCollectPlausibleReferenceImages(record).length > 0;
}`,
    )
    next = next.replace(
      /async function clawbbaMaybeMergeSessionReferenceImages\(opts\) \{\n\tconst record = opts\.params \?\? opts\.args;\n\tif \(!record \|\| typeof record !== "object" \|\| clawbbaParamsHaveReferenceImages\(record\)\) return;/,
      `async function clawbbaMaybeMergeSessionReferenceImages(opts) {
\tconst record = opts.params ?? opts.args;
\tif (!record || typeof record !== "object") return;
\tclawbbaSanitizeReferenceImageParams(record);
\tif (clawbbaParamsHaveReferenceImages(record)) return;`,
    )
  }

  if (!next.includes('clawbbaSanitizeReferenceImageParams(params)')) {
    next = next.replace(
      /await clawbbaMaybeMergeSessionReferenceImages\(\{ params, options, tool: "image_generate", maxCount: \d+ \}\);/,
      `${IMAGE_REFERENCE_SANITIZE_CALL}\n\t\t\tawait clawbbaMaybeMergeSessionReferenceImages({ params, options, tool: "image_generate", maxCount: ${MAX_REFERENCE_IMAGES} });`,
    )
  }

  return next
}

/** @param {string} src */
export function upgradeReferenceRequiredGuard(src) {
  let next = src
  if (!next.includes(REFERENCE_IMAGES_MARKER)) return next

  if (!next.includes('clawbbaAssertReferenceImagesIfRequired')) {
    if (next.includes(HELPERS_ANCHOR)) {
      next = next.replace(HELPERS_ANCHOR, `${ASSERT_HELPERS_SNIPPET}${HELPERS_ANCHOR}`)
    }
  }

  if (!next.includes('templateIdx + 1')) {
    next = next.replace(
      /\t\t\tfor \(let i = templateIdx - 1; i >= 0 && templateIdx - i <= 5; i--\) \{\n\t\t\t\tconst m = msgs\[i\];\n\t\t\t\tif \(m\?\.role !== "user"\) continue;\n\t\t\t\tfor \(const r of clawbbaExtractImageRefsFromMessage\(m\)\) pushRef\(r\);\n\t\t\t\}\n\t\t\}\n\t\tif \(refs\.length === 0\) return;/,
      `\t\t\tfor (let i = templateIdx - 1; i >= 0 && templateIdx - i <= 5; i--) {
\t\t\t\tconst m = msgs[i];
\t\t\t\tif (m?.role !== "user") continue;
\t\t\t\tfor (const r of clawbbaExtractImageRefsFromMessage(m)) pushRef(r);
\t\t\t}
\t\t\tfor (let i = templateIdx + 1; i < msgs.length && i - templateIdx <= 5; i++) {
\t\t\t\tconst m = msgs[i];
\t\t\t\tif (m?.role !== "user") continue;
\t\t\t\tfor (const r of clawbbaExtractImageRefsFromMessage(m)) pushRef(r);
\t\t\t}
\t\t}
\t\tif (refs.length === 0) return;`,
    )
  }

  if (!next.includes(REFERENCE_REQUIRED_GUARD_MARKER)) {
    next = next.replace(
      /await clawbbaMaybeMergeSessionReferenceImages\(\{ params, options, tool: "image_generate", maxCount: \d+ \}\);\n(\t\t\tconst imageInputs = normalizeReferenceImages\(params\);)/,
      `await clawbbaMaybeMergeSessionReferenceImages({ params, options, tool: "image_generate", maxCount: ${MAX_REFERENCE_IMAGES} });\n${IMAGE_REFERENCE_ASSERT_CALL}\n$1`,
    )
  }

  return next
}

export const IMAGE_REFERENCE_PRE_NORMALIZE_NEEDLE = `\t\t\tconst prompt = readStringParam$1(params, "prompt", { required: true });
\t\t\tconst imageInputs = normalizeReferenceImages(params);`

export const IMAGE_REFERENCE_PRE_NORMALIZE_NEEDLE_V2026528 = `\t\t\tconst imageInputs = normalizeReferenceImages(params);`

export const IMAGE_REFERENCE_PRE_NORMALIZE_REPLACEMENT_LET = `\t\t\tlet prompt = readStringParam$1(params, "prompt", { required: true });
\t\t\t${REFERENCE_IMAGES_MARKER}
${IMAGE_REFERENCE_SANITIZE_CALL}
\t\t\tawait clawbbaMaybeMergeSessionReferenceImages({ params, options, tool: "image_generate", maxCount: ${MAX_REFERENCE_IMAGES} });
${IMAGE_REFERENCE_ASSERT_CALL}
\t\t\tconst imageInputs = normalizeReferenceImages(params);`

export const IMAGE_REFERENCE_PRE_NORMALIZE_REPLACEMENT_ALREADY_LET = `\t\t\tlet prompt = readStringParam$1(params, "prompt", { required: true });
\t\t\t${REFERENCE_IMAGES_MARKER}
${IMAGE_REFERENCE_SANITIZE_CALL}
\t\t\tawait clawbbaMaybeMergeSessionReferenceImages({ params, options, tool: "image_generate", maxCount: ${MAX_REFERENCE_IMAGES} });
${IMAGE_REFERENCE_ASSERT_CALL}
\t\t\tconst imageInputs = normalizeReferenceImages(params);`

export const VIDEO_REFERENCE_DISPATCH_TAIL = `\t\t\t\tif (parsedPrompt && parsedPrompt !== prompt) prompt = parsedPrompt;
\t\t\t\tawait clawbbaMaybeMergeSessionReferenceImages({ args, options, tool: "video_generate", maxCount: ${MAX_REFERENCE_IMAGES} });
\t\t\t})();`

export const VIDEO_REFERENCE_DISPATCH_TAIL_OLD = `\t\t\t\tif (parsedPrompt && parsedPrompt !== prompt) prompt = parsedPrompt;
\t\t\t})();`

export function upgradeReferenceImagesMediaUriResolve(src) {
  if (!src.includes(REFERENCE_IMAGES_MARKER) || src.includes('clawbbaResolveOpenClawMediaRefSync')) return src
  const fn = `function clawbbaResolveOpenClawMediaRefSync(value) {
\tconst v = String(value ?? "").trim();
\tif (!/^media:\\/\\//i.test(v)) return v;
\ttry {
\t\tconst parsed = new URL(v);
\t\tif (parsed.hostname !== "inbound") return v;
\t\tconst id = decodeURIComponent(parsed.pathname.replace(/^\\/+/, ""));
\t\tif (!id || id.includes("/") || id.includes("\\\\")) return v;
\t\treturn path.join(resolveUserPath("~/.openclaw"), "media", "inbound", id);
\t} catch (_) {
\t\treturn v;
\t}
}
`
  let next = src.replace(REFERENCE_IMAGES_MARKER, `${REFERENCE_IMAGES_MARKER}\n${fn}`)
  next = next.replace(
    /function clawbbaLooksLikeImageRef\(value\) \{\n\tconst v = String\(value \?\? ""\)\.trim\(\);\n\tif \(!v\) return false;\n\tif \(/,
    'function clawbbaLooksLikeImageRef(value) {\n\tconst v = String(value ?? "").trim();\n\tif (!v) return false;\n\tif (/^media:\\/\\//i.test(v)) return true;\n\tif (',
  )
  next = next.replace(
    /\tconst push = \(raw\) => \{\n\t\tconst v = String\(raw \?\? ""\)\.trim\(\);/,
    '\tconst push = (raw) => {\n\t\tconst v = clawbbaResolveOpenClawMediaRefSync(String(raw ?? "").trim());',
  )
  next = next.replace(
    /\t\tconst pushRef = \(raw\) => \{\n\t\t\tconst v = String\(raw \?\? ""\)\.trim\(\);/,
    '\t\tconst pushRef = (raw) => {\n\t\t\tconst v = clawbbaResolveOpenClawMediaRefSync(String(raw ?? "").trim());',
  )
  return next
}

export function patchReferenceImagesInToolsFile(filePath) {
  const original = fs.readFileSync(filePath, 'utf8')
  let src = upgradeReferenceImagesMediaUriResolve(original)
  src = upgradeReferenceImagePlausibleValidation(src)
  src = upgradeReferenceRequiredGuard(src)
  const hasHelpers = src.includes(REFERENCE_IMAGES_MARKER) && src.includes('clawbbaMaybeMergeSessionReferenceImages')
  const hasImagePre = src.includes('clawbbaMaybeMergeSessionReferenceImages({ params, options, tool: "image_generate"')

  if (!hasHelpers) {
    if (!src.includes(HELPERS_ANCHOR)) return 'missing-anchor'
    if (src.includes('/* clawbba-module-media-runtime-v1 */') && src.includes('clawbbaMaybeMergeSessionReferenceImages')) {
      // module runtime + ref helpers already present
    } else {
      src = src.replace(HELPERS_ANCHOR, `${buildReferenceImagesHelperSource()}\n${HELPERS_ANCHOR}`)
    }
  }

  if (!hasImagePre) {
    if (src.includes(IMAGE_REFERENCE_PRE_NORMALIZE_REPLACEMENT_ALREADY_LET.split('\n')[0])) {
      // already let prompt from media dispatch
      if (src.includes('\t\t\tconst imageInputs = normalizeReferenceImages(params);')) {
        src = src.replace(
          '\t\t\tconst imageInputs = normalizeReferenceImages(params);',
          `\t\t\t${REFERENCE_IMAGES_MARKER}\n\t\t\tawait clawbbaMaybeMergeSessionReferenceImages({ params, options, tool: "image_generate", maxCount: ${MAX_REFERENCE_IMAGES} });\n\t\t\tconst imageInputs = normalizeReferenceImages(params);`,
        )
      }
    } else if (src.includes(IMAGE_REFERENCE_PRE_NORMALIZE_NEEDLE)) {
      src = src.replace(
        IMAGE_REFERENCE_PRE_NORMALIZE_NEEDLE,
        IMAGE_REFERENCE_PRE_NORMALIZE_REPLACEMENT_LET,
      )
    } else if (src.includes(IMAGE_REFERENCE_PRE_NORMALIZE_NEEDLE_V2026528)) {
      src = src.replace(
        IMAGE_REFERENCE_PRE_NORMALIZE_NEEDLE_V2026528,
        `\t\t\t${REFERENCE_IMAGES_MARKER}\n\t\t\tawait clawbbaMaybeMergeSessionReferenceImages({ params, options, tool: "image_generate", maxCount: ${MAX_REFERENCE_IMAGES} });\n\t\t\tconst imageInputs = normalizeReferenceImages(params);`,
      )
    } else if (
      /\t\t\tconst imageInputs = normalizeReferenceImages\(params\);/.test(src) &&
      !src.includes('clawbbaMaybeMergeSessionReferenceImages({ params, options, tool: "image_generate"')
    ) {
      src = src.replace(
        /\t\t\tconst imageInputs = normalizeReferenceImages\(params\);/,
        `\t\t\t${REFERENCE_IMAGES_MARKER}\n\t\t\tawait clawbbaMaybeMergeSessionReferenceImages({ params, options, tool: "image_generate", maxCount: ${MAX_REFERENCE_IMAGES} });\n\t\t\tconst imageInputs = normalizeReferenceImages(params);`,
      )
    } else {
      return 'missing-image-needle'
    }
  }

  if (src.includes(VIDEO_REFERENCE_DISPATCH_TAIL_OLD) && !src.includes('tool: "video_generate"')) {
    src = src.replace(VIDEO_REFERENCE_DISPATCH_TAIL_OLD, VIDEO_REFERENCE_DISPATCH_TAIL)
  }

  src = upgradeReferencePromptEnglishGuard(src)

  if (src === original) return 'skip'

  fs.writeFileSync(filePath, src)
  if (src.includes(REFERENCE_REQUIRED_GUARD_MARKER) && !original.includes(REFERENCE_REQUIRED_GUARD_MARKER)) {
    return 'upgraded-ref-guard'
  }
  if (hasHelpers && hasImagePre) return 'skip'
  if (hasHelpers) return 'upgraded-video'
  return 'patched'
}
