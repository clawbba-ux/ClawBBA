#!/usr/bin/env node
import assert from 'node:assert/strict'
import {
  WEBCHAT_DIRECT_TRANSCRIPT_MARKER,
  buildDirectTranscriptAppendFnBlock,
  buildWebChatMediaLiveInjectDispatchFn,
  upgradeWebChatDirectTranscriptInject,
} from './clawbba-webchat-live-inject.mjs'

const directBlock = buildDirectTranscriptAppendFnBlock(
  'session-utils-X.js',
  'agent-scope-X.js',
  'transcript.runtime.js',
  'transcript-events-X.js',
)
assert.ok(directBlock.includes('agent-scope-X.js'))
assert.ok(directBlock.includes('resolveSessionAgentId", ["_"]'))
assert.ok(directBlock.includes(WEBCHAT_DIRECT_TRANSCRIPT_MARKER))
assert.ok(directBlock.includes('appendExactAssistantMessageToSessionTranscript'))
assert.ok(directBlock.includes('emitSessionTranscriptUpdate'))

const dispatchBlock = buildWebChatMediaLiveInjectDispatchFn('server-plugins-X.js')
assert.ok(dispatchBlock.includes('clawbbaAppendAssistantTranscriptDirect'))
assert.ok(dispatchBlock.includes('if (!injected)'))

const oldInject = `async function clawbbaDispatchWebChatMediaLiveInject(params) {
\tconst sessionKey = "";
\tconst message = "MEDIA:/tmp/x.png";
\ttry {
\t\tconst pluginsModule = await import("./server-plugins-ABC.js");
\t\tconst dispatchGatewayMethodInProcess = clawbbaPickModuleExport(pluginsModule, "dispatchGatewayMethodInProcess", ["r"]);
\t\tconst injectResult = await dispatchGatewayMethodInProcess("chat.inject", {
\t\t\tsessionKey,
\t\t\tmessage,
\t\t\tlabel: params.label || (params.sourceTool === "video_generate" ? "ClawBBA video" : "ClawBBA image")
\t\t}, { timeoutMs: 3e4 });
\t\tawait clawbbaBroadcastWebChatSessionReload({
\t\t\tsessionKey,
\t\t\tchatRunId: params.chatRunId,
\t\t\tmediaMessage: message,
\t\t\tinjectMessageId: injectResult?.messageId
\t\t});
\t\treturn true;
\t} catch (err) {
\t\ttry {
\t\t\tlog$5.warn("clawbba webchat media live inject failed", { error: String(err?.message ?? err) });
\t\t} catch (_) {}
\t\treturn false;
\t}
}`

const upgraded = upgradeWebChatDirectTranscriptInject(oldInject)
assert.ok(upgraded.includes('clawbbaAppendAssistantTranscriptDirect'))
assert.ok(upgraded.includes('let injected = false'))
assert.ok(upgraded.includes('./server-plugins-ABC.js'))

console.log('test-direct-transcript-inject: ok')
