/**
 * OpenClaw v2：Agent 结构化参数 → image_generate / video_generate（无话术 session 解析）
 */
import fs from 'fs'
import path from 'path'
import { buildOpenClawNormalizeModelFnBlock } from './clawbba-media-model-ref.mjs'
import { resolveReadStringParamIdent } from './openclaw-tools-compat.mjs'
import {
  MEDIA_DISPATCH_V2_MARKER,
  MEDIA_DISPATCH_VIDEO_MARKER,
  injectModuleLevelMediaRuntime,
  MODULE_LEVEL_MEDIA_RUNTIME_MARKER,
  toolsSrcHasModuleLevelMediaRuntime,
  validateFnIsModuleScoped,
} from './clawbba-media-tool-validate.mjs'

export const MEDIA_DISPATCH_MARKER = '/* clawbba-media-dispatch */'
export const MEDIA_DISPATCH_V1_MARKER = '/* clawbba-media-dispatch-v1 */'
export { MEDIA_DISPATCH_VIDEO_MARKER } from './clawbba-media-tool-validate.mjs'
export const MEDIA_DISPATCH_PREFLIGHT_MARKER = '/* clawbba-media-dispatch-preflight */'
const NORMALIZE_FN_MARKER = 'clawbbaToOpenClawMediaModel'

export function buildImageGenerateDispatchBlock() {
  return `${MEDIA_DISPATCH_MARKER}
\t\t\t${MEDIA_DISPATCH_V2_MARKER}
\t\t\tawait (async () => {
\t\t\t\tconst __r = await clawbbaValidateImageGenerateParams({
\t\t\t\t\tparams,
\t\t\t\t\toptions,
\t\t\t\t\tmodel,
\t\t\t\t\taspectRatio,
\t\t\t\t\tresolution: explicitResolution,
\t\t\t\t\tprompt,
\t\t\t\t\tnormalizeAspectRatioFn: normalizeAspectRatio$1,
\t\t\t\t\tnormalizeResolutionFn: normalizeResolution$1
\t\t\t\t});
\t\t\t\tmodel = __r.model;
\t\t\t\taspectRatio = __r.aspectRatio;
\t\t\t\texplicitResolution = __r.resolution ?? explicitResolution;
\t\t\t\tprompt = __r.prompt;
\t\t\t})();`
}

export function buildVideoGenerateDispatchBlock() {
  return `${MEDIA_DISPATCH_MARKER}
\t\t\t${MEDIA_DISPATCH_VIDEO_MARKER}
\t\t\t${MEDIA_DISPATCH_V2_MARKER}
\t\t\tawait (async () => {
\t\t\t\tconst __r = await clawbbaValidateVideoGenerateParams({
\t\t\t\t\tparams: args,
\t\t\t\t\toptions,
\t\t\t\t\tmodel,
\t\t\t\t\taspectRatio,
\t\t\t\t\tdurationSeconds,
\t\t\t\t\tprompt,
\t\t\t\t\tnormalizeAspectRatioFn: normalizeAspectRatio
\t\t\t\t});
\t\t\t\tmodel = __r.model;
\t\t\t\taspectRatio = __r.aspectRatio;
\t\t\t\tdurationSeconds = __r.durationSeconds ?? durationSeconds;
\t\t\t\tprompt = __r.prompt;
\t\t\t})();`
}

function readStringParamCallForFile(suffix, toolsSrc) {
  const ident = resolveReadStringParamIdent(toolsSrc)
  if (ident === 'readStringParam') return 'readStringParam'
  return suffix ? 'readStringParam$1' : 'readStringParam'
}

function imageDispatchIsV2(src) {
  return src.includes(MEDIA_DISPATCH_V2_MARKER) && toolsSrcHasModuleLevelMediaRuntime(src)
}

function videoDispatchIsHealthy(src) {
  return src.includes(MEDIA_DISPATCH_VIDEO_MARKER) && validateFnIsModuleScoped(src)
}

function finalizeVideoDispatchPatch(src) {
  let out = injectModuleLevelMediaRuntime(src)
  out = injectNormalizeFnBeforeMediaDispatch(out)
  return out
}

function patchImageGenerateMediaDispatchNeedles(src, toolsSrc = src) {
  let out = src
  let changed = false
  if (imageDispatchIsV2(out)) return { src: out, changed: false }

  const freshBlockRe =
    /\t\t\tconst prompt = readStringParam(\$1)?\(params, "prompt", \{ required: true \}\);\n\t\t\tconst activeDuplicateGuardResult = createImageGenerateDuplicateGuardResult\(options\?\.agentSessionKey, \{ prompt \}\);\n\t\t\tif \(activeDuplicateGuardResult\) return activeDuplicateGuardResult;\n\t\t\tconst imageInputs = normalizeReferenceImages\(params\);\n\t\t\tconst model = readStringParam(\$1)?\(params, "model"\);\n\t\t\tconst filename = readStringParam(\$1)?\(params, "filename"\);\n\t\t\tconst size = readStringParam(\$1)?\(params, "size"\);\n\t\t\tconst aspectRatio = normalizeAspectRatio\$1\(readStringParam(\$1)?\(params, "aspectRatio"\)\);\n\t\t\tconst explicitResolution = normalizeResolution\$1\(readStringParam(\$1)?\(params, "resolution"\)\);/

  if (freshBlockRe.test(out)) {
    out = out.replace(freshBlockRe, (_m, suffix) => {
      changed = true
      const rs = readStringParamCallForFile(suffix, toolsSrc)
      return `\t\t\tlet prompt = ${rs}(params, "prompt");
\t\t\tlet model = ${rs}(params, "model");
\t\t\tlet aspectRatio = normalizeAspectRatio$1(${rs}(params, "aspectRatio"));
\t\t\tlet explicitResolution = normalizeResolution$1(${rs}(params, "resolution"));
${buildImageGenerateDispatchBlock()}
\t\t\tconst imageInputs = normalizeReferenceImages(params);
\t\t\tconst filename = ${rs}(params, "filename");
\t\t\tconst size = ${rs}(params, "size");`
    })
  }

  return { src: out, changed }
}

function patchVideoGenerateMediaDispatchNeedles(src, toolsSrc = src) {
  let out = src
  let changed = false

  const freshVideoRe =
    /\t\t\tconst prompt = readStringParam(\$1)?\(args, "prompt", \{ required: true \}\);\n\t\t\tconst activeDuplicateGuardResult = createVideoGenerateDuplicateGuardResult\(options\?\.agentSessionKey\);\n\t\t\tif \(activeDuplicateGuardResult\) return activeDuplicateGuardResult;\n\t\t\tconst model = readStringParam(\$1)?\(args, "model"\);\n\t\t\tconst filename = readStringParam(\$1)?\(args, "filename"\);\n\t\t\tconst size = readStringParam(\$1)?\(args, "size"\);\n\t\t\tconst aspectRatio = normalizeAspectRatio\(readStringParam(\$1)?\(args, "aspectRatio"\)\);\n\t\t\tconst resolution = normalizeResolution\(readStringParam(\$1)?\(args, "resolution"\)\);\n\t\t\tconst durationSeconds = readNumberParam\(args, "durationSeconds", \{\n\t\t\t\tpositiveInteger: true,\n\t\t\t\tstrict: true\n\t\t\t\}\);\n\t\t\tif \(durationSeconds === void 0 && readSnakeCaseParamRaw\(args, "durationSeconds"\) !== void 0\) throw new ToolInputError\("durationSeconds must be a positive integer"\);/

  if (freshVideoRe.test(out) && !out.includes(MEDIA_DISPATCH_VIDEO_MARKER)) {
    out = out.replace(freshVideoRe, (_m, suffix) => {
      changed = true
      const rs = readStringParamCallForFile(suffix, toolsSrc)
      return `\t\t\tlet prompt = ${rs}(args, "prompt");
\t\t\tlet model = ${rs}(args, "model");
\t\t\tlet aspectRatio = normalizeAspectRatio(${rs}(args, "aspectRatio"));
\t\t\tconst resolution = normalizeResolution(${rs}(args, "resolution"));
\t\t\tlet durationSeconds = readNumberParam(args, "durationSeconds", {
\t\t\t\tpositiveInteger: true,
\t\t\t\tstrict: true
\t\t\t});
\t\t\tif (durationSeconds === void 0 && readSnakeCaseParamRaw(args, "durationSeconds") !== void 0) throw new ToolInputError("durationSeconds must be a positive integer");
\t\t\tconst filename = ${rs}(args, "filename");
\t\t\tconst size = ${rs}(args, "size");
${buildVideoGenerateDispatchBlock()}`
    })
  }

  return { src: out, changed }
}

/** 已 patch 的 dist 若缺 size/filename 声明会导致 ReferenceError: size is not defined */
export function upgradeVideoDispatchMissingSizeFilename(src) {
  if (!src.includes(MEDIA_DISPATCH_VIDEO_MARKER)) return src
  const markerIdx = src.indexOf(MEDIA_DISPATCH_VIDEO_MARKER)
  const requestKeyIdx = src.indexOf('buildMediaGenerationRequestKey', markerIdx)
  if (requestKeyIdx < 0) return src
  const executeStart = src.lastIndexOf('execute: async (_toolCallId, rawArgs)', markerIdx)
  const searchFrom = executeStart >= 0 ? executeStart : Math.max(0, markerIdx - 4000)
  const chunk = src.slice(searchFrom, requestKeyIdx)
  if (/\b(?:const|let) size = readStringParam\(args, "size"\)/.test(chunk)) return src

  const beforeDispatch =
    /\t\t\tif \(durationSeconds === void 0 && readSnakeCaseParamRaw\(args, "durationSeconds"\) !== void 0\) throw new ToolInputError\("durationSeconds must be a positive integer"\);\n(\/\* clawbba-media-dispatch \*\/)/ 
  if (beforeDispatch.test(src)) {
    return src.replace(
      beforeDispatch,
      `\t\t\tif (durationSeconds === void 0 && readSnakeCaseParamRaw(args, "durationSeconds") !== void 0) throw new ToolInputError("durationSeconds must be a positive integer");
\t\t\tconst filename = readStringParam(args, "filename");
\t\t\tconst size = readStringParam(args, "size");
$1`,
    )
  }

  return src
}

/** 仅注入 v2 validate runtime（供测试 / 旧引用） */
export function upgradeMediaDispatchToV2(src) {
  return injectModuleLevelMediaRuntime(src)
}

export function upgradeMediaDispatchToParamsV1(src) {
  return upgradeMediaDispatchToV2(src)
}

export function upgradeMediaDispatchV1NoTDZ(src) {
  return src
}

export function upgradeMediaDispatchMediaTextGuard(src) {
  return src
}

export function upgradeMediaDispatchPreflight(src) {
  return src
}

export function upgradeMediaDispatchPromptGuardOrder(src) {
  return src
}

export function upgradeMediaDispatchIntentFilters(src) {
  return src
}

export function upgradeMediaDispatchModelAssign(src) {
  return src
}

/** 避免 let resolution 与下游 const resolution 冲突 */
export function upgradeMediaDispatchImageResolutionDecl(src) {
  let out = src
  out = out.replace(
    /\t\t\tlet resolution = normalizeResolution\$1\(readStringParam\(params, "resolution"\)\);/g,
    '\t\t\tlet explicitResolution = normalizeResolution$1(readStringParam(params, "resolution"));',
  )
  out = out.replace(
    /resolution: resolution,\n(\t\t\t\t\tnormalizeAspectRatioFn: normalizeAspectRatio\$1)/g,
    'resolution: explicitResolution,\n$1',
  )
  out = out.replace(
    /\t\t\t\tresolution = __r\.resolution;/g,
    '\t\t\t\texplicitResolution = __r.resolution ?? explicitResolution;',
  )
  const dupExplicit =
    /\t\t\tlet explicitResolution = normalizeResolution\$1\(readStringParam\(params, "resolution"\)\);\n[\s\S]*?\t\t\tconst imageInputs = normalizeReferenceImages\(params\);\n\t\t\tconst explicitResolution = normalizeResolution\$1\(readStringParam\(params, "resolution"\)\);/
  if (dupExplicit.test(out)) {
    out = out.replace(dupExplicit, (m) => m.replace(/\n\t\t\tconst explicitResolution = normalizeResolution\$1\(readStringParam\(params, "resolution"\)\);/, ''))
  }
  return out
}

export function injectNormalizeFnBeforeMediaDispatch(src) {
  if (src.includes(MODULE_LEVEL_MEDIA_RUNTIME_MARKER)) return src
  if (src.includes(NORMALIZE_FN_MARKER)) return src
  const block = buildOpenClawNormalizeModelFnBlock()
  const idx = src.indexOf(MEDIA_DISPATCH_MARKER)
  if (idx < 0) return src
  return `${src.slice(0, idx)}${block}\n${src.slice(idx)}`
}

function finalizeImageDispatchPatch(src) {
  let out = injectModuleLevelMediaRuntime(src)
  out = injectNormalizeFnBeforeMediaDispatch(out)
  out = upgradeMediaDispatchImageResolutionDecl(out)
  return out
}

export function patchImageGenerateMediaDispatch(filePath) {
  let src = fs.readFileSync(filePath, 'utf8')
  if (imageDispatchIsV2(src)) return 'skip'

  const { src: patched, changed } = patchImageGenerateMediaDispatchNeedles(src, src)
  let out = finalizeImageDispatchPatch(patched)

  if (!out.includes(MEDIA_DISPATCH_MARKER) || !imageDispatchIsV2(out)) {
    throw new Error(`image_generate media dispatch not injected in ${path.basename(filePath)}`)
  }
  if (changed || out !== src) {
    fs.writeFileSync(filePath, out)
    return 'patched'
  }
  return 'skip'
}

export const MEDIA_DISPATCH_HEADERS_MARKER = '/* clawbba-media-dispatch-headers-v2 */'
export const MEDIA_DISPATCH_HEADERS_V1_MARKER = '/* clawbba-media-dispatch-headers */'

function findOpenRouterImageProviderFile(dist) {
  return fs.readdirSync(dist).find((name) => {
    if (!name.startsWith('image-generation-provider-') || !name.endsWith('.js')) return false
    const src = fs.readFileSync(path.join(dist, name), 'utf8')
    return (
      src.includes('function buildImageConfig(req, model)') &&
      src.includes('async generateImage(req)') &&
      src.includes('postJsonRequest')
    )
  })
}

/** Flux 等非 Gemini 模型也发送 image_config.aspect_ratio（官方仅 Gemini 写入） */
export function patchOpenRouterImageProviderAspect(dist) {
  const file = findOpenRouterImageProviderFile(dist)
  if (!file) return 'missing'
  const filePath = path.join(dist, file)
  let src = fs.readFileSync(filePath, 'utf8')
  const patchedFn = `function buildImageConfig(req, model) {
\t${MEDIA_DISPATCH_MARKER}
\tconst imageConfig = {};
\tconst aspectRatio = normalizeOptionalString(req.aspectRatio);
\tif (aspectRatio) imageConfig.aspect_ratio = aspectRatio;
\tconst resolution = normalizeOptionalString(req.resolution);
\tif (resolution) imageConfig.image_size = resolution;
\treturn imageConfig;
}`
  if (src.includes(`${MEDIA_DISPATCH_MARKER}\n\tconst imageConfig`)) return 'skip'

  const geminiOnly =
    /function buildImageConfig\(req, model\) \{\n\tif \(!isGeminiImageModel\(model\)\) return \{\};\n\tconst imageConfig = \{\};[\s\S]*?\n\treturn imageConfig;\n\}/
  if (geminiOnly.test(src)) {
    src = src.replace(geminiOnly, patchedFn)
    fs.writeFileSync(filePath, src)
    return 'patched'
  }
  return 'missing'
}

/** 生图 POST 必须带 Content-Type + ClawBBA 意图头（Platform express.json 依赖） */
export function patchOpenRouterImageProviderHeaders(dist) {
  const file = findOpenRouterImageProviderFile(dist)
  if (!file) return 'missing'
  const filePath = path.join(dist, file)
  let src = fs.readFileSync(filePath, 'utf8')
  if (src.includes(MEDIA_DISPATCH_HEADERS_MARKER)) return 'skip'

  const headersBlock = `\t\t\t${MEDIA_DISPATCH_HEADERS_V1_MARKER}
\t\t\t${MEDIA_DISPATCH_HEADERS_MARKER}
\t\t\tconst clawbbaAspectHdr = normalizeOptionalString(req.aspectRatio);
\t\t\tconst clawbbaResHdr = normalizeOptionalString(req.resolution);
\t\t\tconst __clawbbaMergedImgHeaders = new Headers(headers);
\t\t\t__clawbbaMergedImgHeaders.set("Content-Type", "application/json");
\t\t\tif (model) __clawbbaMergedImgHeaders.set("X-ClawBBA-Image-Model", model);
\t\t\tif (clawbbaAspectHdr) __clawbbaMergedImgHeaders.set("X-ClawBBA-Image-Aspect", clawbbaAspectHdr);
\t\t\tif (clawbbaResHdr) __clawbbaMergedImgHeaders.set("X-ClawBBA-Image-Resolution", clawbbaResHdr);
\t\t\tconst __clawbbaOrHdr = req.cfg?.models?.providers?.openrouter?.headers;
\t\t\tif (__clawbbaOrHdr && typeof __clawbbaOrHdr === "object") {
\t\t\t\tfor (const [__k, __v] of Object.entries(__clawbbaOrHdr)) {
\t\t\t\t\tif (typeof __v === "string" && __v.trim()) __clawbbaMergedImgHeaders.set(__k, __v.trim());
\t\t\t\t}
\t\t\t}`

  const postNeedle = `\t\t\tconst { response, release } = await postJsonRequest({
\t\t\t\turl: \`\${baseUrl}/chat/completions\`,
\t\t\t\theaders,`
  const postPatched = `\t\t\tconst { response, release } = await postJsonRequest({
\t\t\t\turl: \`\${baseUrl}/chat/completions\`,
\t\t\t\theaders: __clawbbaMergedImgHeaders,`

  if (src.includes(postNeedle) && !src.includes('__clawbbaMergedImgHeaders')) {
    const closeResolve = `\t\t\t\ttransport: "http"
\t\t\t});`
    if (!src.includes(closeResolve)) return 'missing'
    src = src.replace(closeResolve, `${closeResolve}\n${headersBlock}`)
    src = src.replace(postNeedle, postPatched)
    fs.writeFileSync(filePath, src)
    return 'patched'
  }

  if (src.includes('headers: __clawbbaMergedImgHeaders') && !src.includes(MEDIA_DISPATCH_HEADERS_MARKER)) {
    src = src.replace(
      /\t\t\tconst __clawbbaMergedImgHeaders = new Headers\(headers\);/,
      `${MEDIA_DISPATCH_HEADERS_V1_MARKER}\n\t\t\t${MEDIA_DISPATCH_HEADERS_MARKER}\n\t\t\tconst __clawbbaMergedImgHeaders = new Headers(headers);`,
    )
    fs.writeFileSync(filePath, src)
    return 'upgraded-headers-marker'
  }

  return 'missing'
}

export function patchVideoGenerateMediaDispatch(filePath) {
  let src = fs.readFileSync(filePath, 'utf8')
  let out = upgradeVideoDispatchMissingSizeFilename(src)
  let changed = out !== src

  if (!videoDispatchIsHealthy(out)) {
    if (!out.includes(MEDIA_DISPATCH_VIDEO_MARKER)) {
      const needle = patchVideoGenerateMediaDispatchNeedles(out, out)
      out = needle.src
      changed = changed || needle.changed
    }
    out = finalizeVideoDispatchPatch(out)
    out = upgradeVideoDispatchMissingSizeFilename(out)
    changed = changed || out !== src
    if (!videoDispatchIsHealthy(out)) {
      throw new Error(`video_generate media dispatch not injected in ${path.basename(filePath)}`)
    }
  }

  if (changed) {
    fs.writeFileSync(filePath, out)
    if (!src.includes(MEDIA_DISPATCH_VIDEO_MARKER) && out.includes(MEDIA_DISPATCH_VIDEO_MARKER)) {
      return 'patched'
    }
    if (!/\b(?:const|let) size = readStringParam\(args, "size"\)/.test(src) &&
      /\b(?:const|let) size = readStringParam\(args, "size"\)/.test(out)) {
      return 'upgraded-video-size-filename'
    }
    return 'upgraded-video-validate'
  }
  return 'skip'
}
