/**
 * ClawBBA v2 — 薄 runtime：校验 Agent 填入的 image_generate / video_generate 参数（无话术/session 覆盖）
 */
import fs from 'node:fs'
import path from 'node:path'
import { OPENCLAW_IMAGE_ASPECT_RATIOS, OPENCLAW_IMAGE_RESOLUTIONS, IMAGE_RESOLUTION_ALIASES } from './clawbba-media-params-enums.mjs'
import { buildModuleLevelOpenClawMediaModelResolveBlock } from './clawbba-media-model-aliases.mjs'
import { clawbbaDebugLog } from './clawbba-debug-log.mjs'
import { videoValidateRuntimeIsBroken } from './clawbba-video-validate-health.mjs'
import {
  removeMisplacedModuleRuntimeMarkers,
  stripModuleLevelMediaRuntimeBlockSafe,
  upgradeVideoValidateRuntimeInPlace,
  videoValidateNeedsInPlaceUpgrade,
} from './clawbba-openclaw-tools-integrity.mjs'

export const MEDIA_PARAMS_V2_MARKER = '/* clawbba-media-params-v2 */'
export const MEDIA_DISPATCH_V2_MARKER = '/* clawbba-media-dispatch-v2 */'
export const MEDIA_DISPATCH_VIDEO_MARKER = '/* clawbba-media-dispatch-video */'
export const MODULE_LEVEL_MEDIA_RUNTIME_MARKER = '/* clawbba-module-media-runtime-v1 */'

const MODULE_INSERT_ANCHORS = [
  '\nfunction createImageGenerateTool(',
  '\nfunction createVideoGenerateTool(',
]

/** @param {{ params?: Record<string, unknown>; durationSeconds?: unknown }} ctx */
export function resolveVideoDurationSeconds(ctx) {
  const { params, durationSeconds: fromCtx } = ctx ?? {}
  if (fromCtx != null && fromCtx !== '') return fromCtx
  if (!params || typeof params !== 'object') return undefined
  const raw = params.durationSeconds ?? params.duration_seconds
  if (typeof raw === 'number' && Number.isFinite(raw) && raw > 0) return Math.trunc(raw)
  if (typeof raw === 'string') {
    const t = raw.trim()
    if (/^[1-9]\d*$/.test(t)) return Number(t)
  }
  return undefined
}

/** 注入 openclaw-tools：参数校验 + 参考图合并（不解析会话话术） */
export function buildClawbbaMediaToolValidateRuntimeBlock() {
  const resEnum = JSON.stringify(OPENCLAW_IMAGE_RESOLUTIONS)
  const aspEnum = OPENCLAW_IMAGE_ASPECT_RATIOS.join(', ')
  const resAlias = JSON.stringify(IMAGE_RESOLUTION_ALIASES)
  return `${MEDIA_PARAMS_V2_MARKER}
const __CLAWBBA_IMG_RES = ${resEnum};
const __CLAWBBA_IMG_ASP = ${JSON.stringify(OPENCLAW_IMAGE_ASPECT_RATIOS)};
const __CLAWBBA_IMG_RES_ALIAS = ${resAlias};
function clawbbaNormalizeImageResolutionInput(raw) {
\tconst s = String(raw ?? "").trim().toUpperCase();
\tif (!s) return null;
\tif (__CLAWBBA_IMG_RES.includes(s)) return s;
\treturn __CLAWBBA_IMG_RES_ALIAS[s] ?? null;
}
async function clawbbaValidateImageGenerateParams(ctx) {
\tconst { params, options, normalizeAspectRatioFn, normalizeResolutionFn } = ctx;
\tlet { model, aspectRatio, resolution, prompt } = ctx;
\tif (!String(prompt ?? "").trim()) {
\t\tthrow new ToolInputError("image_generate 缺少 prompt（画面描述）。prompt 须写入用户在本轮对话中的生成意图，勿仅用模型自编的通用英文套话。");
\t}
\tif (model) {
\t\tconst __nm = clawbbaToOpenClawMediaModel(model);
\t\tif (__nm) model = __nm;
\t\telse throw new ToolInputError("image_generate.model 无效：使用 openrouter/<vendor/model>（如 openrouter/black-forest-labs/flux.2-pro），或短名 flux.2-pro / black-forest-labs/flux.2-pro。勿用 clawbba/ 前缀。");
\t}
\tif (aspectRatio) {
\t\tconst n = normalizeAspectRatioFn(aspectRatio);
\t\tif (!n) throw new ToolInputError("aspectRatio 无效。允许值: ${aspEnum}");
\t\taspectRatio = n;
\t}
\tif (resolution) {
\t\tconst mapped = clawbbaNormalizeImageResolutionInput(resolution);
\t\tif (mapped === null) throw new ToolInputError('resolution 须为 1K、2K 或 4K（或 720P→1K、1080P→2K）');
\t\tresolution = normalizeResolutionFn(mapped);
\t}
\tawait clawbbaMaybeMergeSessionReferenceImages({ params, options, tool: "image_generate", maxCount: 5 });
\tif (params && typeof params === "object") {
\t\tif (model) params.model = model;
\t\tif (aspectRatio) params.aspectRatio = aspectRatio;
\t\tif (resolution) params.resolution = resolution;
\t\tif (prompt) params.prompt = prompt;
\t}
\treturn { model, aspectRatio, resolution, prompt };
}
function clawbbaResolveVideoDurationSeconds(ctx) {
\tconst { params, durationSeconds: fromCtx } = ctx ?? {};
\tif (fromCtx != null && fromCtx !== "") return fromCtx;
\tif (!params || typeof params !== "object") return void 0;
\tconst raw = params.durationSeconds ?? params.duration_seconds;
\tif (typeof raw === "number" && Number.isFinite(raw) && raw > 0) return Math.trunc(raw);
\tif (typeof raw === "string") {
\t\tconst t = raw.trim();
\t\tif (/^[1-9]\\d*$/.test(t)) return Number(t);
\t}
\treturn void 0;
}
async function clawbbaValidateVideoGenerateParams(ctx) {
\tconst { params, options, normalizeAspectRatioFn } = ctx;
\tlet { model, aspectRatio, prompt } = ctx;
\tlet durationSeconds = clawbbaResolveVideoDurationSeconds(ctx);
\tif (!String(prompt ?? params?.prompt ?? "").trim()) {
\t\tthrow new ToolInputError("video_generate 缺少 prompt（画面描述）。");
\t}
\tif (!String(prompt ?? "").trim() && params && typeof params === "object") {
\t\tprompt = String(params.prompt ?? "").trim();
\t}
\tif (durationSeconds == null || durationSeconds === "") {
\t\tthrow new ToolInputError("video_generate 缺少 durationSeconds（时长，秒）。");
\t}
\tif (model) {
\t\tconst __nm = clawbbaToOpenClawMediaModel(model);
\t\tif (__nm) model = __nm;
\t\telse throw new ToolInputError("video_generate.model 须为 openrouter/<vendor/model>。");
\t}
\tif (aspectRatio) {
\t\tconst n = normalizeAspectRatioFn(aspectRatio);
\t\tif (n) aspectRatio = n;
\t}
\tawait clawbbaMaybeMergeSessionReferenceImages({ params: params, options, tool: "video_generate", maxCount: 5 });
\tif (params && typeof params === "object") {
\t\tif (model) params.model = model;
\t\tif (aspectRatio) params.aspectRatio = aspectRatio;
\t\tif (durationSeconds != null) params.durationSeconds = durationSeconds;
\t\tif (prompt) params.prompt = prompt;
\t}
\treturn { model, aspectRatio, durationSeconds, prompt };
}`
}

export function srcHasModuleLevelModelResolve(src) {
  const imgTool = src.indexOf('function createImageGenerateTool(')
  for (const needle of ['function clawbbaToOpenClawMediaModel(', 'const __CLAWBBA_MODEL_ALIASES']) {
    const idx = src.indexOf(needle)
    if (idx < 0) continue
    if (imgTool < 0 || idx < imgTool) return true
  }
  return false
}

export function buildModuleLevelMediaRuntimeBlock(src = '') {
  const modelPart = srcHasModuleLevelModelResolve(src) ? '' : `${buildModuleLevelOpenClawMediaModelResolveBlock()}\n`
  const validatePart = validateFnIsModuleScoped(src) ? '' : buildClawbbaMediaToolValidateRuntimeBlock()
  if (!modelPart && !validatePart) return ''
  return `${MODULE_LEVEL_MEDIA_RUNTIME_MARKER}\n${modelPart}${validatePart}`.replace(/\n+$/, '\n')
}

export const CLAWBBA_VALIDATE_IMAGE_FN = 'async function clawbbaValidateImageGenerateParams'
export const CLAWBBA_VALIDATE_VIDEO_FN = 'async function clawbbaValidateVideoGenerateParams'

/** @param {string} src */
export function findModuleLevelMediaRuntimeInsertPoint(src) {
  for (const anchor of MODULE_INSERT_ANCHORS) {
    let idx = src.indexOf(anchor)
    if (idx >= 0) return idx + 1
    const bare = anchor.trimStart()
    idx = src.indexOf(bare)
    if (idx === 0 || (idx > 0 && src[idx - 1] === '\n')) return idx
  }
  return -1
}

/** validate 须在 createImageGenerateTool 之前，video_generate 才能访问 */
export function validateFnIsModuleScoped(src) {
  const imgToolIdx = src.indexOf('function createImageGenerateTool(')
  const videoFnIdx = src.indexOf(CLAWBBA_VALIDATE_VIDEO_FN)
  const imageFnIdx = src.indexOf(CLAWBBA_VALIDATE_IMAGE_FN)
  if (imgToolIdx < 0) return false
  if (videoFnIdx < 0 || imageFnIdx < 0) return false
  return videoFnIdx < imgToolIdx && imageFnIdx < imgToolIdx
}

/** @param {string} src */
export function toolsSrcHasModuleLevelMediaRuntime(src) {
  const markerIdx = src.indexOf(MODULE_LEVEL_MEDIA_RUNTIME_MARKER)
  const imgToolIdx = src.indexOf('function createImageGenerateTool(')
  return markerIdx >= 0 && imgToolIdx > markerIdx && validateFnIsModuleScoped(src)
}

/** @param {string} src */
export function toolsSrcHasMediaParamsV2(src) {
  return toolsSrcHasModuleLevelMediaRuntime(src)
}

/** @param {string} src */
export function stripModuleLevelMediaRuntimeBlock(src) {
  return stripModuleLevelMediaRuntimeBlockSafe(src)
}

/** @param {string} src */
export function injectModuleLevelMediaRuntime(src) {
  let base = removeMisplacedModuleRuntimeMarkers(src)
  if (videoValidateNeedsInPlaceUpgrade(base)) {
    base = upgradeVideoValidateRuntimeInPlace(base)
    if (toolsSrcHasModuleLevelMediaRuntime(base) && !videoValidateRuntimeIsBroken(base)) return base
  }
  if (toolsSrcHasModuleLevelMediaRuntime(base) && !videoValidateRuntimeIsBroken(base)) return base
  if (toolsSrcHasModuleLevelMediaRuntime(base) && videoValidateRuntimeIsBroken(base)) {
    base = stripModuleLevelMediaRuntimeBlockSafe(base)
  }
  const block = buildModuleLevelMediaRuntimeBlock(base)
  if (!block) return base
  const insertAt = findModuleLevelMediaRuntimeInsertPoint(base)
  if (insertAt < 0) return base
  return `${base.slice(0, insertAt)}${block}${base.slice(insertAt)}`
}

/** @param {string} src */
export function injectMediaToolValidateRuntime(src) {
  return injectModuleLevelMediaRuntime(src)
}

/** 补全缺失的 v2 校验 runtime（不依赖 dispatch needle 是否匹配） */
export function ensureMediaToolValidateRuntime(filePath) {
  let src = fs.readFileSync(filePath, 'utf8')
  const moduleScoped = toolsSrcHasModuleLevelMediaRuntime(src)
  const videoDispatch =
    src.includes(MEDIA_DISPATCH_VIDEO_MARKER) || /await clawbbaValidateVideoGenerateParams\s*\(/.test(src)
  // #region agent log
  clawbbaDebugLog({
    hypothesisId: 'E',
    location: 'clawbba-media-tool-validate.mjs:ensureMediaToolValidateRuntime',
    message: 'ensure entry',
    data: {
      file: path.basename(filePath),
      moduleScoped,
      videoDispatch,
      validateFnIsModuleScoped: validateFnIsModuleScoped(src),
      hasVideoFn: src.includes(CLAWBBA_VALIDATE_VIDEO_FN),
    },
    runId: process.env.CLAWBBA_DEBUG_RUN_ID || 'ensure',
  })
  // #endregion
  if (moduleScoped && !videoValidateRuntimeIsBroken(src)) return 'skip'
  const out = injectModuleLevelMediaRuntime(src)
  if (out === src) {
    // #region agent log
    clawbbaDebugLog({
      hypothesisId: 'E',
      location: 'clawbba-media-tool-validate.mjs:ensureMediaToolValidateRuntime',
      message: 'missing anchor — no change',
      data: { file: path.basename(filePath) },
      runId: process.env.CLAWBBA_DEBUG_RUN_ID || 'ensure',
    })
    // #endregion
    return 'missing-anchor'
  }
  fs.writeFileSync(filePath, out)
  const result = toolsSrcHasModuleLevelMediaRuntime(out)
    ? videoDispatch
      ? 'upgraded-module-video-validate'
      : 'upgraded-module-validate'
    : 'upgraded-partial'
  // #region agent log
  clawbbaDebugLog({
    hypothesisId: 'E',
    location: 'clawbba-media-tool-validate.mjs:ensureMediaToolValidateRuntime',
    message: 'ensure wrote file',
    data: {
      file: path.basename(filePath),
      result,
      moduleScoped: toolsSrcHasModuleLevelMediaRuntime(out),
    },
    runId: process.env.CLAWBBA_DEBUG_RUN_ID || 'ensure',
  })
  // #endregion
  return result
}
