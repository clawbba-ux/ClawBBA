#!/usr/bin/env node
import assert from 'node:assert/strict'
import {
  promptRequiresReferenceImages,
  REFERENCE_REQUIRED_GUARD_MARKER,
  upgradeReferenceRequiredGuard,
} from './clawbba-reference-images.mjs'

const tpl =
  '请使用 ClawBBA 生成图片能力，模型 google/gemini-2.5-flash-image，为我生成 9:16 请根据参考图生成丰富的电商详情图'

assert.equal(promptRequiresReferenceImages(tpl), true)
assert.equal(promptRequiresReferenceImages('请使用 ClawBBA 生成图片能力，为我生成 16:9 风景'), false)

const oldInject = `\t\t\tawait clawbbaMaybeMergeSessionReferenceImages({ params, options, tool: "image_generate", maxCount: 5 });
\t\t\tconst imageInputs = normalizeReferenceImages(params);`

const upgraded = upgradeReferenceRequiredGuard(
  `/* clawbba-reference-images */\nfunction normalizeReferenceImages(args) {}\n${oldInject}`,
)
assert.ok(upgraded.includes(REFERENCE_REQUIRED_GUARD_MARKER))
assert.ok(upgraded.includes('clawbbaAssertReferenceImagesIfRequired'))

console.log('test-reference-required-guard: ok')
