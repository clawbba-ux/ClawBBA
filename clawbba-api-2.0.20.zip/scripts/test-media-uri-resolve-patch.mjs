#!/usr/bin/env node
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import {
  patchMediaUriResolveInToolsFile,
  runnerMediaUriResolveIsHealthy,
  toolsMediaUriResolveIsHealthy,
} from './clawbba-media-uri-resolve-patch.mjs'
import { findMediaUnderstandingRunnerFile } from './openclaw-dist-paths.mjs'

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'clawbba-media-uri-'))
fs.writeFileSync(
  path.join(tmp, 'media-reference-X.js'),
  'export { resolveMediaReferenceLocalPath as a, classifyMediaReferenceSource as n, normalizeMediaReferenceSource as r };',
)
const toolsSrc = `import { n as classifyMediaReferenceSource, r as normalizeMediaReferenceSource } from "./media-reference-X.js";
function createImageTool() {}
async function loadReferenceImages$1(params) {
  const resolvedImage = (() => {
    if (params.sandboxConfig) return imageRaw;
    return imageRaw;
  })();
}
function run() {
  const imageInputs = [];
  if (imageInputs.length === 0) throw new Error("image required");
  const maxImagesRaw = typeof record.maxImages === "number" ? record.maxImages : void 0;
				const resolvedImage = (() => {
					if (sandboxConfig) return normalizedRef;
					if (normalizedRef.startsWith("~")) return resolveUserPath(normalizedRef);
					if (!isDataUrl && !isFileUrl && !isHttpUrl && !refInfo.looksLikeWindowsDrivePath && !isAbsolute(normalizedRef) && options?.workspaceDir) return resolve(options.workspaceDir, normalizedRef);
					return normalizedRef;
				})();
}
`
const toolsPath = path.join(tmp, 'openclaw-tools-test.js')
fs.writeFileSync(toolsPath, toolsSrc)
const toolsResult = patchMediaUriResolveInToolsFile(toolsPath)
assert.ok(['patched', 'upgraded', 'skip', 'skip-native'].includes(toolsResult), toolsResult)
const patched = fs.readFileSync(toolsPath, 'utf8')
assert.ok(
  toolsMediaUriResolveIsHealthy(patched) || patched.includes('clawbba-media-uri-resolve'),
  'expected media uri marker or native resolve',
)

const runnerSrc = `var MediaAttachmentCache = class {
  resolveLocalPath(attachment) {
    const rawPath = normalizeAttachmentPath(attachment.path);
    if (!rawPath) return;
    return this.workspaceDir ? path.resolve(this.workspaceDir, rawPath) : path.resolve(rawPath);
  }
};
function createMediaAttachmentCache() {}
`
fs.writeFileSync(path.join(tmp, 'runner-test.js'), runnerSrc)
assert.equal(findMediaUnderstandingRunnerFile(tmp), 'runner-test.js')

console.log('test-media-uri-resolve-patch: ok')
