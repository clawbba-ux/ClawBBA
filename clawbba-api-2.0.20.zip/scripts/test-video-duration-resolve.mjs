#!/usr/bin/env node
import assert from 'node:assert/strict'
import { resolveVideoDurationSeconds } from './clawbba-media-tool-validate.mjs'

const args = {
  action: 'generate',
  prompt: '一个老人在农村',
  model: 'clawbba/bytedance/seedance-2.0',
  aspectRatio: '9:16',
  durationSeconds: 5,
  audio: true,
}

assert.equal(
  resolveVideoDurationSeconds({ params: args, model: 'x', prompt: 'p' }),
  5,
  'must read durationSeconds from params when ctx omits it',
)
assert.equal(
  resolveVideoDurationSeconds({ params: args, durationSeconds: 8 }),
  8,
  'ctx durationSeconds takes precedence',
)
assert.equal(resolveVideoDurationSeconds({ params: { duration_seconds: 5 } }), 5)
assert.equal(resolveVideoDurationSeconds({ params: { durationSeconds: '5' } }), 5)
assert.equal(resolveVideoDurationSeconds({ params: { prompt: 'x' } }), undefined)

console.log('test-video-duration-resolve: ok')
