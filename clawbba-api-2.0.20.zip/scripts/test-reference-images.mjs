#!/usr/bin/env node
/**
 * Unit tests for reference-image session parsing (clawbba-reference-images.mjs).
 */
import assert from 'node:assert/strict'
import {
  collectPlausibleReferenceImages,
  extractImageRefsFromMessage,
  isPlausibleReferenceImageRef,
  looksLikeImageRef,
  messageTextFromRecord,
  paramsHaveReferenceImages,
  resolveOpenClawMediaRefSync,
  sanitizeReferenceImageParams,
} from './clawbba-reference-images.mjs'

assert.ok(looksLikeImageRef('/root/.openclaw/media/inbound/photo.png'))
assert.ok(looksLikeImageRef('data:image/png;base64,abc'))
assert.ok(looksLikeImageRef('media://inbound/photo---uuid.png'))
assert.ok(!looksLikeImageRef('hello world'))

const mediaUri = 'media://inbound/ScreenShot_2026-05-31_025953_696---b420faca-2369-4a37-b7ae-858fc94b3be5.png'
const prevHome = process.env.OPENCLAW_HOME
process.env.OPENCLAW_HOME = '/root/.openclaw'
assert.equal(
  resolveOpenClawMediaRefSync(mediaUri),
  '/root/.openclaw/media/inbound/ScreenShot_2026-05-31_025953_696---b420faca-2369-4a37-b7ae-858fc94b3be5.png',
)
if (prevHome === undefined) delete process.env.OPENCLAW_HOME
else process.env.OPENCLAW_HOME = prevHome

const withMediaUri = {
  role: 'user',
  content: [
    { type: 'text', text: '请使用 ClawBBA 生成图片' },
    { type: 'image', path: mediaUri },
  ],
}
assert.ok(
  extractImageRefsFromMessage(withMediaUri).some((p) => p.includes('/media/inbound/ScreenShot')),
)

const withImagePart = {
  role: 'user',
  content: [
    { type: 'text', text: '请使用 ClawBBA 生成图片能力，为我生成 16:9 横图：测试' },
    { type: 'image', path: '/root/.openclaw/media/inbound/ref-1.png' },
  ],
}
assert.deepEqual(extractImageRefsFromMessage(withImagePart), [
  '/root/.openclaw/media/inbound/ref-1.png',
])

const withMediaLine = {
  role: 'user',
  content: '请使用 ClawBBA 生成图片\nMEDIA:/root/.openclaw/media/inbound/ref-2.jpg',
}
assert.deepEqual(extractImageRefsFromMessage(withMediaLine), [
  '/root/.openclaw/media/inbound/ref-2.jpg',
])

assert.equal(
  messageTextFromRecord(withImagePart),
  '请使用 ClawBBA 生成图片能力，为我生成 16:9 横图：测试',
)

assert.equal(paramsHaveReferenceImages({ image: '/tmp/a.png' }), true)
assert.equal(paramsHaveReferenceImages({ images: ['/tmp/a.png'] }), true)
assert.equal(paramsHaveReferenceImages({ prompt: 'x' }), false)
assert.equal(paramsHaveReferenceImages({ images: ['参考图URL'] }), false)
assert.equal(paramsHaveReferenceImages({ images: ['https://example.com/reference-image.jpg'] }), false)
assert.ok(isPlausibleReferenceImageRef('/root/.openclaw/media/inbound/a.png'))
assert.ok(!isPlausibleReferenceImageRef('参考图URL'))

const bogus = { images: ['参考图URL', 'https://example.com/reference-image.jpg'] }
sanitizeReferenceImageParams(bogus)
assert.deepEqual(bogus.images, [])
assert.equal(paramsHaveReferenceImages(bogus), false)

const mixed = { images: ['参考图URL', '/root/.openclaw/media/inbound/real.png'] }
sanitizeReferenceImageParams(mixed)
assert.deepEqual(collectPlausibleReferenceImages(mixed), ['/root/.openclaw/media/inbound/real.png'])

console.log('[clawbba-api] test-reference-images: ok')
