/**
 * OpenClaw image / image_generate: resolve media://inbound/<id> before workspace-relative paths.
 * Without this, media:// is joined under workspace → ENOENT and vision 404 upstream_error.
 */
import fs from 'fs'
import path from 'path'
import {
  findDistJsFile,
  findMediaReferenceDistFile,
  findMediaUnderstandingRunnerFile,
} from './openclaw-dist-paths.mjs'

export const MEDIA_URI_RESOLVE_MARKER = '/* clawbba-media-uri-resolve */'
export const MEDIA_ATTACHMENT_RESOLVE_MARKER = '/* clawbba-media-attachment-resolve */'

const INBOUND_MEDIA_SYNC_HELPER = `${MEDIA_ATTACHMENT_RESOLVE_MARKER}
function clawbbaResolveOpenClawInboundMediaPathSync(value) {
\tconst v = String(value ?? "").trim();
\tif (!/^media:\\/\\//i.test(v)) return;
\ttry {
\t\tconst parsed = new URL(v);
\t\tif (parsed.hostname !== "inbound") return;
\t\tconst id = decodeURIComponent(parsed.pathname.replace(/^\\/+/, ""));
\t\tif (!id || id.includes("/") || id.includes("\\\\")) return;
\t\tconst home = process.env.OPENCLAW_STATE_DIR?.trim() || process.env.OPENCLAW_HOME?.trim();
\t\tconst base = home || path.join(os.homedir(), ".openclaw");
\t\treturn path.join(base, "media", "inbound", id);
\t} catch {
\t\treturn;
\t}
}
`

const RUNNER_RESOLVE_LOCAL_PATH_NEEDLE = `\tresolveLocalPath(attachment) {
\t\tconst rawPath = normalizeAttachmentPath(attachment.path);
\t\tif (!rawPath) return;
\t\treturn this.workspaceDir ? path.resolve(this.workspaceDir, rawPath) : path.resolve(rawPath);
\t}`

const RUNNER_RESOLVE_LOCAL_PATH_ALT_NEEDLE = `\tresolveLocalPath(attachment) {
\t\tconst rawPath = normalizeAttachmentPath(attachment.path);
\t\tif (!rawPath) return;
\t\tconst trimmed = rawPath.trim();
\t\treturn this.workspaceDir ? path.resolve(this.workspaceDir, trimmed) : path.resolve(trimmed);
\t}`

const SANDBOX_INPUT_PATH_NEEDLE = `function resolveSandboxInputPath(filePath, cwd) {
\treturn resolveToCwd(filePath, cwd);
}`

const SANDBOX_INPUT_PATH_REPLACEMENT = `function resolveSandboxInputPath(filePath, cwd) {
\tconst trimmed = String(filePath ?? "").trim();
\tif (/^media:\\/\\//i.test(trimmed)) {
\t\tconst resolved = clawbbaResolveOpenClawInboundMediaPathSync(trimmed);
\t\tif (resolved) return resolved;
\t}
\treturn resolveToCwd(filePath, cwd);
}`

function buildRunnerResolveLocalPathReplacement(param = 'attachment') {
  return `\tresolveLocalPath(${param}) {
\t\tconst rawPath = normalizeAttachmentPath(${param}.path);
\t\tconst rawUrl = normalizeAttachmentPath(${param}.url);
\t\tconst mediaRef = rawPath && /^media:\\/\\//i.test(rawPath.trim()) ? rawPath : rawUrl && /^media:\\/\\//i.test(rawUrl.trim()) ? rawUrl : "";
\t\tif (mediaRef) {
\t\t\tconst resolved = clawbbaResolveOpenClawInboundMediaPathSync(mediaRef);
\t\t\tif (resolved) return resolved;
\t\t}
\t\tif (!rawPath) return;
\t\tconst trimmed = rawPath.trim();
\t\treturn this.workspaceDir ? path.resolve(this.workspaceDir, trimmed) : path.resolve(trimmed);
\t}`
}

const RUNNER_RESOLVE_LOCAL_PATH_REPLACEMENT = buildRunnerResolveLocalPathReplacement('attachment')

const MEDIA_REFERENCE_RESOLVE_NEEDLE = `async function resolveMediaReferenceLocalPath(source) {
\tconst normalizedSource = normalizeMediaReferenceSource(source);
\treturn (await resolveInboundMediaReference(normalizedSource))?.physicalPath ?? normalizedSource;
}`

const MEDIA_REFERENCE_RESOLVE_REPLACEMENT = `async function resolveMediaReferenceLocalPath(source) {
\tconst normalizedSource = normalizeMediaReferenceSource(source);
\t${MEDIA_ATTACHMENT_RESOLVE_MARKER}
\tconst clawbbaSyncPath = clawbbaResolveOpenClawInboundMediaPathSync(normalizedSource);
\tif (clawbbaSyncPath) return clawbbaSyncPath;
\treturn (await resolveInboundMediaReference(normalizedSource))?.physicalPath ?? normalizedSource;
}`

const RUNNER_CACHE_CLASS_ANCHORS = [
  'var MediaAttachmentCache = class {',
  'let MediaAttachmentCache = class {',
  'class MediaAttachmentCache {',
]

function injectInboundMediaHelperBefore(src, anchor) {
  if (src.includes('function clawbbaResolveOpenClawInboundMediaPathSync')) return src
  if (!src.includes(anchor)) return src
  return src.replace(anchor, `${INBOUND_MEDIA_SYNC_HELPER}\n${anchor}`)
}

function patchRunnerResolveLocalPathMethod(src) {
  if (src.includes('clawbbaResolveOpenClawInboundMediaPathSync(mediaRef)')) return src
  if (src.includes(RUNNER_RESOLVE_LOCAL_PATH_NEEDLE)) {
    return src.replace(RUNNER_RESOLVE_LOCAL_PATH_NEEDLE, RUNNER_RESOLVE_LOCAL_PATH_REPLACEMENT)
  }
  if (src.includes(RUNNER_RESOLVE_LOCAL_PATH_ALT_NEEDLE)) {
    return src.replace(RUNNER_RESOLVE_LOCAL_PATH_ALT_NEEDLE, RUNNER_RESOLVE_LOCAL_PATH_REPLACEMENT)
  }
  const re =
    /\tresolveLocalPath\((\w+)\)\s*\{\n\t\tconst rawPath = normalizeAttachmentPath\(\1\.path\);[\s\S]*?\n\t\treturn this\.workspaceDir \? path\.resolve\(this\.workspaceDir, (?:rawPath|trimmed)\) : path\.resolve\((?:rawPath|trimmed)\);\n\t\}/
  const m = src.match(re)
  if (m) {
    return src.replace(m[0], buildRunnerResolveLocalPathReplacement(m[1]))
  }
  return src
}

const IMAGE_TOOL_RESOLVED_NEEDLE = `\t\t\t\tconst resolvedImage = (() => {
\t\t\t\t\tif (sandboxConfig) return normalizedRef;
\t\t\t\t\tif (normalizedRef.startsWith("~")) return resolveUserPath(normalizedRef);
\t\t\t\t\tif (!isDataUrl && !isFileUrl && !isHttpUrl && !refInfo.looksLikeWindowsDrivePath && !isAbsolute(normalizedRef) && options?.workspaceDir) return resolve(options.workspaceDir, normalizedRef);
\t\t\t\t\treturn normalizedRef;
\t\t\t\t})();`

const IMAGE_TOOL_RESOLVED_REPLACEMENT = `\t\t\t\t${MEDIA_URI_RESOLVE_MARKER}
\t\t\t\tconst resolvedImage = await (async () => {
\t\t\t\t\tif (refInfo.isMediaStoreUrl) return await resolveMediaReferenceLocalPath(normalizedRef);
\t\t\t\t\tif (sandboxConfig) return normalizedRef;
\t\t\t\t\tif (normalizedRef.startsWith("~")) return resolveUserPath(normalizedRef);
\t\t\t\t\tif (!isDataUrl && !isFileUrl && !isHttpUrl && !refInfo.looksLikeWindowsDrivePath && !isAbsolute(normalizedRef) && options?.workspaceDir) return resolve(options.workspaceDir, normalizedRef);
\t\t\t\t\treturn normalizedRef;
\t\t\t\t})();`

const LOAD_REF_IMAGE_NEEDLE = `\t\tconst resolvedImage = (() => {
\t\t\tif (params.sandboxConfig) return imageRaw;
\t\t\tif (imageRaw.startsWith("~")) return resolveUserPath(imageRaw);
\t\t\treturn imageRaw;
\t\t})();`

const LOAD_REF_IMAGE_REPLACEMENT = `\t\t${MEDIA_URI_RESOLVE_MARKER}
\t\tconst resolvedImage = await (async () => {
\t\t\tif (refInfo.isMediaStoreUrl) return await resolveMediaReferenceLocalPath(imageRaw);
\t\t\tif (params.sandboxConfig) return imageRaw;
\t\t\tif (imageRaw.startsWith("~")) return resolveUserPath(imageRaw);
\t\t\treturn imageRaw;
\t\t})();`

const IMAGE_TOOL_REWRITE_NEEDLES = [
  `\t\t\tif (imageInputs.length === 0) throw new Error("image required");
\t\t\tconst maxImagesRaw = typeof record.maxImages === "number" ? record.maxImages : void 0;`,
  `\t\t\tif (imageInputs.length === 0) throw new ToolInputError("image required");
\t\t\tconst maxImagesRaw = typeof record.maxImages === "number" ? record.maxImages : void 0;`,
]

const IMAGE_TOOL_REWRITE_REPLACEMENT_PREFIX = `\t\t\tif (imageInputs.length === 0) throw new Error("image required");
\t\t\t${MEDIA_URI_RESOLVE_MARKER}
\t\t\tfor (let clawbbaIi = 0; clawbbaIi < imageInputs.length; clawbbaIi++) {
\t\t\t\tconst clawbbaRaw = normalizeMediaReferenceSource(imageInputs[clawbbaIi].trim());
\t\t\t\tconst clawbbaInfo = classifyMediaReferenceSource(clawbbaRaw);
\t\t\t\tif (clawbbaInfo.isMediaStoreUrl) {
\t\t\t\t\timageInputs[clawbbaIi] = await resolveMediaReferenceLocalPath(clawbbaRaw);
\t\t\t\t}
\t\t\t}
\t\t\tconst maxImagesRaw = typeof record.maxImages === "number" ? record.maxImages : void 0;`

const IMAGE_TOOL_REWRITE_REPLACEMENT_PREFIX_TOOL_ERROR = `\t\t\tif (imageInputs.length === 0) throw new ToolInputError("image required");
\t\t\t${MEDIA_URI_RESOLVE_MARKER}
\t\t\tfor (let clawbbaIi = 0; clawbbaIi < imageInputs.length; clawbbaIi++) {
\t\t\t\tconst clawbbaRaw = normalizeMediaReferenceSource(imageInputs[clawbbaIi].trim());
\t\t\t\tconst clawbbaInfo = classifyMediaReferenceSource(clawbbaRaw);
\t\t\t\tif (clawbbaInfo.isMediaStoreUrl) {
\t\t\t\t\timageInputs[clawbbaIi] = await resolveMediaReferenceLocalPath(clawbbaRaw);
\t\t\t\t}
\t\t\t}
\t\t\tconst maxImagesRaw = typeof record.maxImages === "number" ? record.maxImages : void 0;`

/** OpenClaw ≥2026.6 may ship native media-store resolve in tools (no clawbba marker). */
export function toolsMediaUriResolveIsHealthy(src) {
  if (!src || typeof src !== 'string') return false
  if (src.includes(MEDIA_URI_RESOLVE_MARKER)) return true
  return (
    src.includes('resolveMediaReferenceLocalPath') &&
    /refInfo\.isMediaStoreUrl\)\s*return\s+await\s+resolveMediaReferenceLocalPath/.test(src)
  )
}

export function runnerMediaUriResolveIsHealthy(src) {
  if (!src || typeof src !== 'string') return false
  return src.includes('clawbbaResolveOpenClawInboundMediaPathSync(mediaRef)')
}

export function mediaReferenceUriResolveIsHealthy(src) {
  if (!src || typeof src !== 'string') return false
  if (src.includes('clawbbaResolveOpenClawInboundMediaPathSync(normalizedSource)')) return true
  return (
    src.includes('resolveInboundMediaUri') &&
    src.includes('parsed.hostname !== "inbound"') &&
    src.includes('resolveMediaBufferPath')
  )
}

/** @param {string} dist */
export function distMediaAttachmentPathResolveIsHealthy(dist) {
  const runnerFile = findMediaUnderstandingRunnerFile(dist)
  if (runnerFile) {
    try {
      const src = fs.readFileSync(path.join(dist, runnerFile), 'utf8')
      if (runnerMediaUriResolveIsHealthy(src)) return true
    } catch {
      /* fall through */
    }
  }
  const mediaRef = findMediaReferenceDistFile(dist)
  if (!mediaRef) return false
  try {
    return mediaReferenceUriResolveIsHealthy(fs.readFileSync(path.join(dist, mediaRef), 'utf8'))
  } catch {
    return false
  }
}

/**
 * @param {string} src
 * @param {string} mediaRefBasename
 */
function patchMediaReferenceImport(src, mediaRefBasename) {
  if (src.includes('resolveMediaReferenceLocalPath')) return src
  const exact =
    /import \{ n as classifyMediaReferenceSource, r as normalizeMediaReferenceSource \} from "\.\/media-reference-[^"]+\.js";/
  if (exact.test(src)) {
    return src.replace(
      exact,
      `import { a as resolveMediaReferenceLocalPath, n as classifyMediaReferenceSource, r as normalizeMediaReferenceSource } from "./${mediaRefBasename}";`,
    )
  }
  const loose = /import \{([^}]+)\} from "\.\/media-reference-[^"]+\.js";/
  if (!loose.test(src)) return src
  return src.replace(loose, (line, inner) => {
    if (inner.includes('resolveMediaReferenceLocalPath')) return line
    const parts = inner.split(',').map((p) => p.trim()).filter(Boolean)
    if (!parts.some((p) => p.includes('classifyMediaReferenceSource'))) return line
    parts.unshift('a as resolveMediaReferenceLocalPath')
    return `import { ${parts.join(', ')} } from "./${mediaRefBasename}";`
  })
}

function applyImageToolEarlyRewrite(src) {
  if (src.includes('for (let clawbbaIi = 0; clawbbaIi < imageInputs.length')) return src
  for (let i = 0; i < IMAGE_TOOL_REWRITE_NEEDLES.length; i++) {
    const needle = IMAGE_TOOL_REWRITE_NEEDLES[i]
    if (!src.includes(needle)) continue
    const replacement =
      i === 1 ? IMAGE_TOOL_REWRITE_REPLACEMENT_PREFIX_TOOL_ERROR : IMAGE_TOOL_REWRITE_REPLACEMENT_PREFIX
    return src.replace(needle, replacement)
  }
  return src
}

function applyResolvedImagePatches(src) {
  if (src.includes(MEDIA_URI_RESOLVE_MARKER)) return src
  let next = src
  if (next.includes(IMAGE_TOOL_RESOLVED_NEEDLE)) {
    next = next.replace(IMAGE_TOOL_RESOLVED_NEEDLE, IMAGE_TOOL_RESOLVED_REPLACEMENT)
  }
  if (next.includes(LOAD_REF_IMAGE_NEEDLE)) {
    next = next.replace(LOAD_REF_IMAGE_NEEDLE, LOAD_REF_IMAGE_REPLACEMENT)
  }
  const syncImageToolRe =
    /const resolvedImage = \(\(\) => \{\s*if \(sandboxConfig\) return normalizedRef;\s*if \(normalizedRef\.startsWith\("~"\)\) return resolveUserPath\(normalizedRef\);\s*if \(!isDataUrl && !isFileUrl && !isHttpUrl[^]*?return normalizedRef;\s*\}\)\(\);/
  if (next === src && syncImageToolRe.test(next) && !next.includes(MEDIA_URI_RESOLVE_MARKER)) {
    next = next.replace(syncImageToolRe, IMAGE_TOOL_RESOLVED_REPLACEMENT.trim())
  }
  const syncLoadRe =
    /const resolvedImage = \(\(\) => \{\s*if \(params\.sandboxConfig\) return imageRaw;\s*if \(imageRaw\.startsWith\("~"\)\) return resolveUserPath\(imageRaw\);\s*return imageRaw;\s*\}\)\(\);/
  if (!next.includes(MEDIA_URI_RESOLVE_MARKER) && syncLoadRe.test(next)) {
    next = next.replace(syncLoadRe, LOAD_REF_IMAGE_REPLACEMENT.trim())
  }
  return next
}

/**
 * @param {string} toolsPath
 * @returns {'skip'|'skip-native'|'patched'|'upgraded'|'missing-import'|'missing-image-tool'|'missing-load-ref'}
 */
export function patchMediaUriResolveInToolsFile(toolsPath) {
  const dist = path.dirname(toolsPath)
  const mediaRefBasename = findDistJsFile(dist, 'media-reference-', 'classifyMediaReferenceSource')
  if (!mediaRefBasename) return 'missing-import'

  let src = fs.readFileSync(toolsPath, 'utf8')
  const before = src
  src = patchMediaReferenceImport(src, mediaRefBasename)
  src = applyImageToolEarlyRewrite(src)
  src = applyResolvedImagePatches(src)

  if (src === before) {
    if (toolsMediaUriResolveIsHealthy(src)) return 'skip-native'
    if (src.includes(MEDIA_URI_RESOLVE_MARKER)) return 'skip'
    if (!src.includes(IMAGE_TOOL_RESOLVED_NEEDLE) && !src.includes(LOAD_REF_IMAGE_NEEDLE)) {
      return 'missing-image-tool'
    }
    return 'missing-load-ref'
  }

  fs.writeFileSync(toolsPath, src)
  if (before.includes(MEDIA_URI_RESOLVE_MARKER)) return 'upgraded'
  return 'patched'
}

export function patchMediaUriResolveInSandboxFile(dist) {
  const sandboxFile = findDistJsFile(dist, 'sandbox-paths-', 'resolveSandboxInputPath')
  if (!sandboxFile) return 'missing-sandbox'
  const filePath = path.join(dist, sandboxFile)
  let src = fs.readFileSync(filePath, 'utf8')
  const before = src
  if (!src.includes('function clawbbaResolveOpenClawInboundMediaPathSync')) {
    const anchor = 'function resolveSandboxInputPath(filePath, cwd) {'
    if (!src.includes(anchor)) return 'missing-sandbox'
    src = src.replace(anchor, `${INBOUND_MEDIA_SYNC_HELPER}\n${anchor}`)
  }
  if (src.includes('clawbbaResolveOpenClawInboundMediaPathSync(trimmed)')) return 'skip'
  if (!src.includes(SANDBOX_INPUT_PATH_NEEDLE)) return 'missing-sandbox'
  src = src.replace(SANDBOX_INPUT_PATH_NEEDLE, SANDBOX_INPUT_PATH_REPLACEMENT)
  if (src === before) return 'missing-sandbox'
  fs.writeFileSync(filePath, src)
  return before.includes(MEDIA_ATTACHMENT_RESOLVE_MARKER) ? 'upgraded' : 'patched'
}

export function patchMediaUriResolveInMediaReferenceFile(dist) {
  const mediaRefFile = findMediaReferenceDistFile(dist)
  if (!mediaRefFile) return 'missing-media-reference'
  const filePath = path.join(dist, mediaRefFile)
  let src = fs.readFileSync(filePath, 'utf8')
  const before = src
  src = injectInboundMediaHelperBefore(src, 'async function resolveInboundMediaUri(')
  if (!src.includes('function clawbbaResolveOpenClawInboundMediaPathSync')) {
    src = injectInboundMediaHelperBefore(src, 'async function resolveMediaReferenceLocalPath(')
  }
  if (!src.includes('clawbbaResolveOpenClawInboundMediaPathSync(normalizedSource)')) {
    if (src.includes(MEDIA_REFERENCE_RESOLVE_NEEDLE)) {
      src = src.replace(MEDIA_REFERENCE_RESOLVE_NEEDLE, MEDIA_REFERENCE_RESOLVE_REPLACEMENT)
    }
  }
  if (src === before) {
    if (mediaReferenceUriResolveIsHealthy(src)) return 'skip-native'
    return src.includes(MEDIA_ATTACHMENT_RESOLVE_MARKER) ? 'skip' : 'missing-media-reference'
  }
  fs.writeFileSync(filePath, src)
  return before.includes(MEDIA_ATTACHMENT_RESOLVE_MARKER) ? 'upgraded' : 'patched'
}

export function patchMediaUriResolveInRunnerFile(dist) {
  const runnerFile = findMediaUnderstandingRunnerFile(dist)
  if (!runnerFile) return 'missing-runner'
  const filePath = path.join(dist, runnerFile)
  let src = fs.readFileSync(filePath, 'utf8')
  const before = src
  for (const anchor of RUNNER_CACHE_CLASS_ANCHORS) {
    src = injectInboundMediaHelperBefore(src, anchor)
  }
  if (src.includes('clawbbaResolveOpenClawInboundMediaPathSync(mediaRef)')) {
    return 'skip'
  }
  src = patchRunnerResolveLocalPathMethod(src)
  if (src === before) {
    return src.includes(MEDIA_ATTACHMENT_RESOLVE_MARKER) ? 'skip' : 'missing-runner'
  }
  if (!src.includes('clawbbaResolveOpenClawInboundMediaPathSync(mediaRef)')) {
    return 'missing-runner'
  }
  fs.writeFileSync(filePath, src)
  return before.includes(MEDIA_ATTACHMENT_RESOLVE_MARKER) ? 'upgraded' : 'patched'
}

/** @param {string} dist */
export function patchMediaUriResolveDist(dist) {
  const toolsFile = findDistJsFile(dist, 'openclaw-tools-', 'createImageTool')
  const sandbox = patchMediaUriResolveInSandboxFile(dist)
  let runner = patchMediaUriResolveInRunnerFile(dist)
  if (runner === 'missing-runner') {
    runner = `fallback-${patchMediaUriResolveInMediaReferenceFile(dist)}`
  }
  const tools = toolsFile ? patchMediaUriResolveInToolsFile(path.join(dist, toolsFile)) : 'missing-tools'
  return `sandbox-${sandbox}+runner-${runner}+tools-${tools}`
}
