/**
 * 修复重复打 patch 导致的 SyntaxError
 */
import { WEBCHAT_LIVE_MARKER } from './openclaw-announce-patch.mjs'
import { findJsBlockEnd } from './clawbba-js-block-end.mjs'

const INJECT_FN = 'clawbbaInjectWebChatGeneratedMediaLive'
const PROGRESS_FN = 'clawbbaInjectMediaProgressLive'
const PROGRESS_SIG = `export async function ${PROGRESS_FN}`
const PROGRESS_MARKER = '/* clawbba-webchat-progress-inject */'
const WAKE_MARKER = '/* clawbba-webchat-live-wake */'
const IMPORT_MARKER = '/* clawbba-webchat-live-import */'

/** @param {string} value */
export function escapeRegExp(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
}

function findBlockEnd(src, openBraceIndex) {
  return findJsBlockEnd(src, openBraceIndex)
}

export function countMediaProgressLiveExports(src) {
  return (src.match(/export async function clawbbaInjectMediaProgressLive/g) || []).length
}

/** Remove one progress export block starting at exportIdx */
function removeProgressExportAt(src, exportIdx) {
  let start = src.lastIndexOf(PROGRESS_MARKER, exportIdx)
  if (start < 0) start = Math.max(0, src.lastIndexOf('\n', exportIdx) + 1)
  const brace = src.indexOf('{', exportIdx)
  if (brace < 0) return src
  const end = findJsBlockEnd(src, brace)
  return (src.slice(0, start) + src.slice(end)).replace(/\n{3,}/g, '\n\n')
}

/** Strip ALL clawbbaInjectMediaProgressLive exports (anywhere in file). */
export function stripAllMediaProgressLiveExports(src) {
  let next = src
  while (countMediaProgressLiveExports(next) > 0) {
    const idx = next.indexOf(PROGRESS_SIG)
    if (idx < 0) break
    const after = removeProgressExportAt(next, idx)
    if (after === next) break
    next = after
  }
  return next.replace(new RegExp(`\\n${PROGRESS_MARKER}\\n`, 'g'), '\n')
}

/** Keep exactly one export; remove extras (1.5.32/33 duplicate bug). */
export function dedupeClawbbaProgressInjectBlocks(src) {
  let next = src
  while (countMediaProgressLiveExports(next) > 1) {
    const first = next.indexOf(PROGRESS_SIG)
    const second = next.indexOf(PROGRESS_SIG, first + PROGRESS_SIG.length)
    if (second < 0) break
    next = removeProgressExportAt(next, second)
  }
  return next
}

/** 移除所有 clawbba webchat live helper 块（含旧版非 export 与重复 export） */
export function dedupeClawbbaInjectHelperBlocks(src) {
  let next = src
  while (next.includes(WEBCHAT_LIVE_MARKER) || next.includes(`function ${INJECT_FN}`)) {
    const markerIdx = next.indexOf(WEBCHAT_LIVE_MARKER)
    const fnIdx = next.indexOf(`function ${INJECT_FN}`)
    const start =
      markerIdx >= 0 && (fnIdx < 0 || markerIdx <= fnIdx)
        ? markerIdx
        : fnIdx >= 0
          ? Math.max(0, next.lastIndexOf('\n', fnIdx) + 1)
          : -1
    if (start < 0) break

    const fnPos = next.indexOf(`function ${INJECT_FN}`, start)
    if (fnPos < 0) {
      next = next.slice(0, start) + next.slice(start + WEBCHAT_LIVE_MARKER.length)
      continue
    }
    const brace = next.indexOf('{', fnPos)
    if (brace < 0) break
    const end = findBlockEnd(next, brace)
    next = (next.slice(0, start) + next.slice(end)).replace(/\n{3,}/g, '\n\n')
  }
  return next
}

/**
 * 仅去重 wake 相关的重复 dynamic import（勿再 slice 到 internalEvents — 会破坏函数体导致 SyntaxError）。
 * wake 注入区由 rebuildWakeInjectionSection 整段重写。
 */
export function dedupeClawbbaWakePatchBlocks(src) {
  let next = src

  const importRe = new RegExp(
    `${IMPORT_MARKER.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\nimport \\{ clawbbaInjectWebChatGeneratedMediaLive \\} from "\\./subagent-announce-delivery-[^"]+\\.js";\\n?`,
    'g',
  )
  let seenImport = false
  next = next.replace(importRe, (m) => {
    if (seenImport) return ''
    seenImport = true
    return m
  })

  return next
}
