/**
 * Text-only model offload: user message used to say [media attached: media://inbound/…].
 * Agents copy that into image(image=media://…) → ENOENT / vision 404.
 * Prefer savedMedia.path (filesystem) in the visible attachment line.
 */
import fs from 'fs'
import path from 'path'
import { findDistJsFile } from './openclaw-dist-paths.mjs'

export const GATEWAY_OFFLOAD_PATH_MARKER = '/* clawbba-gateway-offload-path */'

const NEEDLE = `\t\t\tconst mediaRef = \`media://inbound/\${savedMedia.id}\`;
\t\t\tif (isImage) updatedMessage += \`\\n[media attached: \${mediaRef}]\`;`

const REPLACEMENT = `\t\t\tconst mediaRef = \`media://inbound/\${savedMedia.id}\`;
\t\t\t${GATEWAY_OFFLOAD_PATH_MARKER}
\t\t\tconst clawbbaAttachPath = typeof savedMedia.path === "string" && savedMedia.path.trim() ? savedMedia.path.trim() : mediaRef;
\t\t\tif (isImage) updatedMessage += \`\\n[media attached: \${clawbbaAttachPath}]\\nMEDIA:\${clawbbaAttachPath}\`;`

/** @param {string} dist */
export function patchGatewayOffloadPathDist(dist) {
  const file = findDistJsFile(dist, 'attachment-normalize-', 'Offloaded image for text-only')
  if (!file) return 'missing-file'
  const filePath = path.join(dist, file)
  let src = fs.readFileSync(filePath, 'utf8')
  if (src.includes(GATEWAY_OFFLOAD_PATH_MARKER)) return 'skip'
  if (!src.includes(NEEDLE)) return 'pattern-missing'
  src = src.replace(NEEDLE, REPLACEMENT)
  fs.writeFileSync(filePath, src)
  return 'patched'
}
