#!/usr/bin/env node
/**
 * 对照 OpenClaw 源码与运行时 dist，列出 media:// patch 目标文件（排错用）。
 */
import fs from 'node:fs'
import path from 'node:path'
import {
  findAllOpenclawDists,
  findDistJsFile,
  findMediaReferenceDistFile,
  findMediaUnderstandingRunnerFile,
  formatOpenclawDistDiscoveryReport,
} from './openclaw-dist-paths.mjs'

const OPENCLAW_SRC = process.env.OPENCLAW_SRC?.trim() || ''

const SOURCE_FILES = [
  'src/media-understanding/attachments.cache.ts',
  'src/media/media-reference.ts',
  'src/gateway/chat-attachments.ts',
  'src/agents/tools/image-tool.ts',
]

function srcStatus() {
  if (!OPENCLAW_SRC) {
    console.log('[clawbba-api] OPENCLAW_SRC 未设置（可选，用于对照源码路径）')
    return
  }
  console.log(`[clawbba-api] OPENCLAW_SRC=${OPENCLAW_SRC}`)
  for (const rel of SOURCE_FILES) {
    const p = path.join(OPENCLAW_SRC, rel)
    console.log(fs.existsSync(p) ? `  ✓ ${rel}` : `  ✗ ${rel} (missing)`)
  }
}

function probeDist(dist) {
  console.log(`\n[clawbba-api] dist: ${dist}`)
  const tools = findDistJsFile(dist, 'openclaw-tools-', 'createImageTool')
  const runner = findMediaUnderstandingRunnerFile(dist)
  const mediaRef = findMediaReferenceDistFile(dist)
  const attach = findDistJsFile(dist, 'attachment-normalize-', 'Offloaded image for text-only')
  const sandbox = findDistJsFile(dist, 'sandbox-paths-', 'resolveSandboxInputPath')
  console.log(`  openclaw-tools: ${tools ?? '(missing)'}`)
  console.log(`  media-runner:   ${runner ?? '(missing)'}`)
  console.log(`  media-reference: ${mediaRef ?? '(missing)'}`)
  console.log(`  attach-normalize: ${attach ?? '(missing)'}`)
  console.log(`  sandbox-paths: ${sandbox ?? '(missing)'}`)
  if (runner) {
    const src = fs.readFileSync(path.join(dist, runner), 'utf8')
    console.log(
      `  runner patched: ${src.includes('clawbbaResolveOpenClawInboundMediaPathSync(mediaRef)') ? 'yes' : 'no'}`,
    )
  }
}

srcStatus()
const dists = findAllOpenclawDists()
if (!dists.length) {
  console.error('[clawbba-api] 未找到 OpenClaw dist；请安装 openclaw 或设置 OPENCLAW_DIST')
  process.exit(1)
}
console.log(formatOpenclawDistDiscoveryReport(dists))
for (const dist of dists) {
  probeDist(dist)
}
