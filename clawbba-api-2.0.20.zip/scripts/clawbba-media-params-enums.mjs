/** OpenClaw image_generate / video_generate 枚举（与 upstream 2026.5.28 一致） */
export const OPENCLAW_IMAGE_RESOLUTIONS = ['1K', '2K', '4K']

export const OPENCLAW_IMAGE_ASPECT_RATIOS = [
  '1:1',
  '2:3',
  '3:2',
  '3:4',
  '4:3',
  '4:5',
  '5:4',
  '9:16',
  '16:9',
  '21:9',
]

export const IMAGE_RESOLUTION_ALIASES = {
  '720P': '1K',
  '1080P': '2K',
  '1440P': '2K',
  '2160P': '4K',
}
