#!/usr/bin/env node
import assert from 'node:assert/strict'
import { buildVideoGenerationParams } from './clawbba-media-capabilities-core.mjs'
import { mergeVideoOptions, resolveStaticVideoOptions } from './clawbba-video-generation-specs.mjs'
import { VIDEO_MODEL_SPECS } from './clawbba-openclaw-media-catalog.mjs'

for (const spec of VIDEO_MODEL_SPECS) {
  const vo = resolveStaticVideoOptions(spec.id, spec)
  const gp = buildVideoGenerationParams({
    id: spec.id,
    openclaw_ref: `openrouter/${spec.id}`,
    ...vo,
  })
  assert.equal(gp.tool, 'video_generate')
  assert.equal(gp.model, `openrouter/${spec.id}`)
  assert.ok(gp.parameters.prompt.required)
  assert.ok(gp.parameters.durationSeconds.required)
  assert.ok(Array.isArray(gp.parameters.durationSeconds.allowed))
  assert.ok(gp.workflows.text_to_video)
  assert.ok(gp.example_call.durationSeconds != null)
}

const merged = mergeVideoOptions(
  { duration_presets: [4, 8], aspect_ratios: ['16:9'] },
  resolveStaticVideoOptions('bytedance/seedance-2.0'),
)
assert.deepEqual(merged.duration_presets, [4, 8])
assert.deepEqual(merged.aspect_ratios, ['16:9'])
assert.ok(merged.supported_frame_types.includes('reference_image'))

console.log('test-video-generation-params: ok')
