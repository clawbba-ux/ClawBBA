#!/usr/bin/env node
import assert from 'node:assert/strict'
import {
  aspectTemplateConflictMessage,
  parseAspectFromTemplate,
} from './clawbba-aspect-template.mjs'

const userTpl =
  '请使用 ClawBBA 生成图片能力，模型 google/gemini-2.5-flash-image，为我生成 9:16、1K 横图：根据参考图生成一个电商用的主图和详情图'

assert.ok(aspectTemplateConflictMessage(userTpl))
assert.equal(parseAspectFromTemplate(userTpl), null)
assert.equal(parseAspectFromTemplate('为我生成 9:16 竖图'), '9:16')
assert.equal(parseAspectFromTemplate('为我生成 16:9 横图'), '16:9')

console.log('test-aspect-template: ok')
