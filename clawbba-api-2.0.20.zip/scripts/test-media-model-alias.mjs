#!/usr/bin/env node
import assert from 'node:assert/strict'
import {
  resolvePlatformModelId,
  toOpenClawMediaModelRefWithAliases,
} from './clawbba-media-model-aliases.mjs'

assert.equal(resolvePlatformModelId('flux.2-pro'), 'black-forest-labs/flux.2-pro')
assert.equal(
  toOpenClawMediaModelRefWithAliases('flux.2-pro'),
  'openrouter/black-forest-labs/flux.2-pro',
)
assert.equal(
  toOpenClawMediaModelRefWithAliases('openrouter/google/gemini-2.5-flash-image'),
  'openrouter/google/gemini-2.5-flash-image',
)
assert.equal(resolvePlatformModelId('not-a-real-model-xyz'), null)

console.log('test-media-model-alias: ok')
