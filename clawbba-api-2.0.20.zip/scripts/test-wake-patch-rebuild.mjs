#!/usr/bin/env node
import assert from 'node:assert/strict'
import { execSync } from 'node:child_process'
import fs from 'fs'
import os from 'os'
import path from 'path'
import {
  EXTERNAL_WAKE_DELIVERY_MARKER,
  rebuildWakeInjectionSection,
  upgradeWakeExternalDelivery,
} from './clawbba-webchat-live-wake-patch.mjs'

const minimalWake = `async function wakeMediaGenerationTaskCompletion(params) {
\tif (!params.handle) return true;
\tconst announceId = \`\${params.toolName}:\${params.handle.taskId}:\${params.status}\`;
\tconst mediaUrls = Array.from(new Set([...params.mediaUrls ?? [], ...mediaUrlsFromGeneratedAttachments(params.attachments)]));
\tconst internalEvents = [];
\tconst triggerMessage = "done";
\tconst delivery = await deliverSubagentAnnouncement({
\t\trequesterSessionKey: params.handle.requesterSessionKey,
\t});
\treturn delivery.delivered;
}
`

/** v1.5.81 partial upgrade: new block + orphan legacy webchat try/catch */
const brokenPartialUpgrade = `async function wakeMediaGenerationTaskCompletion(params) {
\tif (!params.handle) return true;
\tconst announceId = \`\${params.toolName}:\${params.handle.taskId}:\${params.status}\`;
\tconst mediaUrls = Array.from(new Set([...params.mediaUrls ?? [], ...mediaUrlsFromGeneratedAttachments(params.attachments)]));
\tlet clawbbaWakeDeliveredExternal = false;
\t/* clawbba-external-wake-delivery */
\t/* clawbba-webchat-live-wake */
\tif (params.status === "ok" && mediaUrls.length > 0) {
\t\tconst __clawbbaSk = "x";
\t\tconst __clawbbaCh = "webchat";
\t\tif (!clawbbaWakeDeliveredExternal && __clawbbaSk && (__clawbbaCh === "webchat")) {
\t\t\ttry { await clawbbaInjectWebChatGeneratedMediaLive({}); } catch (_) {}
\t\t}
\t}
\t\ttry {
\t\t\tconst { clawbbaInjectWebChatGeneratedMediaLive } = await import("./subagent-announce-delivery-X.js");
\t\t\tawait clawbbaInjectWebChatGeneratedMediaLive({ sessionKey: __clawbbaSk, mediaUrls });
\t\t} catch (__clawbbaErr) {}
\t\t}
\t}
\tconst internalEvents = [];
\tconst delivery = await deliverSubagentAnnouncement({});
\treturn delivery.delivered;
}
`

const { src: fixed } = rebuildWakeInjectionSection(brokenPartialUpgrade, 'subagent-announce-delivery-X.js')
assert.ok(fixed.includes(EXTERNAL_WAKE_DELIVERY_MARKER))
const orphanTry = fixed.indexOf('const internalEvents')
const slice = fixed.slice(0, orphanTry)
assert.equal((slice.match(/\ttry \{/g) || []).length, 2, 'orphan try blocks should be gone')

const tmp = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'clawbba-wake-')), 'tools.js')
fs.writeFileSync(tmp, brokenPartialUpgrade)
const upgraded = upgradeWakeExternalDelivery(fs.readFileSync(tmp, 'utf8'), 'subagent-announce-delivery-X.js')
fs.writeFileSync(tmp, upgraded)
execSync(`node --check ${JSON.stringify(path.basename(tmp))}`, { cwd: path.dirname(tmp) })

const { src: fresh } = rebuildWakeInjectionSection(minimalWake, 'subagent-announce-delivery-X.js')
assert.ok(fresh.includes('clawbbaDispatchRecoverMediaDelivery'))

console.log('test-wake-patch-rebuild: ok')
