#!/usr/bin/env bash
# ClawBBA × OpenClaw 一次性配置（不调用 openclaw config patch，避免 --merge 兼容问题）
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
PATCH_FILE="${CLAWBBA_PATCH_FILE:-$ROOT_DIR/clawbba-openclaw.patch.json}"

echo "══════════════════════════════════════════"
echo " ClawBBA × OpenClaw 一次性配置"
echo "══════════════════════════════════════════"

if command -v openclaw >/dev/null 2>&1; then
  # shellcheck disable=SC1091
  source "$SCRIPT_DIR/openclaw-detect-version.sh"
  if openclaw_detect_version_from_skill "$ROOT_DIR" 0; then
    echo "→ OpenClaw ${OPENCLAW_VERSION:-unknown} · profile ${OPENCLAW_COMPAT_PROFILE_ID:-unknown}"
    export OPENCLAW_VERSION OPENCLAW_COMPAT_PROFILE_ID OPENCLAW_COMPAT_PROFILE_TIER
    export OPENCLAW_COMPAT_TOOLS_BUNDLE OPENCLAW_COMPAT_SUPPORTS_SYSTEM_PROMPT_OVERRIDE
  else
    echo "→ OpenClaw compat profile 检测失败，将按运行时 openclaw --version 推断" >&2
  fi
fi

if [[ -z "${CLAWBBA_API_KEY:-}" ]]; then
  echo "错误: 请 export CLAWBBA_API_KEY='cbb_sk_live_…'" >&2
  exit 1
fi

export CLAWBBA_API_BASE="${CLAWBBA_API_BASE:-https://www.clawbba.com/api/v1}"
export CLAWBBA_API_KEY
export OPENROUTER_API_KEY="${OPENROUTER_API_KEY:-$CLAWBBA_API_KEY}"

echo "→ 生成媒体能力表 media-capabilities…"
node "$SCRIPT_DIR/generate-media-capabilities.mjs"

echo "→ 生成配置 patch…"
node "$SCRIPT_DIR/generate-openclaw-patch.mjs" > "$PATCH_FILE"

echo "→ 合并 openclaw.json（保留本地额外模型）…"
node "$SCRIPT_DIR/apply-openclaw-config.mjs" "$PATCH_FILE"

echo "→ 修复 openclaw.json schema（OpenClaw 版本兼容）…"
node "$SCRIPT_DIR/fix-openclaw-config-schema.mjs"

echo "→ 同步 provider / models.json…"
node "$SCRIPT_DIR/fix-provider-config.mjs"

echo "→ 修复 provider schema（ClawBBA 生图/生视频模型表）…"
node "$SCRIPT_DIR/fix-openclaw-provider-schema.mjs"

echo "→ 修复文本看图 imageModel（clawbba vision，非生图 flux）…"
node "$SCRIPT_DIR/fix-openclaw-vision-config.mjs"

echo "→ 确保新建会话 ClawBBA 品牌（默认 clawbba 模型 + 同步 agent models.json）…"
node "$SCRIPT_DIR/ensure-clawbba-session-branding.mjs" "$PATCH_FILE"

if command -v openclaw >/dev/null 2>&1; then
  echo "→ 打入并验证 ClawBBA runtime patch（失败自动重试）…"
  bash "$SCRIPT_DIR/ensure-openclaw-patches.sh" --install

  echo "→ 验证 OpenClaw 配置…"
  if ! openclaw config validate; then
    echo "[clawbba-api] ✗ openclaw.json 校验失败；若提示 systemPromptOverride，请执行 node scripts/fix-openclaw-config-schema.mjs" >&2
    exit 1
  fi

  echo ""
  echo "✓ 配置已写入。一键安装脚本将自动 openclaw gateway restart"
  echo "  新开对话后用自然语言描述生图/生视频（见 references/media-capabilities.md）"
else
  echo "未找到 openclaw CLI，已写入 openclaw.json；安装 OpenClaw 后重跑 install-clawbba-api.sh"
fi
