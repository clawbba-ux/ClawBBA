#!/usr/bin/env node
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import {
  injectModuleLevelMediaRuntime,
  toolsSrcHasModuleLevelMediaRuntime,
  validateFnIsModuleScoped,
} from './clawbba-media-tool-validate.mjs'
import { videoValidateRuntimeIsHealthy } from './clawbba-video-validate-health.mjs'

const broken = `function createImageGenerateTool(options) {}
function createVideoGenerateTool(options) {
\texecute: async (args) => {
\t\tawait clawbbaValidateVideoGenerateParams({ params: args, options: {}, model: "x", prompt: "p", durationSeconds: 5, normalizeAspectRatioFn: (x) => x });
\t}
}`

assert.ok(!validateFnIsModuleScoped(broken))
const fixed = injectModuleLevelMediaRuntime(broken)
assert.ok(toolsSrcHasModuleLevelMediaRuntime(fixed))
assert.ok(videoValidateRuntimeIsHealthy(fixed))

console.log('test-video-validate-partial: ok')
