/**
 * Debug-mode NDJSON logger (session 8f862e). Safe: no secrets/PII.
 */
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'

const SESSION_ID = '8f862e'
const ENDPOINT = 'http://127.0.0.1:7861/ingest/e548f6c6-9195-45fa-9582-7d92f4968df8'
const LOG_CANDIDATES = [
  '/var/www/crypto-payment-demo/.cursor/debug-8f862e.log',
  path.join(os.homedir(), '.openclaw', 'clawbba-debug-8f862e.log'),
]

function resolveLogPath() {
  for (const p of LOG_CANDIDATES) {
    try {
      fs.mkdirSync(path.dirname(p), { recursive: true })
      fs.appendFileSync(p, '')
      return p
    } catch {
      /* try next */
    }
  }
  return LOG_CANDIDATES[1]
}

const LOG_PATH = resolveLogPath()

/** @param {{ hypothesisId?: string, location: string, message: string, data?: Record<string, unknown>, runId?: string }} entry */
export function clawbbaDebugLog(entry) {
  const line = JSON.stringify({
    sessionId: SESSION_ID,
    timestamp: Date.now(),
    ...entry,
  })
  try {
    fs.appendFileSync(LOG_PATH, `${line}\n`)
  } catch {
    /* ignore */
  }
  // #region agent log
  fetch(ENDPOINT, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-Debug-Session-Id': SESSION_ID },
    body: line,
  }).catch(() => {})
  // #endregion
}

export function clawbbaDebugLogPath() {
  return LOG_PATH
}
