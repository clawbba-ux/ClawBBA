#!/usr/bin/env node
import assert from 'node:assert/strict'
import {
  formatClawbbaUserMediaModelRef,
  isPlatformModelId,
  stripPlatformModelId,
  toOpenClawMediaModelRef,
} from './clawbba-media-model-ref.mjs'

assert.equal(stripPlatformModelId('openrouter/black-forest-labs/flux.2-pro'), 'black-forest-labs/flux.2-pro')
assert.equal(stripPlatformModelId('clawbba/google/gemini-2.5-flash-preview'), 'google/gemini-2.5-flash-preview')
assert.equal(toOpenClawMediaModelRef('black-forest-labs/flux.2-pro'), 'openrouter/black-forest-labs/flux.2-pro')
assert.equal(toOpenClawMediaModelRef('flux.2-pro'), 'openrouter/black-forest-labs/flux.2-pro')
assert.equal(toOpenClawMediaModelRef('openrouter/google/veo-3.1-fast'), 'openrouter/google/veo-3.1-fast')
assert.equal(toOpenClawMediaModelRef('clawbba/black-forest-labs/flux.2-pro'), 'openrouter/black-forest-labs/flux.2-pro')
assert.equal(isPlatformModelId('black-forest-labs/flux.2-pro'), true)
assert.equal(toOpenClawMediaModelRef('not-a-model'), null)
assert.equal(
  formatClawbbaUserMediaModelRef('openrouter', 'google/veo-3.1-lite'),
  'ClawBBA/google/veo-3.1-lite',
)
assert.equal(
  formatClawbbaUserMediaModelRef('openrouter', 'x-ai/grok-imagine-image-quality'),
  'ClawBBA/x-ai/grok-imagine-image-quality',
)
assert.equal(formatClawbbaUserMediaModelRef('openai', 'dall-e-3'), 'openai/dall-e-3')

console.log('[clawbba-api] ✓ media-model-ref tests passed')
