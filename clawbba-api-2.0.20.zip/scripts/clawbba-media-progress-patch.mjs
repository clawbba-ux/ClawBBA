/**
 * OpenClaw 生图/生视频后台任务进度：5s keepalive + 里程碑推送进度条到 WebChat / 微信等渠道。
 */
import fs from 'fs'
import path from 'path'

export const MEDIA_PROGRESS_MARKER = '/* clawbba-media-progress-v1 */'
export const MEDIA_PROGRESS_V2_MARKER = '/* clawbba-media-progress-v2 */'
export const MEDIA_PROGRESS_V3_MARKER = '/* clawbba-media-progress-v3-origin */'
export const MEDIA_PROGRESS_V4_MARKER = '/* clawbba-media-progress-v4-cfg */'
export const MEDIA_PROGRESS_POLL_MARKER = '/* clawbba-media-progress-poll-note */'

const KEEPALIVE_MS_NEEDLE = 'const MEDIA_GENERATION_TASK_KEEPALIVE_INTERVAL_MS = 6e4;'

function buildProgressHelpersBlock(announceBasename, deliveryRuntimeBasename) {
  return `${MEDIA_PROGRESS_MARKER}
${MEDIA_PROGRESS_V2_MARKER}
${MEDIA_PROGRESS_V3_MARKER}
const CLAWBBA_MEDIA_PROGRESS_EMIT_MIN_MS = 25e3;
const CLAWBBA_MEDIA_PROGRESS_MILESTONES = [0, 10, 25, 40, 55, 70, 85, 95];
function clawbbaFormatProgressBar(percent) {
\tconst p = Math.max(0, Math.min(100, Math.round(Number(percent) || 0)));
\tconst filled = Math.round(p / 5);
\treturn \`\${"█".repeat(filled)}\${"░".repeat(20 - filled)} \${p}%\`;
}
function clawbbaFormatLocalElapsedLabel(startedAt) {
\tconst elapsed = Math.max(0, Date.now() - (Number(startedAt) || Date.now()));
\tconst mins = Math.floor(elapsed / 6e4);
\tconst secs = Math.floor(elapsed / 1e3) % 60;
\treturn mins > 0 ? \`\${mins} 分 \${secs} 秒\` : \`\${secs} 秒\`;
}
function clawbbaNoteMediaPollProgress(pollBody) {
\tconst g = globalThis.__clawbbaMediaPollProgress || (globalThis.__clawbbaMediaPollProgress = {});
\tconst pct = typeof pollBody?.progress_percent === "number" ? pollBody.progress_percent : null;
\tif (pct == null) return;
\tconst taskStartedAt = typeof g.taskStartedAt === "number" ? g.taskStartedAt : null;
\tconst serverElapsedMs = typeof pollBody?.elapsed_ms === "number" ? pollBody.elapsed_ms : null;
\tlet elapsedLabel = typeof pollBody.elapsed_label === "string" ? pollBody.elapsed_label : "";
\tif (taskStartedAt != null && serverElapsedMs != null && serverElapsedMs > Math.max(120000, (Date.now() - taskStartedAt) + 90000)) {
\t\telapsedLabel = clawbbaFormatLocalElapsedLabel(taskStartedAt);
\t}
\tg.percent = pct;
\tg.label = typeof pollBody.progress_label === "string" ? pollBody.progress_label : "";
\tg.bar = typeof pollBody.progress_bar === "string" ? pollBody.progress_bar : clawbbaFormatProgressBar(pct);
\tg.elapsedLabel = elapsedLabel;
\tg.at = Date.now();
\tg.jobId = typeof pollBody?.job_id === "string" ? pollBody.job_id : (typeof pollBody?.jobId === "string" ? pollBody.jobId : g.jobId);
}
function clawbbaResolveMediaProgress(params) {
\tconst g = globalThis.__clawbbaMediaPollProgress || {};
\tconst anchor = typeof params.startedAt === "number" ? params.startedAt : null;
\tconst sameTask = anchor != null && typeof g.taskStartedAt === "number" && Math.abs(g.taskStartedAt - anchor) < 5000;
\tif (sameTask && g.at && Date.now() - g.at < 45e3 && typeof g.percent === "number") {
\t\tlet elapsedLabel = g.elapsedLabel || "";
\t\tif (!elapsedLabel && anchor != null) elapsedLabel = clawbbaFormatLocalElapsedLabel(anchor);
\t\treturn {
\t\t\tpercent: g.percent,
\t\t\tlabel: g.label || params.fallbackLabel,
\t\t\tbar: g.bar || clawbbaFormatProgressBar(g.percent),
\t\t\telapsedLabel
\t\t};
\t}
\tconst elapsed = Math.max(0, Date.now() - params.startedAt);
\tconst expected = params.expectedMs || (params.mediaKind === "video" ? 720e3 : 300e3);
\tconst pct = Math.max(3, Math.min(95, Math.round(elapsed / expected * 100)));
\tconst mins = Math.floor(elapsed / 6e4);
\tconst secs = Math.floor(elapsed / 1e3) % 60;
\tconst elapsedLabel = mins > 0 ? \`\${mins} 分 \${secs} 秒\` : \`\${secs} 秒\`;
\treturn {
\t\tpercent: pct,
\t\tlabel: params.fallbackLabel,
\t\tbar: clawbbaFormatProgressBar(pct),
\t\telapsedLabel
\t};
}
function clawbbaBuildProgressUserMessage(params) {
\tconst icon = params.mediaKind === "video" ? "🎬" : "🎨";
\treturn [
\t\t\`\${icon} \${params.label}\`,
\t\tparams.bar,
\t\tparams.elapsedLabel ? \`已等待 \${params.elapsedLabel} · 完成后会自动发送\` : "完成后会自动发送"
\t].filter(Boolean).join("\\n");
}
function clawbbaShouldEmitProgressMilestone(state, percent) {
\tconst p = Math.max(0, Math.min(100, Math.round(Number(percent) || 0)));
\tif (state.lastEmittedPercent == null) return true;
\tif (p >= 100 && state.lastEmittedPercent < 100) return true;
\tconst last = state.lastEmittedPercent;
\tfor (const m of CLAWBBA_MEDIA_PROGRESS_MILESTONES) {
\t\tif (last < m && p >= m) return true;
\t}
\treturn Date.now() - (state.lastEmitAt || 0) >= CLAWBBA_MEDIA_PROGRESS_EMIT_MIN_MS && p - last >= 8;
}
async function clawbbaEmitMediaGenerationProgressLive(params) {
\tif (!params?.handle) return false;
\tconst resolved = clawbbaResolveMediaProgress({
\t\tstartedAt: params.startedAt,
\t\texpectedMs: params.expectedMs,
\t\tmediaKind: params.mediaKind,
\t\tfallbackLabel: params.fallbackLabel
\t});
\tif (!clawbbaShouldEmitProgressMilestone(params.state, resolved.percent)) return false;
\tconst message = clawbbaBuildProgressUserMessage({
\t\tmediaKind: params.mediaKind,
\t\tlabel: resolved.label,
\t\tbar: resolved.bar,
\t\telapsedLabel: resolved.elapsedLabel
\t});
\tparams.state.lastEmittedPercent = resolved.percent;
\tparams.state.lastEmitAt = Date.now();
\trecordMediaGenerationTaskProgress({
\t\thandle: params.handle,
\t\tprogressSummary: \`\${resolved.label} \${resolved.percent}%\`,
\t\teventSummary: resolved.bar
\t});
\tconst sessionKey = typeof params.handle.requesterSessionKey === "string" ? params.handle.requesterSessionKey.trim() : "";
\tif (!sessionKey) return false;
\tlet origin = null;
\tif (typeof clawbbaResolveMediaDeliveryContext === "function") {
\t\tconst resolvedCtx = await clawbbaResolveMediaDeliveryContext({ sessionKey, requesterOrigin: params.handle?.requesterOrigin, cfg: params.config });
\t\torigin = resolvedCtx?.origin ?? null;
\t}
\tif (!origin) origin = normalizeDeliveryContext(params.handle.requesterOrigin);
\tif (origin?.channel && origin?.to && isDeliverableMessageChannel(origin.channel)) {
\t\ttry {
\t\t\tconst agentId = resolveAgentIdFromSessionKey(sessionKey);
\t\t\tconst { sendMessage } = await import("./${deliveryRuntimeBasename}");
\t\t\tawait sendMessage({
\t\t\t\tcfg: params.config,
\t\t\t\tchannel: origin.channel,
\t\t\t\tto: origin.to,
\t\t\t\taccountId: origin.accountId,
\t\t\t\tthreadId: origin.threadId,
\t\t\t\tcontent: message,
\t\t\t\trequesterSessionKey: sessionKey,
\t\t\t\tagentId,
\t\t\t\tbestEffort: true,
\t\t\t\tmirror: { sessionKey, agentId }
\t\t\t});
\t\t\treturn true;
\t\t} catch (error) {
\t\t\ttry {
\t\t\t\tlog$5.warn("clawbba media progress direct delivery failed", { error: String(error?.message ?? error) });
\t\t\t} catch (_) {}
\t\t}
\t}
\ttry {
\t\tconst { clawbbaInjectMediaProgressLive } = await import("./${announceBasename}");
\t\treturn await clawbbaInjectMediaProgressLive({
\t\t\tsessionKey,
\t\t\tchatRunId: typeof params.handle?.requesterChatRunId === "string" ? params.handle.requesterChatRunId : void 0,
\t\t\tmessage,
\t\t\tlabel: params.mediaKind === "video" ? "ClawBBA 视频进度" : "ClawBBA 生图进度"
\t\t});
\t} catch (error) {
\t\ttry {
\t\t\tlog$5.warn("clawbba media progress inject failed", { error: String(error?.message ?? error) });
\t\t} catch (_) {}
\t}
\treturn false;
}
async function clawbbaWithMediaGenerationTaskKeepalive(params) {
\tif (!params.handle) return await params.run();
\tconst mediaKind = params.mediaKind === "video" ? "video" : "image";
\tconst fallbackLabel = mediaKind === "video" ? "正在生成视频…" : "正在生成图片…";
\tconst startedAt = Date.now();
\tconst expectedMs = mediaKind === "video" ? 720e3 : 300e3;
\tconst emitState = { lastEmitAt: 0, lastEmittedPercent: null };
\tglobalThis.__clawbbaMediaPollProgress = { taskStartedAt: startedAt, taskId: params.handle?.taskId ?? null };
\tawait clawbbaEmitMediaGenerationProgressLive({
\t\thandle: params.handle,
\t\tconfig: params.config,
\t\tstartedAt,
\t\texpectedMs,
\t\tmediaKind,
\t\tfallbackLabel,
\t\tstate: emitState
\t});
\tconst interval = setInterval(() => {
\t\tvoid clawbbaEmitMediaGenerationProgressLive({
\t\t\thandle: params.handle,
\t\t\tconfig: params.config,
\t\t\tstartedAt,
\t\t\texpectedMs,
\t\t\tmediaKind,
\t\t\tfallbackLabel,
\t\t\tstate: emitState
\t\t});
\t}, MEDIA_GENERATION_TASK_KEEPALIVE_INTERVAL_MS);
\tinterval.unref?.();
\ttry {
\t\treturn await params.run();
\t} finally {
\t\tclearInterval(interval);
\t}
}`
}

const WITH_KEEPALIVE_NEEDLE = `async function withMediaGenerationTaskKeepalive(params) {
\tif (!params.handle) return await params.run();
\tconst interval = setInterval(() => {
\t\trecordMediaGenerationTaskProgress({
\t\t\thandle: params.handle,
\t\t\tprogressSummary: params.progressSummary,
\t\t\teventSummary: params.eventSummary
\t\t});
\t}, MEDIA_GENERATION_TASK_KEEPALIVE_INTERVAL_MS);
\tinterval.unref?.();
\ttry {
\t\treturn await params.run();
\t} finally {
\t\tclearInterval(interval);
\t}
}`

const WITH_KEEPALIVE_REPLACEMENT = `async function withMediaGenerationTaskKeepalive(params) {
\treturn clawbbaWithMediaGenerationTaskKeepalive(params);
}`

const SCHEDULE_KEEPALIVE_CALL_NEEDLE = `\t\t\tconst executed = await withMediaGenerationTaskKeepalive({
\t\t\t\thandle: params.handle,
\t\t\t\tprogressSummary: params.progressSummary,
\t\t\t\trun: params.run
\t\t\t});`

const SCHEDULE_KEEPALIVE_CALL_REPLACEMENT = `\t\t\tconst executed = await withMediaGenerationTaskKeepalive({
\t\t\t\thandle: params.handle,
\t\t\t\tconfig: params.config,
\t\t\t\tprogressSummary: params.progressSummary,
\t\t\t\tmediaKind: /video/i.test(String(params.toolName || "")) ? "video" : "image",
\t\t\t\trun: params.run
\t\t\t});`

const STARTED_TOOL_NEEDLE =
  'text: [`Background task started for ${params.generationLabel} generation (${params.taskHandle?.taskId ?? "unknown"}). Do not call ${params.toolName} again for this request. Wait for the completion event; the completion agent will send the finished ${params.completionLabel} here when it\'s ready.`, ...params.messages ?? []].filter((entry) => Boolean(entry)).join("\\n")'

const STARTED_TOOL_REPLACEMENT =
  'text: [`Background task started for ${params.generationLabel} generation (${params.taskHandle?.taskId ?? "unknown"}). Do not call ${params.toolName} again for this request. Wait for the completion event; the completion agent will send the finished ${params.completionLabel} here when it\'s ready.`, "ClawBBA: reply ONE short line to the user now (e.g. 正在生成图片/视频，请稍候…). Progress updates will be pushed automatically during generation.", ...params.messages ?? []].filter((entry) => Boolean(entry)).join("\\n")'

const IMAGE_POLL_INSERT_NEEDLE = `\t\t\t\t\t\ttry {
\t\t\t\t\t\t\tpollBody = await pollRes.json();
\t\t\t\t\t\t} catch (_) {
\t\t\t\t\t\t\tpollBody = null;
\t\t\t\t\t\t}
\t\t\t\t\t\tif (!pollRes.ok && pollRes.status !== 404) continue;`

const IMAGE_POLL_NOTE = `\t\t\t\t\t\t${MEDIA_PROGRESS_POLL_MARKER}
\t\t\t\t\t\tclawbbaNoteMediaPollProgress(pollBody);`

const VIDEO_POLL_INSERT_NEEDLE = `\t\t\terrorContext: "OpenRouter video status request failed",
\t\t\tauditContext: "openrouter-video-status"
\t\t});
\t\tconst status = normalizeOptionalString(payload.status);`

const VIDEO_POLL_NOTE = `\t\t${MEDIA_PROGRESS_POLL_MARKER}
\t\tclawbbaNoteMediaPollProgress(payload);
\t\tconst status = normalizeOptionalString(payload.status);`

const VIDEO_POLL_INSERT_REPLACEMENT = `\t\t\terrorContext: "OpenRouter video status request failed",
\t\t\tauditContext: "openrouter-video-status"
\t\t});
${VIDEO_POLL_NOTE}`

const IMAGE_POLL_HELPER = `function clawbbaNoteMediaPollProgress(pollBody) {
\tconst g = globalThis.__clawbbaMediaPollProgress || (globalThis.__clawbbaMediaPollProgress = {});
\tconst pct = typeof pollBody?.progress_percent === "number" ? pollBody.progress_percent : null;
\tif (pct == null) return;
\tg.percent = pct;
\tg.label = typeof pollBody.progress_label === "string" ? pollBody.progress_label : "";
\tg.bar = typeof pollBody.progress_bar === "string" ? pollBody.progress_bar : \`\${Math.round(pct)}%\`;
\tg.elapsedLabel = typeof pollBody.elapsed_label === "string" ? pollBody.elapsed_label : "";
\tg.at = Date.now();
}
`

/** 1.5.32 bug: helper was inserted inside provider return object → ParseError */
export function repairBrokenImagePollHelperInsert(src) {
  let next = src
  const badInsideObject =
    /(\t+\/\* clawbba-image-provider \*\/\n)?\t+function clawbbaNoteMediaPollProgress\(pollBody\) \{[\s\S]*?\n\}\n(\t+)?async generateImage\(req\) \{/g
  if (badInsideObject.test(next)) {
    next = next.replace(badInsideObject, (m, markerPart, indent) => {
      const marker = markerPart || `${indent || '\t\t'}/* clawbba-image-provider */\n`
      return `${marker}${indent || '\t\t'}async generateImage(req) {`
    })
  }
  return next
}

function ensureModuleLevelPollHelper(src) {
  let next = repairBrokenImagePollHelperInsert(src)
  if (next.includes('function clawbbaNoteMediaPollProgress(')) return next
  const anchors = [
    'function buildOpenRouterImageGenerationProvider() {',
    'function buildOpenRouterImageGenerationProvider () {',
  ]
  for (const anchor of anchors) {
    if (next.includes(anchor)) {
      return next.replace(anchor, `${IMAGE_POLL_HELPER}${anchor}`)
    }
  }
  return next
}

function findOpenclawToolsFile(dist) {
  return fs.readdirSync(dist).find((name) => {
    if (!name.startsWith('openclaw-tools-') || !name.endsWith('.js')) return false
    return fs.readFileSync(path.join(dist, name), 'utf8').includes('async function withMediaGenerationTaskKeepalive(params)')
  })
}

function findAnnounceBasename(dist) {
  return fs.readdirSync(dist).find((name) => {
    if (!name.startsWith('subagent-announce-delivery-') || !name.endsWith('.js')) return false
    return fs.readFileSync(path.join(dist, name), 'utf8').includes('clawbbaInjectWebChatGeneratedMediaLive')
  })
}

function findDeliveryRuntimeBasename(dist, toolsSrc) {
  const fromTools = toolsSrc.match(/import\("\.\/(task-registry-delivery-runtime-[^"]+\.js)"\)/)
  if (fromTools) return fromTools[1]
  return fs.readdirSync(dist).find((name) => name.startsWith('task-registry-delivery-runtime-') && name.endsWith('.js'))
}

function patchToolsProgress(dist) {
  const file = findOpenclawToolsFile(dist)
  if (!file) return 'missing-tools'
  const announce = findAnnounceBasename(dist)
  if (!announce) return 'missing-announce'

  const filePath = path.join(dist, file)
  let src = fs.readFileSync(filePath, 'utf8')
  const deliveryRuntime = findDeliveryRuntimeBasename(dist, src)
  if (!deliveryRuntime) return 'missing-delivery-runtime'
  if (src.includes(MEDIA_PROGRESS_MARKER) && src.includes('clawbbaWithMediaGenerationTaskKeepalive')) {
    const upgradedV4 = upgradeMediaProgressToolsV4Cfg(src)
    if (upgradedV4 !== src) {
      fs.writeFileSync(filePath, upgradedV4)
      return 'upgraded-tools-v4'
    }
    const upgradedV3 = upgradeMediaProgressToolsV3(src)
    if (upgradedV3 !== src) {
      fs.writeFileSync(filePath, upgradedV3)
      return 'upgraded-tools-v3'
    }
    const upgraded = upgradeMediaProgressToolsV2(src, announce)
    if (upgraded !== src) {
      fs.writeFileSync(filePath, upgraded)
      return 'upgraded-tools-v2'
    }
    let throttled = false
    if (src.includes('MEDIA_GENERATION_TASK_KEEPALIVE_INTERVAL_MS = 5e3')) {
      src = src.replace(
        'MEDIA_GENERATION_TASK_KEEPALIVE_INTERVAL_MS = 5e3',
        'MEDIA_GENERATION_TASK_KEEPALIVE_INTERVAL_MS = 12e3',
      )
      throttled = true
    }
    if (src.includes('CLAWBBA_MEDIA_PROGRESS_EMIT_MIN_MS = 12e3')) {
      src = src.replace(
        'CLAWBBA_MEDIA_PROGRESS_EMIT_MIN_MS = 12e3',
        'CLAWBBA_MEDIA_PROGRESS_EMIT_MIN_MS = 25e3',
      )
      throttled = true
    }
    if (throttled) {
      fs.writeFileSync(filePath, src)
      return 'upgraded-tools-throttle'
    }
    return 'skip'
  }

  if (src.includes(KEEPALIVE_MS_NEEDLE)) {
    src = src.replace(
      KEEPALIVE_MS_NEEDLE,
      'const MEDIA_GENERATION_TASK_KEEPALIVE_INTERVAL_MS = 12e3;',
    )
  } else if (src.includes('MEDIA_GENERATION_TASK_KEEPALIVE_INTERVAL_MS = 5e3')) {
    src = src.replace(
      'MEDIA_GENERATION_TASK_KEEPALIVE_INTERVAL_MS = 5e3',
      'MEDIA_GENERATION_TASK_KEEPALIVE_INTERVAL_MS = 12e3',
    )
  } else if (!src.includes('MEDIA_GENERATION_TASK_KEEPALIVE_INTERVAL_MS = 12e3')) {
    return 'pattern-missing-keepalive-ms'
  }

  const helperBlock = buildProgressHelpersBlock(announce, deliveryRuntime)
  const insertBefore = 'function touchMediaGenerationTaskRunContext(handle) {'
  if (!src.includes('function clawbbaWithMediaGenerationTaskKeepalive')) {
    if (!src.includes(insertBefore)) return 'pattern-missing-touch-fn'
    src = src.replace(insertBefore, `${helperBlock}\n${insertBefore}`)
  }

  if (src.includes(WITH_KEEPALIVE_NEEDLE)) {
    src = src.replace(WITH_KEEPALIVE_NEEDLE, WITH_KEEPALIVE_REPLACEMENT)
  } else if (!src.includes('clawbbaWithMediaGenerationTaskKeepalive(params)')) {
    return 'pattern-missing-keepalive-fn'
  }

  if (src.includes(SCHEDULE_KEEPALIVE_CALL_NEEDLE)) {
    src = src.replace(SCHEDULE_KEEPALIVE_CALL_NEEDLE, SCHEDULE_KEEPALIVE_CALL_REPLACEMENT)
  }

  if (src.includes(STARTED_TOOL_NEEDLE)) {
    src = src.replace(STARTED_TOOL_NEEDLE, STARTED_TOOL_REPLACEMENT)
  }

  fs.writeFileSync(filePath, src)
  return 'patched-tools'
}

function patchImageProviderProgress(dist) {
  const file = fs.readdirSync(dist).find((name) => {
    if (!name.startsWith('image-generation-provider-') || !name.endsWith('.js')) return false
    const src = fs.readFileSync(path.join(dist, name), 'utf8')
    return src.includes('async generateImage(req)') && src.includes('clawbba-image-async-job-poll')
  })
  if (!file) return 'missing-image'
  const filePath = path.join(dist, file)
  let src = fs.readFileSync(filePath, 'utf8')
  const before = src
  src = ensureModuleLevelPollHelper(src)
  if (!src.includes(IMAGE_POLL_INSERT_NEEDLE)) return 'pattern-missing-image'
  if (!src.includes(MEDIA_PROGRESS_POLL_MARKER)) {
    src = src.replace(IMAGE_POLL_INSERT_NEEDLE, `${IMAGE_POLL_INSERT_NEEDLE}\n${IMAGE_POLL_NOTE}`)
  }
  if (src === before) return src.includes(MEDIA_PROGRESS_POLL_MARKER) ? 'skip-image' : 'pattern-missing-image'
  fs.writeFileSync(filePath, src)
  return before.includes('function clawbbaNoteMediaPollProgress(pollBody) {') &&
    before.includes('\t\tfunction clawbbaNoteMediaPollProgress')
    ? 'repaired-image'
    : 'patched-image'
}

function patchVideoProviderProgress(dist) {
  const file = fs.readdirSync(dist).find((name) => {
    if (!name.startsWith('video-generation-provider-') || !name.endsWith('.js')) return false
    const src = fs.readFileSync(path.join(dist, name), 'utf8')
    return (
      src.includes('async function pollOpenRouterVideo(params)') &&
      src.includes('auditContext: "openrouter-video-status"')
    )
  })
  if (!file) return 'missing-video'
  const filePath = path.join(dist, file)
  let src = fs.readFileSync(filePath, 'utf8')
  if (src.includes(MEDIA_PROGRESS_POLL_MARKER)) return 'skip-video'
  if (!src.includes(VIDEO_POLL_INSERT_NEEDLE)) return 'pattern-missing-video'

  if (!src.includes('function clawbbaNoteMediaPollProgress(')) {
    src = src.replace(
      'async function pollOpenRouterVideo(params) {',
      `${IMAGE_POLL_HELPER}async function pollOpenRouterVideo(params) {`,
    )
  }
  src = src.replace(VIDEO_POLL_INSERT_NEEDLE, VIDEO_POLL_INSERT_REPLACEMENT)
  fs.writeFileSync(filePath, src)
  return 'patched-video'
}

/** @param {string} src @param {string} announceBasename */
export function upgradeMediaProgressToolsV2(src, announceBasename) {
  if (!src.includes(MEDIA_PROGRESS_MARKER) || src.includes(MEDIA_PROGRESS_V2_MARKER)) return src
  let next = src.replace(MEDIA_PROGRESS_MARKER, `${MEDIA_PROGRESS_MARKER}\n${MEDIA_PROGRESS_V2_MARKER}`)
  if (!next.includes('function clawbbaFormatLocalElapsedLabel')) {
    next = next.replace(
      'function clawbbaNoteMediaPollProgress(pollBody) {',
      `function clawbbaFormatLocalElapsedLabel(startedAt) {
\tconst elapsed = Math.max(0, Date.now() - (Number(startedAt) || Date.now()));
\tconst mins = Math.floor(elapsed / 6e4);
\tconst secs = Math.floor(elapsed / 1e3) % 60;
\treturn mins > 0 ? \`\${mins} 分 \${secs} 秒\` : \`\${secs} 秒\`;
}
function clawbbaNoteMediaPollProgress(pollBody) {`,
    )
  }
  const oldNoteFn =
    /function clawbbaNoteMediaPollProgress\(pollBody\) \{\s*const g = globalThis\.__clawbbaMediaPollProgress[\s\S]*?g\.at = Date\.now\(\);\s*\}/
  const newNoteFn = `function clawbbaNoteMediaPollProgress(pollBody) {
\tconst g = globalThis.__clawbbaMediaPollProgress || (globalThis.__clawbbaMediaPollProgress = {});
\tconst pct = typeof pollBody?.progress_percent === "number" ? pollBody.progress_percent : null;
\tif (pct == null) return;
\tconst taskStartedAt = typeof g.taskStartedAt === "number" ? g.taskStartedAt : null;
\tconst serverElapsedMs = typeof pollBody?.elapsed_ms === "number" ? pollBody.elapsed_ms : null;
\tlet elapsedLabel = typeof pollBody.elapsed_label === "string" ? pollBody.elapsed_label : "";
\tif (taskStartedAt != null && serverElapsedMs != null && serverElapsedMs > Math.max(120000, (Date.now() - taskStartedAt) + 90000)) {
\t\telapsedLabel = clawbbaFormatLocalElapsedLabel(taskStartedAt);
\t}
\tg.percent = pct;
\tg.label = typeof pollBody.progress_label === "string" ? pollBody.progress_label : "";
\tg.bar = typeof pollBody.progress_bar === "string" ? pollBody.progress_bar : clawbbaFormatProgressBar(pct);
\tg.elapsedLabel = elapsedLabel;
\tg.at = Date.now();
\tg.jobId = typeof pollBody?.job_id === "string" ? pollBody.job_id : (typeof pollBody?.jobId === "string" ? pollBody.jobId : g.jobId);
}`
  if (oldNoteFn.test(next)) next = next.replace(oldNoteFn, newNoteFn)

  const oldResolveHead =
    /function clawbbaResolveMediaProgress\(params\) \{\s*const g = globalThis\.__clawbbaMediaPollProgress[\s\S]*?elapsedLabel: g\.elapsedLabel \|\| ""\s*\};\s*\}/
  const newResolveHead = `function clawbbaResolveMediaProgress(params) {
\tconst g = globalThis.__clawbbaMediaPollProgress || {};
\tconst anchor = typeof params.startedAt === "number" ? params.startedAt : null;
\tconst sameTask = anchor != null && typeof g.taskStartedAt === "number" && Math.abs(g.taskStartedAt - anchor) < 5000;
\tif (sameTask && g.at && Date.now() - g.at < 45e3 && typeof g.percent === "number") {
\t\tlet elapsedLabel = g.elapsedLabel || "";
\t\tif (!elapsedLabel && anchor != null) elapsedLabel = clawbbaFormatLocalElapsedLabel(anchor);
\t\treturn {
\t\t\tpercent: g.percent,
\t\t\tlabel: g.label || params.fallbackLabel,
\t\t\tbar: g.bar || clawbbaFormatProgressBar(g.percent),
\t\t\telapsedLabel
\t\t};
\t}`
  if (oldResolveHead.test(next)) next = next.replace(oldResolveHead, newResolveHead)

  if (!next.includes('globalThis.__clawbbaMediaPollProgress = { taskStartedAt: startedAt')) {
    next = next.replace(
      'const emitState = { lastEmitAt: 0, lastEmittedPercent: null };\n\tawait clawbbaEmitMediaGenerationProgressLive({',
      'const emitState = { lastEmitAt: 0, lastEmittedPercent: null };\n\tglobalThis.__clawbbaMediaPollProgress = { taskStartedAt: startedAt, taskId: params.handle?.taskId ?? null };\n\tawait clawbbaEmitMediaGenerationProgressLive({',
    )
  }

  const injectNeedle = `return await clawbbaInjectMediaProgressLive({
\t\t\tsessionKey,
\t\t\tmessage,`
  const injectReplacement = `return await clawbbaInjectMediaProgressLive({
\t\t\tsessionKey,
\t\t\tchatRunId: typeof params.handle?.requesterChatRunId === "string" ? params.handle.requesterChatRunId : void 0,
\t\t\tmessage,`
  if (next.includes(injectNeedle) && !next.includes('requesterChatRunId')) {
    next = next.replace(injectNeedle, injectReplacement)
  }

  return next
}

/** @param {string} src */
export function upgradeMediaProgressToolsV4Cfg(src) {
  if (!src.includes(MEDIA_PROGRESS_MARKER) || src.includes(MEDIA_PROGRESS_V4_MARKER)) return src
  const oldResolve =
    'await clawbbaResolveMediaDeliveryContext({ sessionKey, requesterOrigin: params.handle?.requesterOrigin });'
  const newResolve =
    'await clawbbaResolveMediaDeliveryContext({ sessionKey, requesterOrigin: params.handle?.requesterOrigin, cfg: params.config });'
  if (!src.includes(oldResolve)) return src
  return src.replace(MEDIA_PROGRESS_V3_MARKER, `${MEDIA_PROGRESS_V3_MARKER}\n${MEDIA_PROGRESS_V4_MARKER}`).replaceAll(oldResolve, newResolve)
}

/** @param {string} src */
export function upgradeMediaProgressToolsV3(src) {
  if (!src.includes(MEDIA_PROGRESS_MARKER) || src.includes(MEDIA_PROGRESS_V3_MARKER)) return src
  const oldOrigin =
    '\tconst origin = normalizeDeliveryContext(params.handle.requesterOrigin);'
  const newOrigin = `\tlet origin = null;
\tif (typeof clawbbaResolveMediaDeliveryContext === "function") {
\t\tconst resolvedCtx = await clawbbaResolveMediaDeliveryContext({ sessionKey, requesterOrigin: params.handle?.requesterOrigin, cfg: params.config });
\t\torigin = resolvedCtx?.origin ?? null;
\t}
\tif (!origin) origin = normalizeDeliveryContext(params.handle.requesterOrigin);`
  if (!src.includes(oldOrigin)) return src
  return src.replace(MEDIA_PROGRESS_V2_MARKER, `${MEDIA_PROGRESS_V2_MARKER}\n${MEDIA_PROGRESS_V3_MARKER}`).replace(oldOrigin, newOrigin)
}

/** @param {string} dist */
export function patchMediaGenerationProgress(dist) {
  return {
    tools: patchToolsProgress(dist),
    image: patchImageProviderProgress(dist),
    video: patchVideoProviderProgress(dist),
  }
}
