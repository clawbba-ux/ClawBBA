#!/usr/bin/env node
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { execSync } from 'node:child_process'

import { countFunctionDefinitions } from './clawbba-external-recover-delivery.mjs'

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'clawbba-patch-528-'))
const tgz = path.join('/var/www/crypto-payment-demo/packages/clawbba-api', 'openclaw-2026.5.28.tgz')
assert.ok(fs.existsSync(tgz), 'openclaw-2026.5.28.tgz required')
execSync(`tar -xzf ${JSON.stringify(tgz)}`, { cwd: tmp })
const dist = path.join(tmp, 'package', 'dist')
execSync(`OPENCLAW_DIST=${JSON.stringify(dist)} node ${JSON.stringify(path.join('/var/www/crypto-payment-demo/packages/clawbba-api/scripts/patch-openclaw-media-delivery.mjs'))}`, {
  stdio: 'pipe',
})
const tools = fs.readdirSync(dist).find((n) => n.startsWith('openclaw-tools-'))
const src = fs.readFileSync(path.join(dist, tools), 'utf8')
const matches = src.match(/function clawbbaReadRecoverJobIdField/g) || []
assert.equal(matches.length, 1, 'helper must be injected once')
assert.ok(!src.includes('pick.image_job_id || pick.job_id'))
assert.ok(src.includes('clawbbaValidateImageGenerateParams'))
assert.ok(!src.includes('clawbbaResolveMediaTemplateText'))
assert.ok(src.includes('clawbba-image-recover-strict-job'))
assert.ok(!src.includes('globalThis.__clawbbaLastImageJobId'))
assert.equal(countFunctionDefinitions(src, 'clawbbaDedupeImageBuffers'), 1, 'dedupe helper once')
execSync(`node --check ${JSON.stringify(path.join(dist, tools))}`)
console.log('test-patch-fresh-528: ok')
