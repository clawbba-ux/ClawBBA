import {
  CLAWBBA_VALIDATE_VIDEO_FN,
  MEDIA_DISPATCH_VIDEO_MARKER,
  validateFnIsModuleScoped,
} from './clawbba-media-tool-validate.mjs'

/** @param {string} src */
export function videoDispatchPresent(src) {
  return (
    src.includes(MEDIA_DISPATCH_VIDEO_MARKER) ||
    /await clawbbaValidateVideoGenerateParams\s*\(/.test(src)
  )
}

/** @param {string} src */
export function videoValidateFnPresent(src) {
  return src.includes(CLAWBBA_VALIDATE_VIDEO_FN)
}

/** Broken: dispatch 调用 validate，但 validate 不在模块级（常见于 528 误注入 image_generate 内部） */
export function videoValidateRuntimeIsBroken(src) {
  if (!videoDispatchPresent(src)) return false
  if (!validateFnIsModuleScoped(src)) return true
  return (
    videoDispatchPresent(src) &&
    src.includes(CLAWBBA_VALIDATE_VIDEO_FN) &&
    !src.includes('clawbbaResolveVideoDurationSeconds')
  )
}

/** @param {string} src */
export function videoValidateRuntimeIsHealthy(src) {
  if (!videoDispatchPresent(src)) return true
  if (!validateFnIsModuleScoped(src)) return false
  if (src.includes(CLAWBBA_VALIDATE_VIDEO_FN) && !src.includes('clawbbaResolveVideoDurationSeconds')) {
    return false
  }
  return true
}

/** @param {string} src */
export function mediaValidateRuntimeSummary(src) {
  return {
    videoDispatch: videoDispatchPresent(src),
    videoValidateFn: videoValidateFnPresent(src),
    moduleScoped: validateFnIsModuleScoped(src),
    broken: videoValidateRuntimeIsBroken(src),
  }
}
