#!/usr/bin/env node
import assert from 'node:assert/strict'
import { RESOLUTION_ALIAS_MARKER, upgradeImageResolutionAliases } from './clawbba-image-resolution-alias.mjs'

const vanilla = `function normalizeResolution$1(raw) {
\tconst normalized = raw?.trim().toUpperCase();
\tif (!normalized) return;
\tif (normalized === "1K" || normalized === "2K" || normalized === "4K") return normalized;
\tthrow new ToolInputError("resolution must be one of 1K, 2K, or 4K");
}`

const upgraded = upgradeImageResolutionAliases(vanilla)
assert.ok(upgraded.includes(RESOLUTION_ALIAS_MARKER))
assert.ok(upgraded.includes('"1080P": "2K"'))
assert.equal(upgradeImageResolutionAliases(upgraded), upgraded)

console.log('test-image-resolution-alias: ok')
