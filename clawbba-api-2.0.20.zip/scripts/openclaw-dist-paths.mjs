/**
 * Discover every OpenClaw dist/ directory that may be loaded at runtime.
 *
 * Covers: npm / pnpm / yarn global, nvm shims, system node_modules, OPENCLAW_DIST,
 * CLI script targets, and pnpm content-addressable store (.pnpm/...).
 *
 * Patch + verify must use findAllOpenclawDists() so no install layout is missed.
 */
import fs from 'fs'
import os from 'os'
import path from 'path'
import { execSync } from 'child_process'

const MARKER_FILE_PREFIX = 'openclaw-tools-'

function runQuiet(cmd) {
  try {
    return execSync(cmd, { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] }).trim()
  } catch {
    return ''
  }
}

export function distLooksLikeOpenclaw(dist) {
  if (!dist || typeof dist !== 'string') return false
  try {
    return fs
      .readdirSync(dist)
      .some((name) => name.startsWith(MARKER_FILE_PREFIX) && name.endsWith('.js'))
  } catch {
    return false
  }
}

function pushUnique(list, value) {
  if (!value || typeof value !== 'string') return
  const resolved = path.resolve(value.trim())
  if (!list.includes(resolved)) list.push(resolved)
}

function realpathSafe(p) {
  try {
    return fs.realpathSync(p)
  } catch {
    return path.resolve(p)
  }
}

/** OPENCLAW_DIST or colon-separated OPENCLAW_DISTS */
function pushEnvDistDirs(list) {
  for (const key of ['OPENCLAW_DIST', 'OPENCLAW_DISTS']) {
    const raw = process.env[key]
    if (!raw) continue
    for (const part of raw.split(path.delimiter)) {
      const trimmed = part.trim()
      if (!trimmed) continue
      pushUnique(list, trimmed)
      if (!trimmed.endsWith(`${path.sep}dist`)) {
        pushUnique(list, path.join(trimmed, 'dist'))
      }
    }
  }
}

function resolveDistFromPackageJson(packageJsonPath) {
  if (!packageJsonPath) return null
  return path.join(path.dirname(packageJsonPath), 'dist')
}

/** Same Node resolution the CLI/gateway uses when openclaw is on PATH. */
function resolveDistViaRequire() {
  const out = runQuiet(
    'node -e "try{const p=require.resolve(\\"openclaw/package.json\\");process.stdout.write(p)}catch{process.exit(1)}"',
  )
  return out ? resolveDistFromPackageJson(out) : null
}

/** Parse npm/pnpm/yarn shell shim or symlink to dist/index.js */
function resolveDistFromCliBin(binPath) {
  if (!binPath) return null
  const found = []

  try {
    const realBin = fs.realpathSync(binPath)
    pushUnique(found, inferDistFromIndexJs(realBin))

    const stat = fs.statSync(realBin)
    if (stat.isFile() && stat.size < 256 * 1024) {
      const text = fs.readFileSync(realBin, 'utf8')
      for (const re of [
        /["']([^"']+\/openclaw\/dist\/index\.js)["']/g,
        /["']([^"']+\/dist\/index\.js)["']/g,
      ]) {
        let m
        while ((m = re.exec(text)) !== null) {
          pushUnique(found, path.dirname(m[1]))
        }
      }
    }
  } catch {
    /* ignore */
  }

  return found.filter(distLooksLikeOpenclaw)
}

function inferDistFromIndexJs(filePath) {
  if (!filePath) return null
  const normalized = filePath.replace(/\\/g, '/')
  if (normalized.endsWith('/dist/index.js')) {
    return path.dirname(filePath)
  }
  return null
}

function globalPackageRoots() {
  const roots = []
  const home = os.homedir()

  pushUnique(roots, runQuiet('npm root -g 2>/dev/null'))
  pushUnique(roots, runQuiet('pnpm root -g 2>/dev/null'))
  pushUnique(roots, runQuiet('yarn global dir 2>/dev/null'))

  const envPrefix = process.env.NPM_CONFIG_PREFIX || process.env.PREFIX
  if (envPrefix) {
    pushUnique(roots, path.join(envPrefix, 'lib', 'node_modules'))
    pushUnique(roots, path.join(envPrefix, 'node_modules'))
  }

  for (const base of [
    path.join(home, '.npm-global', 'lib', 'node_modules'),
    path.join(home, '.node_modules_global'),
    '/usr/local/lib/node_modules',
    '/usr/lib/node_modules',
    '/opt/homebrew/lib/node_modules',
  ]) {
    pushUnique(roots, base)
  }

  // pnpm global store layouts
  for (const base of [
    process.env.PNPM_HOME,
    path.join(home, '.local', 'share', 'pnpm'),
    path.join(home, 'Library', 'pnpm'),
  ]) {
    if (!base) continue
    pushUnique(roots, base)
    pushUnique(roots, path.join(base, 'global'))
    for (let i = 0; i <= 9; i += 1) {
      pushUnique(roots, path.join(base, 'global', String(i), 'node_modules'))
    }
  }

  return roots.filter(Boolean)
}

function distFromPackageRoot(root) {
  if (!root) return null
  return path.join(root, 'openclaw', 'dist')
}

/** Bounded walk for .../openclaw/dist under store roots (no external find). */
function scanTreeForOpenclawDist(root, maxDepth = 10) {
  const hits = []
  const visited = new Set()

  function walk(dir, depth) {
    if (depth > maxDepth) return
    let key
    try {
      key = realpathSafe(dir)
    } catch {
      return
    }
    if (visited.has(key)) return
    visited.add(key)

    if (path.basename(dir) === 'openclaw') {
      const dist = path.join(dir, 'dist')
      if (distLooksLikeOpenclaw(dist)) pushUnique(hits, dist)
    }

    let entries
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true })
    } catch {
      return
    }

    for (const ent of entries) {
      if (!ent.isDirectory()) continue
      const name = ent.name
      if (name === 'node_modules' || name === '.pnpm' || name.startsWith('openclaw@') || name === 'global') {
        walk(path.join(dir, name), depth + 1)
      } else if (depth <= 2 && (name === 'pnpm' || name === 'share' || name === '.local')) {
        walk(path.join(dir, name), depth + 1)
      }
    }
  }

  walk(root, 0)
  return hits
}

/** @returns {string[]} candidate dist dirs, best-first */
export function collectOpenclawDistCandidates() {
  const candidates = []

  pushEnvDistDirs(candidates)

  pushUnique(candidates, resolveDistViaRequire())

  const bin = runQuiet('command -v openclaw 2>/dev/null || which openclaw 2>/dev/null')
  for (const dist of resolveDistFromCliBin(bin) ?? []) {
    pushUnique(candidates, dist)
  }

  for (const root of globalPackageRoots()) {
    pushUnique(candidates, distFromPackageRoot(root))
    for (const hit of scanTreeForOpenclawDist(root)) {
      pushUnique(candidates, hit)
    }
  }

  return candidates.filter(distLooksLikeOpenclaw)
}

/** Primary runtime dist (first candidate after dedupe ordering). */
export function findPrimaryOpenclawDist() {
  const all = findAllOpenclawDists()
  return all[0] ?? null
}

/**
 * Every distinct OpenClaw dist directory.
 * Dedupes by realpath but keeps separate physical copies (pnpm shim vs .pnpm store).
 */
export function findAllOpenclawDists() {
  const seenReal = new Set()
  const out = []

  for (const dist of collectOpenclawDistCandidates()) {
    const key = realpathSafe(dist)
    if (seenReal.has(key)) continue
    seenReal.add(key)
    out.push(dist)
  }

  return out
}

/**
 * Resolve a hashed OpenClaw dist bundle (never .d.ts — readdir may list .d.ts before .js).
 * @param {string} dist
 * @param {string} prefix e.g. "server-plugins-"
 * @param {string} [contentNeedle] when multiple .js files share a prefix, pick one containing this text
 */
export function findDistJsFile(dist, prefix, contentNeedle) {
  if (!dist || !prefix) return undefined
  let names
  try {
    names = fs.readdirSync(dist)
  } catch {
    return undefined
  }
  const candidates = names.filter((name) => name.startsWith(prefix) && name.endsWith('.js'))
  if (!contentNeedle) return candidates[0]
  return candidates.find((name) => {
    try {
      return fs.readFileSync(path.join(dist, name), 'utf8').includes(contentNeedle)
    } catch {
      return false
    }
  })
}

/** @deprecated use findDistJsFile */
export function findDistFile(dist, prefix, contentNeedle) {
  return findDistJsFile(dist, prefix, contentNeedle)
}

const MEDIA_RUNNER_SKIP_FILE_RE = /^(fs-safe-|onboarding-plugin-install-)/

/**
 * media-understanding runner bundle (hashed runner-*.js or bundled MediaAttachmentCache).
 * @param {string} dist
 */
export function findMediaUnderstandingRunnerFile(dist) {
  // Upstream: src/media-understanding/attachments.cache.ts (bundled as runner-* or attachments.cache-*)
  for (const prefix of ['runner-', 'attachments.cache-']) {
    const hit = findDistJsFile(dist, prefix, 'resolveLocalPath(attachment)')
    if (hit) return hit
  }
  if (!dist) return undefined
  let names
  try {
    names = fs.readdirSync(dist).filter((name) => name.endsWith('.js'))
  } catch {
    return undefined
  }
  let bestName
  let bestScore = 0
  for (const name of names) {
    if (MEDIA_RUNNER_SKIP_FILE_RE.test(name)) continue
    let src
    try {
      src = fs.readFileSync(path.join(dist, name), 'utf8')
    } catch {
      continue
    }
    const hasCache =
      src.includes('var MediaAttachmentCache = class') ||
      src.includes('let MediaAttachmentCache = class') ||
      src.includes('export class MediaAttachmentCache') ||
      /class MediaAttachmentCache\b/.test(src)
    const hasResolve = /resolveLocalPath\s*\(\s*\w+\s*\)/.test(src)
    const hasNorm = src.includes('normalizeAttachmentPath')
    if (!hasCache || !hasResolve || !hasNorm) continue
    let score = 10
    if (name.startsWith('runner-')) score += 50
    if (src.includes('resolveLocalPath(attachment)')) score += 30
    if (src.includes('createMediaAttachmentCache(')) score += 20
    if (score > bestScore) {
      bestScore = score
      bestName = name
    }
  }
  return bestName
}

/** @param {string} dist */
export function findMediaReferenceDistFile(dist) {
  return findDistJsFile(dist, 'media-reference-', 'resolveMediaReferenceLocalPath')
}

export function formatOpenclawDistDiscoveryReport(dists) {
  const lines = [`[clawbba-api] discovered ${dists.length} OpenClaw dist path(s):`]
  for (const dist of dists) {
    lines.push(`  - ${dist}`)
    try {
      const rp = realpathSafe(dist)
      if (rp !== path.resolve(dist)) lines.push(`    → ${rp}`)
    } catch {
      /* ignore */
    }
  }
  return lines.join('\n')
}
