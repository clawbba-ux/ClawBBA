/**
 * 生图/生视频 model 短名 → ClawBBA platform id（vendor/model）
 */
import { IMAGE_MODEL_SPECS, VIDEO_MODEL_SPECS } from './clawbba-openclaw-media-catalog.mjs'

function slugifyLabel(label) {
  return String(label || '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
}

/** @param {Array<{ id: string, label?: string }>} specs */
export function buildMediaModelAliasMap(specs) {
  const map = Object.create(null)
  const add = (key, platformId) => {
    const k = String(key || '').trim().toLowerCase()
    if (!k || map[k]) return
    map[k] = platformId
  }

  for (const spec of specs) {
    const id = String(spec.id || '').trim()
    if (!id) continue
    add(id, id)
    const slash = id.indexOf('/')
    if (slash > 0) {
      add(id.slice(slash + 1), id)
      add(id.slice(0, slash).replace(/-/g, '') + '/' + id.slice(slash + 1), id)
    }
    const slug = slugifyLabel(spec.label)
    if (slug) add(slug, id)
  }

  add('flux', 'black-forest-labs/flux.2-pro')
  add('flux-pro', 'black-forest-labs/flux.2-pro')
  add('flux2-pro', 'black-forest-labs/flux.2-pro')
  add('nano-banana-2', 'google/gemini-3.1-flash-image-preview')
  add('nano-banana', 'google/gemini-2.5-flash-image')
  add('veo', 'google/veo-3.1-fast')
  add('veo-fast', 'google/veo-3.1-fast')

  return map
}

export const MEDIA_MODEL_ALIAS_MAP = buildMediaModelAliasMap([
  ...IMAGE_MODEL_SPECS,
  ...VIDEO_MODEL_SPECS,
])

/**
 * @param {string} raw
 * @param {Record<string, string>} [aliasMap]
 * @returns {string|null} platform id vendor/model
 */
export function resolvePlatformModelId(raw, aliasMap = MEDIA_MODEL_ALIAS_MAP) {
  const s = String(raw || '')
    .trim()
    .replace(/^(clawbba|openrouter)\//i, '')
  if (!s) return null
  if (/^[a-z0-9][a-z0-9._-]*\/[a-z0-9][a-z0-9._-]+$/i.test(s)) return s
  const key = s.toLowerCase()
  return aliasMap[key] ?? null
}

export function toOpenClawMediaModelRefWithAliases(raw, aliasMap = MEDIA_MODEL_ALIAS_MAP) {
  const id = resolvePlatformModelId(raw, aliasMap)
  if (!id) return null
  return `openrouter/${id}`
}

/** 注入 openclaw-tools（模块级，image/video 共享） */
export function buildModuleLevelOpenClawMediaModelResolveBlock() {
  const aliasesJson = JSON.stringify(MEDIA_MODEL_ALIAS_MAP)
  return `const __CLAWBBA_MODEL_ALIASES = ${aliasesJson};
function clawbbaResolvePlatformModelId(raw) {
\tconst s = String(raw || "").trim().replace(/^(clawbba|openrouter)\\//i, "");
\tif (!s) return null;
\tif (/^[a-z0-9][a-z0-9._-]*\\/[a-z0-9][a-z0-9._-]+$/i.test(s)) return s;
\tconst key = s.toLowerCase();
\treturn __CLAWBBA_MODEL_ALIASES[key] || null;
}
function clawbbaToOpenClawMediaModel(raw) {
\tconst id = clawbbaResolvePlatformModelId(raw);
\tif (!id) return null;
\treturn \`openrouter/\${id}\`;
}`
}

/** 注入 openclaw-tools：clawbbaToOpenClawMediaModel + 别名表 */
export function buildOpenClawMediaModelResolveBlock() {
  const aliasesJson = JSON.stringify(MEDIA_MODEL_ALIAS_MAP)
  return `\t\t\tconst __CLAWBBA_MODEL_ALIASES = ${aliasesJson};
\t\t\tfunction clawbbaResolvePlatformModelId(raw) {
\t\t\t\tconst s = String(raw || "").trim().replace(/^(clawbba|openrouter)\\//i, "");
\t\t\t\tif (!s) return null;
\t\t\t\tif (/^[a-z0-9][a-z0-9._-]*\\/[a-z0-9][a-z0-9._-]+$/i.test(s)) return s;
\t\t\t\tconst key = s.toLowerCase();
\t\t\t\treturn __CLAWBBA_MODEL_ALIASES[key] || null;
\t\t\t}
\t\t\tconst clawbbaToOpenClawMediaModel = (raw) => {
\t\t\t\tconst id = clawbbaResolvePlatformModelId(raw);
\t\t\t\tif (!id) return null;
\t\t\t\treturn \`openrouter/\${id}\`;
\t\t\t};`
}
