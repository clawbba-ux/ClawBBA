#!/usr/bin/env node
import assert from 'node:assert/strict'
import { upgradeReferenceImagePlausibleValidation } from './clawbba-reference-images.mjs'

const legacy = `/* clawbba-reference-images */
function clawbbaParamsHaveReferenceImages(record) {
\tif (!record || typeof record !== "object") return false;
\tif (typeof record.image === "string" && record.image.trim()) return true;
\treturn Array.isArray(record.images) && record.images.some((v) => typeof v === "string" && String(v).trim());
}
async function clawbbaMaybeMergeSessionReferenceImages(opts) {
\tconst record = opts.params ?? opts.args;
\tif (!record || typeof record !== "object" || clawbbaParamsHaveReferenceImages(record)) return;
}
await clawbbaMaybeMergeSessionReferenceImages({ params, options, tool: "image_generate", maxCount: 5 });
`

const upgraded = upgradeReferenceImagePlausibleValidation(legacy)
assert.ok(upgraded.includes('clawbbaSanitizeReferenceImageParams'))
assert.ok(upgraded.includes('clawbbaIsPlausibleReferenceImageRef'))
assert.ok(upgraded.includes('clawbbaCollectPlausibleReferenceImages'))

console.log('test-reference-plausible-upgrade: ok')
