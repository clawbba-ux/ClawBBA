#!/usr/bin/env node
import assert from 'node:assert/strict'
import {
  buildWebChatLiveHelper,
  upgradeAnnounceShouldInjectWebChat,
} from './openclaw-announce-patch.mjs'
import { WEBCHAT_DIRECT_TRANSCRIPT_MARKER } from './clawbba-webchat-live-inject.mjs'

const block = buildWebChatLiveHelper(
  'global-singleton-X.js',
  'gateway-request-scope-X.js',
  'session-utils-X.js',
  'transcript.runtime.js',
  'transcript-events-X.js',
)
assert.ok(block.includes('function clawbbaShouldInjectWebChatMediaLive'))
assert.ok(block.includes(WEBCHAT_DIRECT_TRANSCRIPT_MARKER))
assert.ok(block.includes('clawbbaAppendAssistantTranscriptDirect'))
assert.ok(block.includes('export async function clawbbaInjectMediaProgressLive'))
assert.ok(block.includes('if (!chatRunId && !clawbbaShouldInjectWebChatMediaLive(sessionKey))'))

const legacy = `/* clawbba-webchat-media-live */
export async function clawbbaInjectMediaProgressLive(params) {
\tif (!sessionKey || !message || !clawbbaShouldInjectWebChatMediaLive(sessionKey)) return false;
}`
const upgraded = upgradeAnnounceShouldInjectWebChat(legacy)
assert.ok(upgraded.includes('function clawbbaShouldInjectWebChatMediaLive'))
assert.ok(upgraded.includes('if (!chatRunId && !clawbbaShouldInjectWebChatMediaLive(sessionKey))'))

console.log('[clawbba-api] test-announce-webchat-helper: ok')
