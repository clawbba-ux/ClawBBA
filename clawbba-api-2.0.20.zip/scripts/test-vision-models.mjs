#!/usr/bin/env node
import assert from 'node:assert/strict'
import {
  applyVisionInputToProviderEntry,
  buildSmokeChatModelCandidates,
  isDeprecatedVisionModelId,
  pickVisionTextModelId,
  remapDeprecatedVisionModelId,
  resolveImageModelPrimary,
  rowSupportsVisionInput,
} from './clawbba-vision-models.mjs'
import { buildMinimalModelDefinition } from './openclaw-provider-block.mjs'

const rows = [
  { id: 'google/gemini-2.5-flash-preview', category: 'text', text_options: { supports_image_input: true } },
  { id: 'black-forest-labs/flux.2-flex', category: 'image' },
  { id: 'meta-llama/llama-3.1-8b-instruct', category: 'text', text_options: { supports_image_input: false } },
]

assert.equal(rowSupportsVisionInput(rows[0]), true)
assert.equal(rowSupportsVisionInput(rows[1]), false)
assert.equal(rowSupportsVisionInput(rows[2]), false)

const entry = buildMinimalModelDefinition(rows[0].id, 'Gemini', 'text')
applyVisionInputToProviderEntry(entry, rows[0])
assert.deepEqual(entry.input, ['text', 'image'])

assert.equal(pickVisionTextModelId(rows), 'google/gemini-2.5-flash-preview')
assert.equal(
  resolveImageModelPrimary(rows, 'meta-llama/llama-3.1-8b-instruct'),
  'clawbba/meta-llama/llama-3.1-8b-instruct',
)
assert.equal(
  resolveImageModelPrimary(rows, 'deepseek/deepseek-chat'),
  'clawbba/deepseek/deepseek-chat',
)
assert.equal(
  resolveImageModelPrimary(rows, 'google/gemini-2.5-flash-preview'),
  'clawbba/google/gemini-2.5-flash-preview',
)

assert.equal(isDeprecatedVisionModelId('google/gemini-2.0-flash-001'), true)
assert.equal(rowSupportsVisionInput({ id: 'google/gemini-2.0-flash-001', category: 'text' }), false)
assert.equal(
  resolveImageModelPrimary(
    [...rows, { id: 'google/gemini-2.0-flash-001', category: 'text', text_options: { supports_image_input: true } }],
    'google/gemini-2.0-flash-001',
  ),
  null,
)
assert.equal(
  remapDeprecatedVisionModelId('clawbba/google/gemini-2.0-flash-001', rows, 'deepseek/deepseek-chat'),
  'clawbba/deepseek/deepseek-chat',
)
assert.equal(
  remapDeprecatedVisionModelId('clawbba/google/gemini-2.0-flash-001', rows),
  'clawbba/google/gemini-2.5-flash-preview',
)

const smokeCandidates = buildSmokeChatModelCandidates('deepseek/deepseek-v3.2', rows)
assert.equal(smokeCandidates[0], 'deepseek/deepseek-v3.2')
assert.ok(!smokeCandidates.includes('google/gemini-2.0-flash-001'))
assert.ok(smokeCandidates.includes('google/gemini-2.5-flash-preview'))

console.log('test-vision-models: ok')
