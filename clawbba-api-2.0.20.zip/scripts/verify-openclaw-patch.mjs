#!/usr/bin/env node
/**
 * 验证 clawbba media-delivery patch 是否已打到所有 OpenClaw dist（pnpm 常有双路径）。
 */
import fs from 'fs'
import path from 'node:path'
import { findAllOpenclawDists, findDistJsFile, formatOpenclawDistDiscoveryReport } from './openclaw-dist-paths.mjs'
import {
  VERIFY_PATCH_FLUX_ONLY_LABELS,
  VERIFY_PATCH_INSTALL_LABELS,
  VERIFY_PATCH_LABELS as L,
} from './clawbba-user-display.mjs'
import {
  recoverFnHasWebChatDispatchInject,
  recoverFnHasVideoRecoverDelivery,
  repairLegacyPluginImport,
  toolsSrcHasLegacyPluginImport,
} from './clawbba-webchat-live-inject.mjs'
import { videoValidateRuntimeIsHealthy, videoValidateRuntimeIsBroken } from './clawbba-video-validate-health.mjs'
import { recoverFnHasAgentSessionKeyParam } from './clawbba-video-recover-patch.mjs'
import { imageRecoverRuntimeIsHealthy } from './clawbba-image-recover-patch.mjs'
import { GATEWAY_OFFLOAD_PATH_MARKER } from './clawbba-gateway-offload-path-patch.mjs'
import { IMAGE_TOOL_POLICY_MARKER } from './clawbba-image-tool-policy-patch.mjs'
import {
  distMediaAttachmentPathResolveIsHealthy,
  runnerMediaUriResolveIsHealthy,
  toolsMediaUriResolveIsHealthy,
} from './clawbba-media-uri-resolve-patch.mjs'
import { findMediaReferenceDistFile, findMediaUnderstandingRunnerFile } from './openclaw-dist-paths.mjs'

function findDistFile(dist, prefix) {
  const needles = {
    'server-plugins-': 'dispatchGatewayMethodInProcess',
    'global-singleton-': 'resolveGlobalSingleton',
    'gateway-request-scope-': 'getPluginRuntimeGatewayRequestScope',
  }
  return findDistJsFile(dist, prefix, needles[prefix])
}

function findModelRefPatchFile(dist) {
  return fs.readdirSync(dist).find((name) => {
    if (!name.startsWith('model-ref-') || !name.endsWith('.js')) return false
    const src = fs.readFileSync(path.join(dist, name), 'utf8')
    return src.includes('function parseGenerationModelRef')
  })
}

function findClawbbaImageProviderFile(dist) {
  return fs.readdirSync(dist).find((name) => {
    if (!name.startsWith('image-generation-provider-') || !name.endsWith('.js')) return false
    const src = fs.readFileSync(path.join(dist, name), 'utf8')
    return (
      src.includes('async generateImage(req)') &&
      src.includes('postJsonRequest') &&
      src.includes('`${baseUrl}/chat/completions`')
    )
  })
}

const CHECKS = [
  {
    label: L.wake,
    pickFile: (dist) => findDistFile(dist, 'openclaw-tools-'),
    needle: 'localMedia = mediaUrls.filter',
  },
  {
    label: L.announceAuto,
    pickFile: (dist) => findDistFile(dist, 'subagent-announce-delivery-'),
    needle: 'clawbbaLocalMediaWebChatCompletion',
  },
  {
    label: L.announceLive,
    pickFile: (dist) => findDistFile(dist, 'subagent-announce-delivery-'),
    needle: 'export async function clawbbaInjectWebChatGeneratedMediaLive',
  },
  {
    label: L.webchatLiveWake,
    pickFile: (dist) => findDistFile(dist, 'openclaw-tools-'),
    needle: 'clawbba-external-wake-delivery',
  },
  {
    label: L.webchatLiveInjectHelper,
    pickFile: (dist) => findDistFile(dist, 'openclaw-tools-'),
    needle: 'clawbbaBroadcastWebChatSessionReload',
  },
  {
    label: L.modelRef,
    pickFile: (dist) => findModelRefPatchFile(dist),
    needle: '__clawbbaImgProviders',
  },
  {
    label: L.imgDispatch,
    pickFile: (dist) => findDistFile(dist, 'openclaw-tools-'),
    needle: 'clawbbaToOpenClawMediaModel',
  },
  {
    label: L.imgValidateV2,
    pickFile: (dist) => findDistFile(dist, 'openclaw-tools-'),
    needle: 'clawbbaValidateImageGenerateParams',
    forbidden: 'clawbbaResolveMediaTemplateText',
  },
  {
    label: L.vidValidateV2,
    pickFile: (dist) => findDistFile(dist, 'openclaw-tools-'),
    needle: '/* clawbba-module-media-runtime-v1 */',
    forbidden: 'clawbbaResolveMediaTemplateText',
  },
  {
    label: L.refImages,
    pickFile: (dist) => findDistFile(dist, 'openclaw-tools-'),
    needle: 'clawbbaMaybeMergeSessionReferenceImages',
  },
  {
    label: L.imgConfig,
    pickFile: (dist) =>
      fs
        .readdirSync(dist)
        .find(
          (name) =>
            name.startsWith('image-generation-provider-') &&
            name.endsWith('.js') &&
            fs.readFileSync(path.join(dist, name), 'utf8').includes('function buildImageConfig(req, model)'),
        ),
    needle: '/* clawbba-media-dispatch */',
  },
  {
    label: L.imgHeaders,
    pickFile: findClawbbaImageProviderFile,
    needle: '/* clawbba-media-dispatch-headers-v2 */',
    optional: true,
  },
  {
    label: L.imgHeadersSpread,
    pickFile: findClawbbaImageProviderFile,
    forbidden: 'headers: { ...headers, ...clawbbaMediaHeaders }',
    optional: true,
  },
  {
    label: L.videoProvider,
    pickFile: (dist) =>
      fs.readdirSync(dist).find((name) => {
        if (!name.startsWith('video-generation-provider-') || !name.endsWith('.js')) return false
        const src = fs.readFileSync(path.join(dist, name), 'utf8')
        return src.includes('auditContext: "openrouter-video-submit"')
      }),
    needle: '/* clawbba-video-provider */',
    optional: true,
  },
  {
    label: L.imgProvAsync,
    pickFile: findClawbbaImageProviderFile,
    needle: '/* clawbba-image-async-job-poll-v6 */',
    optional: true,
  },
  {
    label: L.videoRecover,
    pickFile: (dist) => findDistFile(dist, 'openclaw-tools-'),
    needle: 'clawbbaResolveOpenRouterApiKey',
    optional: true,
  },
  {
    label: L.imgRecover,
    pickFile: (dist) => findDistFile(dist, 'openclaw-tools-'),
    needle: 'clawbbaRecoverImageTask',
    optional: true,
  },
  {
    label: L.imgRecoverStrict,
    pickFile: (dist) => findDistFile(dist, 'openclaw-tools-'),
    forbidden: 'pick.image_job_id || pick.job_id',
    needle: 'clawbba-image-recover-strict-job',
  },
  {
    label: L.imgRecoverAuto,
    pickFile: (dist) => findDistFile(dist, 'openclaw-tools-'),
    needle: 'clawbba-image-auto-recover',
    optional: true,
  },
  {
    label: L.mediaProgress,
    pickFile: (dist) => findDistFile(dist, 'openclaw-tools-'),
    needle: '/* clawbba-media-progress-v1 */',
    optional: true,
  },
  {
    label: L.videoRecoverLive,
    pickFile: (dist) => findDistFile(dist, 'openclaw-tools-'),
    needle: 'clawbbaBroadcastWebChatSessionReload',
  },
  {
    label: L.userMediaModelDisplay,
    pickFile: (dist) => findDistFile(dist, 'openclaw-tools-'),
    needle: 'clawbbaFormatUserMediaModel',
  },
  {
    label: L.mediaUriResolve,
    pickFile: (dist) => findDistFile(dist, 'openclaw-tools-'),
    needle: 'clawbba-media-uri-resolve',
    altHealthy: toolsMediaUriResolveIsHealthy,
  },
  {
    label: L.mediaUriResolveRunner,
    pickFile: (dist) => findMediaUnderstandingRunnerFile(dist),
    needle: 'clawbbaResolveOpenClawInboundMediaPathSync(mediaRef)',
    altHealthy: runnerMediaUriResolveIsHealthy,
  },
  {
    label: L.gatewayOffloadPath,
    pickFile: (dist) => findDistJsFile(dist, 'attachment-normalize-', 'Offloaded image for text-only'),
    needle: GATEWAY_OFFLOAD_PATH_MARKER,
  },
  {
    label: L.imageToolPolicy,
    pickFile: (dist) => findDistFile(dist, 'openclaw-tools-'),
    needle: IMAGE_TOOL_POLICY_MARKER,
  },
]

const fluxOnly = process.argv.includes('--flux-only')
const installMode = process.argv.includes('--install')

function countsAsCriticalForRun(c) {
  if (c.optional) return false
  if (installMode) return VERIFY_PATCH_INSTALL_LABELS.has(c.label)
  if (fluxOnly) return VERIFY_PATCH_FLUX_ONLY_LABELS.has(c.label)
  return true
}

function shouldRunCheck(c) {
  if (c.optional) return true
  if (installMode) return VERIFY_PATCH_INSTALL_LABELS.has(c.label)
  if (fluxOnly) return VERIFY_PATCH_FLUX_ONLY_LABELS.has(c.label)
  return true
}

const CRITICAL_CHECKS = CHECKS.filter((c) => countsAsCriticalForRun(c))

function verifyDist(dist) {
  let criticalOk = 0
  let optionalOk = 0
  for (const c of CHECKS) {
    if (!shouldRunCheck(c)) {
      continue
    }
    if (c.label === L.mediaUriResolveRunner) {
      const runnerFile = findMediaUnderstandingRunnerFile(dist)
      const mediaRefFile = findMediaReferenceDistFile(dist)
      if (distMediaAttachmentPathResolveIsHealthy(dist)) {
        const shown = runnerFile && runnerMediaUriResolveIsHealthy(
          fs.readFileSync(path.join(dist, runnerFile), 'utf8'),
        )
          ? runnerFile
          : mediaRefFile
            ? `${mediaRefFile}${runnerFile ? '' : ' (no runner bundle)'}`
            : runnerFile
        console.log(`[clawbba-api] ✓ ${c.label}: ${shown}`)
        if (countsAsCriticalForRun(c)) criticalOk += 1
      } else if (!runnerFile && !mediaRefFile) {
        console.error(
          `[clawbba-api] ✗ ${c.label}: file missing (dist 内无 runner-*.js / media-reference-*.js；请升级 OpenClaw 或设置 OPENCLAW_DIST)`,
        )
      } else {
        const probe = runnerFile ?? mediaRefFile
        console.error(`[clawbba-api] ✗ ${c.label}: not patched (${probe})`)
      }
      continue
    }
    const file = c.pickFile(dist)
    if (!file) {
      const tag = c.optional ? '○' : '✗'
      console.error(`[clawbba-api] ${tag} ${c.label}: file missing`)
      continue
    }
    const src = fs.readFileSync(path.join(dist, file), 'utf8')
    if (c.label === L.vidValidateV2) {
      const broken = videoValidateRuntimeIsBroken(src)
      const ok = videoValidateRuntimeIsHealthy(src)
      if (ok && !broken) {
        console.log(`[clawbba-api] ✓ ${c.label}: ${file}`)
        if (countsAsCriticalForRun(c)) criticalOk += 1
      } else {
        console.error(
          `[clawbba-api] ✗ ${c.label}: ${broken ? 'video dispatch present but async function clawbbaValidateVideoGenerateParams missing (run repair-video-validate-runtime.mjs)' : 'not patched'} (${file})`,
        )
      }
      continue
    }
    if (c.label === L.videoRecoverLive) {
      const okInject = recoverFnHasVideoRecoverDelivery(src)
      const okParams = recoverFnHasAgentSessionKeyParam(src)
      const badDtsImport = /\.d\.ts"\)/.test(src) && src.includes('server-plugins-')
      const badPluginImport = toolsSrcHasLegacyPluginImport(src)
      if (okInject && okParams && !badDtsImport && !badPluginImport) {
        console.log(`[clawbba-api] ✓ ${c.label}: ${file}`)
        if (countsAsCriticalForRun(c)) criticalOk += 1
      } else {
        console.error(
          `[clawbba-api] ✗ ${c.label}: ${badPluginImport ? 'legacy plugin import' : badDtsImport ? 'server-plugins .d.ts import' : !okInject ? 'recover delivery missing' : 'agentSessionKey param missing'} (${file})`,
        )
      }
      continue
    }
    if (c.label === L.imgRecoverStrict) {
      const okStrict = c.needle && src.includes(c.needle)
      const okPollGuard = imageRecoverRuntimeIsHealthy(src)
      if (okStrict && okPollGuard && !(c.forbidden && src.includes(c.forbidden))) {
        console.log(`[clawbba-api] ✓ ${c.label}: ${file}`)
        if (countsAsCriticalForRun(c)) criticalOk += 1
      } else if (c.forbidden && src.includes(c.forbidden)) {
        console.error(`[clawbba-api] ✗ ${c.label}: broken pattern in ${file} (re-run patch-openclaw-media-delivery.mjs)`)
      } else if (!okPollGuard) {
        console.error(`[clawbba-api] ✗ ${c.label}: image recover runtime helpers incomplete (${file})`)
      } else {
        console.error(`[clawbba-api] ✗ ${c.label}: not patched (${file})`)
      }
      continue
    }
    if (c.forbidden && src.includes(c.forbidden)) {
      console.error(`[clawbba-api] ✗ ${c.label}: broken pattern in ${file} (re-run patch-openclaw-media-delivery.mjs)`)
      continue
    }
    if (c.forbidden && !src.includes(c.forbidden)) {
      console.log(`[clawbba-api] ✓ ${c.label}: ${file}`)
      if (countsAsCriticalForRun(c)) criticalOk += 1
      else if (c.optional) optionalOk += 1
      continue
    }
    const altOk = typeof c.altHealthy === 'function' && c.altHealthy(src)
    if ((c.needle && src.includes(c.needle)) || altOk) {
      console.log(`[clawbba-api] ✓ ${c.label}: ${file}`)
      if (countsAsCriticalForRun(c)) criticalOk += 1
      else if (c.optional) optionalOk += 1
    } else if (c.optional) {
      console.log(`[clawbba-api] ○ ${c.label}: optional, not patched (${file})`)
    } else {
      console.error(`[clawbba-api] ✗ ${c.label}: not patched (${file})`)
    }
  }
  return criticalOk === CRITICAL_CHECKS.length
}

const dists = findAllOpenclawDists()
if (!dists.length) {
  console.error('[clawbba-api] ✗ 未找到 OpenClaw dist')
  process.exit(1)
}

console.log(formatOpenclawDistDiscoveryReport(dists))
let allOk = true
for (const dist of dists) {
  console.log(`[clawbba-api] — ${dist}`)
  if (!verifyDist(dist)) allOk = false
}

if (!allOk) {
  if (process.env.CLAWBBA_INSTALL_SILENT_HINT !== '1') {
    const skill =
      process.env.CLAWBBA_SKILL_DIR ||
      process.env.OPENCLAW_SKILL_DIR ||
      `${process.env.HOME || '~'}/.openclaw/skills/clawbba-api`
    const mode = installMode ? '--install' : fluxOnly ? '--flux-only' : ''
    console.error(
      `[clawbba-api] 修复: bash ${skill}/scripts/ensure-openclaw-patches.sh ${mode}`.trim(),
    )
    console.error(`[clawbba-api] 或重跑: curl -fsSL https://www.clawbba.com/downloads/install-clawbba-api.sh | bash`)
  }
  process.exit(1)
}

console.log(
  installMode
    ? '[clawbba-api] ✓ ClawBBA 安装 patch 已就绪（含 WebChat 即时显示）'
    : fluxOnly
      ? '[clawbba-api] ✓ ClawBBA 关键 patch 已就绪'
      : '[clawbba-api] ✓ ClawBBA 全部 patch 已就绪',
)
