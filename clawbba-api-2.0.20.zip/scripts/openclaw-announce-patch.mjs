/**
 * OpenClaw subagent-announce-delivery patches（多版本兼容）
 * @see references/openclaw-compat.md
 */
import fs from 'fs'
import path from 'path'
import { dedupeClawbbaInjectHelperBlocks, dedupeClawbbaProgressInjectBlocks, stripAllMediaProgressLiveExports, countMediaProgressLiveExports, escapeRegExp } from './clawbba-patch-dedupe.mjs'
import {
  buildClawbbaShouldInjectWebChatMediaLiveFn,
  buildWebChatHistoryReloadBlock,
  buildDirectTranscriptAppendFnBlock,
  upgradeDirectTranscriptAgentScopeResolve,
  WEBCHAT_DIRECT_TRANSCRIPT_MARKER,
  WEBCHAT_DIRECT_TRANSCRIPT_AGENT_SCOPE_MARKER,
  WEBCHAT_HISTORY_RELOAD_MARKER,
} from './clawbba-webchat-live-inject.mjs'

export const ANNOUNCE_MARKER = '/* clawbba-local-media-delivery */'
export const WEBCHAT_LIVE_MARKER = '/* clawbba-webchat-media-live */'
export const EXTERNAL_WAKE_ANNOUNCE_SKIP_MEDIA_MARKER = '/* clawbba-external-wake-announce-skip-media */'

export const CLAWBBA_EXTERNAL_WAKE_ANNOUNCE_HOOK = `\t\t${EXTERNAL_WAKE_ANNOUNCE_SKIP_MEDIA_MARKER}
\t\tconst clawbbaSkipExternalMediaResend = (() => { try { return !!globalThis.__clawbbaExternalMediaAlreadyDelivered; } catch (_) { return false; } })();`

export const CLAWBBA_WEBCHAT_MEDIA_BLOCK = `\t\tconst clawbbaLocalMediaWebChatCompletion = (() => {
\t\t\tif (!agentMediatedCompletion || expectedMediaUrls.length === 0) return false;
\t\t\tconst tool = normalizeOptionalLowercaseString(params.sourceTool) ?? "";
\t\t\tif (tool !== "image_generate" && tool !== "video_generate") return false;
\t\t\tconst sessionKey = String(params.requesterSessionKey ?? params.targetRequesterSessionKey ?? "");
\t\t\tif (sessionKey.includes(":dashboard:")) return true;
\t\t\tconst ch = normalizeMessageChannel(requesterSessionOrigin?.channel ?? sessionOnlyOrigin?.channel ?? effectiveDirectOrigin?.channel ?? requesterEntry?.channel);
\t\t\treturn ch === "webchat";
\t\t})();`

/** Injects assistant MEDIA lines via direct transcript append (no operator.admin) + chat.inject fallback. */
export function buildWebChatLiveHelper(
  globalSingletonBasename,
  gatewayRequestScopeBasename,
  sessionUtilsBasename,
  agentScopeBasename,
  transcriptRuntimeBasename,
  transcriptEventsBasename,
) {
  const reloadBlock = buildWebChatHistoryReloadBlock(globalSingletonBasename, gatewayRequestScopeBasename)
  const directAppend = buildDirectTranscriptAppendFnBlock(
    sessionUtilsBasename,
    agentScopeBasename,
    transcriptRuntimeBasename,
    transcriptEventsBasename,
  )
  return `${WEBCHAT_LIVE_MARKER}
${buildClawbbaShouldInjectWebChatMediaLiveFn()}
${reloadBlock}
${directAppend}
export async function clawbbaInjectWebChatGeneratedMediaLive(params) {
\tconst mediaUrls = Array.isArray(params.mediaUrls) ? params.mediaUrls.filter((url) => typeof url === "string" && url.trim().length > 0) : [];
\tif (mediaUrls.length === 0 || !params.sessionKey?.trim()) return false;
\tconst label = typeof params.completionLabel === "string" && params.completionLabel.trim() ? params.completionLabel.trim() : "media";
\tconst preset = typeof params.message === "string" ? params.message.trim() : "";
\tconst message = preset && preset.includes("MEDIA:") ? preset : [
\t\t\`The generated \${label} is ready.\`,
\t\t...mediaUrls.map((url) => \`MEDIA:\${url.trim()}\`)
\t].join("\\n");
\tconst injectLabel = params.sourceTool === "video_generate" ? "ClawBBA video" : "ClawBBA image";
\tlet injectMessageId = "";
\tlet injected = false;
\tif (typeof clawbbaAppendAssistantTranscriptDirect === "function") {
\t\tconst direct = await clawbbaAppendAssistantTranscriptDirect({ sessionKey: params.sessionKey.trim(), message, label: injectLabel });
\t\tif (direct?.ok && direct.messageId) {
\t\t\tinjected = true;
\t\t\tinjectMessageId = direct.messageId;
\t\t} else if (direct?.error) {
\t\t\tdefaultRuntime.log(\`[warn] clawbba direct transcript inject failed: \${direct.error}\`);
\t\t}
\t}
\tif (!injected) {
\t\ttry {
\t\t\tconst injectResult = await subagentAnnounceDeliveryDeps.dispatchGatewayMethodInProcess("chat.inject", {
\t\t\t\tsessionKey: params.sessionKey.trim(),
\t\t\t\tmessage,
\t\t\t\tlabel: injectLabel
\t\t\t}, { timeoutMs: 3e4 });
\t\t\tinjectMessageId = injectResult?.messageId ?? "";
\t\t\tinjected = true;
\t\t} catch (err) {
\t\t\tdefaultRuntime.log(\`[warn] clawbba webchat media live inject failed: \${String(err?.message ?? err)}\`);
\t\t}
\t}
\tif (injected) {
\t\tawait clawbbaBroadcastWebChatSessionReload({
\t\t\tsessionKey: params.sessionKey.trim(),
\t\t\tchatRunId: params.chatRunId,
\t\t\tmediaMessage: message,
\t\t\tinjectMessageId
\t\t});
\t\treturn true;
\t}
\treturn false;
}
/* clawbba-webchat-progress-inject */
export async function clawbbaInjectMediaProgressLive(params) {
\tconst sessionKey = typeof params.sessionKey === "string" ? params.sessionKey.trim() : "";
\tconst message = typeof params.message === "string" ? params.message.trim() : "";
\tconst chatRunId = typeof params.chatRunId === "string" ? params.chatRunId.trim() : "";
\tif (!sessionKey || !message) return false;
\tif (!chatRunId && !clawbbaShouldInjectWebChatMediaLive(sessionKey)) return false;
\ttry {
\t\tconst injectResult = await subagentAnnounceDeliveryDeps.dispatchGatewayMethodInProcess("chat.inject", {
\t\t\tsessionKey,
\t\t\tmessage,
\t\t\tlabel: typeof params.label === "string" && params.label.trim() ? params.label.trim() : "ClawBBA progress"
\t\t}, { timeoutMs: 3e4 });
\t\tawait clawbbaBroadcastWebChatSessionReload({
\t\t\tsessionKey,
\t\t\tchatRunId: params.chatRunId,
\t\t\tmediaMessage: message,
\t\t\tinjectMessageId: injectResult?.messageId
\t\t});
\t\treturn true;
\t} catch (err) {
\t\tdefaultRuntime.log(\`[warn] clawbba media progress inject failed: \${String(err?.message ?? err)}\`);
\t\treturn false;
\t}
}
`
}

export const WEBCHAT_LIVE_TRY_DIRECT_NEEDLE = `\t\tconst tryGeneratedMediaDirectDelivery = async (announceResponse) => {
\t\t\tif (requesterActivity.isActive && !activeRequesterWakeFailed) return;`

export const WEBCHAT_LIVE_TRY_DIRECT_REPLACEMENT = `\t\tconst tryGeneratedMediaDirectDelivery = async (announceResponse) => {
\t\t\tif (requesterActivity.isActive && !activeRequesterWakeFailed) {
\t\t\t\tif (clawbbaLocalMediaWebChatCompletion && expectedMediaUrls.length > 0) {
\t\t\t\t\tconst clawbbaLiveMediaUrls = resolveGeneratedMediaDirectFallbackUrls({
\t\t\t\t\t\texpectedMediaUrls,
\t\t\t\t\t\tannounceResponse
\t\t\t\t\t});
\t\t\t\t\tif (clawbbaLiveMediaUrls.length > 0) {
\t\t\t\t\t\tconst clawbbaLiveMirrored = await clawbbaInjectWebChatGeneratedMediaLive({
\t\t\t\t\t\t\tsessionKey: canonicalRequesterSessionKey,
\t\t\t\t\t\t\tmediaUrls: clawbbaLiveMediaUrls,
\t\t\t\t\t\t\tsourceTool: params.sourceTool,
\t\t\t\t\t\t\tcompletionLabel: resolveGeneratedMediaCompletionLabel({
\t\t\t\t\t\t\t\tsourceTool: params.sourceTool,
\t\t\t\t\t\t\t\tinternalEvents: params.internalEvents
\t\t\t\t\t\t\t})
\t\t\t\t\t\t});
\t\t\t\t\t\tif (clawbbaLiveMirrored) return {
\t\t\t\t\t\t\tdelivered: true,
\t\t\t\t\t\t\tpath: "clawbba-webchat-live"
\t\t\t\t\t\t};
\t\t\t\t\t}
\t\t\t\t}
\t\t\t\treturn;
\t\t\t}`

export const WEBCHAT_LIVE_STEER_NEEDLE = `\t\t\tconst wakeOutcome = await resolveActiveWakeWithRetries(requesterActivity.sessionId, params.triggerMessage, wakeOptions, params.signal);
\t\t\tif (wakeOutcome.queued) return {
\t\t\t\tdelivered: true,
\t\t\t\tdeliveredAt: wakeOutcome.deliveredAtMs,
\t\t\t\tenqueuedAt: wakeOutcome.enqueuedAtMs,
\t\t\t\tpath: "steered"
\t\t\t};`

export const WEBCHAT_LIVE_STEER_REPLACEMENT = `\t\t\tconst wakeOutcome = await resolveActiveWakeWithRetries(requesterActivity.sessionId, params.triggerMessage, wakeOptions, params.signal);
\t\t\tif (wakeOutcome.queued) {
\t\t\t\tif (clawbbaLocalMediaWebChatCompletion && expectedMediaUrls.length > 0) {
\t\t\t\t\tawait clawbbaInjectWebChatGeneratedMediaLive({
\t\t\t\t\t\tsessionKey: canonicalRequesterSessionKey,
\t\t\t\t\t\tmediaUrls: expectedMediaUrls,
\t\t\t\t\t\tsourceTool: params.sourceTool,
\t\t\t\t\t\tcompletionLabel: resolveGeneratedMediaCompletionLabel({
\t\t\t\t\t\t\tsourceTool: params.sourceTool,
\t\t\t\t\t\t\tinternalEvents: params.internalEvents
\t\t\t\t\t\t})
\t\t\t\t\t});
\t\t\t\t}
\t\t\t\treturn {
\t\t\t\t\tdelivered: true,
\t\t\t\t\tdeliveredAt: wakeOutcome.deliveredAtMs,
\t\t\t\t\tenqueuedAt: wakeOutcome.enqueuedAtMs,
\t\t\t\t\tpath: "steered"
\t\t\t\t};
\t\t\t}`

/** OpenClaw 2026.5.28+：resolveQueueEmbeddedPiMessageOutcome + steered path */
export const WEBCHAT_LIVE_STEER_QUEUE_NEEDLE = `\t\t\tif (wakeOutcome.queued) return {
\t\t\t\tdelivered: true,
\t\t\t\tdeliveredAt: wakeOutcome.deliveredAtMs,
\t\t\t\tenqueuedAt: wakeOutcome.enqueuedAtMs,
\t\t\t\tpath: "steered"
\t\t\t};`

export const WEBCHAT_LIVE_STEER_QUEUE_REPLACEMENT = `\t\t\tif (wakeOutcome.queued) {
\t\t\t\tif (clawbbaLocalMediaWebChatCompletion && expectedMediaUrls.length > 0) {
\t\t\t\t\tawait clawbbaInjectWebChatGeneratedMediaLive({
\t\t\t\t\t\tsessionKey: canonicalRequesterSessionKey,
\t\t\t\t\t\tmediaUrls: expectedMediaUrls,
\t\t\t\t\t\tsourceTool: params.sourceTool,
\t\t\t\t\t\tcompletionLabel: resolveGeneratedMediaCompletionLabel({
\t\t\t\t\t\t\tsourceTool: params.sourceTool,
\t\t\t\t\t\t\tinternalEvents: params.internalEvents
\t\t\t\t\t\t})
\t\t\t\t\t});
\t\t\t\t}
\t\t\t\treturn {
\t\t\t\t\tdelivered: true,
\t\t\t\t\tdeliveredAt: wakeOutcome.deliveredAtMs,
\t\t\t\t\tenqueuedAt: wakeOutcome.enqueuedAtMs,
\t\t\t\t\tpath: "steered"
\t\t\t\t};
\t\t\t}`

/** OpenClaw 2026.5.28+：active session 时 chat.inject（deliverGeneratedMediaCompletionDirect 之前） */
export const WEBCHAT_LIVE_TRY_DIRECT_NEEDLE_528 = `\t\tconst tryGeneratedMediaDirectDelivery = async (announceResponse) => {
\t\t\tif (requesterActivity.isActive && !activeRequesterWakeFailed) return;
\t\t\tconst missingMediaUrls = resolveGeneratedMediaDirectFallbackUrls({`

export const WEBCHAT_LIVE_TRY_DIRECT_REPLACEMENT_528 = `\t\tconst tryGeneratedMediaDirectDelivery = async (announceResponse) => {
\t\t\tif (requesterActivity.isActive && !activeRequesterWakeFailed) {
\t\t\t\tif (clawbbaLocalMediaWebChatCompletion && expectedMediaUrls.length > 0) {
\t\t\t\t\tconst clawbbaLiveMediaUrls = resolveGeneratedMediaDirectFallbackUrls({
\t\t\t\t\t\texpectedMediaUrls,
\t\t\t\t\t\tannounceResponse
\t\t\t\t\t});
\t\t\t\t\tif (clawbbaLiveMediaUrls.length > 0) {
\t\t\t\t\t\tconst clawbbaLiveMirrored = await clawbbaInjectWebChatGeneratedMediaLive({
\t\t\t\t\t\t\tsessionKey: canonicalRequesterSessionKey,
\t\t\t\t\t\t\tmediaUrls: clawbbaLiveMediaUrls,
\t\t\t\t\t\t\tsourceTool: params.sourceTool,
\t\t\t\t\t\t\tcompletionLabel: resolveGeneratedMediaCompletionLabel({
\t\t\t\t\t\t\t\tsourceTool: params.sourceTool,
\t\t\t\t\t\t\t\tinternalEvents: params.internalEvents
\t\t\t\t\t\t\t})
\t\t\t\t\t\t});
\t\t\t\t\t\tif (clawbbaLiveMirrored) return {
\t\t\t\t\t\t\tdelivered: true,
\t\t\t\t\t\t\tpath: "clawbba-webchat-live"
\t\t\t\t\t\t};
\t\t\t\t\t}
\t\t\t\t}
\t\t\t\treturn;
\t\t\t}
\t\t\tconst missingMediaUrls = resolveGeneratedMediaDirectFallbackUrls({`

/** OpenClaw 2026.5.28+ direct 成功返回前 chat.inject */
export const WEBCHAT_LIVE_DIRECT_SUCCESS_NEEDLE_528 = `\t\tif (params.expectsCompletionMessage && shouldDeliverAgentFinal && !isSubagentCompletion && !hasVisibleGatewayAgentPayload(directAnnounceResponse)) return {
\t\t\tdelivered: false,
\t\t\tpath: "direct",
\t\t\terror: "completion agent did not produce a visible reply"
\t\t};
\t\treturn {
\t\t\tdelivered: true,
\t\t\tpath: "direct"
\t\t};`

export const WEBCHAT_LIVE_DIRECT_SUCCESS_REPLACEMENT_528 = `\t\tif (params.expectsCompletionMessage && shouldDeliverAgentFinal && !isSubagentCompletion && !hasVisibleGatewayAgentPayload(directAnnounceResponse)) return {
\t\t\tdelivered: false,
\t\t\tpath: "direct",
\t\t\terror: "completion agent did not produce a visible reply"
\t\t};
\t\tif (clawbbaLocalMediaWebChatCompletion && expectedMediaUrls.length > 0) {
\t\t\tawait clawbbaInjectWebChatGeneratedMediaLive({
\t\t\t\tsessionKey: canonicalRequesterSessionKey,
\t\t\t\tmediaUrls: expectedMediaUrls,
\t\t\t\tsourceTool: params.sourceTool,
\t\t\t\tcompletionLabel: resolveGeneratedMediaCompletionLabel({
\t\t\t\t\tsourceTool: params.sourceTool,
\t\t\t\t\tinternalEvents: params.internalEvents
\t\t\t\t})
\t\t\t});
\t\t}
\t\treturn {
\t\t\tdelivered: true,
\t\t\tpath: "direct"
\t\t};`

/** Direct announce 成功返回前 chat.inject（无需刷新 WebChat） */
export const WEBCHAT_LIVE_DIRECT_SUCCESS_NEEDLE = `\t\tif (params.expectsCompletionMessage && shouldDeliverAgentFinal && !hasVisibleGatewayAgentPayload(directAnnounceResponse)) return {
\t\t\tdelivered: false,
\t\t\tpath: "direct",
\t\t\terror: "completion agent did not produce a visible reply"
\t\t};
\t\treturn {
\t\t\tdelivered: true,
\t\t\tpath: "direct"
\t\t};`

export const WEBCHAT_LIVE_DIRECT_SUCCESS_REPLACEMENT = `\t\tif (params.expectsCompletionMessage && shouldDeliverAgentFinal && !hasVisibleGatewayAgentPayload(directAnnounceResponse)) return {
\t\t\tdelivered: false,
\t\t\tpath: "direct",
\t\t\terror: "completion agent did not produce a visible reply"
\t\t};
\t\tif (clawbbaLocalMediaWebChatCompletion && expectedMediaUrls.length > 0) {
\t\t\tawait clawbbaInjectWebChatGeneratedMediaLive({
\t\t\t\tsessionKey: canonicalRequesterSessionKey,
\t\t\t\tmediaUrls: expectedMediaUrls,
\t\t\t\tsourceTool: params.sourceTool,
\t\t\t\tcompletionLabel: resolveGeneratedMediaCompletionLabel({
\t\t\t\t\tsourceTool: params.sourceTool,
\t\t\t\t\tinternalEvents: params.internalEvents
\t\t\t\t})
\t\t\t});
\t\t}
\t\treturn {
\t\t\tdelivered: true,
\t\t\tpath: "direct"
\t\t};`

/** OpenClaw 2026.5.28+：completionRoute + subagent direct message 分支 */
export const ANNOUNCE_PATCH_2026528 = {
  id: '2026.5.28-completion-route',
  needle: `\t\tconst expectedMediaUrls = collectExpectedMediaFromInternalEvents(params.internalEvents);
\t\tconst completionRouteRequiresMessageToolDelivery = params.expectsCompletionMessage && completionRequiresMessageToolDelivery({
\t\t\tcfg,
\t\t\trequesterSessionKey: params.requesterSessionKey,
\t\t\ttargetRequesterSessionKey: canonicalRequesterSessionKey,
\t\t\trequesterEntry,
\t\t\tdirectOrigin: effectiveDirectOrigin,
\t\t\trequesterSessionOrigin
\t\t});
\t\tconst subagentDirectMessageCompletionRequiresMessageTool = params.expectsCompletionMessage && isSubagentCompletion && deliveryTarget.deliver && isDirectMessageDeliveryTarget(deliveryTarget, canonicalRequesterSessionKey);
\t\tconst requiresMessageToolDelivery = completionRouteRequiresMessageToolDelivery || agentMediatedCompletion && expectedMediaUrls.length > 0 || subagentDirectMessageCompletionRequiresMessageTool;`,
  replacement: `\t\tconst expectedMediaUrls = collectExpectedMediaFromInternalEvents(params.internalEvents);
\t\t${ANNOUNCE_MARKER}
${CLAWBBA_WEBCHAT_MEDIA_BLOCK}
${CLAWBBA_EXTERNAL_WAKE_ANNOUNCE_HOOK}
\t\tconst completionRouteRequiresMessageToolDelivery = params.expectsCompletionMessage && completionRequiresMessageToolDelivery({
\t\t\tcfg,
\t\t\trequesterSessionKey: params.requesterSessionKey,
\t\t\ttargetRequesterSessionKey: canonicalRequesterSessionKey,
\t\t\trequesterEntry,
\t\t\tdirectOrigin: effectiveDirectOrigin,
\t\t\trequesterSessionOrigin
\t\t});
\t\tconst subagentDirectMessageCompletionRequiresMessageTool = params.expectsCompletionMessage && isSubagentCompletion && deliveryTarget.deliver && isDirectMessageDeliveryTarget(deliveryTarget, canonicalRequesterSessionKey);
\t\tconst requiresMessageToolDelivery = completionRouteRequiresMessageToolDelivery || (agentMediatedCompletion && expectedMediaUrls.length > 0 && !clawbbaLocalMediaWebChatCompletion && !clawbbaSkipExternalMediaResend) || subagentDirectMessageCompletionRequiresMessageTool;`,
}

/** 2026.5.18 – 2026.5.26：agentMediated && (media || policy) */
export const ANNOUNCE_PATCH_2026518 = {
  id: '2026.5.18-media-or-policy',
  needle: `\t\tconst expectedMediaUrls = collectExpectedMediaFromInternalEvents(params.internalEvents);
\t\tconst requiresMessageToolDelivery = agentMediatedCompletion && (expectedMediaUrls.length > 0 || completionRequiresMessageToolDelivery({
\t\t\tcfg,
\t\t\trequesterSessionKey: params.requesterSessionKey,
\t\t\ttargetRequesterSessionKey: canonicalRequesterSessionKey,
\t\t\trequesterEntry,
\t\t\tdirectOrigin: effectiveDirectOrigin,
\t\t\trequesterSessionOrigin
\t\t}));`,
  replacement: `\t\tconst expectedMediaUrls = collectExpectedMediaFromInternalEvents(params.internalEvents);
\t\t${ANNOUNCE_MARKER}
${CLAWBBA_WEBCHAT_MEDIA_BLOCK}
\t\tconst requiresMessageToolDelivery = agentMediatedCompletion && ((expectedMediaUrls.length > 0 && !clawbbaLocalMediaWebChatCompletion) || completionRequiresMessageToolDelivery({
\t\t\tcfg,
\t\t\trequesterSessionKey: params.requesterSessionKey,
\t\t\ttargetRequesterSessionKey: canonicalRequesterSessionKey,
\t\t\trequesterEntry,
\t\t\tdirectOrigin: effectiveDirectOrigin,
\t\t\trequesterSessionOrigin
\t\t}));`,
}

/** 2026.5.27+、部分 5.x：policy || (agentMediated && media) */
export const ANNOUNCE_PATCH_LEGACY = {
  id: 'legacy-policy-or-media',
  needle: `\t\tconst expectedMediaUrls = collectExpectedMediaFromInternalEvents(params.internalEvents);
\t\tconst requiresMessageToolDelivery = params.expectsCompletionMessage && completionRequiresMessageToolDelivery({
\t\t\tcfg,
\t\t\trequesterSessionKey: params.requesterSessionKey,
\t\t\ttargetRequesterSessionKey: canonicalRequesterSessionKey,
\t\t\trequesterEntry,
\t\t\tdirectOrigin: effectiveDirectOrigin,
\t\t\trequesterSessionOrigin
\t\t}) || agentMediatedCompletion && expectedMediaUrls.length > 0;`,
  replacement: `\t\tconst expectedMediaUrls = collectExpectedMediaFromInternalEvents(params.internalEvents);
\t\t${ANNOUNCE_MARKER}
${CLAWBBA_WEBCHAT_MEDIA_BLOCK}
\t\tconst requiresMessageToolDelivery = params.expectsCompletionMessage && completionRequiresMessageToolDelivery({
\t\t\tcfg,
\t\t\trequesterSessionKey: params.requesterSessionKey,
\t\t\ttargetRequesterSessionKey: canonicalRequesterSessionKey,
\t\t\trequesterEntry,
\t\t\tdirectOrigin: effectiveDirectOrigin,
\t\t\trequesterSessionOrigin
\t\t}) || (agentMediatedCompletion && expectedMediaUrls.length > 0 && !clawbbaLocalMediaWebChatCompletion);`,
}

/** 2026.5.12 – 2026.5.17：无 expectedMediaUrls，仅 agentMediated && policy */
export const ANNOUNCE_PATCH_2026512 = {
  id: '2026.5.12-agent-mediated-and-policy',
  needle: `\t\tconst requiresMessageToolDelivery = requiresAgentMediatedCompletionDelivery({
\t\t\texpectsCompletionMessage: params.expectsCompletionMessage,
\t\t\tsourceTool: params.sourceTool
\t\t}) && completionRequiresMessageToolDelivery({
\t\t\tcfg,
\t\t\trequesterSessionKey: params.requesterSessionKey,
\t\t\ttargetRequesterSessionKey: params.targetRequesterSessionKey,
\t\t\trequesterEntry,
\t\t\tdirectOrigin: effectiveDirectOrigin,
\t\t\trequesterSessionOrigin
\t\t});`,
  replacement: `\t\tconst agentMediatedCompletion = requiresAgentMediatedCompletionDelivery({
\t\t\texpectsCompletionMessage: params.expectsCompletionMessage,
\t\t\tsourceTool: params.sourceTool
\t\t});
\t\tconst expectedMediaUrls = collectExpectedMediaFromInternalEvents(params.internalEvents);
\t\t${ANNOUNCE_MARKER}
${CLAWBBA_WEBCHAT_MEDIA_BLOCK}
\t\tconst requiresMessageToolDelivery = agentMediatedCompletion && ((expectedMediaUrls.length > 0 && !clawbbaLocalMediaWebChatCompletion) || completionRequiresMessageToolDelivery({
\t\t\tcfg,
\t\t\trequesterSessionKey: params.requesterSessionKey,
\t\t\ttargetRequesterSessionKey: params.targetRequesterSessionKey,
\t\t\trequesterEntry,
\t\t\tdirectOrigin: effectiveDirectOrigin,
\t\t\trequesterSessionOrigin
\t\t}));`,
}

export const ANNOUNCE_PATCHES_ORDERED = [
  ANNOUNCE_PATCH_2026528,
  ANNOUNCE_PATCH_2026518,
  ANNOUNCE_PATCH_LEGACY,
  ANNOUNCE_PATCH_2026512,
]

/** WebChat live 路由 patch（policy patch 之后应用；528 专用 needle 须在前） */
export const WEBCHAT_LIVE_ROUTE_PATCHES_ORDERED = [
  {
    id: 'try-direct-528',
    needle: WEBCHAT_LIVE_TRY_DIRECT_NEEDLE_528,
    replacement: WEBCHAT_LIVE_TRY_DIRECT_REPLACEMENT_528,
  },
  {
    id: 'try-direct',
    needle: WEBCHAT_LIVE_TRY_DIRECT_NEEDLE,
    replacement: WEBCHAT_LIVE_TRY_DIRECT_REPLACEMENT,
  },
  {
    id: 'steer-queue',
    needle: WEBCHAT_LIVE_STEER_QUEUE_NEEDLE,
    replacement: WEBCHAT_LIVE_STEER_QUEUE_REPLACEMENT,
  },
  {
    id: 'direct-success-528',
    needle: WEBCHAT_LIVE_DIRECT_SUCCESS_NEEDLE_528,
    replacement: WEBCHAT_LIVE_DIRECT_SUCCESS_REPLACEMENT_528,
  },
  {
    id: 'direct-success',
    needle: WEBCHAT_LIVE_DIRECT_SUCCESS_NEEDLE,
    replacement: WEBCHAT_LIVE_DIRECT_SUCCESS_REPLACEMENT,
  },
]

export function applyWebChatLiveRoutePatches(src) {
  if (!hasAnnouncePolicyPatch(src)) return { src, applied: [] }
  let next = src
  const applied = []
  for (const patch of WEBCHAT_LIVE_ROUTE_PATCHES_ORDERED) {
    if (!next.includes(patch.needle)) continue
    next = next.replace(patch.needle, patch.replacement)
    applied.push(patch.id)
  }
  return { src: next, applied }
}

function hasAnnouncePolicyPatch(src) {
  return src.includes(ANNOUNCE_MARKER) && src.includes('clawbbaLocalMediaWebChatCompletion')
}

function hasWebChatLiveHelper(src) {
  return (
    (src.match(new RegExp(`function ${'clawbbaInjectWebChatGeneratedMediaLive'}`, 'g')) || []).length === 1 &&
    (src.match(/export async function clawbbaInjectMediaProgressLive/g) || []).length === 1 &&
    src.includes('export async function clawbbaInjectWebChatGeneratedMediaLive') &&
    src.includes('export async function clawbbaInjectMediaProgressLive') &&
    src.includes('function clawbbaShouldInjectWebChatMediaLive') &&
    src.includes('if (!chatRunId && !clawbbaShouldInjectWebChatMediaLive(sessionKey))') &&
    src.includes(WEBCHAT_HISTORY_RELOAD_MARKER) &&
    src.includes('clawbbaBroadcastWebChatSessionReload')
  )
}

function needsWebChatLiveHelperUpgrade(src) {
  return (
    src.includes(WEBCHAT_LIVE_MARKER) &&
    (!src.includes('function clawbbaShouldInjectWebChatMediaLive') ||
      !src.includes('if (!chatRunId && !clawbbaShouldInjectWebChatMediaLive(sessionKey))'))
  )
}

/** Surgical upgrade when full block replace regex misses (multi-version announce dist). */
export function upgradeAnnounceDirectTranscriptFailureLog(src) {
  if (src.includes('clawbba direct transcript inject failed')) return src
  const old =
    '\t\tif (direct?.ok && direct.messageId) {\n\t\t\tinjected = true;\n\t\t\tinjectMessageId = direct.messageId;\n\t\t}\n\t}'
  const neu =
    '\t\tif (direct?.ok && direct.messageId) {\n\t\t\tinjected = true;\n\t\t\tinjectMessageId = direct.messageId;\n\t\t} else if (direct?.error) {\n\t\t\tdefaultRuntime.log(`[warn] clawbba direct transcript inject failed: ${direct.error}`);\n\t\t}\n\t}'
  if (!src.includes(old)) return src
  return src.replace(old, neu)
}

export function upgradeAnnounceShouldInjectWebChat(src) {
  if (!needsWebChatLiveHelperUpgrade(src)) return src
  let next = src
  if (!next.includes('function clawbbaShouldInjectWebChatMediaLive')) {
    next = next.replace(WEBCHAT_LIVE_MARKER, `${WEBCHAT_LIVE_MARKER}\n${buildClawbbaShouldInjectWebChatMediaLiveFn()}`)
  }
  const oldProgressGuard =
    'if (!sessionKey || !message || !clawbbaShouldInjectWebChatMediaLive(sessionKey)) return false;'
  const newProgressGuard = `const chatRunId = typeof params.chatRunId === "string" ? params.chatRunId.trim() : "";
\tif (!sessionKey || !message) return false;
\tif (!chatRunId && !clawbbaShouldInjectWebChatMediaLive(sessionKey)) return false;`
  if (next.includes(oldProgressGuard)) {
    next = next.replace(oldProgressGuard, newProgressGuard)
  }
  return next
}

function replaceWebChatLiveHelperBlock(
  src,
  globalSingletonBasename,
  gatewayRequestScopeBasename,
  sessionUtilsBasename,
  agentScopeBasename,
  transcriptRuntimeBasename,
  transcriptEventsBasename,
) {
  const helper = buildWebChatLiveHelper(
    globalSingletonBasename,
    gatewayRequestScopeBasename,
    sessionUtilsBasename,
    agentScopeBasename,
    transcriptRuntimeBasename,
    transcriptEventsBasename,
  )
  const sendAnchor = 'async function sendSubagentAnnounceDirectly(params) {'
  if (src.includes(WEBCHAT_LIVE_MARKER)) {
    return src.replace(
      new RegExp(
        `${escapeRegExp(WEBCHAT_LIVE_MARKER)}[\\s\\S]*?(?=\\n\\nasync function sendSubagentAnnounceDirectly)`,
        'm',
      ),
      helper.trimEnd(),
    )
  }
  if (src.includes(sendAnchor)) {
    return src.replace(sendAnchor, `${helper}\n${sendAnchor}`)
  }
  return src
}

/** Fix duplicate/missing clawbbaInjectMediaProgressLive (1.5.32–1.5.33 bug). */
export function repairAnnounceWebChatHelpers(
  src,
  globalSingletonBasename,
  gatewayRequestScopeBasename,
  sessionUtilsBasename,
  agentScopeBasename,
  transcriptRuntimeBasename,
  transcriptEventsBasename,
) {
  let next = upgradeAnnounceShouldInjectWebChat(src)
  next = upgradeAnnounceDirectTranscriptFailureLog(next)
  if (agentScopeBasename) {
    next = upgradeDirectTranscriptAgentScopeResolve(next, agentScopeBasename)
  }
  const webchatMarkerCount = (next.match(new RegExp(WEBCHAT_LIVE_MARKER.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g')) || [])
    .length
  const mediaExportCount = (next.match(/export async function clawbbaInjectWebChatGeneratedMediaLive/g) || [])
    .length
  if (webchatMarkerCount > 1 || mediaExportCount > 1) {
    next = dedupeClawbbaInjectHelperBlocks(next)
  }
  next = dedupeClawbbaProgressInjectBlocks(next)

  const progressCount = countMediaProgressLiveExports(next)
  if (
    progressCount === 1 &&
    hasWebChatLiveHelper(next) &&
    !needsWebChatLiveHelperUpgrade(next) &&
    next.includes(WEBCHAT_DIRECT_TRANSCRIPT_MARKER) &&
    next.includes(WEBCHAT_DIRECT_TRANSCRIPT_AGENT_SCOPE_MARKER)
  ) {
    return next
  }

  if (
    globalSingletonBasename &&
    gatewayRequestScopeBasename &&
    sessionUtilsBasename &&
    agentScopeBasename &&
    transcriptRuntimeBasename &&
    transcriptEventsBasename &&
    hasAnnouncePolicyPatch(next)
  ) {
    if (progressCount !== 1) {
      next = stripAllMediaProgressLiveExports(next)
    }
    if (
      !next.includes(WEBCHAT_LIVE_MARKER) ||
      countMediaProgressLiveExports(next) !== 1 ||
      needsWebChatLiveHelperUpgrade(next) ||
      !next.includes(WEBCHAT_DIRECT_TRANSCRIPT_MARKER) ||
      !next.includes(WEBCHAT_DIRECT_TRANSCRIPT_AGENT_SCOPE_MARKER)
    ) {
      next = replaceWebChatLiveHelperBlock(
        next,
        globalSingletonBasename,
        gatewayRequestScopeBasename,
        sessionUtilsBasename,
        agentScopeBasename,
        transcriptRuntimeBasename,
        transcriptEventsBasename,
      )
    }
    next = dedupeClawbbaProgressInjectBlocks(next)
  } else if (progressCount > 1) {
    next = dedupeClawbbaProgressInjectBlocks(next)
  }

  return next
}

/** Export chat.inject helper (wake path imports this). Always dedupe before insert. */
function applyWebChatLiveHelperExport(
  src,
  globalSingletonBasename,
  gatewayRequestScopeBasename,
  sessionUtilsBasename,
  agentScopeBasename,
  transcriptRuntimeBasename,
  transcriptEventsBasename,
) {
  let next = repairAnnounceWebChatHelpers(
    src,
    globalSingletonBasename,
    gatewayRequestScopeBasename,
    sessionUtilsBasename,
    agentScopeBasename,
    transcriptRuntimeBasename,
    transcriptEventsBasename,
  )

  if (!hasAnnouncePolicyPatch(next)) {
    return { src: next, result: next !== src ? 'deduped-only' : 'live-skipped-no-announce' }
  }

  if (hasWebChatLiveHelper(next) && next.includes(WEBCHAT_DIRECT_TRANSCRIPT_MARKER) && next.includes(WEBCHAT_DIRECT_TRANSCRIPT_AGENT_SCOPE_MARKER)) {
    const withLog = upgradeAnnounceDirectTranscriptFailureLog(next)
    if (withLog !== next) return { src: withLog, result: 'upgraded-direct-log' }
    return { src: next, result: next !== src ? 'deduped' : 'skip-live' }
  }

  const sendAnchor = 'async function sendSubagentAnnounceDirectly(params) {'
  if (!next.includes(sendAnchor)) {
    return { src: next, result: 'live-send-anchor-missing' }
  }

  if (
    !globalSingletonBasename ||
    !gatewayRequestScopeBasename ||
    !sessionUtilsBasename ||
    !agentScopeBasename ||
    !transcriptRuntimeBasename ||
    !transcriptEventsBasename
  ) {
    return { src: next, result: 'live-gateway-scope-missing' }
  }

  next = replaceWebChatLiveHelperBlock(
    next,
    globalSingletonBasename,
    gatewayRequestScopeBasename,
    sessionUtilsBasename,
    agentScopeBasename,
    transcriptRuntimeBasename,
    transcriptEventsBasename,
  )
  next = dedupeClawbbaProgressInjectBlocks(next)
  return { src: next, result: 'patched-live-helper' }
}

function applyAnnouncePolicyPatch(src) {
  if (hasAnnouncePolicyPatch(src)) return { src, result: 'skip' }
  for (const patch of ANNOUNCE_PATCHES_ORDERED) {
    if (src.includes(patch.needle)) {
      return { src: src.replace(patch.needle, patch.replacement), result: `patched-${patch.id}` }
    }
  }
  return { src, result: 'pattern-missing' }
}

/** In-place: skip WeChat media re-send in announce when wake already delivered externally */
export function upgradeAnnounceExternalWakeSkipMedia(src) {
  if (src.includes(EXTERNAL_WAKE_ANNOUNCE_SKIP_MEDIA_MARKER)) return src
  if (!src.includes(ANNOUNCE_MARKER)) return src
  const hookNeedle = `${ANNOUNCE_MARKER}\n${CLAWBBA_WEBCHAT_MEDIA_BLOCK}\n\t\tconst completionRouteRequiresMessageToolDelivery`
  const hookReplacement = `${ANNOUNCE_MARKER}\n${CLAWBBA_WEBCHAT_MEDIA_BLOCK}\n${CLAWBBA_EXTERNAL_WAKE_ANNOUNCE_HOOK}\n\t\tconst completionRouteRequiresMessageToolDelivery`
  let next = src.includes(hookNeedle) ? src.replace(hookNeedle, hookReplacement) : src
  if (next === src) {
    const altNeedle = `${ANNOUNCE_MARKER}\n${CLAWBBA_WEBCHAT_MEDIA_BLOCK}\n\t\tconst requiresMessageToolDelivery`
    const altReplacement = `${ANNOUNCE_MARKER}\n${CLAWBBA_WEBCHAT_MEDIA_BLOCK}\n${CLAWBBA_EXTERNAL_WAKE_ANNOUNCE_HOOK}\n\t\tconst requiresMessageToolDelivery`
    if (next.includes(altNeedle)) next = next.replace(altNeedle, altReplacement)
  }
  if (!next.includes(EXTERNAL_WAKE_ANNOUNCE_SKIP_MEDIA_MARKER)) return src
  next = next.replace(
    /expectedMediaUrls\.length > 0 && !clawbbaLocalMediaWebChatCompletion(\))/g,
    'expectedMediaUrls.length > 0 && !clawbbaLocalMediaWebChatCompletion && !clawbbaSkipExternalMediaResend$1',
  )
  return next
}

/**
 * @param {string} filePath
 * @returns {string} patched-* | skip | pattern-missing
 */
export function patchSubagentAnnounceDeliveryFile(
  filePath,
  globalSingletonBasename,
  gatewayRequestScopeBasename,
  sessionUtilsBasename,
  agentScopeBasename,
  transcriptRuntimeBasename,
  transcriptEventsBasename,
) {
  const raw = fs.readFileSync(filePath, 'utf8')
  let src = repairAnnounceWebChatHelpers(
    raw,
    globalSingletonBasename,
    gatewayRequestScopeBasename,
    sessionUtilsBasename,
    agentScopeBasename,
    transcriptRuntimeBasename,
    transcriptEventsBasename,
  )

  if (
    hasAnnouncePolicyPatch(src) &&
    hasWebChatLiveHelper(src) &&
    src.includes(WEBCHAT_DIRECT_TRANSCRIPT_MARKER) &&
    src.includes(WEBCHAT_DIRECT_TRANSCRIPT_AGENT_SCOPE_MARKER)
  ) {
    const routes = applyWebChatLiveRoutePatches(src)
    src = routes.src
    if (src !== raw || routes.applied.length) fs.writeFileSync(filePath, src)
    if (routes.applied.length) return `upgraded-routes:${routes.applied.join(',')}`
    return src !== raw ? 'deduped' : 'skip'
  }
  const policy = applyAnnouncePolicyPatch(src)
  let next = upgradeAnnounceExternalWakeSkipMedia(policy.src)
  const routes = applyWebChatLiveRoutePatches(next)
  next = routes.src
  const live = applyWebChatLiveHelperExport(
    next,
    globalSingletonBasename,
    gatewayRequestScopeBasename,
    sessionUtilsBasename,
    agentScopeBasename,
    transcriptRuntimeBasename,
    transcriptEventsBasename,
  )
  src = repairAnnounceWebChatHelpers(
    live.src,
    globalSingletonBasename,
    gatewayRequestScopeBasename,
    sessionUtilsBasename,
    agentScopeBasename,
    transcriptRuntimeBasename,
    transcriptEventsBasename,
  )

  if (policy.result === 'pattern-missing' && live.result.startsWith('live-')) {
    return 'pattern-missing'
  }

  if (policy.result === 'skip' && (live.result === 'skip-live' || live.result === 'deduped')) {
    if (src !== raw) fs.writeFileSync(filePath, src)
    return live.result === 'deduped' ? 'deduped' : 'skip'
  }

  if (src !== raw) {
    fs.writeFileSync(filePath, src)
  }

  if (policy.result !== 'skip' && live.result === 'patched-live-helper') {
    return `${policy.result}+live-helper${routes.applied.length ? `+routes:${routes.applied.join(',')}` : ''}`
  }
  if (policy.result !== 'skip') {
    return routes.applied.length ? `${policy.result}+routes:${routes.applied.join(',')}` : policy.result
  }
  if (live.result === 'patched-live-helper') return live.result
  if (live.result === 'skip-live') return 'skip'
  return live.result
}

/**
 * @param {string} dist
 * @param {(prefix: string) => string|undefined} findDistFile
 */
export function patchSubagentAnnounceDeliveryDist(dist, findDistFile) {
  const file = findDistFile(dist, 'subagent-announce-delivery-')
  const gatewayScopeFile = findDistFile(dist, 'gateway-request-scope-')
  const globalSingletonFile = findDistFile(dist, 'global-singleton-')
  const sessionUtilsFile = findDistFile(dist, 'session-utils-')
  const agentScopeFile = findDistFile(dist, 'agent-scope-')
  const transcriptEventsFile = findDistFile(dist, 'transcript-events-')
  const transcriptRuntimeFile =
    fs.existsSync(path.join(dist, 'transcript.runtime.js'))
      ? 'transcript.runtime.js'
      : findDistFile(dist, 'transcript.runtime-')
  if (
    !file ||
    !gatewayScopeFile ||
    !globalSingletonFile ||
    !sessionUtilsFile ||
    !agentScopeFile ||
    !transcriptEventsFile ||
    !transcriptRuntimeFile
  ) {
    return 'missing-file'
  }
  const result = patchSubagentAnnounceDeliveryFile(
    path.join(dist, file),
    globalSingletonFile,
    gatewayScopeFile,
    sessionUtilsFile,
    agentScopeFile,
    transcriptRuntimeFile,
    transcriptEventsFile,
  )
  if (result === 'pattern-missing') {
    process.stderr.write(
      `[clawbba-api] warn: subagent announce 无匹配模式 (${file})；2026.5.2 等极旧版可能仅依赖 wake patch\n`,
    )
  }
  if (result === 'live-send-anchor-missing' || result === 'live-skipped-no-announce') {
    process.stderr.write(
      `[clawbba-api] warn: webchat chat.inject helper 未写入 (${file})；请确认 wake patch 已应用\n`,
    )
  }
  return result
}
