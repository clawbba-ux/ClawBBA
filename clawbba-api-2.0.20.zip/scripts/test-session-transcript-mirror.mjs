#!/usr/bin/env node
import assert from 'node:assert/strict'
import {
  SESSION_TRANSCRIPT_MIRROR_MARKER,
  upgradeSessionTranscriptMirrorDispatch,
} from './clawbba-external-recover-delivery.mjs'
import {
  WEBCHAT_SESSION_MIRROR_MARKER,
  upgradeWebChatSessionMirrorInject,
} from './clawbba-webchat-live-inject.mjs'

const oldDispatch = `async function clawbbaDispatchRecoverMediaDelivery(params) {
\tconst sessionKey = typeof params.sessionKey === "string" ? params.sessionKey.trim() : "";
\tconst mediaPaths = Array.isArray(params.mediaPaths) ? params.mediaPaths.filter((p) => typeof p === "string" && p.trim()) : [];
\tif (!sessionKey || mediaPaths.length === 0) return false;
\tif (typeof clawbbaDispatchRecoverMediaToExternalChannel === "function") {
\t\tconst external = await clawbbaDispatchRecoverMediaToExternalChannel({
\t\t\tcfg: params.cfg,
\t\t\tsessionKey,
\t\t\tchatRunId: params.chatRunId,
\t\t\tmediaPaths,
\t\t\tcaption: params.caption,
\t\t\tlabel: params.label,
\t\t\tmediaKind: params.mediaKind
\t\t});
\t\tif (external) return "external";
\t}
\tif (typeof clawbbaDispatchWebChatMediaLiveInject === "function") {
\t\tconst injected = await clawbbaDispatchWebChatMediaLiveInject({
\t\t\tsessionKey,
\t\t\tchatRunId: params.chatRunId,
\t\t\tmediaUrls: mediaPaths,
\t\t\tsourceTool: params.sourceTool,
\t\t\tcompletionLabel: params.completionLabel,
\t\t\tmessage: params.message
\t\t});
\t\tif (injected) return "webchat";
\t}
\treturn false;
}`

const upgradedDispatch = upgradeSessionTranscriptMirrorDispatch(oldDispatch)
assert.ok(upgradedDispatch.includes(SESSION_TRANSCRIPT_MIRROR_MARKER))
assert.ok(upgradedDispatch.includes('mirrorSessionTranscript: true'))
assert.ok(!upgradedDispatch.includes('if (external) return "external";\n\t}'))

const oldInject = `async function clawbbaDispatchWebChatMediaLiveInject(params) {
\tconst mediaUrls = [];
\tconst sessionKey = "";
\tconst chatRunId = typeof params.chatRunId === "string" ? params.chatRunId.trim() : "";
\tif (!sessionKey || mediaUrls.length === 0) return false;
\tif (!chatRunId && !clawbbaShouldInjectWebChatMediaLive(sessionKey)) return false;
}`

const upgradedInject = upgradeWebChatSessionMirrorInject(oldInject)
assert.ok(upgradedInject.includes(WEBCHAT_SESSION_MIRROR_MARKER))
assert.ok(upgradedInject.includes('mirrorSessionTranscript'))

console.log('test-session-transcript-mirror: ok')
