#!/usr/bin/env node
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { execSync } from 'node:child_process'
import {
  patchMediaTaskChatRunIdRouting,
  upgradeMediaTaskChatRunIdRouting,
  MEDIA_TASK_CHAT_RUNID_MARKER,
} from './clawbba-media-task-chat-runid-patch.mjs'
import { MEDIA_TASK_ORIGIN_ENRICH_MARKER } from './clawbba-external-recover-delivery.mjs'

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'clawbba-task-runid-'))
execSync('npm pack openclaw@2026.5.27 --silent', { cwd: tmp, stdio: 'pipe' })
const packed = fs.readdirSync(tmp).find((n) => n.endsWith('.tgz'))
execSync(`tar -xzf ${JSON.stringify(packed)}`, { cwd: tmp })
const dist = path.join(tmp, 'package', 'dist')
const toolsFile = fs.readdirSync(dist).find((n) => n.startsWith('openclaw-tools-'))
const toolsPath = path.join(dist, toolsFile)

assert.equal(patchMediaTaskChatRunIdRouting(toolsPath), 'patched')

let src = fs.readFileSync(toolsPath, 'utf8')
assert.ok(src.includes(MEDIA_TASK_CHAT_RUNID_MARKER))
assert.ok(src.includes('requesterChatRunId: options?.runId'))
assert.ok(src.includes('requesterChatRunId: typeof params.requesterChatRunId'))
assert.ok(!src.includes('chatRunId: params.handle?.runId'))

assert.ok(src.includes(MEDIA_TASK_ORIGIN_ENRICH_MARKER))
assert.ok(src.includes('// clawbba-media-task-origin-enrich'))
assert.ok(!src.includes('/* /* clawbba-media-task-origin-enrich'))
assert.ok(src.includes('clawbbaEnrichMediaTaskRequesterOrigin'))

execSync(`node --check ${JSON.stringify(toolsPath)}`, { stdio: 'pipe' })

const upgraded = upgradeMediaTaskChatRunIdRouting(src)
assert.equal(upgraded, src)
assert.equal(patchMediaTaskChatRunIdRouting(toolsPath), 'skip')

console.log('test-media-task-chat-runid-patch: ok')
