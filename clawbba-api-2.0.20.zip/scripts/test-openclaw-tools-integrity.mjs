#!/usr/bin/env node
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { execSync } from 'node:child_process'
import {
  MODULE_LEVEL_MEDIA_RUNTIME_MARKER,
  openclawToolsSrcIntegrityOk,
  removeMisplacedModuleRuntimeMarkers,
  stripModuleLevelMediaRuntimeBlockSafe,
} from './clawbba-openclaw-tools-integrity.mjs'
import { injectModuleLevelMediaRuntime } from './clawbba-media-tool-validate.mjs'

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'integrity-'))
execSync(`tar -xzf ${JSON.stringify(path.join('/var/www/crypto-payment-demo/packages/clawbba-api', 'openclaw-2026.5.28.tgz'))} -C ${JSON.stringify(tmp)}`, {
  stdio: 'pipe',
})
const dist = path.join(tmp, 'package/dist')
process.env.OPENCLAW_DIST = dist
execSync(`node ${JSON.stringify(path.join('/var/www/crypto-payment-demo/packages/clawbba-api/scripts/patch-openclaw-media-delivery.mjs'))}`, {
  stdio: 'pipe',
})
const toolsPath = path.join(dist, fs.readdirSync(dist).find((f) => f.startsWith('openclaw-tools-')))
let src = fs.readFileSync(toolsPath, 'utf8')
assert.ok(openclawToolsSrcIntegrityOk(src))

const imgTool = src.indexOf('function createImageGenerateTool(')
const early = Math.max(1000, imgTool - 2000)
src = `${src.slice(0, early)}${MODULE_LEVEL_MEDIA_RUNTIME_MARKER}\n/* misplaced */\n${src.slice(early)}`
const stripped = stripModuleLevelMediaRuntimeBlockSafe(src)
assert.ok(
  stripped.includes('function buildActiveMusicGenerationTaskPromptContextForSession'),
  'unsafe strip must not remove OpenClaw core functions',
)

const cleaned = removeMisplacedModuleRuntimeMarkers(src)
const upgraded = injectModuleLevelMediaRuntime(cleaned.replace(/function clawbbaResolveVideoDurationSeconds[\s\S]*?return void 0;\n\}/, ''))
fs.writeFileSync(toolsPath, upgraded)
execSync(`node --check ${JSON.stringify(path.basename(toolsPath))}`, { cwd: dist, stdio: 'pipe' })
assert.ok(openclawToolsSrcIntegrityOk(upgraded))

console.log('test-openclaw-tools-integrity: ok')
