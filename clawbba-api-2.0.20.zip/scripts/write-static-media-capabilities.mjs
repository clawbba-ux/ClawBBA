#!/usr/bin/env node
import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'
import {
  buildMediaCapabilitiesFromStaticSpecs,
  renderMediaCapabilitiesMarkdown,
} from './clawbba-media-capabilities-core.mjs'

const root = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'references')
const cap = buildMediaCapabilitiesFromStaticSpecs()
fs.writeFileSync(path.join(root, 'media-capabilities.json'), `${JSON.stringify(cap, null, 2)}\n`)
fs.writeFileSync(path.join(root, 'media-capabilities.md'), `${renderMediaCapabilitiesMarkdown(cap)}\n`)
console.log('write-static-media-capabilities: ok')
