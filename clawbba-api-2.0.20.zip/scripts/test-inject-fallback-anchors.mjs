#!/usr/bin/env node
import assert from 'node:assert/strict'
import {
  CLAWBBA_VALIDATE_VIDEO_FN,
  injectMediaToolValidateRuntime,
  toolsSrcHasModuleLevelMediaRuntime,
  validateFnIsModuleScoped,
} from './clawbba-media-tool-validate.mjs'
import { buildVideoGenerateDispatchBlock } from './clawbba-media-dispatch-patch.mjs'

const brokenConstRef = `function createImageGenerateTool() {}
function createVideoGenerateTool() {
\t${buildVideoGenerateDispatchBlock()}
}`

const out1 = injectMediaToolValidateRuntime(brokenConstRef)
assert.ok(out1.includes(CLAWBBA_VALIDATE_VIDEO_FN))
assert.ok(validateFnIsModuleScoped(out1))
assert.ok(toolsSrcHasModuleLevelMediaRuntime(out1))

console.log('test-inject-fallback-anchors: ok')
