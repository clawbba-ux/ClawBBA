/**
 * Read-only media tool actions (tasks/list/status): deliver tool text directly to the
 * user channel and suppress empty-agent incomplete-turn errors.
 */
import fs from 'fs'
import path from 'path'

export const READONLY_TOOL_TEXT_REPLY_MARKER = '/* clawbba-readonly-tool-text-reply */'
export const READONLY_TOOL_TEXT_REPLY_V2_MARKER = '/* clawbba-readonly-tool-text-reply-v2 */'
export const READONLY_TOOL_TEXT_REPLY_V3_MARKER = '/* clawbba-readonly-tool-text-reply-v3-origin */'
export const READONLY_TOOL_INCOMPLETE_TURN_MARKER = '/* clawbba-readonly-tool-incomplete-turn */'

export function buildReadOnlyToolTextReplyDispatchBlock(serverPluginsBasename, deliveryRuntimeBasename) {
  return `${READONLY_TOOL_TEXT_REPLY_MARKER}
${READONLY_TOOL_TEXT_REPLY_V2_MARKER}
${READONLY_TOOL_TEXT_REPLY_V3_MARKER}
function clawbbaMarkReadOnlyToolTextReplyDispatched(chatRunId) {
\tglobalThis.__clawbbaReadOnlyToolReplyDispatched = {
\t\trunId: typeof chatRunId === "string" ? chatRunId.trim() : "",
\t\tat: Date.now()
\t};
}
async function clawbbaDispatchReadOnlyToolTextReply(params) {
\tconst message = typeof params.message === "string" ? params.message.trim() : "";
\tconst sessionKey = typeof params.sessionKey === "string" ? params.sessionKey.trim() : "";
\tconst chatRunId = typeof params.chatRunId === "string" ? params.chatRunId.trim() : "";
\tif (!message || !sessionKey) return false;
\tlet delivered = false;
\tconst tryWebChatInject = async () => {
\t\tif (!chatRunId && !clawbbaShouldInjectWebChatMediaLive(sessionKey)) return false;
\t\ttry {
\t\t\tconst pluginsModule = await import("./${serverPluginsBasename}");
\t\t\tconst dispatchGatewayMethodInProcess = clawbbaPickModuleExport(pluginsModule, "dispatchGatewayMethodInProcess", ["r"]);
\t\t\tconst injectResult = await dispatchGatewayMethodInProcess("chat.inject", {
\t\t\t\tsessionKey,
\t\t\t\tmessage,
\t\t\t\tlabel: typeof params.label === "string" && params.label.trim() ? params.label.trim() : "ClawBBA tool result"
\t\t\t}, { timeoutMs: 3e4 });
\t\t\tawait clawbbaBroadcastWebChatSessionReload({
\t\t\t\tsessionKey,
\t\t\t\tchatRunId,
\t\t\t\tmediaMessage: message,
\t\t\t\tinjectMessageId: injectResult?.messageId
\t\t\t});
\t\t\treturn true;
\t\t} catch (err) {
\t\t\ttry {
\t\t\t\tlog$5.warn("clawbba readonly tool webchat inject failed", { error: String(err?.message ?? err) });
\t\t\t} catch (_) {}
\t\t\treturn false;
\t\t}
\t};
\tconst tryWeixinUploadFailureHint = async () => {
\t\ttry {
\t\t\tconst pluginsModule = await import("./${serverPluginsBasename}");
\t\t\tconst dispatchGatewayMethodInProcess = clawbbaPickModuleExport(pluginsModule, "dispatchGatewayMethodInProcess", ["r"]);
\t\t\tconst hint = [
\t\t\t\t"微信通道媒体上传失败（微信 CDN 返回 ret:-1）。",
\t\t\t\t"生成结果已保留在当前会话，请在 WebChat 查看；如需补发请使用 recover（同一 jobId，勿重新生成）。"
\t\t\t].join("\\n");
\t\t\tconst injectResult = await dispatchGatewayMethodInProcess("chat.inject", {
\t\t\t\tsessionKey,
\t\t\t\tmessage: hint,
\t\t\t\tlabel: "ClawBBA delivery notice"
\t\t\t}, { timeoutMs: 3e4 });
\t\t\tawait clawbbaBroadcastWebChatSessionReload({
\t\t\t\tsessionKey,
\t\t\t\tchatRunId,
\t\t\t\tmediaMessage: hint,
\t\t\t\tinjectMessageId: injectResult?.messageId
\t\t\t});
\t\t\treturn true;
\t\t} catch (_) {
\t\t\treturn false;
\t\t}
\t};
\tconst tryExternalSend = async () => {
\t\ttry {
\t\t\tlet origin = null;
\t\t\tif (typeof clawbbaResolveMediaDeliveryContext === "function") {
\t\t\t\tconst resolvedCtx = await clawbbaResolveMediaDeliveryContext({ sessionKey, requesterOrigin: params.requesterOrigin, cfg: params.cfg });
\t\t\t\torigin = resolvedCtx?.origin ?? null;
\t\t\t}
\t\t\tif (!origin) {
\t\t\t\tconst delivery = inferDeliveryFromSessionKey(sessionKey);
\t\t\t\torigin = normalizeDeliveryContext(delivery);
\t\t\t}
\t\t\tif (!origin?.channel || !origin?.to || !isDeliverableMessageChannel(origin.channel)) return false;
\t\t\tconst ch = normalizeMessageChannel(origin.channel);
\t\t\tif (ch === "webchat") return false;
\t\t\tconst agentId = resolveAgentIdFromSessionKey(sessionKey);
\t\t\tconst { sendMessage } = await import("./${deliveryRuntimeBasename}");
\t\t\tawait sendMessage({
\t\t\t\tcfg: params.cfg,
\t\t\t\tchannel: origin.channel,
\t\t\t\tto: origin.to,
\t\t\t\taccountId: origin.accountId,
\t\t\t\tthreadId: origin.threadId,
\t\t\t\tcontent: message,
\t\t\t\trequesterSessionKey: sessionKey,
\t\t\t\tagentId,
\t\t\t\tbestEffort: true,
\t\t\t\tmirror: { sessionKey, agentId }
\t\t\t});
\t\t\treturn true;
\t\t} catch (err) {
\t\t\ttry {
\t\t\t\tlog$5.warn("clawbba readonly tool direct delivery failed", { error: String(err?.message ?? err) });
\t\t\t} catch (_) {}
\t\t\ttry {
\t\t\t\tconst raw = String(err?.message ?? err ?? "");
\t\t\t\tconst delivery = inferDeliveryFromSessionKey(sessionKey);
\t\t\t\tconst origin = normalizeDeliveryContext(delivery);
\t\t\t\tconst ch = normalizeMessageChannel(origin?.channel ?? "");
\t\t\t\tif ((ch === "wechat" || ch.includes("weixin")) && /(getUploadUrl|upload URL|ret\\s*[:=]\\s*-1|ret":-1)/i.test(raw)) {
\t\t\t\t\tawait tryWeixinUploadFailureHint();
\t\t\t\t}
\t\t\t} catch (_) {}
\t\t\treturn false;
\t\t}
\t};
\tif (chatRunId || clawbbaShouldInjectWebChatMediaLive(sessionKey)) {
\t\tdelivered = await tryWebChatInject();
\t}
\tif (!delivered) delivered = await tryExternalSend();
\tif (!delivered) delivered = await tryWebChatInject();
\tif (delivered) clawbbaMarkReadOnlyToolTextReplyDispatched(chatRunId);
\treturn delivered;
}`
}

const INCOMPLETE_TURN_NEEDLE = /function resolveIncompleteTurnPayloadText\(params\) \{\n\tconst toolUseTerminal = params\.attempt\.lastAssistant\?\.stopReason === "toolUse";/

const INCOMPLETE_TURN_REPLACEMENT = `function resolveIncompleteTurnPayloadText(params) {
\t${READONLY_TOOL_INCOMPLETE_TURN_MARKER}
\tconst __clawbbaReadOnlyReply = globalThis.__clawbbaReadOnlyToolReplyDispatched;
\tif (__clawbbaReadOnlyReply && typeof __clawbbaReadOnlyReply.at === "number" && Date.now() - __clawbbaReadOnlyReply.at < 120000) return null;
\tconst toolUseTerminal = params.attempt.lastAssistant?.stopReason === "toolUse";`

function findSelectionFile(dist) {
  return fs.readdirSync(dist).find((name) => {
    if (!name.startsWith('selection-') || !name.endsWith('.js')) return false
    const src = fs.readFileSync(path.join(dist, name), 'utf8')
    return src.includes('function resolveIncompleteTurnPayloadText(params)')
  })
}

function findDeliveryRuntimeBasename(dist, toolsSrc) {
  const fromTools = toolsSrc.match(/import\("\.\/(task-registry-delivery-runtime-[^"]+\.js)"\)/)
  if (fromTools) return fromTools[1]
  return fs.readdirSync(dist).find(
    (name) => name.startsWith('task-registry-delivery-runtime-') && name.endsWith('.js'),
  )
}

/** @param {string} src */
export function upgradeReadOnlyToolTextReplyV3(src) {
  if (!src.includes(READONLY_TOOL_TEXT_REPLY_MARKER) || src.includes(READONLY_TOOL_TEXT_REPLY_V3_MARKER)) return src
  const oldBlock =
    `\tconst tryExternalSend = async () => {
\t\ttry {
\t\t\tconst delivery = inferDeliveryFromSessionKey(sessionKey);
\t\t\tconst origin = normalizeDeliveryContext(delivery);`
  const newBlock =
    `\tconst tryExternalSend = async () => {
\t\ttry {
\t\t\tlet origin = null;
\t\t\tif (typeof clawbbaResolveMediaDeliveryContext === "function") {
\t\t\t\tconst resolvedCtx = await clawbbaResolveMediaDeliveryContext({ sessionKey, requesterOrigin: params.requesterOrigin, cfg: params.cfg });
\t\t\t\torigin = resolvedCtx?.origin ?? null;
\t\t\t}
\t\t\tif (!origin) {
\t\t\t\tconst delivery = inferDeliveryFromSessionKey(sessionKey);
\t\t\t\torigin = normalizeDeliveryContext(delivery);
\t\t\t}`
  if (!src.includes(oldBlock)) return src
  return src.replace(READONLY_TOOL_TEXT_REPLY_V2_MARKER, `${READONLY_TOOL_TEXT_REPLY_V2_MARKER}\n${READONLY_TOOL_TEXT_REPLY_V3_MARKER}`).replace(oldBlock, newBlock)
}

/** @param {string} src */
export function upgradeReadOnlyToolTextReplyDispatch(src, serverPluginsBasename, deliveryRuntimeBasename) {
  if (!src.includes(READONLY_TOOL_TEXT_REPLY_MARKER)) return src
  let next = upgradeReadOnlyToolTextReplyV3(src)
  if (next.includes(READONLY_TOOL_TEXT_REPLY_V3_MARKER)) return next
  if (src.includes(READONLY_TOOL_TEXT_REPLY_V2_MARKER)) return src
  const block = buildReadOnlyToolTextReplyDispatchBlock(serverPluginsBasename, deliveryRuntimeBasename)
  return src.replace(
    /\/\* clawbba-readonly-tool-text-reply \*\/[\s\S]*?(?=async function clawbbaDispatchWebChatMediaLiveInject\(params\) \{)/,
    `${block}\n`,
  )
}

/**
 * @param {string} dist
 */
export function patchReadOnlyToolIncompleteTurnSuppress(dist) {
  const file = findSelectionFile(dist)
  if (!file) return 'missing-selection'
  const filePath = path.join(dist, file)
  let src = fs.readFileSync(filePath, 'utf8')
  if (src.includes(READONLY_TOOL_INCOMPLETE_TURN_MARKER)) return 'skip'
  if (!INCOMPLETE_TURN_NEEDLE.test(src)) return 'pattern-missing'
  src = src.replace(INCOMPLETE_TURN_NEEDLE, INCOMPLETE_TURN_REPLACEMENT)
  fs.writeFileSync(filePath, src)
  return 'patched'
}

/**
 * @param {string} toolsPath
 * @param {string} serverPluginsBasename
 * @param {string} deliveryRuntimeBasename
 */
export function ensureReadOnlyToolTextReplyDispatchInTools(
  toolsPath,
  serverPluginsBasename,
  deliveryRuntimeBasename,
) {
  let src = fs.readFileSync(toolsPath, 'utf8')
  let changed = false
  if (!src.includes(READONLY_TOOL_TEXT_REPLY_MARKER)) {
    if (!src.includes('async function clawbbaDispatchWebChatMediaLiveInject(params)')) return src
    const block = buildReadOnlyToolTextReplyDispatchBlock(serverPluginsBasename, deliveryRuntimeBasename)
    src = src.replace(
      'async function clawbbaDispatchWebChatMediaLiveInject(params) {',
      `${block}\nasync function clawbbaDispatchWebChatMediaLiveInject(params) {`,
    )
    changed = true
  } else {
    const upgraded = upgradeReadOnlyToolTextReplyDispatch(src, serverPluginsBasename, deliveryRuntimeBasename)
    if (upgraded !== src) {
      src = upgraded
      changed = true
    }
  }
  if (changed) fs.writeFileSync(toolsPath, src)
  return src
}

/**
 * @param {string} dist
 * @param {(dist: string, prefix: string, exportName?: string) => string | undefined} findDistFile
 */
export function patchReadOnlyToolTextReplyDist(dist, findDistFile) {
  const toolsFile = findDistFile(dist, 'openclaw-tools-')
  const pluginsFile = findDistFile(dist, 'server-plugins-')
  if (!toolsFile || !pluginsFile) return { tools: 'missing-file', selection: 'missing-file' }
  const toolsPath = path.join(dist, toolsFile)
  const toolsSrc = fs.readFileSync(toolsPath, 'utf8')
  const deliveryRuntime = findDeliveryRuntimeBasename(dist, toolsSrc)
  if (!deliveryRuntime) return { tools: 'missing-delivery-runtime', selection: patchReadOnlyToolIncompleteTurnSuppress(dist) }

  const before = toolsSrc
  ensureReadOnlyToolTextReplyDispatchInTools(toolsPath, pluginsFile, deliveryRuntime)
  const after = fs.readFileSync(toolsPath, 'utf8')
  let toolsResult = 'skip'
  if (!after.includes(READONLY_TOOL_TEXT_REPLY_MARKER)) {
    toolsResult = 'pattern-missing'
  } else if (after !== before) {
    toolsResult = after.includes(READONLY_TOOL_TEXT_REPLY_V2_MARKER) && before.includes(READONLY_TOOL_TEXT_REPLY_MARKER)
      ? 'upgraded-v2'
      : 'patched'
  }

  return {
    tools: toolsResult,
    selection: patchReadOnlyToolIncompleteTurnSuppress(dist),
  }
}
