#!/usr/bin/env node
import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import { patchImageToolClawbbaPolicyDist } from './clawbba-image-tool-policy-patch.mjs'
import { IMAGE_TOOL_POLICY_MARKER } from './clawbba-image-tool-policy-patch.mjs'

const dist = '/var/www/crypto-payment-demo/server/package/dist'
const tools = fs.readdirSync(dist).find((n) => n.startsWith('openclaw-tools-') && n.endsWith('.js'))
assert.ok(tools, 'need openclaw-tools bundle in server/package/dist')

const copyDir = fs.mkdtempSync(path.join('/tmp', 'clawbba-policy-'))
const copyPath = path.join(copyDir, tools)
fs.copyFileSync(path.join(dist, tools), copyPath)
const r = patchImageToolClawbbaPolicyDist(copyDir)
assert.equal(r, 'patched', `patch result: ${r}`)
const src = fs.readFileSync(copyPath, 'utf8')
assert.ok(src.includes(IMAGE_TOOL_POLICY_MARKER))
assert.ok(src.includes('__clawbbaChat?.provider === "clawbba"'))
console.log('test-image-tool-policy-patch: ok')
