#!/usr/bin/env node
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { execSync } from 'node:child_process'
import { patchWebChatLiveWakeInToolsFile } from './clawbba-webchat-live-wake-patch.mjs'
import { patchWebChatLiveInjectHelperInToolsFile } from './clawbba-webchat-live-inject.mjs'
import { patchExternalRecoverMediaDelivery } from './clawbba-external-recover-delivery.mjs'

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'clawbba-wx-origin-'))
execSync('npm pack openclaw@2026.5.27 --silent', { cwd: tmp, stdio: 'pipe' })
const tgz = fs.readdirSync(tmp).find((n) => n.endsWith('.tgz'))
execSync(`tar -xzf ${JSON.stringify(tgz)}`, { cwd: tmp })

const dist = path.join(tmp, 'package', 'dist')
const findDist = (d, prefix) => fs.readdirSync(d).find((n) => n.startsWith(prefix) && n.endsWith('.js'))
const toolsFile = findDist(dist, 'openclaw-tools-')
const pluginsFile = findDist(dist, 'server-plugins-')
const gatewayFile = findDist(dist, 'gateway-request-scope-')
const globalSingletonFile = findDist(dist, 'global-singleton-')
const sessionUtilsFile = findDist(dist, 'session-utils-')
const agentScopeFile = findDist(dist, 'agent-scope-')
const transcriptRuntimeFile = fs
  .readdirSync(dist)
  .find((n) => n.startsWith('transcript.runtime-') && n.endsWith('.js'))
const transcriptEventsFile = findDist(dist, 'transcript-events-')
const announceFile = findDist(dist, 'subagent-announce-delivery-')
const toolsPath = path.join(dist, toolsFile)

assert.ok(sessionUtilsFile, 'session-utils bundle required')

patchWebChatLiveInjectHelperInToolsFile(
  toolsPath,
  pluginsFile,
  globalSingletonFile,
  gatewayFile,
  sessionUtilsFile,
  agentScopeFile,
  transcriptRuntimeFile,
  transcriptEventsFile,
)
const ext = patchExternalRecoverMediaDelivery(dist, findDist)
assert.ok(['patched', 'upgraded-v3-no-compress', 'upgraded-session-mirror'].includes(ext), ext)
assert.notEqual(ext, 'origin-resolve-missing')
assert.equal(patchExternalRecoverMediaDelivery(dist, findDist), 'skip')

const wake = patchWebChatLiveWakeInToolsFile(toolsPath, announceFile)
assert.ok(['patched-wake', 'rebuilt-wake', 'upgraded', 'skip'].includes(wake), wake)

const src = fs.readFileSync(toolsPath, 'utf8')
assert.ok(src.includes('clawbba-media-delivery-origin-resolve-v1'))
assert.ok(src.includes('clawbba-media-delivery-origin-resolve-v3'))
assert.ok(src.includes('clawbbaScanSessionStorePreservedTo'))
assert.ok(src.includes('cfg: params.cfg'))
assert.ok(src.includes('clawbbaResolveMediaDeliveryContext'))
assert.ok(src.includes('requesterOrigin: params.handle?.requesterOrigin'))
assert.ok(src.includes('requesterOrigin: params.requesterOrigin'))
assert.ok(src.includes('clawbbaCollectMediaDeliverySessionKeys'))
assert.ok(src.includes('aliasSessionKeys'))

console.log('test-weixin-media-delivery-origin: ok')
