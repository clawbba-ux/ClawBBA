#!/usr/bin/env node
import assert from 'node:assert/strict'
import {
  MEDIA_DISPATCH_MEDIATEXT_GUARD_MARKER,
  upgradeMediaDispatchMediaTextGuard,
} from './clawbba-media-dispatch-patch.mjs'

const legacy = `/* clawbba-media-dispatch */
\t\t\tawait (async () => {
\t\t\t\tlet mediaText = prompt;
\t\t\t\tconst mModel = mediaText.match(/模型/);
\t\t\t})();`

const upgraded = upgradeMediaDispatchMediaTextGuard(legacy)
assert.ok(upgraded.includes(MEDIA_DISPATCH_MEDIATEXT_GUARD_MARKER))
assert.ok(upgraded.includes('typeof prompt === "string"'))
assert.ok(!upgraded.includes('let mediaText = prompt;'))

console.log('test-media-dispatch-mediatext-guard: ok')
