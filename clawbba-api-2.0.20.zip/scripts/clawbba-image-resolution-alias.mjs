/**
 * Map Agent-supplied 720P/1080P/… to OpenClaw image_generate 1K/2K/4K.
 */
import fs from 'fs'

export const RESOLUTION_ALIAS_MARKER = '/* clawbba-resolution-alias */'

const RESOLUTION_FN_RE =
  /function normalizeResolution\$1\(raw\) \{\n\tconst normalized = raw\?\.trim\(\)\.toUpperCase\(\);\n\tif \(!normalized\) return;\n\tif \(normalized === "1K" \|\| normalized === "2K" \|\| normalized === "4K"\) return normalized;\n\tthrow new ToolInputError\("resolution must be one of 1K, 2K, or 4K"\);\n\}/

const RESOLUTION_FN_WITH_ALIAS = `function normalizeResolution$1(raw) {
\tconst normalized = raw?.trim().toUpperCase();
\tif (!normalized) return;
\tif (normalized === "1K" || normalized === "2K" || normalized === "4K") return normalized;
\t${RESOLUTION_ALIAS_MARKER}
\tconst alias = { "720P": "1K", "1080P": "2K", "1440P": "2K", "2160P": "4K" };
\tif (alias[normalized]) return alias[normalized];
\tthrow new ToolInputError("resolution must be one of 1K, 2K, or 4K");
}`

/** @param {string} src */
export function upgradeImageResolutionAliases(src) {
  if (src.includes(RESOLUTION_ALIAS_MARKER)) return src
  if (!RESOLUTION_FN_RE.test(src)) return src
  return src.replace(RESOLUTION_FN_RE, RESOLUTION_FN_WITH_ALIAS)
}

/** @param {string} toolsPath */
export function patchImageResolutionAliasesInToolsFile(toolsPath) {
  const before = fs.readFileSync(toolsPath, 'utf8')
  const src = upgradeImageResolutionAliases(before)
  if (src === before) return before.includes(RESOLUTION_ALIAS_MARKER) ? 'skip' : 'pattern-missing'
  fs.writeFileSync(toolsPath, src)
  return 'upgraded'
}
