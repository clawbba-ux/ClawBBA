/**
 * 生成前用户确认 — 注入 OpenClaw tools runtime
 */
import {
  CLAWBBA_MEDIA_CONFIRM_PHRASE,
  buildMediaConfirmationMessage,
  isMediaGenerationConfirmPhrase,
  mediaJobFingerprint,
} from './clawbba-media-prompt-standards.mjs'
import {
  DEFAULT_IMAGE_MODEL_ID,
  DEFAULT_IMAGE_MODEL_LABEL,
  DEFAULT_VIDEO_MODEL_ID,
  DEFAULT_VIDEO_MODEL_LABEL,
} from './clawbba-openclaw-media-catalog.mjs'

export const MEDIA_CONFIRM_MARKER = '/* clawbba-media-confirm-gate */'

/**
 * Inline helpers injected into openclaw-tools bundle (after media-params block).
 */
export function buildMediaConfirmationHelperSource() {
  return `${MEDIA_CONFIRM_MARKER}
function clawbbaIsMediaGenerationConfirmPhrase(text) {
\tconst t = String(text ?? "").trim();
\tif (!t) return false;
\treturn /^(确认生成|确认开始|开始生成|confirm|yes\\s*generate)\\s*$/i.test(t);
}
function clawbbaMediaJobFingerprint(fields) {
\treturn [
\t\tfields.tool || "",
\t\tfields.model || "",
\t\tfields.aspectRatio || "",
\t\tfields.resolution || "",
\t\tfields.durationSeconds ?? "",
\t\tfields.mode || "",
\t\tfields.prompt || "",
\t\tfields.refCount ?? 0
\t].join("|");
}
function clawbbaRememberPendingMediaConfirm(sessionKey, fingerprint) {
\ttry {
\t\tconst store = globalThis.__clawbbaPendingMediaConfirm || (globalThis.__clawbbaPendingMediaConfirm = new Map());
\t\tstore.set(sessionKey, { fingerprint, at: Date.now() });
\t} catch (_) {}
}
function clawbbaClearPendingMediaConfirm(sessionKey) {
\ttry {
\t\tglobalThis.__clawbbaPendingMediaConfirm?.delete(sessionKey);
\t} catch (_) {}
}
async function clawbbaUserConfirmedMediaJob(sessionKey, fingerprint) {
\tconst sk = String(sessionKey ?? "").trim();
\tif (!sk) return false;
\ttry {
\t\tconst pending = globalThis.__clawbbaPendingMediaConfirm?.get(sk);
\t\tif (pending && pending.fingerprint === fingerprint && Date.now() - pending.at < 600000) {
\t\t\tconst rt = await getRuntime();
\t\t\tconst { storePath, entry } = rt.loadSessionEntry(sk);
\t\t\tconst sessionId = entry?.sessionId;
\t\t\tif (!sessionId || !storePath) return false;
\t\t\tconst msgs = await rt.readSessionMessagesAsync(sessionId, storePath, entry?.sessionFile, { mode: "recent", maxMessages: 32, maxBytes: 512000 });
\t\t\tfor (let i = msgs.length - 1; i >= 0; i--) {
\t\t\t\tconst m = msgs[i];
\t\t\t\tif (m?.role !== "user") continue;
\t\t\t\tconst t = clawbbaMessageTextFromUserRecord(m).trim();
\t\t\t\tif (clawbbaIsMediaGenerationConfirmPhrase(t)) {
\t\t\t\t\tclawbbaClearPendingMediaConfirm(sk);
\t\t\t\t\treturn true;
\t\t\t\t}
\t\t\t}
\t\t}
\t} catch (_) {}
\treturn false;
}
function clawbbaLookupImageModelConstraints(modelId) {
\tconst id = String(modelId ?? "").replace(/^openrouter\\//i, "").trim();
\tconst m = {
\t\t"google/gemini-3.1-flash-image-preview": "比例含 1:4/4:1/1:8/8:1；分辨率 0.5K/1K/2K/4K；支持参考图",
\t\t"google/gemini-3-pro-image-preview": "比例 1:1–21:9；分辨率 1K/2K/4K；支持参考图",
\t\t"google/gemini-2.5-flash-image": "比例 1:1–21:9；分辨率 1K/2K/4K；支持参考图",
\t\t"black-forest-labs/flux.2-pro": "比例 OpenClaw 枚举；分辨率 1K/2K/4K；支持参考图",
\t\t"openai/gpt-5.4-image-2": "比例 1:1–21:9；分辨率 1K/2K"
\t};
\treturn m[id] || "比例须为 OpenClaw 枚举(如 9:16/16:9)；分辨率 1K/2K/4K；详见 GET /api/v1/models image_options";
}
function clawbbaLookupVideoModelConstraints(modelId) {
\tconst id = String(modelId ?? "").replace(/^openrouter\\//i, "").trim();
\tconst m = {
\t\t"google/veo-3.1-fast": "常见 16:9/9:16；时长 5–8 秒；720p/1080p；可带音频",
\t\t"google/veo-3.1": "16:9/9:16；多时长；720p/1080p",
\t\t"alibaba/wan-2.6": "16:9/9:16；5/8/10 秒；部分 SKU 支持图生视频"
\t};
\treturn m[id] || "比例 16:9 或 9:16；时长写在话术(如 8 秒)；分辨率 720p/1080p 视模型；详见 video_options";
}
function clawbbaBuildMediaConfirmToolMessage(ctx) {
\tconst toolLabel = ctx.tool === "video_generate" ? "生视频" : "生图";
\tconst usedDefault = !ctx.modelId || String(ctx.modelId).includes("默认");
\tconst defaultId = ctx.tool === "video_generate" ? "${DEFAULT_VIDEO_MODEL_ID}" : "${DEFAULT_IMAGE_MODEL_ID}";
\tconst defaultLabel = ctx.tool === "video_generate" ? "${DEFAULT_VIDEO_MODEL_LABEL}" : "${DEFAULT_IMAGE_MODEL_LABEL}";
\tconst lines = [
\t\t"【ClawBBA 生成参数确认单】",
\t\t\`任务类型：\${toolLabel}\`,
\t\t\`模型：\${ctx.modelDisplay}\${usedDefault ? \`（话术未指定，默认 \${defaultId} · \${defaultLabel}）\` : ""}\`,
\t\t\`比例：\${ctx.aspectRatio || "（未指定，模型默认）"}\`
\t];
\tif (ctx.tool === "image_generate") {
\t\tlines.push(\`分辨率：\${ctx.resolution || "（未指定）"}\`);
\t} else {
\t\tlines.push(\`时长：\${ctx.durationSeconds != null ? ctx.durationSeconds + " 秒" : "（未指定）"}\`);
\t}
\tif (ctx.mode) lines.push(\`模式：\${ctx.mode}\`);
\tif (ctx.prompt) {
\t\tconst p = String(ctx.prompt);
\t\tlines.push(\`画面描述：\${p.length > 200 ? p.slice(0, 200) + "…" : p}\`);
\t}
\tif (ctx.constraints) lines.push(\`模型参数要求：\${ctx.constraints}\`);
\tlines.push(
\t\t"",
\t\t"请核对以上参数。无误后请回复「${CLAWBBA_MEDIA_CONFIRM_PHRASE}」开始任务（将扣费）。",
\t\t"若要修改，请重新发送自然语言描述（见 https://www.clawbba.com/agent/api-keys ）。",
\t\t"不清楚参数格式时，可让 Agent 根据 GET /api/v1/models 说明 image_options / video_options。"
\t);
\treturn lines.join("\\n");
}
async function clawbbaRequireUserConfirmBeforeMediaJob(ctx) {
\t${MEDIA_CONFIRM_MARKER}
\tif (ctx.options?.__clawbbaMediaConfirmed === true) return;
\tconst sk = typeof ctx.options?.agentSessionKey === "string" ? ctx.options.agentSessionKey.trim() : "";
\tif (!sk) return;
\tconst refCount = ctx.refCount ?? 0;
\tconst fp = clawbbaMediaJobFingerprint({
\t\ttool: ctx.tool,
\t\tmodel: ctx.modelId || ctx.modelDisplay || "",
\t\taspectRatio: ctx.aspectRatio || "",
\t\tresolution: ctx.resolution || "",
\t\tdurationSeconds: ctx.durationSeconds,
\t\tmode: ctx.mode || "",
\t\tprompt: ctx.prompt || "",
\t\trefCount
\t});
\tif (await clawbbaUserConfirmedMediaJob(sk, fp)) return;
\tclawbbaRememberPendingMediaConfirm(sk, fp);
\tthrow new ToolInputError(clawbbaBuildMediaConfirmToolMessage(ctx));
}`
}

/** @param {string} src */
export function toolsSrcHasMediaConfirmGate(src) {
  return src.includes(MEDIA_CONFIRM_MARKER) && src.includes('clawbbaRequireUserConfirmBeforeMediaJob')
}

/** @param {string} src */
export function injectMediaConfirmationHelperSource(src) {
  if (toolsSrcHasMediaConfirmGate(src)) return src
  const block = buildMediaConfirmationHelperSource()
  const anchor = 'async function clawbbaResolveClawbbaImageParams'
  const idx = src.indexOf(anchor)
  if (idx < 0) return src
  return `${src.slice(0, idx)}${block}\n${src.slice(idx)}`
}

export { isMediaGenerationConfirmPhrase, mediaJobFingerprint, buildMediaConfirmationMessage }
