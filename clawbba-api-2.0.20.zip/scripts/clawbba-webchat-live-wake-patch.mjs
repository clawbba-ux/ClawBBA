/**
 * OpenClaw 2026.5.27+：生图/生视频完成后在 wakeMediaGenerationTaskCompletion 里
 * - 微信/Telegram 等外渠：sendMessage 直发原会话（避免 inter-session 落到错误模型/新窗口）
 * - WebChat/Dashboard：chat.inject 即时显示
 */
import fs from 'fs'
import path from 'path'
import { dedupeClawbbaWakePatchBlocks } from './clawbba-patch-dedupe.mjs'

export const WEBCHAT_LIVE_WAKE_MARKER = '/* clawbba-webchat-live-wake */'
export const EXTERNAL_WAKE_DELIVERY_MARKER = '/* clawbba-external-wake-delivery */'
export const EXTERNAL_WAKE_SKIP_ANNOUNCE_MARKER = '/* clawbba-external-wake-skip-announce */'
export const EXTERNAL_WAKE_ANNOUNCE_CONTINUE_MARKER = '/* clawbba-external-wake-announce-continue */'

const WAKE_FN = 'async function wakeMediaGenerationTaskCompletion(params) {'
const MEDIA_URLS_LINE =
  '\tconst mediaUrls = Array.from(new Set([...params.mediaUrls ?? [], ...mediaUrlsFromGeneratedAttachments(params.attachments)]));'
const INTERNAL_EVENTS_NEEDLE = '\tconst internalEvents'

const ANNOUNCE_CALL_NEEDLE = `\tconst delivery = await deliverSubagentAnnouncement({`
const ANNOUNCE_SKIP_GUARD_OLD = `\t${EXTERNAL_WAKE_SKIP_ANNOUNCE_MARKER}
\tif (clawbbaWakeDeliveredExternal) return true;
\tconst delivery = await deliverSubagentAnnouncement({`
const ANNOUNCE_CONTINUE_GUARD = `\t${EXTERNAL_WAKE_ANNOUNCE_CONTINUE_MARKER}
\tif (clawbbaWakeDeliveredExternal) {
\t\ttry { globalThis.__clawbbaExternalMediaAlreadyDelivered = params.handle?.taskId ?? true; } catch (_) {}
\t}
\tconst delivery = await deliverSubagentAnnouncement({`

function buildWakeDeliveryBlock(announceBasename) {
  return `\tlet clawbbaWakeDeliveredExternal = false;
\t${EXTERNAL_WAKE_DELIVERY_MARKER}
\t${WEBCHAT_LIVE_WAKE_MARKER}
\tif (params.status === "ok" && mediaUrls.length > 0) {
\t\tconst __clawbbaSk = typeof params.handle.requesterSessionKey === "string" ? params.handle.requesterSessionKey.trim() : "";
\t\tconst __clawbbaCh = normalizeMessageChannel(params.handle.requesterOrigin?.channel ?? "");
\t\tif (__clawbbaSk && __clawbbaCh && __clawbbaCh !== "webchat" && !__clawbbaSk.includes(":dashboard:")) {
\t\t\ttry {
\t\t\t\tif (typeof clawbbaDispatchRecoverMediaDelivery === "function") {
\t\t\t\t\tconst __extMode = await clawbbaDispatchRecoverMediaDelivery({
\t\t\t\t\t\tcfg: params.config,
\t\t\t\t\t\tsessionKey: __clawbbaSk,
\t\t\t\t\t\trequesterOrigin: params.handle?.requesterOrigin,
\t\t\t\t\t\tchatRunId: params.handle?.requesterChatRunId,
\t\t\t\t\t\tmediaPaths: mediaUrls,
\t\t\t\t\t\tcaption: "",
\t\t\t\t\t\tsourceTool: params.toolName,
\t\t\t\t\t\tcompletionLabel: params.completionLabel,
\t\t\t\t\t\tmessage: typeof params.result === "string" && params.result.includes("MEDIA:") ? params.result : void 0,
\t\t\t\t\t\tlabel: params.toolName === "video_generate" ? "ClawBBA video" : "ClawBBA image",
\t\t\t\t\t\tmediaKind: params.toolName === "video_generate" ? "video" : "image"
\t\t\t\t\t});
\t\t\t\t\tif (__extMode === "external") clawbbaWakeDeliveredExternal = true;
\t\t\t\t}
\t\t\t} catch (__clawbbaExtErr) {
\t\t\t\tlog$5.warn("clawbba external wake delivery failed", { error: String(__clawbbaExtErr?.message ?? __clawbbaExtErr) });
\t\t\t}
\t\t}
\t\tif (!clawbbaWakeDeliveredExternal && __clawbbaSk && (__clawbbaCh === "webchat" || __clawbbaSk.includes(":dashboard:"))) {
\t\t\ttry {
\t\t\t\tconst { clawbbaInjectWebChatGeneratedMediaLive } = await import("./${announceBasename}");
\t\t\t\tawait clawbbaInjectWebChatGeneratedMediaLive({
\t\t\t\t\tsessionKey: __clawbbaSk,
\t\t\t\t\tchatRunId: params.handle?.requesterChatRunId,
\t\t\t\t\tmediaUrls,
\t\t\t\t\tsourceTool: params.toolName,
\t\t\t\t\tcompletionLabel: params.completionLabel,
\t\t\t\t\tmessage: typeof params.result === "string" && params.result.includes("MEDIA:") ? params.result : void 0
\t\t\t\t});
\t\t\t} catch (__clawbbaErr) {
\t\t\t\tlog$5.warn("clawbba webchat live wake inject failed", { error: String(__clawbbaErr?.message ?? __clawbbaErr) });
\t\t\t}
\t\t}
\t}`
}

/**
 * Idempotent: replace everything between mediaUrls and internalEvents with one clean clawbba wake block.
 * Fixes v1.5.81 partial legacy upgrade leaving orphan `}` (SyntaxError).
 * @param {string} src
 * @param {string} announceBasename
 * @returns {{ src: string, rebuilt: boolean }}
 */
export function rebuildWakeInjectionSection(src, announceBasename) {
  const fnStart = src.indexOf(WAKE_FN)
  if (fnStart < 0) return { src, rebuilt: false }

  const mediaIdx = src.indexOf(MEDIA_URLS_LINE, fnStart)
  if (mediaIdx < 0) return { src, rebuilt: false }

  const afterMedia = mediaIdx + MEDIA_URLS_LINE.length
  const internalIdx = src.indexOf(INTERNAL_EVENTS_NEEDLE, afterMedia)
  if (internalIdx < 0) return { src, rebuilt: false }

  const injection = `\n${buildWakeDeliveryBlock(announceBasename)}\n`
  const next = src.slice(0, afterMedia) + injection + src.slice(internalIdx)
  const changed = next !== src
  return { src: next, rebuilt: changed }
}

/**
 * @param {string} src
 */
export function ensureAnnounceSkipGuard(src) {
  if (src.includes(EXTERNAL_WAKE_ANNOUNCE_CONTINUE_MARKER)) return upgradeWakeAnnounceCleanup(src)
  if (src.includes(EXTERNAL_WAKE_SKIP_ANNOUNCE_MARKER)) {
    return upgradeWakeAnnounceCleanup(src.replace(ANNOUNCE_SKIP_GUARD_OLD, ANNOUNCE_CONTINUE_GUARD))
  }
  if (!src.includes(ANNOUNCE_CALL_NEEDLE)) return src
  return upgradeWakeAnnounceCleanup(src.replace(ANNOUNCE_CALL_NEEDLE, ANNOUNCE_CONTINUE_GUARD))
}

export function upgradeWakeAnnounceCleanup(src) {
  if (src.includes('__clawbbaExternalMediaAlreadyDelivered = undefined')) return src
  const needle = '\treturn delivery.delivered;'
  const replacement = `\ttry { globalThis.__clawbbaExternalMediaAlreadyDelivered = undefined; } catch (_) {}\n\treturn delivery.delivered;`
  if (!src.includes(needle)) return src
  return src.replace(needle, replacement)
}

/** @deprecated use rebuildWakeInjectionSection */
export function upgradeWakeExternalDelivery(src, announceBasename = 'subagent-announce-delivery.js') {
  const { src: next, rebuilt } = rebuildWakeInjectionSection(src, announceBasename)
  const withGuard = ensureAnnounceSkipGuard(next)
  return withGuard !== src || rebuilt ? withGuard : src
}

/**
 * @param {string} toolsPath
 * @param {string} announceBasename e.g. subagent-announce-delivery-DK-Ub9gW.js
 */
export function patchWebChatLiveWakeInToolsFile(toolsPath, announceBasename) {
  const raw = fs.readFileSync(toolsPath, 'utf8')
  let src = dedupeClawbbaWakePatchBlocks(raw)
  const before = src

  const { src: rebuilt, rebuilt: didRebuild } = rebuildWakeInjectionSection(src, announceBasename)
  src = ensureAnnounceSkipGuard(rebuilt)

  if (!src.includes(EXTERNAL_WAKE_DELIVERY_MARKER)) {
    return 'pattern-missing'
  }
  if (!src.includes(EXTERNAL_WAKE_ANNOUNCE_CONTINUE_MARKER) && !src.includes(EXTERNAL_WAKE_SKIP_ANNOUNCE_MARKER)) {
    return 'pattern-missing'
  }

  if (src.includes('chatRunId: params.handle?.runId')) {
    src = src.replace(/chatRunId: params\.handle\?\.runId/g, 'chatRunId: params.handle?.requesterChatRunId')
  }

  if (src === before) return 'skip'

  fs.writeFileSync(toolsPath, src)
  if (!before.includes(EXTERNAL_WAKE_DELIVERY_MARKER)) return 'patched-wake'
  return didRebuild ? 'rebuilt-wake' : 'upgraded'
}

/**
 * @param {string} dist
 * @param {(dist: string, prefix: string) => string|undefined} findDistFile
 */
export function patchWebChatLiveWakeDist(dist, findDistFile) {
  const toolsFile = findDistFile(dist, 'openclaw-tools-')
  const announceFile = findDistFile(dist, 'subagent-announce-delivery-')
  if (!toolsFile || !announceFile) return 'missing-file'
  const announceSrc = fs.readFileSync(path.join(dist, announceFile), 'utf8')
  if (!announceSrc.includes('export async function clawbbaInjectWebChatGeneratedMediaLive')) {
    return 'announce-live-helper-missing'
  }
  return patchWebChatLiveWakeInToolsFile(path.join(dist, toolsFile), announceFile)
}
