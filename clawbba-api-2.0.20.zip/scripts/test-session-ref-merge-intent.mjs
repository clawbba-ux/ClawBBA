#!/usr/bin/env node
import assert from 'node:assert/strict'
import {
  promptRequiresReferenceImages,
  sessionMergeRequiresStrongReferenceIntent,
} from './clawbba-reference-images.mjs'

const tpl =
  '请使用 ClawBBA 生成图片能力，模型 google/gemini-2.5-flash-image，为我生成 9:16、1K 横图：根据参考图生成一个电商用的主图和详情图'

assert.equal(promptRequiresReferenceImages(tpl), true)
assert.equal(sessionMergeRequiresStrongReferenceIntent(tpl), true)
assert.equal(sessionMergeRequiresStrongReferenceIntent('请使用 ClawBBA 生成图片能力，为我生成 16:9 风景'), false)
assert.equal(sessionMergeRequiresStrongReferenceIntent('请上传附件后生成'), false)

console.log('test-session-ref-merge-intent: ok')
