/**
 * ClawBBA 话术比例解析 / 矛盾检测（与 clawbba-media-params 注入块保持一致）
 */

/** @param {string} mediaText */
export function parseAspectFromTemplate(mediaText) {
  const t = String(mediaText ?? '')
  const ratio9x16 = /9\s*[:：]\s*16/.test(t)
  const ratio16x9 = /16\s*[:：]\s*9/.test(t)
  const ratio21x9 = /21\s*[:：]\s*9/.test(t)
  const wordPortrait = /竖图|竖屏|portrait/i.test(t)
  const wordLandscape = /横图|横屏|landscape/i.test(t)

  if (ratio9x16 && ratio16x9) return null
  if (ratio9x16 && wordLandscape && !wordPortrait && !ratio16x9) return null
  if (ratio16x9 && wordPortrait && !wordLandscape && !ratio9x16) return null

  if (ratio9x16) return '9:16'
  if (ratio16x9 || ratio21x9) return ratio21x9 ? '21:9' : '16:9'

  if (/16\s*[:：]\s*9|横图|横屏|landscape/i.test(t) && !wordPortrait) return '16:9'
  if (/9\s*[:：]\s*16|竖图|竖屏|portrait/i.test(t) && !wordLandscape) return '9:16'

  for (const pair of [
    ['21:9', /21\s*[:：]\s*9/],
    ['16:9', /16\s*[:：]\s*9/],
    ['9:16', /9\s*[:：]\s*16/],
    ['4:3', /4\s*[:：]\s*3/],
    ['3:4', /3\s*[:：]\s*4/],
    ['1:1', /1\s*[:：]\s*1/],
  ]) {
    if (pair[1].test(t)) return pair[0]
  }
  return null
}

/** @param {string} mediaText @returns {string|null} */
export function aspectTemplateConflictMessage(mediaText) {
  const t = String(mediaText ?? '')
  const ratio9x16 = /9\s*[:：]\s*16/.test(t)
  const ratio16x9 = /16\s*[:：]\s*9/.test(t)
  const wordPortrait = /竖图|竖屏|portrait/i.test(t)
  const wordLandscape = /横图|横屏|landscape/i.test(t)

  if (ratio9x16 && ratio16x9) {
    return '比例矛盾：同时写了 9:16 与 16:9。请只保留一种比例。'
  }
  if (ratio9x16 && wordLandscape && !wordPortrait && !ratio16x9) {
    return '比例矛盾：写了 9:16 又写了「横图」。请改为「9:16 竖图」或「16:9 横图」。'
  }
  if (ratio16x9 && wordPortrait && !wordLandscape && !ratio9x16) {
    return '比例矛盾：写了 16:9 又写了「竖图」。请改为「16:9 横图」或「9:16 竖图」。'
  }
  return null
}
