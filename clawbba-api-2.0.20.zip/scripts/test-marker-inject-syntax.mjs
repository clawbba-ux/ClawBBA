#!/usr/bin/env node
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { execSync } from 'node:child_process'
import {
  buildClawbbaUserMediaModelDisplayFnBlock,
  ensureClawbbaUserMediaModelDisplayFnInSrc,
  isUserMediaModelDisplayMisplaced,
} from './clawbba-media-model-ref.mjs'

const MARKER = '/* clawbba-local-media-delivery */'
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'marker-inject-'))
execSync(`tar -xzf ${JSON.stringify(path.join('/var/www/crypto-payment-demo/packages/clawbba-api', 'openclaw-2026.5.28.tgz'))} -C ${JSON.stringify(tmp)}`, {
  stdio: 'pipe',
})
const dist = path.join(tmp, 'package/dist')
process.env.OPENCLAW_DIST = dist
execSync(`node ${JSON.stringify(path.join('/var/www/crypto-payment-demo/packages/clawbba-api/scripts/patch-openclaw-media-delivery.mjs'))}`, {
  stdio: 'pipe',
})
const toolsPath = path.join(dist, fs.readdirSync(dist).find((f) => f.startsWith('openclaw-tools-')))
let src = fs.readFileSync(toolsPath, 'utf8')
src = src.replace(/\/\* clawbba-user-media-model-display \*\/[\s\S]*?\n\}/, '')
src = src.replace(/async function executeVideoGenerationJob\(params\) \{[\s\S]*?\n\}/, '')
src = src.replace(/\/\* clawbba-video-recover \*\//g, '/* clawbba-video-recover-removed */')
const idx = src.indexOf(MARKER)
assert.ok(idx >= 0, 'MARKER must exist after wake patch')
const bad = `${src.slice(0, idx)}${buildClawbbaUserMediaModelDisplayFnBlock()}\n${src.slice(idx)}`
fs.writeFileSync(toolsPath, bad)
let failed = false
try {
  execSync(`node --check ${JSON.stringify(path.basename(toolsPath))}`, { cwd: dist, stdio: 'pipe' })
} catch {
  failed = true
}
assert.equal(failed, true, 'misplaced inject must fail syntax check')

const fixed = ensureClawbbaUserMediaModelDisplayFnInSrc(bad)
fs.writeFileSync(toolsPath, fixed)
execSync(`node --check ${JSON.stringify(path.basename(toolsPath))}`, { cwd: dist, stdio: 'pipe' })
assert.ok(fixed.includes('function clawbbaFormatUserMediaModel('))
assert.ok(!isUserMediaModelDisplayMisplaced(fixed))

console.log('test-marker-inject-syntax: ok')
