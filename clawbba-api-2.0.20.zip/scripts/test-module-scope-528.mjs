#!/usr/bin/env node
/**
 * OpenClaw 2026.5.28：validate 必须在 createImageGenerateTool 之前（模块级）
 */
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { execSync } from 'node:child_process'
import {
  CLAWBBA_VALIDATE_VIDEO_FN,
  validateFnIsModuleScoped,
} from './clawbba-media-tool-validate.mjs'
import { videoValidateRuntimeIsHealthy } from './clawbba-video-validate-health.mjs'

const tgz = path.join('/var/www/crypto-payment-demo/packages/clawbba-api', 'openclaw-2026.5.28.tgz')
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'clawbba-scope-528-'))
execSync(`tar -xzf ${JSON.stringify(tgz)}`, { cwd: tmp })
const dist = path.join(tmp, 'package', 'dist')
execSync(
  `OPENCLAW_DIST=${JSON.stringify(dist)} node ${JSON.stringify(path.join(path.dirname(new URL(import.meta.url).pathname), 'patch-openclaw-media-delivery.mjs'))}`,
  { stdio: 'pipe' },
)
const tools = path.join(dist, fs.readdirSync(dist).find((n) => n.startsWith('openclaw-tools-')))
const src = fs.readFileSync(tools, 'utf8')
const imgTool = src.indexOf('function createImageGenerateTool(')
const videoFn = src.indexOf(CLAWBBA_VALIDATE_VIDEO_FN)
const videoDispatch = src.indexOf('clawbba-media-dispatch-video')
assert.ok(imgTool > 0 && videoFn > 0 && videoFn < imgTool, 'validate before createImageGenerateTool')
assert.ok(validateFnIsModuleScoped(src))
assert.ok(videoValidateRuntimeIsHealthy(src))
assert.ok(videoDispatch > imgTool, 'video dispatch inside tool execute is OK')
execSync(`node --check ${JSON.stringify(tools)}`)
console.log('test-module-scope-528: ok')
