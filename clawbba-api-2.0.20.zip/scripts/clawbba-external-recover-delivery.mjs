/**
 * External channel (WeChat / Telegram / …) recover delivery:
 * sequential sendMessage (original quality — no re-encode/compress).
 */
import fs from 'fs'
import path from 'path'

export const EXTERNAL_RECOVER_DELIVERY_MARKER = '/* clawbba-external-recover-delivery */'
export const EXTERNAL_RECOVER_DELIVERY_V2_MARKER = '/* clawbba-external-recover-delivery-v2 */'
export const EXTERNAL_RECOVER_DELIVERY_V3_MARKER = '/* clawbba-external-recover-delivery-v3-no-compress */'
export const MEDIA_DELIVERY_ORIGIN_RESOLVE_V1_MARKER = '/* clawbba-media-delivery-origin-resolve-v1 */'
export const MEDIA_DELIVERY_ORIGIN_RESOLVE_V2_MARKER = '/* clawbba-media-delivery-origin-resolve-v2 */'
export const MEDIA_DELIVERY_ORIGIN_RESOLVE_V3_MARKER = '/* clawbba-media-delivery-origin-resolve-v3-store-scan */'
export const MEDIA_TASK_ORIGIN_ENRICH_MARKER = 'clawbba-media-task-origin-enrich'
export const SESSION_TRANSCRIPT_MIRROR_MARKER = '/* clawbba-session-transcript-mirror */'
export const IMAGE_RECOVER_EXTERNAL_DELIVERY_MARKER = '/* clawbba-image-recover-external-delivery */'
export const IMAGE_RECOVER_DELIVERY_GUARD_MARKER = '/* clawbba-image-recover-delivery-guard */'
export const VIDEO_RECOVER_EXTERNAL_DELIVERY_MARKER = '/* clawbba-video-recover-external-delivery */'

export function buildClawbbaDedupeImageBuffersFnBlock() {
  return `function clawbbaDedupeImageBuffers(buffers) {
\tconst seen = new Set();
\tconst out = [];
\tfor (const b of buffers) {
\t\tif (!b?.buffer?.length) continue;
\t\tlet key;
\t\ttry {
\t\t\tkey = crypto.createHash("sha256").update(b.buffer).digest("hex");
\t\t} catch (_) {
\t\t\tkey = \`\${b.buffer.length}:\${b.mime}:\${b.buffer.subarray(0, Math.min(32, b.buffer.length)).toString("base64")}\`;
\t\t}
\t\tif (seen.has(key)) continue;
\t\tseen.add(key);
\t\tout.push(b);
\t}
\treturn out;
}`
}

/** @param {string} deliveryRuntimeBasename @param {string} sessionUtilsBasename */
export function buildMediaDeliveryOriginResolveBlock(sessionUtilsBasename) {
  return `${MEDIA_DELIVERY_ORIGIN_RESOLVE_V1_MARKER}
${MEDIA_DELIVERY_ORIGIN_RESOLVE_V2_MARKER}
${MEDIA_DELIVERY_ORIGIN_RESOLVE_V3_MARKER}
function clawbbaNormalizeMediaDeliveryOrigin(raw) {
\ttry {
\t\tconst origin = normalizeDeliveryContext(raw);
\t\tif (!origin?.channel || !origin?.to || !isDeliverableMessageChannel(origin.channel)) return null;
\t\tconst ch = normalizeMessageChannel(origin.channel);
\t\tif (!ch || ch === "webchat") return null;
\t\treturn { origin, channel: ch };
\t} catch (_) {
\t\treturn null;
\t}
}
function clawbbaCollectMediaDeliverySessionKeys(...keys) {
\tconst out = [];
\tconst seen = new Set();
\tfor (const raw of keys) {
\t\tconst k = typeof raw === "string" ? raw.trim() : "";
\t\tif (!k || seen.has(k)) continue;
\t\tseen.add(k);
\t\tout.push(k);
\t}
\treturn out;
}
function clawbbaSessionRestMatches(a, b) {
\tconst left = typeof a === "string" ? a.trim() : "";
\tconst right = typeof b === "string" ? b.trim() : "";
\tif (!left || !right) return false;
\tif (left === right) return true;
\ttry {
\t\tconst pl = parseAgentSessionKey(left);
\t\tconst pr = parseAgentSessionKey(right);
\t\tif (pl && pr) {
\t\t\treturn pl.agentId === pr.agentId && String(pl.rest || "main").toLowerCase() === String(pr.rest || "main").toLowerCase();
\t\t}
\t} catch (_) {}
\treturn left.toLowerCase() === right.toLowerCase();
}
function clawbbaPreferPreservedDeliveryTo(primary, fallback) {
\tconst a = typeof primary === "string" ? primary.trim() : "";
\tconst b = typeof fallback === "string" ? fallback.trim() : "";
\tif (!a) return b;
\tif (!b) return a;
\tif (a.toLowerCase() !== b.toLowerCase()) return a;
\tif (a === b) return a;
\tconst aMixed = a !== a.toLowerCase();
\tconst bMixed = b !== b.toLowerCase();
\tif (bMixed && !aMixed) return b;
\tif (aMixed && !bMixed) return a;
\treturn b;
}
function clawbbaCollectEntryDeliveryToCandidates(entry) {
\tif (!entry || typeof entry !== "object") return [];
\tconst dc = entry.deliveryContext && typeof entry.deliveryContext === "object" ? entry.deliveryContext : null;
\treturn [dc?.to, entry.lastTo, entry.origin?.to].filter((v) => typeof v === "string" && v.trim()).map((v) => v.trim());
}
function clawbbaScanSessionStorePreservedTo(cfg, sessionKey, inferredTo) {
\tconst inferredLower = typeof inferredTo === "string" ? inferredTo.trim().toLowerCase() : "";
\tif (!cfg || !sessionKey) return "";
\ttry {
\t\tconst target = resolveGatewaySessionStoreTarget({ cfg, key: sessionKey.trim() });
\t\tconst store = loadSessionStore(target.storePath);
\t\tlet preserved = "";
\t\tconst considerEntry = (entry) => {
\t\t\tfor (const to of clawbbaCollectEntryDeliveryToCandidates(entry)) {
\t\t\t\tif (inferredLower && to.toLowerCase() !== inferredLower) continue;
\t\t\t\tpreserved = clawbbaPreferPreservedDeliveryTo(preserved, to);
\t\t\t}
\t\t};
\t\tfor (const sk of target.storeKeys || []) considerEntry(store[sk]);
\t\tif (!preserved) for (const entry of Object.values(store || {})) considerEntry(entry);
\t\treturn preserved;
\t} catch (_) {
\t\treturn "";
\t}
}
function clawbbaEnrichMediaTaskRequesterOrigin(params) {
\tconst sessionKey = typeof params?.sessionKey === "string" ? params.sessionKey.trim() : "";
\tconst cfg = params?.cfg;
\tconst raw = params?.requesterOrigin && typeof params.requesterOrigin === "object" ? params.requesterOrigin : {};
\tconst inferred = sessionKey ? inferDeliveryFromSessionKey(sessionKey) : null;
\tconst inferredTo = typeof raw.to === "string" && raw.to.trim() ? raw.to.trim() : (typeof params?.currentChannelId === "string" && params.currentChannelId.trim() ? params.currentChannelId.trim() : (inferred?.to ?? ""));
\tconst scanned = cfg && sessionKey ? clawbbaScanSessionStorePreservedTo(cfg, sessionKey, inferredTo) : "";
\tconst to = clawbbaPreferPreservedDeliveryTo(clawbbaPreferPreservedDeliveryTo(inferredTo, scanned), scanned) || inferredTo;
\ttry {
\t\tif (to && to !== to.toLowerCase()) {
\t\t\tconst cache = globalThis.__clawbbaPreservedDeliveryToCache || (globalThis.__clawbbaPreservedDeliveryToCache = new Map());
\t\t\tcache.set(to.toLowerCase(), to);
\t\t}
\t} catch (_) {}
\tconst channel = raw.channel ?? inferred?.channel;
\tconst accountId = raw.accountId ?? inferred?.accountId;
\tconst threadId = raw.threadId ?? inferred?.threadId;
\tif (!channel || !to) return params?.requesterOrigin;
\treturn normalizeDeliveryContext({ channel, to, accountId, threadId });
}
async function clawbbaResolveMediaDeliveryContext(params) {
\tconst sessionKey = typeof params.sessionKey === "string" ? params.sessionKey.trim() : "";
\tif (!sessionKey) return null;
\tconst cfg = params.cfg;
\tlet aliasSessionKeys = clawbbaCollectMediaDeliverySessionKeys(sessionKey);
\tlet transcriptSessionKey = sessionKey;
\tlet sessionOrigin = null;
\tlet sessionTo = "";
\tlet canonicalKey = sessionKey;
\tconst keyOrigin = clawbbaNormalizeMediaDeliveryOrigin(inferDeliveryFromSessionKey(sessionKey));
\tconst inferredTo = keyOrigin?.origin?.to ?? "";
\ttry {
\t\tconst cached = globalThis.__clawbbaPreservedDeliveryToCache?.get(inferredTo.toLowerCase());
\t\tif (typeof cached === "string" && cached.trim()) sessionTo = clawbbaPreferPreservedDeliveryTo(sessionTo, cached.trim());
\t} catch (_) {}
\tif (cfg) {
\t\ttry {
\t\t\tconst target = resolveGatewaySessionStoreTarget({ cfg, key: sessionKey });
\t\t\tcanonicalKey = target.canonicalKey || sessionKey;
\t\t\taliasSessionKeys = clawbbaCollectMediaDeliverySessionKeys(sessionKey, canonicalKey);
\t\t\ttranscriptSessionKey = clawbbaSessionRestMatches(sessionKey, canonicalKey) ? sessionKey : canonicalKey;
\t\t\tsessionTo = clawbbaScanSessionStorePreservedTo(cfg, sessionKey, inferredTo);
\t\t\tconst store = loadSessionStore(target.storePath);
\t\t\tlet entry = null;
\t\t\tfor (const sk of target.storeKeys || []) {
\t\t\t\tconst candidate = store[sk];
\t\t\t\tif (!candidate) continue;
\t\t\t\tif (!entry || (candidate.updatedAt ?? 0) > (entry.updatedAt ?? 0)) entry = candidate;
\t\t\t}
\t\t\tif (!sessionTo && entry) {
\t\t\t\tfor (const to of clawbbaCollectEntryDeliveryToCandidates(entry)) {
\t\t\t\t\tsessionTo = clawbbaPreferPreservedDeliveryTo(sessionTo, to);
\t\t\t\t}
\t\t\t}
\t\t\tif (sessionTo || entry) {
\t\t\t\tconst dc = entry?.deliveryContext && typeof entry.deliveryContext === "object" ? entry.deliveryContext : null;
\t\t\t\tsessionOrigin = clawbbaNormalizeMediaDeliveryOrigin({
\t\t\t\t\tchannel: dc?.channel ?? entry?.lastChannel ?? entry?.channel ?? keyOrigin?.origin?.channel,
\t\t\t\t\tto: sessionTo || void 0,
\t\t\t\t\taccountId: dc?.accountId ?? entry?.lastAccountId ?? keyOrigin?.origin?.accountId,
\t\t\t\t\tthreadId: dc?.threadId ?? entry?.lastThreadId ?? keyOrigin?.origin?.threadId
\t\t\t\t});
\t\t\t}
\t\t} catch (_) {}
\t}
\tif (!sessionTo) {
\t\ttry {
\t\t\tconst sessionUtilsModule = await import("./${sessionUtilsBasename}");
\t\t\tconst loadSessionEntry = clawbbaPickModuleExport(sessionUtilsModule, "loadSessionEntry", ["c"]);
\t\t\tconst loaded = loadSessionEntry(sessionKey);
\t\t\tconst entry = loaded?.entry;
\t\t\tcanonicalKey = typeof loaded?.canonicalKey === "string" && loaded.canonicalKey.trim() ? loaded.canonicalKey.trim() : sessionKey;
\t\t\taliasSessionKeys = clawbbaCollectMediaDeliverySessionKeys(sessionKey, canonicalKey);
\t\t\ttranscriptSessionKey = clawbbaSessionRestMatches(sessionKey, canonicalKey) ? sessionKey : canonicalKey;
\t\t\tif (entry) {
\t\t\t\tfor (const to of clawbbaCollectEntryDeliveryToCandidates(entry)) {
\t\t\t\t\tsessionTo = clawbbaPreferPreservedDeliveryTo(sessionTo, to);
\t\t\t\t}
\t\t\t\tif (!sessionOrigin) {
\t\t\t\t\tconst dc = entry.deliveryContext && typeof entry.deliveryContext === "object" ? entry.deliveryContext : null;
\t\t\t\t\tsessionOrigin = clawbbaNormalizeMediaDeliveryOrigin({
\t\t\t\t\t\tchannel: dc?.channel ?? entry.lastChannel ?? entry.channel,
\t\t\t\t\t\tto: sessionTo || void 0,
\t\t\t\t\t\taccountId: dc?.accountId ?? entry.lastAccountId,
\t\t\t\t\t\tthreadId: dc?.threadId ?? entry.lastThreadId
\t\t\t\t\t});
\t\t\t\t}
\t\t\t}
\t\t} catch (_) {}
\t}
\tconst handleOrigin = params.requesterOrigin ? clawbbaNormalizeMediaDeliveryOrigin(params.requesterOrigin) : null;
\tlet picked = sessionOrigin || handleOrigin || keyOrigin;
\tif (picked?.origin) {
\t\tconst reqTo = handleOrigin?.origin?.to ?? "";
\t\tconst preservedTo = [reqTo, sessionTo, inferredTo].reduce((acc, to) => clawbbaPreferPreservedDeliveryTo(acc, to), "");
\t\tif (preservedTo) picked = { ...picked, origin: { ...picked.origin, to: preservedTo } };
\t}
\ttry {
\t\tconst finalTo = picked?.origin?.to;
\t\tif (typeof finalTo === "string" && finalTo.trim() && finalTo !== finalTo.toLowerCase()) {
\t\t\tconst cache = globalThis.__clawbbaPreservedDeliveryToCache || (globalThis.__clawbbaPreservedDeliveryToCache = new Map());
\t\t\tcache.set(finalTo.toLowerCase(), finalTo.trim());
\t\t}
\t} catch (_) {}
\tif (!picked) return null;
\ttry {
\t\tlog$5.info("clawbba media delivery origin resolved", {
\t\t\tsessionKey,
\t\t\treqTo: handleOrigin?.origin?.to ?? "",
\t\t\tsessionTo,
\t\t\tpickedTo: picked?.origin?.to ?? "",
\t\t\tvia: sessionTo ? (cfg ? "store-scan+merge" : "session+merge") : (handleOrigin ? "handle+merge" : "infer+merge")
\t\t});
\t} catch (_) {}
\treturn { ...picked, sessionKey: transcriptSessionKey, transcriptSessionKey, aliasSessionKeys };
}`
}

/** @param {string} deliveryRuntimeBasename @param {string} sessionUtilsBasename */
export function buildExternalRecoverMediaDispatchBlock(deliveryRuntimeBasename, sessionUtilsBasename) {
  return `${EXTERNAL_RECOVER_DELIVERY_MARKER}
${EXTERNAL_RECOVER_DELIVERY_V2_MARKER}
${EXTERNAL_RECOVER_DELIVERY_V3_MARKER}
${buildMediaDeliveryOriginResolveBlock(sessionUtilsBasename)}
function clawbbaIsWeixinLikeChannel(channel) {
\tconst ch = String(channel || "").toLowerCase();
\treturn ch.includes("weixin") || ch === "wechat";
}
function clawbbaRecoverExternalSendGapMs(channel) {
\treturn clawbbaIsWeixinLikeChannel(channel) ? 4500 : 1500;
}
function clawbbaRecoverExternalRetryDelaysMs(channel) {
\treturn clawbbaIsWeixinLikeChannel(channel) ? [1e3, 3e3, 8e3, 15e3, 3e4] : [1e3, 3e3, 8e3];
}
async function clawbbaRecoverSendExternalWithRetry(sendMessage, payload, channel, mediaUrl) {
\tconst delays = clawbbaRecoverExternalRetryDelaysMs(channel);
\tlet lastErr = null;
\tfor (let attempt = 0; attempt <= delays.length; attempt++) {
\t\ttry {
\t\t\tawait sendMessage(payload);
\t\t\treturn { ok: true, attempt: attempt + 1 };
\t\t} catch (err) {
\t\t\tlastErr = err;
\t\t\tif (attempt >= delays.length) break;
\t\t\tconst waitMs = Number(delays[attempt] || 0);
\t\t\ttry {
\t\t\t\tlog$5.warn("clawbba recover external media send retry", { mediaUrl, channel, attempt: attempt + 1, waitMs, error: String(err?.message ?? err) });
\t\t\t} catch (_) {}
\t\t\tif (waitMs > 0) await new Promise((r) => setTimeout(r, waitMs));
\t\t}
\t}
\treturn { ok: false, attempt: delays.length + 1, error: String(lastErr?.message ?? lastErr) };
}
async function clawbbaDispatchRecoverMediaToExternalChannel(params) {
\tconst sessionKey = typeof params.sessionKey === "string" ? params.sessionKey.trim() : "";
\tconst mediaPaths = Array.isArray(params.mediaPaths) ? params.mediaPaths.filter((p) => typeof p === "string" && p.trim()) : [];
\tconst chatRunId = typeof params.chatRunId === "string" ? params.chatRunId.trim() : "";
\tif (!sessionKey || mediaPaths.length === 0) return false;
\tconst resolved = await clawbbaResolveMediaDeliveryContext({
\t\tsessionKey,
\t\trequesterOrigin: params.requesterOrigin,
\t\tcfg: params.cfg
\t});
\tif (!resolved) return false;
\tconst { origin, channel: ch, sessionKey: deliverSessionKey } = resolved;
\tconst agentId = resolveAgentIdFromSessionKey(deliverSessionKey);
\tconst gapMs = clawbbaRecoverExternalSendGapMs(ch);
\tconst caption = typeof params.caption === "string" ? params.caption.trim() : "";
\tlet delivered = 0;
\ttry {
\t\tconst { sendMessage } = await import("./${deliveryRuntimeBasename}");
\t\tfor (let i = 0; i < mediaPaths.length; i++) {
\t\t\tconst mediaUrl = mediaPaths[i].trim();
\t\t\tconst content = i === 0 && caption ? caption : "";
\t\t\ttry {
\t\t\t\tconst payload = {
\t\t\t\t\tcfg: params.cfg,
\t\t\t\t\tchannel: origin.channel,
\t\t\t\t\tto: origin.to,
\t\t\t\t\taccountId: origin.accountId,
\t\t\t\t\tthreadId: origin.threadId,
\t\t\t\t\tcontent,
\t\t\t\t\tmediaUrl,
\t\t\t\t\trequesterSessionKey: deliverSessionKey,
\t\t\t\t\tagentId,
\t\t\t\t\tbestEffort: true,
\t\t\t\t\tmirror: { sessionKey: deliverSessionKey, agentId }
\t\t\t\t};
\t\t\t\tconst sent = await clawbbaRecoverSendExternalWithRetry(sendMessage, payload, ch, mediaUrl);
\t\t\t\tif (!sent.ok) throw new Error(sent.error || "external send failed");
\t\t\t\tdelivered++;
\t\t\t} catch (err) {
\t\t\t\ttry {
\t\t\t\t\tlog$5.warn("clawbba recover external media send failed", { mediaUrl, channel: ch, error: String(err?.message ?? err) });
\t\t\t\t} catch (_) {}
\t\t\t}
\t\t\tif (i < mediaPaths.length - 1 && gapMs > 0) await new Promise((r) => setTimeout(r, gapMs));
\t\t}
\t} catch (err) {
\t\ttry {
\t\t\tlog$5.warn("clawbba recover external delivery failed", { error: String(err?.message ?? err) });
\t\t} catch (_) {}
\t\treturn false;
\t}
\tif (delivered > 0 && typeof clawbbaMarkReadOnlyToolTextReplyDispatched === "function") {
\t\tclawbbaMarkReadOnlyToolTextReplyDispatched(chatRunId);
\t}
\treturn delivered > 0;
}
async function clawbbaDispatchRecoverMediaDelivery(params) {
\tconst sessionKey = typeof params.sessionKey === "string" ? params.sessionKey.trim() : "";
\tconst mediaPaths = Array.isArray(params.mediaPaths) ? params.mediaPaths.filter((p) => typeof p === "string" && p.trim()) : [];
\tif (!sessionKey || mediaPaths.length === 0) return false;
\t${SESSION_TRANSCRIPT_MIRROR_MARKER}
\tconst deliveryCtx = await clawbbaResolveMediaDeliveryContext({
\t\tsessionKey,
\t\trequesterOrigin: params.requesterOrigin,
\t\tcfg: params.cfg
\t});
\tconst transcriptSessionKey = deliveryCtx?.transcriptSessionKey || sessionKey;
\tconst aliasSessionKeys = Array.isArray(deliveryCtx?.aliasSessionKeys) && deliveryCtx.aliasSessionKeys.length
\t\t? deliveryCtx.aliasSessionKeys
\t\t: clawbbaCollectMediaDeliverySessionKeys(sessionKey, transcriptSessionKey);
\tlet mirrored = false;
\tif (typeof clawbbaDispatchWebChatMediaLiveInject === "function") {
\t\tfor (const sk of aliasSessionKeys) {
\t\t\tconst ok = await clawbbaDispatchWebChatMediaLiveInject({
\t\t\t\tsessionKey: sk,
\t\t\t\tchatRunId: params.chatRunId,
\t\t\t\tmediaUrls: mediaPaths,
\t\t\t\tsourceTool: params.sourceTool,
\t\t\t\tcompletionLabel: params.completionLabel,
\t\t\t\tmessage: params.message,
\t\t\t\tlabel: params.label,
\t\t\t\tmirrorSessionTranscript: true
\t\t\t});
\t\t\tif (ok) mirrored = true;
\t\t}
\t}
\tlet external = false;
\tif (typeof clawbbaDispatchRecoverMediaToExternalChannel === "function") {
\t\texternal = await clawbbaDispatchRecoverMediaToExternalChannel({
\t\t\tcfg: params.cfg,
\t\t\tsessionKey,
\t\t\trequesterOrigin: params.requesterOrigin,
\t\t\tchatRunId: params.chatRunId,
\t\t\tmediaPaths,
\t\t\tcaption: params.caption,
\t\t\tlabel: params.label,
\t\t\tmediaKind: params.mediaKind
\t\t});
\t}
\tif (external) return "external";
\tif (!external && mirrored) {
\t\ttry {
\t\t\tconst delivery = inferDeliveryFromSessionKey(sessionKey);
\t\t\tconst origin = normalizeDeliveryContext(delivery);
\t\t\tconst ch = normalizeMessageChannel(origin?.channel ?? "");
\t\t\tif (clawbbaIsWeixinLikeChannel(ch)) {
\t\t\t\tconst hint = [
\t\t\t\t\t"微信通道媒体上传失败（微信 CDN 异常），但已在当前 WebChat 会话保留生成结果。",
\t\t\t\t\t"请在 WebChat 查看 MEDIA 条目；如需补发请使用 image_generate action=recover（同一 jobId，不重新生成）。"
\t\t\t\t].join("\\n");
\t\t\t\tlet hinted = false;
\t\t\t\tif (typeof clawbbaAppendAssistantTranscriptDirect === "function") {
\t\t\t\t\tconst direct = await clawbbaAppendAssistantTranscriptDirect({
\t\t\t\t\t\tsessionKey,
\t\t\t\t\t\tmessage: hint,
\t\t\t\t\t\tlabel: "ClawBBA delivery notice"
\t\t\t\t\t});
\t\t\t\t\thinted = !!direct?.ok;
\t\t\t\t\tif (hinted && typeof clawbbaBroadcastWebChatSessionReload === "function") {
\t\t\t\t\t\tawait clawbbaBroadcastWebChatSessionReload({
\t\t\t\t\t\t\tsessionKey,
\t\t\t\t\t\t\tchatRunId: params.chatRunId,
\t\t\t\t\t\t\tmediaMessage: hint,
\t\t\t\t\t\t\tinjectMessageId: direct?.messageId || ""
\t\t\t\t\t\t});
\t\t\t\t\t}
\t\t\t\t}
\t\t\t\tif (!hinted && typeof clawbbaDispatchReadOnlyToolTextReply === "function") {
\t\t\t\t\tawait clawbbaDispatchReadOnlyToolTextReply({
\t\t\t\t\t\tsessionKey,
\t\t\t\t\t\tchatRunId: params.chatRunId,
\t\t\t\t\t\tsourceTool: params.sourceTool || "image_generate",
\t\t\t\t\t\tlabel: "ClawBBA delivery notice",
\t\t\t\t\t\ttext: hint
\t\t\t\t\t});
\t\t\t\t}
\t\t\t}
\t\t} catch (_) {}
\t}
\tif (mirrored) return "webchat";
\treturn false;
}`
}

export function buildImageRecoverDeliveryTailBlock() {
  return `\t${IMAGE_RECOVER_EXTERNAL_DELIVERY_MARKER}
\t${IMAGE_RECOVER_DELIVERY_GUARD_MARKER}
\tlet deliveryMode = false;
\tif (agentSessionKey) {
\t\tif (typeof clawbbaDispatchRecoverMediaDelivery === "function") {
\t\t\tdeliveryMode = await clawbbaDispatchRecoverMediaDelivery({
\t\t\t\tcfg,
\t\t\t\tsessionKey: agentSessionKey,
\t\t\t\tchatRunId,
\t\t\t\tmediaPaths: savedImages.map((img) => img.path),
\t\t\t\tcaption: built.lines?.[0] || \`Recovered image job \${jobId}\`,
\t\t\t\tsourceTool: "image_generate",
\t\t\t\tcompletionLabel: "image",
\t\t\t\tmessage: built.lines.join("\\n"),
\t\t\t\tlabel: "ClawBBA image recover",
\t\t\t\tmediaKind: "image"
\t\t\t});
\t\t} else if (typeof clawbbaDispatchWebChatMediaLiveInject === "function") {
\t\t\tawait clawbbaDispatchWebChatMediaLiveInject({
\t\t\t\tsessionKey: agentSessionKey,
\t\t\t\tchatRunId,
\t\t\t\tmediaUrls: savedImages.map((img) => img.path),
\t\t\t\tsourceTool: "image_generate",
\t\t\t\tcompletionLabel: "image",
\t\t\t\tmessage: built.lines.join("\\n")
\t\t\t});
\t\t}
\t}
\tif (deliveryMode === "external") {
\t\tconst confirm = [
\t\t\t\`Recovered image job \${jobId} — delivered to your chat channel.\`,
\t\t\t"Reply with ONE short confirmation only; do NOT paste MEDIA: lines or call message tool (avoids duplicate WeChat CDN uploads)."
\t\t].join("\\n");
\t\treturn { content: [{ type: "text", text: confirm }], details: { ...built.details, deliveredExternal: true } };
\t}
\treturn { content: built.content, details: built.details };`
}

/** @param {string} src */
export function upgradeImageRecoverDeliveryGuard(src) {
  if (src.includes(IMAGE_RECOVER_DELIVERY_GUARD_MARKER)) return src
  if (!src.includes(IMAGE_RECOVER_EXTERNAL_DELIVERY_MARKER)) return src
  const unguardedRe =
    /\t\/\* clawbba-image-recover-external-delivery \*\/\n\tlet deliveryMode = false;\n\tif \(agentSessionKey\) \{\n\t\tdeliveryMode = await clawbbaDispatchRecoverMediaDelivery\(\{[\s\S]*?\t\}\);\n\t\}\n\tif \(deliveryMode === "external"\) \{[\s\S]*?\treturn \{ content: built\.content, details: built\.details \};/
  if (!unguardedRe.test(src)) return src
  return src.replace(unguardedRe, buildImageRecoverDeliveryTailBlock())
}

/** @param {string} dist @param {string} toolsSrc */
export function findDeliveryRuntimeBasename(dist, toolsSrc) {
  const fromTools = toolsSrc.match(/import\("\.\/(task-registry-delivery-runtime-[^"]+\.js)"\)/)
  if (fromTools) return fromTools[1]
  return fs.readdirSync(dist).find(
    (n) => n.startsWith('task-registry-delivery-runtime-') && n.endsWith('.js'),
  )
}

/** @param {string} src @param {string} fnName */
export function countFunctionDefinitions(src, fnName) {
  const escaped = fnName.replace(/\$/g, '\\$')
  const fnRe = new RegExp(`(?:async )?function ${escaped}\\s*\\(`, 'g')
  return (src.match(fnRe) || []).length
}

const RECOVER_HELPER_FN_NAMES = [
  'clawbbaDedupeImageBuffers',
  'clawbbaAssertPollJobIdMatches',
  'clawbbaPollClawbbaImageJob',
]

/** Remove duplicate recover helper fn bodies (keep first). Fixes partial-upgrade SyntaxError. */
export function stripDuplicateRecoverHelperDefinitions(src) {
  let out = src
  for (const fnName of RECOVER_HELPER_FN_NAMES) {
    if (countFunctionDefinitions(out, fnName) <= 1) continue
    let seen = 0
    const escaped = fnName.replace(/\$/g, '\\$')
    const paramPat = fnName === 'clawbbaDedupeImageBuffers' ? 'buffers' : '[^)]*'
    const re = new RegExp(`(?:async )?function ${escaped}\\(${paramPat}\\) \\{[\\s\\S]*?\\n\\}`, 'g')
    out = out.replace(re, (m) => {
      seen++
      return seen === 1 ? m : ''
    })
  }
  return out.replace(/\n{3,}/g, '\n\n')
}

/** @param {string} src @param {string} fnName */
export function imageRecoverRuntimeFnDefined(src, fnName) {
  return countFunctionDefinitions(src, fnName) > 0
}

/** @param {string} src */
export function stripRecoverImageCompressionSteps(src) {
  return src.replace(
    /\n\tif \(typeof clawbbaCompressLargeRecoveredImageBuffers === "function"\) \{\n\t\tbuffers = await clawbbaCompressLargeRecoveredImageBuffers\(buffers\);\n\t\} else if \(agentSessionKey && typeof clawbbaMaybeOptimizeImageBuffersForWeixin === "function"\) \{\n\t\ttry \{\n\t\t\tconst delivery = inferDeliveryFromSessionKey\(agentSessionKey\);\n\t\t\tconst origin = normalizeDeliveryContext\(delivery\);\n\t\t\tconst ch = normalizeMessageChannel\(origin\?\.channel ?? ""\);\n\t\t\tif \(clawbbaIsWeixinLikeChannel\(ch\)\) buffers = await clawbbaMaybeOptimizeImageBuffersForWeixin\(buffers\);\n\t\t\} catch \(_\) \{\}\n\t\}/,
    '',
  )
}

/** @param {string} dist @param {string} toolsSrc */
export function findSessionUtilsBasename(dist, toolsSrc) {
  const fromTools = toolsSrc.match(/import\("\.\/(session-utils-[^"]+\.js)"\)/)
  if (fromTools) return fromTools[1]
  return fs.readdirSync(dist).find((n) => n.startsWith('session-utils-') && n.endsWith('.js'))
}

/** @param {string} src @param {string} sessionUtilsBasename */
export function upgradeMediaDeliveryOriginResolveV3(src, sessionUtilsBasename) {
  if (!sessionUtilsBasename) return src
  if (!src.includes(MEDIA_DELIVERY_ORIGIN_RESOLVE_V2_MARKER)) return src
  if (src.includes(MEDIA_DELIVERY_ORIGIN_RESOLVE_V3_MARKER)) return src
  const block = buildMediaDeliveryOriginResolveBlock(sessionUtilsBasename)
  return src.replace(
    /\/\* clawbba-media-delivery-origin-resolve-v1 \*\/[\s\S]*?(?=function clawbbaIsWeixinLikeChannel\(channel\))/,
    `${block}\n`,
  )
}

/** @param {string} src @param {string} sessionUtilsBasename */
export function upgradeMediaDeliveryOriginResolveV2(src, sessionUtilsBasename) {
  if (!sessionUtilsBasename) return src
  if (!src.includes(MEDIA_DELIVERY_ORIGIN_RESOLVE_V1_MARKER)) return src
  if (src.includes(MEDIA_DELIVERY_ORIGIN_RESOLVE_V2_MARKER)) return src
  const block = buildMediaDeliveryOriginResolveBlock(sessionUtilsBasename)
  return src.replace(
    /\/\* clawbba-media-delivery-origin-resolve-v1 \*\/[\s\S]*?(?=function clawbbaIsWeixinLikeChannel\(channel\))/,
    `${block}\n`,
  )
}

/** @param {string} src @param {string} deliveryRuntimeBasename @param {string} sessionUtilsBasename */
export function upgradeMediaDeliveryOriginResolve(src, deliveryRuntimeBasename, sessionUtilsBasename) {
  if (!sessionUtilsBasename) return src
  let next = upgradeMediaDeliveryOriginResolveV2(src, sessionUtilsBasename)
  if (next.includes(MEDIA_DELIVERY_ORIGIN_RESOLVE_V2_MARKER)) return next
  if (!next.includes(MEDIA_DELIVERY_ORIGIN_RESOLVE_V1_MARKER)) return next
  if (!next.includes(EXTERNAL_RECOVER_DELIVERY_MARKER)) return next
  const block = buildExternalRecoverMediaDispatchBlock(deliveryRuntimeBasename, sessionUtilsBasename)
  if (next.includes(EXTERNAL_RECOVER_DELIVERY_V3_MARKER)) {
    return next.replace(
      /\/\* clawbba-external-recover-delivery \*\/[\s\S]*?(?=async function clawbbaDispatchWebChatMediaLiveInject\(params\) \{)/,
      `${block}\n`,
    )
  }
  return next
}

/** @param {string} toolsPath @param {string} deliveryRuntimeBasename @param {string} [distDir] */
export function ensureExternalRecoverMediaDispatchInTools(toolsPath, deliveryRuntimeBasename, distDir) {
  let src = fs.readFileSync(toolsPath, 'utf8')
  const sessionUtils =
    distDir && findSessionUtilsBasename(distDir, src)
      ? findSessionUtilsBasename(distDir, src)
      : null
  if (src.includes(EXTERNAL_RECOVER_DELIVERY_V3_MARKER)) {
    let next = stripRecoverImageCompressionSteps(src)
    next = upgradeMediaDeliveryOriginResolveV3(next, sessionUtils)
    next = upgradeMediaDeliveryOriginResolveV2(next, sessionUtils)
    next = upgradeMediaDeliveryOriginResolve(next, deliveryRuntimeBasename, sessionUtils)
    const mirrored = upgradeSessionTranscriptMirrorDispatch(next)
    if (mirrored !== next) {
      fs.writeFileSync(toolsPath, mirrored)
      next = mirrored
    } else if (next !== src) {
      fs.writeFileSync(toolsPath, next)
    }
    return next
  }
  const block = buildExternalRecoverMediaDispatchBlock(deliveryRuntimeBasename, sessionUtils || 'session-utils.js')
  if (src.includes(EXTERNAL_RECOVER_DELIVERY_MARKER)) {
    src = src.replace(
      /\/\* clawbba-external-recover-delivery \*\/[\s\S]*?(?=async function clawbbaDispatchWebChatMediaLiveInject\(params\) \{)/,
      `${block}\n`,
    )
  } else {
    const anchors = [
      'async function clawbbaDispatchWebChatMediaLiveInject(params) {',
      'async function clawbbaDispatchReadOnlyToolTextReply(params) {',
      'async function clawbbaRecoverVideoTask({',
      'function createImageGenerateTool(options) {',
    ]
    const anchor = anchors.find((a) => src.includes(a))
    if (!anchor) return src
    src = src.replace(anchor, `${block}\n${anchor}`)
  }
  src = stripRecoverImageCompressionSteps(src)
  fs.writeFileSync(toolsPath, src)
  return src
}

/** @param {string} toolsPath @param {string} distDir */
export function ensureImageRecoverDeliveryInTools(toolsPath, distDir) {
  let src = fs.readFileSync(toolsPath, 'utf8')
  src = upgradeImageRecoverDeliveryGuard(src)
  if (
    !imageRecoverRuntimeFnDefined(src, 'clawbbaDispatchRecoverMediaDelivery') &&
    src.includes('async function clawbbaRecoverImageTask')
  ) {
    const deliveryRuntime = findDeliveryRuntimeBasename(distDir, src)
    if (deliveryRuntime) {
      ensureExternalRecoverMediaDispatchInTools(toolsPath, deliveryRuntime, distDir)
      src = fs.readFileSync(toolsPath, 'utf8')
      src = upgradeImageRecoverDeliveryGuard(src)
    }
  }
  const onDisk = fs.readFileSync(toolsPath, 'utf8')
  if (src !== onDisk) fs.writeFileSync(toolsPath, src)
  return src
}

/** @param {string} src */
export function upgradeSessionTranscriptMirrorDispatch(src) {
  if (!src.includes('async function clawbbaDispatchRecoverMediaDelivery(params)')) return src
  if (src.includes(MEDIA_DELIVERY_ORIGIN_RESOLVE_V1_MARKER)) return src
  if (src.includes(SESSION_TRANSCRIPT_MIRROR_MARKER)) return src
  const oldRe =
    /async function clawbbaDispatchRecoverMediaDelivery\(params\) \{\n\tconst sessionKey[\s\S]*?\tif \(typeof clawbbaDispatchRecoverMediaToExternalChannel === "function"\) \{\n\t\tconst external = await clawbbaDispatchRecoverMediaToExternalChannel\(\{[\s\S]*?\}\);\n\t\tif \(external\) return "external";\n\t\}\n\tif \(typeof clawbbaDispatchWebChatMediaLiveInject === "function"\) \{\n\t\tconst injected = await clawbbaDispatchWebChatMediaLiveInject\(\{[\s\S]*?\}\);\n\t\tif \(injected\) return "webchat";\n\t\}\n\treturn false;\n\}/
  if (!oldRe.test(src)) return src
  const replacement = `async function clawbbaDispatchRecoverMediaDelivery(params) {
\tconst sessionKey = typeof params.sessionKey === "string" ? params.sessionKey.trim() : "";
\tconst mediaPaths = Array.isArray(params.mediaPaths) ? params.mediaPaths.filter((p) => typeof p === "string" && p.trim()) : [];
\tif (!sessionKey || mediaPaths.length === 0) return false;
\t${SESSION_TRANSCRIPT_MIRROR_MARKER}
\tlet mirrored = false;
\tif (typeof clawbbaDispatchWebChatMediaLiveInject === "function") {
\t\tmirrored = await clawbbaDispatchWebChatMediaLiveInject({
\t\t\tsessionKey,
\t\t\tchatRunId: params.chatRunId,
\t\t\tmediaUrls: mediaPaths,
\t\t\tsourceTool: params.sourceTool,
\t\t\tcompletionLabel: params.completionLabel,
\t\t\tmessage: params.message,
\t\t\tlabel: params.label,
\t\t\tmirrorSessionTranscript: true
\t\t});
\t}
\tlet external = false;
\tif (typeof clawbbaDispatchRecoverMediaToExternalChannel === "function") {
\t\texternal = await clawbbaDispatchRecoverMediaToExternalChannel({
\t\t\tcfg: params.cfg,
\t\t\tsessionKey,
\t\t\tchatRunId: params.chatRunId,
\t\t\tmediaPaths,
\t\t\tcaption: params.caption,
\t\t\tlabel: params.label,
\t\t\tmediaKind: params.mediaKind
\t\t});
\t}
\tif (external) return "external";
\tif (mirrored) return "webchat";
\treturn false;
}`
  return src.replace(oldRe, replacement)
}

/**
 * @param {string} dist
 * @param {(dist: string, prefix: string, exportName?: string) => string | undefined} findDistFile
 */
export function patchExternalRecoverMediaDelivery(dist, findDistFile) {
  const toolsFile = findDistFile(dist, 'openclaw-tools-')
  if (!toolsFile) return 'missing-tools'
  const toolsPath = path.join(dist, toolsFile)
  const toolsSrc = fs.readFileSync(toolsPath, 'utf8')
  const deliveryRuntime = findDeliveryRuntimeBasename(dist, toolsSrc)
  if (!deliveryRuntime) return 'missing-deps'
  const before = toolsSrc
  ensureExternalRecoverMediaDispatchInTools(toolsPath, deliveryRuntime, dist)
  ensureImageRecoverDeliveryInTools(toolsPath, dist)
  let after = fs.readFileSync(toolsPath, 'utf8')
  const mirrored = upgradeSessionTranscriptMirrorDispatch(after)
  if (mirrored !== after) {
    fs.writeFileSync(toolsPath, mirrored)
    after = mirrored
  }
  if (!after.includes(EXTERNAL_RECOVER_DELIVERY_V3_MARKER)) return 'pattern-missing'
  if (!after.includes(MEDIA_DELIVERY_ORIGIN_RESOLVE_V1_MARKER)) return 'origin-resolve-missing'
  if (!after.includes(MEDIA_DELIVERY_ORIGIN_RESOLVE_V2_MARKER)) return 'origin-resolve-v2-missing'
  if (!after.includes(MEDIA_DELIVERY_ORIGIN_RESOLVE_V3_MARKER)) return 'origin-resolve-v3-missing'
  if (!after.includes(SESSION_TRANSCRIPT_MIRROR_MARKER)) return 'mirror-missing'
  if (after === before) return 'skip'
  if (before.includes(SESSION_TRANSCRIPT_MIRROR_MARKER)) return 'skip'
  if (before.includes(EXTERNAL_RECOVER_DELIVERY_V2_MARKER)) return 'upgraded-v3-no-compress'
  if (before.includes(EXTERNAL_RECOVER_DELIVERY_MARKER)) return 'upgraded-v3-no-compress'
  if (before.includes(EXTERNAL_RECOVER_DELIVERY_V3_MARKER)) return 'upgraded-session-mirror'
  return 'patched'
}

/** @param {string} src */
export function imageRecoverHasExternalDelivery(src) {
  return src.includes(IMAGE_RECOVER_EXTERNAL_DELIVERY_MARKER)
}

/** @param {string} src */
export function upgradeImageRecoverExternalDelivery(src) {
  if (imageRecoverHasExternalDelivery(src)) return upgradeImageRecoverDeliveryGuard(src)
  const oldBlock =
    /\tconst \{ pollBody, buffers \} = await clawbbaPollClawbbaImageJob\(\{ baseUrl, hdrs, jobId, maxWaitMs \}\);\n\tconst savedImages = await clawbbaSaveRecoveredImageBuffers\(\{ cfg, buffers, filename \}\);\n\tconst built = clawbbaBuildRecoveredImageToolResult\(\{ jobId, pollBody, savedImages \}\);\n\tif \(agentSessionKey\) \{\n\t\tawait clawbbaDispatchWebChatMediaLiveInject\(\{[\s\S]*?\t\}\);\n\t\}\n\treturn \{ content: built\.content, details: built\.details \};/
  if (!oldBlock.test(src)) return src
  const replacement = `\tconst { pollBody, buffers: rawBuffers } = await clawbbaPollClawbbaImageJob({ baseUrl, hdrs, jobId, maxWaitMs });
\tclawbbaAssertPollJobIdMatches(jobId, pollBody);
\tconst buffers = clawbbaDedupeImageBuffers(rawBuffers);
\tconst savedImages = await clawbbaSaveRecoveredImageBuffers({ cfg, buffers, filename });
\tconst built = clawbbaBuildRecoveredImageToolResult({ jobId, pollBody, savedImages });
${buildImageRecoverDeliveryTailBlock()}`
  return src.replace(oldBlock, replacement)
}

/** @param {string} src */
export function upgradeVideoRecoverExternalDelivery(src) {
  if (src.includes(VIDEO_RECOVER_EXTERNAL_DELIVERY_MARKER)) return src
  const oldBlock =
    /\tconst built = clawbbaBuildRecoveredVideoToolResult\(\{ jobId, statusPayload, saved \}\);[\s\S]*?return \{\n\t\tcontent: built\.content,\n\t\tdetails: built\.details,\n\t\};/
  if (!oldBlock.test(src)) return src
  const replacement = `\tconst built = clawbbaBuildRecoveredVideoToolResult({ jobId, statusPayload, saved });
\t${VIDEO_RECOVER_EXTERNAL_DELIVERY_MARKER}
\tlet deliveryMode = false;
\tif (agentSessionKey) {
\t\tif (typeof clawbbaDispatchRecoverMediaDelivery === "function") {
\t\t\tdeliveryMode = await clawbbaDispatchRecoverMediaDelivery({
\t\t\t\tcfg,
\t\t\t\tsessionKey: agentSessionKey,
\t\t\t\tchatRunId,
\t\t\t\tmediaPaths: [saved.path],
\t\t\t\tcaption: built.lines?.[0] || \`Recovered video job \${jobId}\`,
\t\t\t\tsourceTool: "video_generate",
\t\t\t\tcompletionLabel: "video",
\t\t\t\tmessage: built.lines.join("\\n"),
\t\t\t\tlabel: "ClawBBA video recover",
\t\t\t\tmediaKind: "video"
\t\t\t});
\t\t} else if (typeof clawbbaDispatchWebChatMediaLiveInject === "function") {
\t\t\tawait clawbbaDispatchWebChatMediaLiveInject({
\t\t\t\tsessionKey: agentSessionKey,
\t\t\t\tchatRunId,
\t\t\t\tmediaUrls: [saved.path],
\t\t\t\tsourceTool: "video_generate",
\t\t\t\tcompletionLabel: "video",
\t\t\t\tmessage: built.lines.join("\\n")
\t\t\t});
\t\t}
\t}
\tif (deliveryMode === "external") {
\t\tconst confirm = [
\t\t\t\`Recovered video job \${jobId} — delivered to your chat channel.\`,
\t\t\t"Reply with ONE short confirmation only; do NOT paste MEDIA: lines or call message tool."
\t\t].join("\\n");
\t\treturn { content: [{ type: "text", text: confirm }], details: { ...built.details, deliveredExternal: true } };
\t}
\treturn {
\t\tcontent: built.content,
\t\tdetails: built.details,
\t};`
  return src.replace(oldBlock, replacement)
}
