#!/usr/bin/env node
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { execSync } from 'node:child_process'
import { patchImageGenerateRecoverAction } from './clawbba-image-recover-patch.mjs'
import { patchVideoGenerateRecoverAction } from './clawbba-video-recover-patch.mjs'
import { patchWebChatLiveInjectHelperInToolsFile } from './clawbba-webchat-live-inject.mjs'
import { patchReadOnlyToolTextReplyDist } from './clawbba-readonly-tool-reply-patch.mjs'
import { patchExternalRecoverMediaDelivery } from './clawbba-external-recover-delivery.mjs'

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'clawbba-ext-recover-'))
execSync('npm pack openclaw@2026.5.27 --silent', { cwd: tmp, stdio: 'pipe' })
const tgz = fs.readdirSync(tmp).find((n) => n.endsWith('.tgz'))
execSync(`tar -xzf ${JSON.stringify(tgz)}`, { cwd: tmp })

const dist = path.join(tmp, 'package', 'dist')
const findDist = (d, prefix) => fs.readdirSync(d).find((n) => n.startsWith(prefix) && n.endsWith('.js'))
const toolsFile = findDist(dist, 'openclaw-tools-')
const pluginsFile = findDist(dist, 'server-plugins-')
const gatewayFile = findDist(dist, 'gateway-request-scope-')
const globalSingletonFile = findDist(dist, 'global-singleton-')
const toolsPath = path.join(dist, toolsFile)

assert.equal(patchWebChatLiveInjectHelperInToolsFile(toolsPath, pluginsFile, globalSingletonFile, gatewayFile), 'patched')
assert.equal(patchImageGenerateRecoverAction(toolsPath), 'patched')
assert.equal(patchVideoGenerateRecoverAction(toolsPath), 'patched')
const readonly = patchReadOnlyToolTextReplyDist(dist, findDist)
assert.equal(readonly.tools, 'patched')
const ext = patchExternalRecoverMediaDelivery(dist, findDist)
assert.ok(['patched', 'upgraded-v3-no-compress'].includes(ext), ext)

const src = fs.readFileSync(toolsPath, 'utf8')
assert.ok(src.includes('clawbbaDispatchRecoverMediaDelivery'))
assert.ok(src.includes('clawbba-image-recover-external-delivery'))
assert.ok(src.includes('clawbba-video-recover-external-delivery'))
assert.ok(src.includes('clawbba-external-recover-delivery-v3-no-compress'))
assert.ok(src.includes('clawbba-media-delivery-origin-resolve-v1'))
assert.ok(src.includes('clawbbaResolveMediaDeliveryContext'))
assert.ok(!src.includes('clawbbaCompressLargeRecoveredImageBuffers'))
assert.ok(!src.includes('clawbbaMaybeOptimizeImageBuffersForWeixin'))

assert.equal(patchExternalRecoverMediaDelivery(dist, findDist), 'skip')
assert.equal(patchImageGenerateRecoverAction(toolsPath), 'skip')

console.log('test-external-recover-delivery: ok')
