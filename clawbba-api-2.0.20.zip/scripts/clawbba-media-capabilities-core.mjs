/**
 * ClawBBA v2 — 生图/生视频能力声明（安装与官网 API 共用）
 * @see references/media-capabilities.json
 */
import {
  DEFAULT_IMAGE_MODEL_ID,
  DEFAULT_VIDEO_MODEL_ID,
  IMAGE_MODEL_SPECS,
  PATCH_IMAGE_MODEL_PREFER,
  PATCH_VIDEO_MODEL_PREFER,
  VIDEO_MODEL_SPECS,
} from './clawbba-openclaw-media-catalog.mjs'
import {
  OPENCLAW_IMAGE_ASPECT_RATIOS,
  OPENCLAW_IMAGE_RESOLUTIONS,
} from './clawbba-media-params-enums.mjs'
import {
  mergeVideoOptions,
  OPENCLAW_VIDEO_ASPECT_RATIOS,
  OPENCLAW_VIDEO_RESOLUTIONS,
  resolveStaticVideoOptions,
} from './clawbba-video-generation-specs.mjs'

export const MEDIA_CAPABILITIES_VERSION = '2.1'

/** 写入 media-capabilities.json，供 Agent 读取 */
export const MEDIA_AGENT_GUIDANCE = {
  prompt_fidelity:
    'image_generate.prompt / video_generate.prompt 必须包含用户在本轮对话中声明的生成意图（产品、主体、风格、场景、相对参考图的修改）。允许翻译为英文或补充光影，但禁止用与用户需求无关的通用套话替代；图生图时参考图不能替代用户文字要求。model、aspectRatio、resolution、durationSeconds 写入工具字段，不要只写在 prompt 里。',
  video_param_assembly:
    '生视频：先与用户确认模型、工作流（文生/图生首帧尾帧/参考图）、时长、比例、分辨率、是否带音频（若该模型支持）。全部选完后，读取该模型 models.<id>.generation_params，将用户选择映射为 video_generate 工具字段并一次性调用；字段值必须在 generation_params.parameters.*.allowed 内；用户未指定的可选项用 default，用户说了「随便/默认」时用 default，否则追问缺失项。',
  video_workflow_pick:
    '无参考图 → text_to_video；首帧 → image_to_video_first_frame（image + imageRoles:[first_frame]）；尾帧 → image_to_video_last_frame；风格/主体参考 → image_to_video_reference（images + imageRoles:[reference_image]）。仅当 supported_frame_types 含对应 role 时才提供该工作流。',
}

export const MEDIA_WORKFLOWS = {
  text_to_image: {
    tool: 'image_generate',
    label: '文生图',
    required: ['prompt'],
    optional: ['model', 'aspectRatio', 'resolution', 'quality', 'outputFormat'],
    openclaw_notes: 'model 省略时用 agents.defaults.imageGenerationModel.primary（openrouter/<id>）',
  },
  image_to_image: {
    tool: 'image_generate',
    label: '图生图',
    required: ['prompt', 'images'],
    optional: ['model', 'aspectRatio', 'resolution'],
    openclaw_notes: '参考图用 image 或 images[]（~/.openclaw/media/inbound/… 本地路径）',
  },
  text_to_video: {
    tool: 'video_generate',
    label: '文生视频',
    required: ['prompt', 'durationSeconds'],
    optional: ['model', 'aspectRatio', 'resolution'],
    openclaw_notes: 'durationSeconds 须为模型支持的秒数',
  },
  image_to_video_first_frame: {
    tool: 'video_generate',
    label: '图生视频（首帧）',
    required: ['prompt', 'durationSeconds', 'image', 'imageRoles'],
    imageRoles: ['first_frame'],
    optional: ['model', 'aspectRatio', 'resolution'],
  },
  image_to_video_last_frame: {
    tool: 'video_generate',
    label: '图生视频（尾帧）',
    required: ['prompt', 'durationSeconds', 'image', 'imageRoles'],
    imageRoles: ['last_frame'],
    optional: ['model', 'aspectRatio', 'resolution'],
  },
  image_to_video_reference: {
    tool: 'video_generate',
    label: '图生视频（参考图）',
    required: ['prompt', 'durationSeconds', 'images', 'imageRoles'],
    imageRoles: ['reference_image'],
    optional: ['model', 'aspectRatio', 'resolution'],
  },
}

export const OPENCLAW_TOOL_SCHEMA = {
  image_generate: {
    aspectRatio: OPENCLAW_IMAGE_ASPECT_RATIOS,
    resolution: OPENCLAW_IMAGE_RESOLUTIONS,
    params: [
      'action',
      'prompt',
      'model',
      'aspectRatio',
      'resolution',
      'image',
      'images',
      'quality',
      'outputFormat',
      'jobId',
    ],
  },
  video_generate: {
    aspectRatio: OPENCLAW_VIDEO_ASPECT_RATIOS,
    resolution: OPENCLAW_VIDEO_RESOLUTIONS,
    imageRoles: ['first_frame', 'last_frame', 'reference_image'],
    params: [
      'action',
      'prompt',
      'model',
      'aspectRatio',
      'resolution',
      'durationSeconds',
      'audio',
      'image',
      'images',
      'imageRoles',
      'jobId',
    ],
  },
}

function normResList(list) {
  if (!Array.isArray(list)) return undefined
  const out = list.map((r) => String(r).trim().toUpperCase()).filter(Boolean)
  return out.length ? [...new Set(out)] : undefined
}

/**
 * 为单个视频模型生成 Agent 可读的 generation_params（拼装 video_generate 用）
 * @param {Record<string, unknown>} entry compactModelEntry 结果
 */
export function buildVideoGenerationParams(entry) {
  const id = String(entry.id || '').trim()
  const modelRef = String(entry.openclaw_ref || `openrouter/${id}`).trim()
  const durations = Array.isArray(entry.duration_presets) ? entry.duration_presets : [5, 8]
  const aspects = Array.isArray(entry.aspect_ratios) ? entry.aspect_ratios : ['16:9', '9:16']
  const resolutions = normResList(entry.resolutions) || ['720P', '1080P']
  const frameTypes = Array.isArray(entry.supported_frame_types)
    ? entry.supported_frame_types
    : ['first_frame', 'last_frame']
  const defaultDuration = entry.default_duration ?? durations[0] ?? 5
  const defaultAspect = entry.default_aspect_ratio ?? aspects[0] ?? '16:9'
  const defaultResolution = entry.default_resolution ?? resolutions[0] ?? '720P'
  const showAudio = entry.show_audio_toggle === true

  const parameters = {
    model: {
      tool_field: 'model',
      required: true,
      value: modelRef,
      description: '固定为本模型；用户指定其它模型时换读对应 models.<id>.generation_params',
    },
    prompt: {
      tool_field: 'prompt',
      required: true,
      type: 'string',
      description: '画面描述，须保留用户在本轮对话中的生成意图',
    },
    durationSeconds: {
      tool_field: 'durationSeconds',
      required: true,
      type: 'integer',
      allowed: durations,
      default: defaultDuration,
      user_phrases: ['N秒', 'N 秒', 'duration N'],
    },
    aspectRatio: {
      tool_field: 'aspectRatio',
      required: false,
      type: 'string',
      allowed: aspects,
      default: defaultAspect,
      user_phrases: ['16:9', '9:16', '横图', '竖图', '方图'],
    },
    resolution: {
      tool_field: 'resolution',
      required: false,
      type: 'string',
      allowed: resolutions,
      default: defaultResolution,
      user_phrases: ['480p', '720p', '1080p', '4K'],
    },
  }

  if (showAudio) {
    parameters.audio = {
      tool_field: 'audio',
      required: false,
      type: 'boolean',
      allowed: [true, false],
      default: entry.default_generate_audio !== false,
      user_phrases: ['带音频', '不要音频', '静音'],
      maps_to_api: 'generate_audio',
    }
  }

  if (entry.supports_image_to_video) {
    parameters.image = {
      tool_field: 'image',
      required: false,
      type: 'string',
      description: '单张参考图本地路径（~/.openclaw/media/inbound/…）；首帧/尾帧工作流用',
    }
    parameters.images = {
      tool_field: 'images',
      required: false,
      type: 'array',
      description: '多张参考图；reference_image 工作流用',
    }
    parameters.imageRoles = {
      tool_field: 'imageRoles',
      required: false,
      type: 'array',
      allowed: frameTypes,
      description: '与 image/images 配合；first_frame | last_frame | reference_image',
    }
  }

  const workflows = {
    text_to_video: {
      label: '文生视频',
      required_parameters: ['model', 'prompt', 'durationSeconds'],
      optional_parameters: ['aspectRatio', 'resolution', ...(showAudio ? ['audio'] : [])],
    },
  }

  if (entry.supports_image_to_video && frameTypes.includes('first_frame')) {
    workflows.image_to_video_first_frame = {
      label: '图生视频（首帧）',
      required_parameters: ['model', 'prompt', 'durationSeconds', 'image', 'imageRoles'],
      imageRoles_value: ['first_frame'],
      optional_parameters: ['aspectRatio', 'resolution', ...(showAudio ? ['audio'] : [])],
    }
  }
  if (entry.supports_image_to_video && frameTypes.includes('last_frame')) {
    workflows.image_to_video_last_frame = {
      label: '图生视频（尾帧）',
      required_parameters: ['model', 'prompt', 'durationSeconds', 'image', 'imageRoles'],
      imageRoles_value: ['last_frame'],
      optional_parameters: ['aspectRatio', 'resolution', ...(showAudio ? ['audio'] : [])],
    }
  }
  if (entry.supports_image_to_video && frameTypes.includes('reference_image')) {
    workflows.image_to_video_reference = {
      label: '图生视频（参考图）',
      required_parameters: ['model', 'prompt', 'durationSeconds', 'images', 'imageRoles'],
      imageRoles_value: ['reference_image'],
      optional_parameters: ['aspectRatio', 'resolution', ...(showAudio ? ['audio'] : [])],
    }
  }

  const example = {
    model: modelRef,
    prompt: '用户确认的画面描述（保留原意）',
    durationSeconds: defaultDuration,
    aspectRatio: defaultAspect,
  }
  if (resolutions.length) example.resolution = defaultResolution
  if (showAudio) example.audio = entry.default_generate_audio !== false

  return {
    tool: 'video_generate',
    model_id: id,
    model: modelRef,
    workflows,
    parameters,
    assembly:
      '用户选完模型与本表 workflows 后，将每项用户选择映射到 parameters 中同名 tool_field；allowed 外的值须改选或告知用户不支持；然后一次性调用 video_generate。',
    example_call: example,
  }
}

function normCategory(m) {
  return String(m?.category || '').toLowerCase()
}

function pickDefaultId(rows, preferList, category) {
  const ids = new Set(rows.map((r) => String(r.id || '').trim()).filter(Boolean))
  for (const p of preferList) {
    if (ids.has(p)) return p
  }
  const hit = rows.find((m) => normCategory(m) === category)
  return hit?.id ? String(hit.id).trim() : null
}

function applyVideoOptionsToEntry(entry, vo) {
  if (!vo || typeof vo !== 'object') return
  entry.aspect_ratios = vo.aspect_ratios ?? entry.aspect_ratios
  entry.resolutions = normResList(vo.resolutions ?? vo.resolutions_text ?? vo.resolutions_image)
  entry.duration_presets = vo.duration_presets
  entry.default_duration = vo.default_duration
  entry.default_aspect_ratio = vo.default_aspect_ratio
  entry.default_resolution = vo.default_resolution
  entry.duration_min = vo.duration_min
  entry.duration_max = vo.duration_max
  entry.supports_image_to_video = vo.supports_image_to_video
  entry.supported_frame_types = vo.supported_frame_types
  entry.show_audio_toggle = vo.show_audio_toggle
  entry.default_generate_audio = vo.default_generate_audio
  entry.supports_seed = vo.supports_seed
}

function compactModelEntry(m, { staticVideoSpec } = {}) {
  const id = String(m.id || '').trim()
  const cat = normCategory(m)
  const entry = {
    id,
    name: String(m.name || id).trim() || id,
    category: cat,
    openclaw_ref: `openrouter/${id}`,
  }
  const io = m.image_options
  const apiVo = m.video_options
  if (io && typeof io === 'object') {
    entry.aspect_ratios = io.aspect_ratios
    entry.image_sizes = io.image_sizes
    entry.default_aspect_ratio = io.default_aspect_ratio
    entry.default_image_size = io.default_image_size
    entry.supports_reference_images =
      io.supports_image_input === true || Number(io.max_reference_images) > 0
    entry.max_reference_images = io.max_reference_images
  }
  if (cat === 'video') {
    const staticVo = resolveStaticVideoOptions(id, staticVideoSpec)
    const mergedVo = mergeVideoOptions(apiVo, staticVo)
    applyVideoOptionsToEntry(entry, mergedVo)
    entry.generation_params = buildVideoGenerationParams(entry)
  }
  return entry
}

/**
 * @param {Array<Record<string, unknown>>} rows catalog rows from GET /api/v1/models
 */
export function buildMediaCapabilitiesFromCatalogRows(rows) {
  const list = Array.isArray(rows) ? rows : []
  const imageDefault = pickDefaultId(list, PATCH_IMAGE_MODEL_PREFER, 'image') || DEFAULT_IMAGE_MODEL_ID
  const videoDefault = pickDefaultId(list, PATCH_VIDEO_MODEL_PREFER, 'video') || DEFAULT_VIDEO_MODEL_ID
  const models = {}
  for (const m of list) {
    const cat = normCategory(m)
    if (cat !== 'image' && cat !== 'video') continue
    const id = String(m.id || '').trim()
    if (!id) continue
    models[id] = compactModelEntry(m, {
      staticVideoSpec: VIDEO_MODEL_SPECS.find((s) => s.id === id),
    })
  }
  return {
    version: MEDIA_CAPABILITIES_VERSION,
    generated_at: new Date().toISOString(),
    agent_guidance: MEDIA_AGENT_GUIDANCE,
    defaults: {
      image: imageDefault,
      image_openclaw: `openrouter/${imageDefault}`,
      video: videoDefault,
      video_openclaw: `openrouter/${videoDefault}`,
    },
    workflows: MEDIA_WORKFLOWS,
    openclaw_tool_schema: OPENCLAW_TOOL_SCHEMA,
    models,
  }
}

export function renderMediaCapabilitiesMarkdown(cap) {
  const lines = [
    '# ClawBBA 媒体生成能力表（v2）',
    '',
    '对话模型根据本表收集参数，直接调用 OpenClaw `image_generate` / `video_generate`。**无需固定中文话术。**',
    '',
    '**Prompt 原意：** `prompt` 必须承载用户在本轮对话中的生成意图，禁止用大模型自编与用户无关的通用英文描述替代。',
    '',
    `默认生图：\`${cap.defaults.image}\` → tool \`${cap.defaults.image_openclaw}\``,
    `默认生视频：\`${cap.defaults.video}\` → tool \`${cap.defaults.video_openclaw}\``,
    '',
    '## 工作流',
    '',
  ]
  for (const [key, wf] of Object.entries(cap.workflows || {})) {
    lines.push(`### ${wf.label} (\`${key}\`)`)
    lines.push(`- 工具：\`${wf.tool}\``)
    lines.push(`- 必填：${(wf.required || []).map((x) => `\`${x}\``).join(', ')}`)
    if (wf.optional?.length) lines.push(`- 可选：${wf.optional.map((x) => `\`${x}\``).join(', ')}`)
    if (wf.imageRoles?.length) lines.push(`- imageRoles：${wf.imageRoles.map((x) => `\`${x}\``).join(', ')}`)
    if (wf.openclaw_notes) lines.push(`- ${wf.openclaw_notes}`)
    lines.push('')
  }
  lines.push('## 生图模型')
  lines.push('')
  for (const [id, m] of Object.entries(cap.models || {})) {
    if (m.category !== 'image') continue
    lines.push(`- **${m.name}** (\`${id}\`) — tool \`${m.openclaw_ref}\``)
    if (m.aspect_ratios?.length) lines.push(`  - 比例：${m.aspect_ratios.join(', ')}`)
    if (m.image_sizes?.length) lines.push(`  - 分辨率：${m.image_sizes.join(', ')}`)
    if (m.supports_reference_images) lines.push('  - 支持参考图（图生图）')
  }
  lines.push('')
  lines.push('## 生视频模型')
  lines.push('')
  for (const [id, m] of Object.entries(cap.models || {})) {
    if (m.category !== 'video') continue
    lines.push(`- **${m.name}** (\`${id}\`) — tool \`${m.openclaw_ref}\``)
    if (m.duration_presets?.length) {
      const def = m.default_duration != null ? `，默认 ${m.default_duration}s` : ''
      lines.push(`  - 时长：${m.duration_presets.join(', ')} 秒${def}`)
    }
    if (m.aspect_ratios?.length) {
      const def = m.default_aspect_ratio ? `，默认 ${m.default_aspect_ratio}` : ''
      lines.push(`  - 比例：${m.aspect_ratios.join(', ')}${def}`)
    }
    if (m.resolutions?.length) {
      const def = m.default_resolution ? `，默认 ${m.default_resolution}` : ''
      lines.push(`  - 分辨率：${m.resolutions.join(', ')}${def}`)
    }
    if (m.show_audio_toggle) lines.push('  - 音频：可选带音频/静音（tool 字段 `audio`）')
    if (m.supported_frame_types?.length) {
      lines.push(`  - 图生视频 imageRoles：${m.supported_frame_types.join(', ')}`)
    }
    if (m.generation_params?.workflows) {
      lines.push(`  - 工作流：${Object.keys(m.generation_params.workflows).join(', ')}`)
    }
    lines.push(`  - 拼装：见 JSON \`models.${id}.generation_params\``)
  }
  lines.push('')
  lines.push('**拼装规则：** 用户选完模型与各参数后，按该模型 `generation_params.parameters` 映射为 `video_generate` 字段并一次性调用。')
  lines.push('')
  lines.push('完整 JSON：`references/media-capabilities.json`')
  return lines.join('\n')
}

/** 无 API 时打包进 zip 的静态能力表 */
export function buildMediaCapabilitiesFromStaticSpecs() {
  const rows = [
    ...IMAGE_MODEL_SPECS.map((s) => ({
      id: s.id,
      name: s.label,
      category: 'image',
      image_options: { aspect_ratios: OPENCLAW_IMAGE_ASPECT_RATIOS, image_sizes: OPENCLAW_IMAGE_RESOLUTIONS },
    })),
    ...VIDEO_MODEL_SPECS.map((s) => ({
      id: s.id,
      name: s.label,
      category: 'video',
      video_options: resolveStaticVideoOptions(s.id, s),
    })),
  ]
  return buildMediaCapabilitiesFromCatalogRows(rows)
}
