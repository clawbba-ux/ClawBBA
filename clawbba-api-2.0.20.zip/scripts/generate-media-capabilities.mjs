#!/usr/bin/env node
/**
 * 从 ClawBBA /api/v1/models 生成 references/media-capabilities.json + .md
 * 用法: CLAWBBA_API_KEY=... node scripts/generate-media-capabilities.mjs
 */
import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'
import {
  buildMediaCapabilitiesFromCatalogRows,
  renderMediaCapabilitiesMarkdown,
} from './clawbba-media-capabilities-core.mjs'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const ROOT = path.join(__dirname, '..')
const API_BASE = (process.env.CLAWBBA_API_BASE || 'https://www.clawbba.com/api/v1').replace(/\/$/, '')
const API_KEY = String(process.env.CLAWBBA_API_KEY || '').trim()

async function fetchModels() {
  const res = await fetch(`${API_BASE}/models`, {
    headers: { Authorization: `Bearer ${API_KEY}`, Accept: 'application/json' },
  })
  const text = await res.text()
  let body
  try {
    body = text ? JSON.parse(text) : {}
  } catch {
    throw new Error(`HTTP ${res.status}: 非 JSON`)
  }
  if (!res.ok) throw new Error(`HTTP ${res.status}: ${body.error || body.message || text.slice(0, 120)}`)
  return Array.isArray(body.data) ? body.data : []
}

async function main() {
  if (!API_KEY.startsWith('cbb_sk_live_')) {
    console.error('错误: 需要 CLAWBBA_API_KEY (cbb_sk_live_…)')
    process.exit(1)
  }
  const rows = await fetchModels()
  const cap = buildMediaCapabilitiesFromCatalogRows(rows)
  const jsonPath = path.join(ROOT, 'references', 'media-capabilities.json')
  const mdPath = path.join(ROOT, 'references', 'media-capabilities.md')
  fs.mkdirSync(path.dirname(jsonPath), { recursive: true })
  fs.writeFileSync(jsonPath, `${JSON.stringify(cap, null, 2)}\n`)
  fs.writeFileSync(mdPath, `${renderMediaCapabilitiesMarkdown(cap)}\n`)
  const nImg = Object.values(cap.models).filter((m) => m.category === 'image').length
  const nVid = Object.values(cap.models).filter((m) => m.category === 'video').length
  process.stderr.write(
    `[clawbba-api] media-capabilities: image=${nImg} video=${nVid} → ${path.basename(jsonPath)}\n`,
  )
}

main().catch((e) => {
  console.error(e.message || e)
  process.exit(1)
})
