# clawbba-api

Connect [OpenClaw](https://docs.openclaw.ai/) to the [ClawBBA Platform API](https://www.clawbba.com/api/v1) with your `cbb_sk_live_…` key — chat, image, and video models through one OpenAI-compatible endpoint.

## Quick start

1. Register / sign in: https://www.clawbba.com  
2. Top up balance: https://www.clawbba.com/product/CDKEY  
3. Create API key: https://www.clawbba.com/agent/api-keys  
4. **One-line install on your OpenClaw machine:**

```bash
export CLAWBBA_API_KEY='cbb_sk_live_YOUR_KEY'
curl -fsSL https://www.clawbba.com/downloads/install-clawbba-api.sh | bash
```

5. Restart OpenClaw Gateway or start a new agent session (the script tries `openclaw gateway restart`).

Manual setup (if skill already installed):

```bash
export CLAWBBA_API_KEY='cbb_sk_live_YOUR_KEY'
export OPENROUTER_API_KEY="$CLAWBBA_API_KEY"
./scripts/setup.sh --yes
openclaw config validate
```

## Image & video in OpenClaw (2026.5+)

After `setup.sh`, OpenClaw’s built-in **`image_generate`** and **`video_generate`** tools call the same ClawBBA Platform API (via repointed `models.providers.openrouter`). See [references/media-generation.md](./references/media-generation.md).

```bash
export OPENROUTER_API_KEY="$CLAWBBA_API_KEY"
/tool image_generate action=list
/tool video_generate action=list
```

## Install from ClawHub

Publisher: [clawbba-ux/clawbba-api](https://clawhub.ai/clawbba-ux/clawbba-api)

```bash
npm i -g clawhub
clawhub login
clawhub install clawbba-api
cd skills/clawbba-api   # or your workspace skills path
export CLAWBBA_API_KEY='cbb_sk_live_YOUR_KEY'
./scripts/setup.sh
```

Or with OpenClaw CLI:

```bash
openclaw skills install clawbba-api
export CLAWBBA_API_KEY='cbb_sk_live_YOUR_KEY'
./skills/clawbba-api/scripts/setup.sh
```

## Verify key only

```bash
CLAWBBA_API_KEY='cbb_sk_live_…' ./scripts/verify-key.sh
```

## Changelog

### 2.0.0

- **Breaking：放弃固定 ClawBBA 话术。** 安装生成 `references/media-capabilities.json`；对话模型用自然语言收集 `image_generate` / `video_generate` 参数后自动提交（无「确认生成」）。
- **Runtime v2：** `clawbbaValidateImageGenerateParams` / `clawbbaValidateVideoGenerateParams` 替代会话话术解析；保留交付、recover、参考图、禁止 Gemini 自动 describe。
- **工作流声明：** 文生图、图生图、文生视频、图生视频首帧/尾帧/参考图（`imageRoles`），对齐 OpenClaw 2026.5.28 工具 Schema。

### 1.6.11

- **禁止自动 Gemini 看图描述：** patch `runImagePrompt` — `provider===clawbba` 时不调用 vision LLM（避免上传参考图触发 `google/gemini-2.5-flash` Description）。`resolveImageModelConfigForTool` 强制 `imageModel` 与对话模型一致。废弃 vision id remap 优先用户对话模型，不再硬编码 Gemini。

### 1.6.10

- **Fix `sessionTemplate is not defined`：** v18 升级只改了 `const mediaTemplate = …`，preflight 函数体仍引用 `sessionTemplate`；新增 `upgradeMediaParamsSessionTemplateRefs`，patch/verify 禁止残留 `sessionTemplate`。

### 1.6.9

- **Fix 安装 SyntaxError：** `upgradeMediaParamsTemplateV18` 在 `clawbbaParseModelFromTemplate` 前多留闭合 `}`，导致 `Unexpected token 'function'`；改为按 `function clawbbaParseModelFromTemplate` 锚点切片，并 `repairMediaParamsStrayBraceBeforeParseModel` 修复已写坏的 dist。

### 1.6.8

- **微信/外渠话术：** `clawbbaResolveMediaTemplateText` — 会话 transcript 图+文分条、无空格话术规范化；Agent 工具里完整 ClawBBA 话术可作回退；用户话术中的模型/比例/分辨率**强制覆盖** Agent 自填参数（禁止 flux+16:9 覆盖 gemini+9:16）。
- **模型 id：** `模型google/…` 无空格可解析；`image_generate.model` 须为 `openrouter/vendor/model`（非 `clawbba/`）。

### 1.6.7

- **Fix:** 1.6.6 仅 upgrade dispatch 调用 `clawbbaPreflightImageGenerateAllowed` 但未注入函数体 → `ReferenceError: is not defined`。新增 `upgradeMediaParamsPreflightRuntime`；patch 升级链会补齐 runtime；`verify-openclaw-patch` 校验 `async function clawbbaPreflightImageGenerateAllowed`。

### 1.6.6

- **生图 preflight：** `image_generate` / `video_generate` 在解析参数前强制 `agentSessionKey` + 会话内完整 ClawBBA 话术；仅发「请使用 ClawBBA 生成图片能力」等不完整话术时立即 `ToolInputError`，禁止 Agent 自填 prompt 绕过。
- **参数解析：** 有会话时只从用户话术取 `prompt`/比例/模型，不再回退 Agent 工具参数。
- **升级链：** 已装旧 patch 的网关运行 `upgradeMediaDispatchPreflight`；`verify-openclaw-patch` 新增 preflight 项。

### 1.6.5

- **看图与对话同模型：** `imageModel.primary` 与 `agents.defaults.model` 对齐，不再自动切 Gemini 看图；图生图仅 `image_generate` + inbound 参考图路径。

### 1.6.4

- **话术完整性：** 仅发「请使用 ClawBBA 生成图片能力」等不完整话术时 `ToolInputError`，禁止 Agent 自填 prompt 绕过；须含「为我生成」、比例/时长、冒号后画面描述。
- **上游解析：** 增强 `extractImagesFromChatCompletionData`（`data[]` / `type:image`+`source`）缓解 Gemini 3.1 200 无图链。

### 1.6.3

- **生成前确认：** `image_generate` / `video_generate` 解析参数后抛出「生成参数确认单」，用户回复「确认生成」后同参数再次调用才进入任务；未指定模型时确认单展示默认模型 ID 与参数要求。
- **标准话术：** `clawbba-media-prompt-standards.mjs` 与官网 API Keys / `GET /api/user/platform-openclaw-guide` 对齐；各模型附带 `image_options` / `video_options` 约束说明。

### 1.6.2

- **图生图门禁：** 会话合并参考图仅限强参考意图（参考图/根据参考图/图生图等），且只扫描话术相邻 ±1 条用户消息；合并使用 plausible 校验，避免误绑历史会话图片。
- **话术比例：** 检测 `9:16` + `横图` 等矛盾，在 `image_generate` 解析阶段 `ToolInputError` 并提示标准模板。

### 1.6.0 — 媒体参数合规重构

- **统一模块** `clawbba-media-params.mjs`：话术解析 → OpenClaw 校验 → 写回 params → **生成参数摘要**（`ClawBBA 生成参数：模型=… · 比例=…`）。
- **默认参数**：未写模型时用 OpenClaw `imageGenerationModel` / `videoGenerationModel`；用户话术可覆盖 aspectRatio / resolution / duration。
- **缺参/错参**：`ToolInputError` 附带标准话术模板，引导用户完善话术，不再 silent 失败或乱猜。
- **参考图**：严格 OpenClaw — 有 inbound 附件 → 图生图；无话术参考意图 → 文生图；有参考意图无图 → 拦截并提示上传。
- **resolution**：仅 1K/2K/4K；1080P/720P 自动映射并写回 params。
- **dispatch v1**：替换分散 regex 块为 `clawbbaResolveClawbbaImageParams` / `clawbbaResolveClawbbaVideoParams`。
- **Agent 规则**重写：defaults、模板、参考图、缺参处理、参数展示。

### 1.5.88

- **Fix:** Dashboard 无图 — `clawbba direct transcript inject failed: export resolveSessionAgentId missing`。根因：误从 `session-utils` 取 `resolveSessionAgentId`（该符号在 `agent-scope` 导出为 `_`）。现改为 `import agent-scope` + `clawbbaPickModuleExport(..., ["_"])`。
- **Fix:** Agent 传 `resolution: "1080P"` → `resolution must be one of 1K, 2K, or 4K`。现映射 720P→1K、1080P/1440P→2K、2160P→4K。
- **Fix:** 英文 prompt「based on the reference image」未触发参考图 guard（仅匹配中文）。现中英文均拦截无图时的 `image_generate`。

### 1.5.87

- **Fix:** `Cannot read properties of undefined (reading 'match')` — Agent 未传 `prompt` 时 media-dispatch 块 `let mediaText = prompt` 为 undefined；改为 `typeof prompt === "string" ? prompt : ""`。
- **Fix:** direct transcript 失败时打 `clawbba direct transcript inject failed` 日志（便于区分未打补丁 vs append 失败）。

### 1.5.86

- **Fix:** Agent 用占位符 `参考图URL` / `example.com/reference-image.jpg` 绕过 1.5.83 guard → OpenClaw 报 `Local media path is not under an allowed directory`。现 `clawbbaSanitizeReferenceImageParams` 剔除无效 refs，guard 只认真实 inbound 路径/URL；占位符会重新触发「请先上传参考图」。
- **Fix:** `google/gemini-2.5-flash-image` 上游 200 但「未解析到图片链接」— 增强 `extractImagesFromChatCompletionData`（`inlineData`/`b64_json`/embedded base64）。

### 1.5.85

- **Fix:** 微信/外渠后台 wake 写 WebChat 历史失败 — 日志 `missing scope: operator.admin` + `clawbba webchat media live inject failed`。根因：`media-generate-background-shared` 上下文调用 `chat.inject` 无 `operator.admin` scope。现优先 **直接 append session transcript**（OpenClaw `appendExactAssistantMessageToSessionTranscript`，与 `chat.inject` 同源），失败才 fallback `chat.inject`；生图/生视频 wake 与 recover 均适用。

### 1.5.84

- **Fix:** 微信/外渠生图成功后 WebChat 控制台同一会话无图 — 外渠 `sendMessage` 成功时提前 `return "external"` 且 `clawbbaShouldInjectWebChatMediaLive(weixin)` 为 false，导致 **从不** `chat.inject` 写入 session transcript。现外渠发送后 **始终** `mirrorSessionTranscript` 注入 Dashboard/WebChat 历史（微信 CDN 失败时也能看到成图）。
- **Fix (2.0.6):** 微信自然语言生图完成但 `getUploadUrl ret:-1` — OpenClaw 会把 sessionKey 里的微信用户 ID 小写化，`inferDeliveryFromSessionKey` 得到错误 `to`；现生图 wake / 外渠投递 **优先 `handle.requesterOrigin` 与 session.lastTo`**（保留大小写），与 recover 路径一致。

### 1.5.83

- **Fix:** 微信先发 ClawBBA 话术（含「根据参考图」）后 Agent 立刻 `image_generate` 且无附件 → 文生图/解析失败。runtime 在 `image_generate` 内 **强制拦截**：话术含参考图意图但 session 无 `image`/`images` 时 `ToolInputError`，提示先上传参考图；并向前扫描话术 **之后** 的用户消息取图。

### 1.5.82

- **Fix:** `patch-openclaw-media-delivery` 在从 1.5.80→1.5.81 升级时可能留下多余 `}` → `SyntaxError: Unexpected token '}'`。现对 `wakeMediaGenerationTaskCompletion` 在 `mediaUrls` 与 `internalEvents` 之间 **整段重建** 注入块；禁用会破坏函数体的 wake dedupe slice。

### 1.5.81

- **Fix:** 微信/外渠生图完成后落到「新会话」且署名 **Gemini 2.5 Flash** — 实为 inter-session 用 `imageModel` 处理完成通知，非生图结果。`wakeMediaGenerationTaskCompletion` 对外渠先 `sendMessage` 直发原会话并跳过 announce。
- **Fix:** 参考图 A + ClawBBA 话术 — 从 `[media attached: …]` 解析路径、近邻用户消息回溯增至 5 条，强化「参考图」意图匹配。

### 1.5.80

- **Fix（附件看图 404）:** `agents.defaults.imageModel` 误为 `clawbba/google/gemini-2.0-flash-001`（非用户选的对话模型）→ setup/修复脚本强制迁移到 `gemini-2.5-flash` 等；平台代理对带图 vision 请求自动 remap 废弃模型。
- **Fix:** 禁止将 `gemini-2.0-flash-001` 写入默认文本模型与 vision 自动挑选列表。

### 1.5.79

- **Fix:** 按 OpenClaw 上游 `src/media-understanding/attachments.cache.ts` 定位 runner patch（支持 dist 中 `attachments.cache-*.js` 而不仅是 `runner-*.js`）。
- **Doc/工具:** `references/openclaw-patch-targets.md`、`scripts/probe-openclaw-media-bundles.mjs`（可设 `OPENCLAW_SRC` 对照源码）。

### 1.5.78

- **Fix:** 部分 OpenClaw 安装无独立 `runner-*.js`（`MediaAttachmentCache` 改名/合并）→ 扫描任意含 `resolveLocalPath` + `normalizeAttachmentPath` 的 bundle；若无 runner 则 **fallback patch `media-reference-*.js`**。
- **Verify:** runner 项在 `media-reference` 已能解析 `media://inbound` 时视为通过，不再误报 `file missing`。

### 1.5.77

- **Fix:** `verify-openclaw-patch` 误用 `clawbbaResolveOpenClawInboundMediaPathSync` 校验 image 工具（该符号只在 runner 内）→ 已装 patch 仍报「未 patched」。
- **Fix:** runner 查找支持无 `runner-` 前缀或布局变化的 `MediaAttachmentCache` 包；`resolveLocalPath` 多种 OpenClaw 模板。
- **Fix:** image 工具 patch 兼容 `ToolInputError`、宽松 import、原生 `resolveMediaReferenceLocalPath`（OpenClaw ≥2026.6）。

### 1.5.76

- **Fix（严重）:** Gateway 文本模型 offload 附件时，用户消息仍写 `[media attached: media://inbound/…]`，Agent 原样传给 `image` 工具 → `raw_params.image` 仍为 `media://…` → ENOENT / vision **404 upstream_error**。现改为写入 **`savedMedia.path`** 与 `MEDIA:<本地路径>`。
- **Fix:** `image` 工具在加载前 **预解析** `imageInputs` 中的 `media://`（`resolveMediaReferenceLocalPath`）。
- **Verify:** 安装校验新增 `mediaUriResolve`、`gatewayOffloadPath` 两项，未打 patch 时安装会失败并提示重跑 `ensure-openclaw-patches.sh`。
- **Config:** `fix-openclaw-vision-config` 自动将已废弃的 `google/gemini-2.0-flash-001` 迁移到 catalog 中的 `gemini-2.5-flash` 等 vision 模型。

### 1.5.75

- **Fix（严重）:** `media-understanding` 附件缓存 `resolveLocalPath` 将 `media://inbound/…` 误拼为 `workspace/media:/inbound/…`（日志里 `media-understanding image: failed` + `read ENOENT` 同源）。现于 **runner 附件缓存**、**sandbox read 路径**、**image 工具** 三处同步解析为 `~/.openclaw/media/inbound/…`。
- **说明:** 未选用 Gemini 时仍可能出现 `clawbba/google/gemini-2.0-flash-001` — 那是 OpenClaw `agents.defaults.imageModel`（文本模型 offload 附件后的「看图」专用模型），不是对话模型。

### 1.5.74

- **Fix（严重）:** DeepSeek 等纯文本模型 + 上传参考图 + `请使用 ClawBBA 生成图片` — Gateway 将附件存为 `media://inbound/…`，但 `image` 工具与 `image_generate` 误解析为 `workspace/media:/inbound/…` → vision 404、read ENOENT、生图未带参考图。
- **Fix:** `clawbbaShouldInjectWebChatMediaLive is not defined` — 生图进度经 `subagent-announce-delivery` 动态 import，现于 announce 块内注入 `clawbbaShouldInjectWebChatMediaLive`；有 `chatRunId` 时 Dashboard 进度可 inject。
- **Fix:** 会话参考图合并 — `media://` URI 解析为 `~/.openclaw/media/inbound/…` 再写入 `image_generate.images`。
- **Config:** 默认 vision `imageModel` 优先 `google/gemini-2.5-flash`（在 `2.0-flash-001` 之前）。

### 1.5.43

- **Fix:** WebChat 执行 `/tool image_generate action=tasks` 无输出 — 微信绑定 session 会先走 `sendMessage` 且 `clawbbaShouldInjectWebChatMediaLive` 为 false，导致跳过 `chat.inject`；现 **有 `chatRunId` 时优先 WebChat inject**（Dashboard `/tool` 场景）。
- **Fix:** Agent 规则补充 — `action=tasks|list|status` 须原文回显工具结果，避免空回复。

### 1.5.42

- **Fix（严重）:** 1.5.41 导致 Gateway 无法监听 18789 — `clawbbaListImageTasks` / `clawbbaListVideoTasks` 内 HTTP 响应体与任务列表均声明 `const text`，`openclaw-tools` **SyntaxError**，systemd 显示 running 但端口未监听。已改为 `responseText` + `taskListText`；patch 完成后强制 `node --check openclaw-tools-*.js`。

### 1.5.41

- **Fix:** `/tool image_generate action=tasks`（及 `video_generate action=tasks`）工具执行成功但 Agent 空回复 → `incomplete turn … payloads=0` — 只读 action 完成后**直接推送**任务列表到 WebChat（`chat.inject`）/ 微信等渠道（`sendMessage`），并抑制随后的 incomplete-turn 错误提示。

### 1.5.40

- **Fix:** `image_generate action=tasks|recover` 报 `action must be "generate", "status", or "list"` — patch 漏改 `resolveAction$2` 的 allowed 列表；现与 execute handler 一致放行 `tasks` / `recover`。

### 1.5.39

- **Fix:** 图片/进度仍发到错误会话 — 1.5.38 误用 `handle.runId`（`tool:Image generation:…` 工具 run）作 WebChat `chatRunId`；controller 找不到后回退到**其它活跃会话**。现改为 `requesterChatRunId: options.runId`（用户聊天 run，如 `f7ecaee3-…`），且指定 runId 不存在时**不再**误绑其它 tab。

### 1.5.38

- **Fix:** 进度「已等待 480 分」— SQLite `datetime('now')` 为 UTC，Node 按本地解析导致 +8h 偏差；服务端 `parseSqliteUtcDateMs` 统一按 UTC 计算 elapsed。
- **Fix:** 新建会话但图片/进度发到旧会话 — WebChat 广播不再 loose-match 所有 `:main`；`chatRunId` 绑定 task handle.runId（进度 inject + wake 完成）；每任务重置 poll progress 锚点。

### 1.5.37

- **Feature:** 生图超时恢复（对齐 `video_generate recover`）— `image_generate action=tasks` 列出 ClawBBA job；`action=recover jobId=<id> timeoutMs=600000` 轮询 `GET /api/v1/images/generations/:id` 并下载到 `~/.openclaw/media/tool-image-generation/`（**不二次扣费**）。
- **Feature:** 后台生图任务超时/失败时 OpenClaw **自动 recover**（已知 `job_id` 或 `globalThis.__clawbbaLastImageJobId`），WebChat 即时注入 MEDIA。
- **API:** `GET /api/v1/images/tasks`；poll 响应含 `clawbba_recovery.recover_hint`。

### 1.5.36

- **Fix:** 上游已 `completed` 但 OpenClaw 永不取图 — 旧 poll 在 `data` 无 inline 图时 **无限 2s 轮询**（进度条可到 100% 但 `generateImage` 不返回）。v6：completed 时从 `pollBody.images` https 回退下载；否则立即报错。服务端 poll GET 自动 **重建 data URL**（`enrichCompletedImageJobForPoll`）。
- **Fix:** Agent `read ~/.openclaw/media` → EISDIR — 规则改为禁止读目录；参考图解析拒绝裸 `~/.openclaw/media` 路径。
- **UX:** 进度推送节流（keepalive 5s→12s，里程碑最小间隔 25s），减轻微信通道负载。

### 1.5.35

- **Fix:** `gpt-5.4-image-*` 已扣费但 180s 超时无图 — OpenClaw async poll v5：**202 后立即 `release()` POST fetch guard**（不再与 `fetchWithSsrFGuard` 共用 180s 计时）；轮询上限改为 **15 分钟**（不再用 `req.timeoutMs` 180000 截断）。`setup.sh` 写入 `imageGenerationModel.timeoutMs: 600000`。

### 1.5.34

- **Fix:** Gateway `clawbbaInjectMediaProgressLive has already been declared` — 修复 dedupe 在模板字符串 `{}` 处误截断；安装时 strip 重复 export 并重建单一 WebChat helper 块。

### 1.5.33

- **Fix:** 1.5.32 安装后 Gateway 无法启动 — `image-generation-provider` 进度 helper 误插入对象字面量内（ParseError）；`clawbbaInjectMediaProgressLive` 重复声明。安装时会自动 dedupe + repair。

### 1.5.32

- **UX:** 生图/生视频后台任务期间自动推送进度（百分比 + 进度条 + 已等待时间）。WebChat 经 `chat.inject`；微信/Telegram 等外部渠道经 `sendMessage`；轮询 GET job 返回 `progress_percent` / `progress_bar`。

### 1.5.31

- **Fix:** 202 异步 job 轮询 `Failed to parse URL from /api/v1/images/generations/...` — 服务端 `poll_url` 改为绝对 URL；OpenClaw patch v4 在客户端将相对路径解析为 `https://www.clawbba.com/api/v1/...`。

### 1.5.30

- **Fix:** 生图 `ReadableStream is locked` — patch 在 `response.json()` 后不再调用 `assertOkOrThrowHttpError`（避免重复读 body）；清理 v2 升级遗留的重复代码块。
- **Fix:** 202 异步 job 轮询 `missing image data` — 服务端 job 结果改为写入 **data:image** inline URL（OpenClaw 只认 data URL，不认 https）。

### 1.5.29

- **Fix:** `openai/gpt-5.4-image-*` 生图经 ClawBBA 网关 504 / 已扣费无图 — 慢模型改 **202 异步 job**；OpenClaw provider **轮询直到出图**（`clawbba-image-async-job-poll-v2`，无固定 900s 总超时）。服务端上游 fetch 亦等到返回或断连 recovering。

### 1.5.27

- **UX:** 生图/生视频 Child result 与 WebChat 注入文案中，`Generated … with openrouter/…` 改为用户可见的 `ClawBBA/<平台模型>`；内部仍用 `openrouter/` 调用，功能不变。

### 1.5.26

- **Fix:** 安装校验 `verify-openclaw-patch.mjs` 漏 import `recoverFnHasWebChatDispatchInject`，导致 `ReferenceError` 与「patch 仍未就绪」误报。

### 1.5.25

- **Fix:** `dispatchGatewayMethodInProcess is not a function` — OpenClaw `server-plugins-*.js` 只导出 minified 名 `r`；inject 改用 `clawbbaPickModuleExport(..., ["r"])`，gateway context 同理（`t`/`n`）。

### 1.5.24

- **Fix:** recover 仍须刷新 — patch 误把 `server-plugins-*.d.ts` 写入 dynamic import，运行时报 `Stripping types is currently unsupported`，`clawbba webchat media live inject failed`；`findDistJsFile` 只选 `.js`，并自动修复已打 patch 机器上的 `.d.ts` import。

### 1.5.23

- **Fix:** WebChat `video_generate action=recover` 完成后仍须刷新 — 活跃 run 期间 `session.message` 会被 Control UI 延迟；reload 依赖 `chatAbortControllers` 命中 runId，长时间 recover 后 controller 可能已过期。现强制使用 `options.runId` 广播空 `final` 触发 `chat.history`，并向 raw/canonical 双 sessionKey 投递。

### 1.5.22

- **Fix:** 1.5.21 zip 漏导出 `ensureRecoverFnParams` / `recoverFnHasAgentSessionKeyParam`，导致 patch 与 verify 运行时 ReferenceError / SyntaxError。

### 1.5.21

- **Fix:** `video_generate action=recover` 报 `agentSessionKey is not defined` — 遗留 inject 引用 `agentSessionKey` 但 `clawbbaRecoverVideoTask` 函数签名未声明；升级误判「文件含 agentSessionKey 字符串」而跳过补参；verify 增加函数签名校验。

### 1.5.20

- **Fix:** recover 仍走 1.5.15 遗留 `__clawbbaSk.includes("webchat")` 分支（`agent:main:main` 永不触发 inject）— 升级误判「文件里已有 dispatch 函数」；现按 `clawbbaRecoverVideoTask` 函数体校验并强制替换。

### 1.5.19

- **Fix:** `video_generate action=recover` WebChat 仍须刷新 — 生图/生视频走 wake/announce（后台完成）；recover 是前台同步工具，无 gateway ALS scope，且 `chatAbortControllers` 存 raw sessionKey、`options.runId` 未传入。现用 fallback gateway context + `chatRunId` + `session.message`/`sessions.changed` 三重 reload，与 OpenClaw WebChat 规范对齐。

### 1.5.18

- **Fix:** 1.5.17 从 1.5.16 升级时 patch 校验失败（`video recover WebChat live inject`）— 升级用正则未转义 `/* */` 导致静默未写入 `clawbbaPromptWebChatHistoryReload`；并加强校验与手术式回退升级。

### 1.5.17

- **Fix:** WebChat `recover`/前台工具完成后仍须刷新 — `chat.inject` 使用 `runId=inject-*`，与活跃 `chatRunId` 不匹配时 Control UI 不会拉 `chat.history`；注入后额外用活跃 run 广播空 `final` 触发即时 reload。

### 1.5.16

- **Fix:** `video_generate action=recover` WebChat 仍须刷新 — 1.5.15 误判 session（`agent:main:main` 不含 `webchat` 字符串）；改用 OpenClaw 原生 `parseAgentSessionKey` / `inferDeliveryFromSessionKey` 判定内部渠道，并直接 `dispatchGatewayMethodInProcess('chat.inject')`。

### 1.5.15

- **Fix:** WebChat 执行 `video_generate action=recover` 后需刷新才显示视频 — recover 完成时 `chat.inject` 推送 `MEDIA:`（与后台生图/生视频 wake 路径同类问题）。

### 1.5.14

- **修复 Gateway 无法启动**：1.5.13 重复注入 `clawbbaInjectWebChatGeneratedMediaLive` 导致 `already been declared`；安装时自动 dedupe，wake 路径改用动态 `import()`。

### 1.5.13

- **WebChat 即时显示（加固）**：在 `wakeMediaGenerationTaskCompletion` 完成时 `chat.inject` 推送 `MEDIA:`（不依赖 announce steer 分支）；导出 `clawbbaInjectWebChatGeneratedMediaLive`；安装必检 `webchatLiveWake` + `announceLive`；`ensure-openclaw-patches.sh` 不再吞掉 patch 失败。

### 1.5.12

- **Fix:** WebChat 生图/生视频完成后需刷新浏览器 — 适配 OpenClaw 新版 `resolveQueueEmbeddedPiMessageOutcome`；`chat.inject` live patch；`install` 强制校验 `announceLive`

### 1.5.11

- **Fix:** `--flux-only` 校验误报失败（已 patch 且全 ✓ 仍提示「patch 仍未就绪」）— 修正 critical 计数；已装完整 patch 时自动识别通过

### 1.5.10

- **Change:** 安装流程用 `ensure-openclaw-patches.sh` 自动打 patch + 验证 + 失败重试；`gateway restart` 仍由 install 自动执行，无需再手动跑 patch 命令

### 1.5.9

- **Fix:** `verify-openclaw-patch.mjs` 恢复 `path` 导入（1.5.8 误删导致 ReferenceError）

### 1.5.8

- **Change:** 安装/验证日志与 patch 检查项改为 **ClawBBA** 展示名（内部仍用 OpenClaw `openrouter` provider，功能不变）

### 1.5.7

- **Fix:** 文本对话上传图片 — `models.providers.clawbba` 为 vision 文本模型标记 `input: ["text","image"]`；`agents.defaults.imageModel` 指向 `clawbba/<vision-文本>`，不再误用 `openrouter/flux.*` 做「Describe this image」
- **New:** `fix-openclaw-vision-config.mjs`、`clawbba-vision-models.mjs`；`verify-openclaw-runtime` 校验 `imageModel`
- **Doc:** `openclaw-integration-spec.md` §1.1 区分聊天看图 vs 生图

### 1.1.6

- **Change:** 媒体交付改为 **OpenClaw 本地资产 + `MEDIA:`**（图片/视频）；`patch-openclaw-media-delivery.mjs` 替代公网 URL 方案；Agent 规则禁止依赖 clawbba.com/uploads 作主交付
- **Doc:** `references/media-delivery-local.md`

### 1.1.5

- **Fix:** 生图成功后 WebChat 自动交付 — API 响应携带 `CLAWBBA_IMAGE_URLS` + 公网 Markdown；`setup.sh` 运行 `patch-openclaw-image-delivery.mjs` 注入 completion 通知；Agent 规则禁止 WebChat 使用 `message` 工具发图
- **Doc:** `references/image-delivery-webchat.md`

### 1.1.4

- **Change:** 取消强制「模型编号」菜单；未指定模型时使用 `imageGenerationModel.primary` / `videoGenerationModel.primary`
- **Docs:** `openclaw-agent-behavior.md` — 禁止 `/model` 切换生图；`Background task started` 后只回复一句
- **Sync:** API Keys 页 OpenClaw 接入改为默认话术 + 可选模型 chips（v1.1.4）

### 1.1.3

- **New:** `references/model-picker.md` — 生图 1–8、生视频 1–6 编号菜单与 Agent 话术模板
- **Docs:** `openclaw-agent-behavior.md` — 生图前必须弹出编号菜单；禁止向用户提及 OpenRouter
- **Docs:** `SKILL.md` — 编号选模型用户话术；`always: true` + systemPrompt 注入 ClawBBA 品牌规则
- **Fix:** `setup.sh` 安装后提示编号引导与 OpenRouter 翻译说明
- **Sync:** API Keys 页 OpenClaw 一键接入与生图模型编号 chips 对齐（前台隐藏 openrouter/ 前缀）

### 1.1.1

- **Fix:** 安装时向 `models.json` / `openclaw.json` 写入**真实** `cbb_sk_live_…`（不再使用 `${CLAWBBA_API_KEY}` 占位符，避免 WebChat `403 Your request was blocked`）
- **Fix:** 为 `clawbba` / `openrouter` provider 添加 `headers.User-Agent`（OpenClaw pi 客户端兼容）
- **New:** `scripts/fix-provider-config.mjs` — 已装 1.1.0 用户一键修复
- **New:** `scripts/verify-openclaw-runtime.mjs` — 安装后自检（setup 失败则中断）
- **Docs:** `references/error-translation.md` — 禁止向用户复述 OpenRouter；工具报错翻译模板
- **Fix:** skill `always: true` + `agents.defaults.systemPrompt` 注入 ClawBBA 品牌规则（安装时写入）
- **Docs:** `references/clawbba-media-models.md` — 全部生图/生视频 model_id、用户话术模板、模型切换说明
- **Docs:** 完善 `media-generation.md` / `onboarding.md` 与 API Keys 页模型一键复制话术

### 1.1.0

- 全量模型 catalog、sync agent `models.json`、公网一键安装脚本

## License

MIT-0 (see [LICENSE](./LICENSE)). Publishing on ClawHub releases this skill under MIT-0 per ClawHub policy.

## Links

- API base: `https://www.clawbba.com/api/v1`
- Docs in skill: `references/onboarding.md`, `references/api-endpoints.md`
- Publish guide: [PUBLISH.md](./PUBLISH.md)
