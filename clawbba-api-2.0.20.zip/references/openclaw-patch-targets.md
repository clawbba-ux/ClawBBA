# OpenClaw 源码 → dist patch 对照（ClawBBA）

以 OpenClaw 仓库为准，**不要猜 dist 哈希文件名**。安装时 `patch-openclaw-media-delivery.mjs` 会在 `openclaw/dist/` 里按**内容**查找 bundle。

## 环境变量

| 变量 | 用途 |
|------|------|
| `OPENCLAW_SRC` | 本地 OpenClaw 源码根目录（含 `src/media-understanding/attachments.cache.ts`） |
| `OPENCLAW_DIST` | 运行时 dist（如 `/usr/lib/node_modules/openclaw/dist`） |

## media://inbound 解析

| 问题 | 上游源码 | dist 中常见 bundle |
|------|----------|-------------------|
| 文本模型 offload 后消息仍是 `media://` | `src/gateway/chat-attachments.ts`（`[media attached: …]`） | `attachment-normalize-*.js` |
| media-understanding 把 URI 拼进 workspace | `src/media-understanding/attachments.cache.ts` → `resolveLocalPath()` | `runner-*.js` 或 `attachments.cache-*.js` |
| `image` / `image_generate` 未解析 URI | `src/agents/tools/image-tool.ts`、`image-generate` 参考图加载 | `openclaw-tools-*.js` |
| 通用 URI → 磁盘路径 | `src/media/media-reference.ts` → `resolveMediaReferenceLocalPath()` | `media-reference-*.js` |

## 上游已有能力（2026.5+）

`src/media/media-reference.ts` 已支持 `media://inbound/<id>` → `resolveMediaBufferPath`。  
`attachments.cache.ts` 的 `resolveLocalPath` **未**调用该函数，故仍需 patch runner/attachments.cache bundle。

## 诊断

```bash
export OPENCLAW_SRC=/path/to/openclaw
node ~/.openclaw/skills/clawbba-api/scripts/probe-openclaw-media-bundles.mjs
```
