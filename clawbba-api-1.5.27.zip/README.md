# clawbba-api

Connect [OpenClaw](https://docs.openclaw.ai/) to the [ClawBBA Platform API](https://www.clawbba.com/api/v1) with your `cbb_sk_live_…` key — chat, image, and video models through one OpenAI-compatible endpoint.

## Quick start

1. Register / sign in: https://www.clawbba.com  
2. Top up balance: https://www.clawbba.com/product/CDKEY  
3. Create API key: https://www.clawbba.com/agent/api-keys  
4. **One-line install on your OpenClaw machine:**

```bash
export CLAWBBA_API_KEY='cbb_sk_live_YOUR_KEY'
curl -fsSL https://www.clawbba.com/downloads/install-clawbba-api.sh | bash
```

5. Restart OpenClaw Gateway or start a new agent session (the script tries `openclaw gateway restart`).

Manual setup (if skill already installed):

```bash
export CLAWBBA_API_KEY='cbb_sk_live_YOUR_KEY'
export OPENROUTER_API_KEY="$CLAWBBA_API_KEY"
./scripts/setup.sh --yes
openclaw config validate
```

## Image & video in OpenClaw (2026.5+)

After `setup.sh`, OpenClaw’s built-in **`image_generate`** and **`video_generate`** tools call the same ClawBBA Platform API (via repointed `models.providers.openrouter`). See [references/media-generation.md](./references/media-generation.md).

```bash
export OPENROUTER_API_KEY="$CLAWBBA_API_KEY"
/tool image_generate action=list
/tool video_generate action=list
```

## Install from ClawHub

Publisher: [clawbba-ux/clawbba-api](https://clawhub.ai/clawbba-ux/clawbba-api)

```bash
npm i -g clawhub
clawhub login
clawhub install clawbba-api
cd skills/clawbba-api   # or your workspace skills path
export CLAWBBA_API_KEY='cbb_sk_live_YOUR_KEY'
./scripts/setup.sh
```

Or with OpenClaw CLI:

```bash
openclaw skills install clawbba-api
export CLAWBBA_API_KEY='cbb_sk_live_YOUR_KEY'
./skills/clawbba-api/scripts/setup.sh
```

## Verify key only

```bash
CLAWBBA_API_KEY='cbb_sk_live_…' ./scripts/verify-key.sh
```

## Changelog

### 1.5.27

- **UX:** 生图/生视频 Child result 与 WebChat 注入文案中，`Generated … with openrouter/…` 改为用户可见的 `ClawBBA/<平台模型>`；内部仍用 `openrouter/` 调用，功能不变。

### 1.5.26

- **Fix:** 安装校验 `verify-openclaw-patch.mjs` 漏 import `recoverFnHasWebChatDispatchInject`，导致 `ReferenceError` 与「patch 仍未就绪」误报。

### 1.5.25

- **Fix:** `dispatchGatewayMethodInProcess is not a function` — OpenClaw `server-plugins-*.js` 只导出 minified 名 `r`；inject 改用 `clawbbaPickModuleExport(..., ["r"])`，gateway context 同理（`t`/`n`）。

### 1.5.24

- **Fix:** recover 仍须刷新 — patch 误把 `server-plugins-*.d.ts` 写入 dynamic import，运行时报 `Stripping types is currently unsupported`，`clawbba webchat media live inject failed`；`findDistJsFile` 只选 `.js`，并自动修复已打 patch 机器上的 `.d.ts` import。

### 1.5.23

- **Fix:** WebChat `video_generate action=recover` 完成后仍须刷新 — 活跃 run 期间 `session.message` 会被 Control UI 延迟；reload 依赖 `chatAbortControllers` 命中 runId，长时间 recover 后 controller 可能已过期。现强制使用 `options.runId` 广播空 `final` 触发 `chat.history`，并向 raw/canonical 双 sessionKey 投递。

### 1.5.22

- **Fix:** 1.5.21 zip 漏导出 `ensureRecoverFnParams` / `recoverFnHasAgentSessionKeyParam`，导致 patch 与 verify 运行时 ReferenceError / SyntaxError。

### 1.5.21

- **Fix:** `video_generate action=recover` 报 `agentSessionKey is not defined` — 遗留 inject 引用 `agentSessionKey` 但 `clawbbaRecoverVideoTask` 函数签名未声明；升级误判「文件含 agentSessionKey 字符串」而跳过补参；verify 增加函数签名校验。

### 1.5.20

- **Fix:** recover 仍走 1.5.15 遗留 `__clawbbaSk.includes("webchat")` 分支（`agent:main:main` 永不触发 inject）— 升级误判「文件里已有 dispatch 函数」；现按 `clawbbaRecoverVideoTask` 函数体校验并强制替换。

### 1.5.19

- **Fix:** `video_generate action=recover` WebChat 仍须刷新 — 生图/生视频走 wake/announce（后台完成）；recover 是前台同步工具，无 gateway ALS scope，且 `chatAbortControllers` 存 raw sessionKey、`options.runId` 未传入。现用 fallback gateway context + `chatRunId` + `session.message`/`sessions.changed` 三重 reload，与 OpenClaw WebChat 规范对齐。

### 1.5.18

- **Fix:** 1.5.17 从 1.5.16 升级时 patch 校验失败（`video recover WebChat live inject`）— 升级用正则未转义 `/* */` 导致静默未写入 `clawbbaPromptWebChatHistoryReload`；并加强校验与手术式回退升级。

### 1.5.17

- **Fix:** WebChat `recover`/前台工具完成后仍须刷新 — `chat.inject` 使用 `runId=inject-*`，与活跃 `chatRunId` 不匹配时 Control UI 不会拉 `chat.history`；注入后额外用活跃 run 广播空 `final` 触发即时 reload。

### 1.5.16

- **Fix:** `video_generate action=recover` WebChat 仍须刷新 — 1.5.15 误判 session（`agent:main:main` 不含 `webchat` 字符串）；改用 OpenClaw 原生 `parseAgentSessionKey` / `inferDeliveryFromSessionKey` 判定内部渠道，并直接 `dispatchGatewayMethodInProcess('chat.inject')`。

### 1.5.15

- **Fix:** WebChat 执行 `video_generate action=recover` 后需刷新才显示视频 — recover 完成时 `chat.inject` 推送 `MEDIA:`（与后台生图/生视频 wake 路径同类问题）。

### 1.5.14

- **修复 Gateway 无法启动**：1.5.13 重复注入 `clawbbaInjectWebChatGeneratedMediaLive` 导致 `already been declared`；安装时自动 dedupe，wake 路径改用动态 `import()`。

### 1.5.13

- **WebChat 即时显示（加固）**：在 `wakeMediaGenerationTaskCompletion` 完成时 `chat.inject` 推送 `MEDIA:`（不依赖 announce steer 分支）；导出 `clawbbaInjectWebChatGeneratedMediaLive`；安装必检 `webchatLiveWake` + `announceLive`；`ensure-openclaw-patches.sh` 不再吞掉 patch 失败。

### 1.5.12

- **Fix:** WebChat 生图/生视频完成后需刷新浏览器 — 适配 OpenClaw 新版 `resolveQueueEmbeddedPiMessageOutcome`；`chat.inject` live patch；`install` 强制校验 `announceLive`

### 1.5.11

- **Fix:** `--flux-only` 校验误报失败（已 patch 且全 ✓ 仍提示「patch 仍未就绪」）— 修正 critical 计数；已装完整 patch 时自动识别通过

### 1.5.10

- **Change:** 安装流程用 `ensure-openclaw-patches.sh` 自动打 patch + 验证 + 失败重试；`gateway restart` 仍由 install 自动执行，无需再手动跑 patch 命令

### 1.5.9

- **Fix:** `verify-openclaw-patch.mjs` 恢复 `path` 导入（1.5.8 误删导致 ReferenceError）

### 1.5.8

- **Change:** 安装/验证日志与 patch 检查项改为 **ClawBBA** 展示名（内部仍用 OpenClaw `openrouter` provider，功能不变）

### 1.5.7

- **Fix:** 文本对话上传图片 — `models.providers.clawbba` 为 vision 文本模型标记 `input: ["text","image"]`；`agents.defaults.imageModel` 指向 `clawbba/<vision-文本>`，不再误用 `openrouter/flux.*` 做「Describe this image」
- **New:** `fix-openclaw-vision-config.mjs`、`clawbba-vision-models.mjs`；`verify-openclaw-runtime` 校验 `imageModel`
- **Doc:** `openclaw-integration-spec.md` §1.1 区分聊天看图 vs 生图

### 1.1.6

- **Change:** 媒体交付改为 **OpenClaw 本地资产 + `MEDIA:`**（图片/视频）；`patch-openclaw-media-delivery.mjs` 替代公网 URL 方案；Agent 规则禁止依赖 clawbba.com/uploads 作主交付
- **Doc:** `references/media-delivery-local.md`

### 1.1.5

- **Fix:** 生图成功后 WebChat 自动交付 — API 响应携带 `CLAWBBA_IMAGE_URLS` + 公网 Markdown；`setup.sh` 运行 `patch-openclaw-image-delivery.mjs` 注入 completion 通知；Agent 规则禁止 WebChat 使用 `message` 工具发图
- **Doc:** `references/image-delivery-webchat.md`

### 1.1.4

- **Change:** 取消强制「模型编号」菜单；未指定模型时使用 `imageGenerationModel.primary` / `videoGenerationModel.primary`
- **Docs:** `openclaw-agent-behavior.md` — 禁止 `/model` 切换生图；`Background task started` 后只回复一句
- **Sync:** API Keys 页 OpenClaw 接入改为默认话术 + 可选模型 chips（v1.1.4）

### 1.1.3

- **New:** `references/model-picker.md` — 生图 1–8、生视频 1–6 编号菜单与 Agent 话术模板
- **Docs:** `openclaw-agent-behavior.md` — 生图前必须弹出编号菜单；禁止向用户提及 OpenRouter
- **Docs:** `SKILL.md` — 编号选模型用户话术；`always: true` + systemPrompt 注入 ClawBBA 品牌规则
- **Fix:** `setup.sh` 安装后提示编号引导与 OpenRouter 翻译说明
- **Sync:** API Keys 页 OpenClaw 一键接入与生图模型编号 chips 对齐

### 1.1.1

- **Fix:** 安装时向 `models.json` / `openclaw.json` 写入**真实** `cbb_sk_live_…`（不再使用 `${CLAWBBA_API_KEY}` 占位符，避免 WebChat `403 Your request was blocked`）
- **Fix:** 为 `clawbba` / `openrouter` provider 添加 `headers.User-Agent`（OpenClaw pi 客户端兼容）
- **New:** `scripts/fix-provider-config.mjs` — 已装 1.1.0 用户一键修复
- **New:** `scripts/verify-openclaw-runtime.mjs` — 安装后自检（setup 失败则中断）
- **Docs:** `references/error-translation.md` — 禁止向用户复述 OpenRouter；工具报错翻译模板
- **Fix:** skill `always: true` + `agents.defaults.systemPrompt` 注入 ClawBBA 品牌规则（安装时写入）
- **Docs:** `references/clawbba-media-models.md` — 全部生图/生视频 model_id、用户话术模板、模型切换说明
- **Docs:** 完善 `media-generation.md` / `onboarding.md` 与 API Keys 页模型一键复制话术

### 1.1.0

- 全量模型 catalog、sync agent `models.json`、公网一键安装脚本

## License

MIT-0 (see [LICENSE](./LICENSE)). Publishing on ClawHub releases this skill under MIT-0 per ClawHub policy.

## Links

- API base: `https://www.clawbba.com/api/v1`
- Docs in skill: `references/onboarding.md`, `references/api-endpoints.md`
- Publish guide: [PUBLISH.md](./PUBLISH.md)
