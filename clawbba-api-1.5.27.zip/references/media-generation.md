# ClawBBA × OpenClaw 媒体生成（生图 / 生视频）

`setup.sh` 写入的配置会：

1. 注册 **对话** provider：`clawbba` → `https://www.clawbba.com/api/v1`
2. 将 OpenClaw 内置媒体通道的 `baseUrl` 同样指向 ClawBBA（OpenClaw ≥ 2026.5）
3. 设置 `agents.defaults.imageGenerationModel` / `videoGenerationModel`
4. 在 `agents.defaults.models` 各模型下写入 `params.clawbbaImage` / `params.clawbbaVideo`

用户只需 export **`CLAWBBA_API_KEY`**；`setup.sh` 会在 `openclaw.json` 写入生图/生视频所需的全部 env。

## 用户推荐话术（WebChat 直接复制）

话术使用 **ClawBBA 自然语言**，无需写 `image_generate`；可选 **`模型 {model_id}`** 切换任意已安装模型。完整模型表见 `references/clawbba-media-models.md`。

| 场景 | 输入示例 |
|------|----------|
| 竖图（默认模型） | `请使用 ClawBBA 生成图片能力，为我生成 9:16 竖图：（描述）` |
| 竖图（指定模型） | `请使用 ClawBBA 生成图片能力，模型 google/gemini-3.1-flash-image-preview，为我生成 9:16 竖图：（描述）` |
| 横图 2K | `请使用 ClawBBA 生成图片能力，模型 black-forest-labs/flux.2-pro，为我生成 16:9、2K：（描述）` |
| 生视频（默认） | `请使用 ClawBBA 生成视频能力，为我生成 16:9、8 秒视频：（描述）` |
| 生视频（指定模型） | `请使用 ClawBBA 生成视频能力，模型 google/veo-3.1-fast，为我生成 9:16、5 秒视频：（描述）` |
| 文本对话 | `/model clawbba/google/gemini-2.0-flash-001` |

**不要**在话术里写 OpenRouter、curl 或工具内部名；ClawBBA 安装后**全部**生图/生视频模型均可通过 `模型 …` 选用。

## Agent 应如何呈现结果

生图成功后，Agent **必须**用 Markdown 嵌入图片，而不是只给裸 URL：

```markdown
生图/生视频完成后 Agent 在 assistant 回复写 **`MEDIA:/root/.openclaw/media/...`**（见 `media-delivery-local.md`），不要只给裸 URL。
```

### 为什么有时只看到链接？

1. **Agent 未用 `![alt](url)`** — 纯文本 URL 在 WebChat 里不会自动预览
2. **OpenClaw WebChat 限制** — 部分版本对工具返回的图片不会内联渲染；Markdown 图片 + 可点击链接是正确交付方式
3. **异步完成** — `image_generate` 可能先返回 `Background task started … Do not call image_generate again`；Agent 应等待完成事件，**不要**重复调用或改用 curl

完整 Agent 规则见 `references/openclaw-agent-behavior.md`。

## 前置条件

```bash
export CLAWBBA_API_KEY='cbb_sk_live_你的密钥'
./scripts/setup.sh --yes
openclaw config validate
openclaw gateway restart
# WebChat 新开对话
```

## 生图：`image_generate` 工具

- 默认模型：`agents.defaults.imageGenerationModel.primary`（如 `openrouter/google/gemini-3.1-flash-image-preview`）
- 实际请求：`POST https://www.clawbba.com/api/v1/chat/completions`
- 单张费用通常约 **$0.05–0.15**（以 estimate 为准）

工具参数：

| 工具参数 | 对应 API | 常见值 |
|----------|----------|--------|
| `aspectRatio` | `image_config.aspect_ratio` | `1:1`, `16:9`, `9:16`, `4:3` |
| `resolution` | `image_config.image_size` | `1K`, `2K`, `4K` |
| `image` / `images` | messages 内参考图（图生图 / edit） | 本机路径、`file://`、`data:` 或 `https://`；WebChat 上传后须写入工具参数（见 `media-dispatch-spec.md` §3.1.1） |

各模型允许的枚举见 patch 中 `params.clawbbaImage`，或 `GET /api/v1/models`。

### 检查工具是否可用

```
/tool image_generate action=list
```

应显示已配置的 ClawBBA 生图通道（OpenClaw UI 可能仍显示 “OpenRouter” 标签，对用户说明为 **ClawBBA 内置生图** 即可）。

## 生视频：`video_generate` 工具

- 默认模型：`agents.defaults.videoGenerationModel.primary`
- 实际请求：`POST https://www.clawbba.com/api/v1/videos`，轮询 `GET /api/v1/videos/:jobId`
- 生成较慢（常 3–15 分钟），OpenClaw 会在后台轮询；**超时或用户未收到文件时禁止再次 generate**（避免二次扣费）

### 视频补发（1.5.1+ recover；1.5.2+ content 下载修复，数字资产恢复）

| 场景 | Agent 操作 |
|------|------------|
| 用户说「视频好了但没收到」/ 日志 fetch timeout | `video_generate action=tasks` 查 jobId |
| 任务 status=completed（ClawBBA 已扣费） | `video_generate action=recover jobId=<id> timeoutMs=600000` |
| 仍 pending | 等待后 **再次 recover 同一 jobId**，不要重新 generate |

recover 会轮询 ClawBBA 直至 completed，下载到 `~/.openclaw/media/tool-video-generation/`，在回复中写 `MEDIA:<本地路径>`。

```
/tool video_generate action=tasks
/tool video_generate action=recover jobId=gen_xxx timeoutMs=600000
```

| 工具参数 | API 字段 | 说明 |
|----------|----------|------|
| `aspectRatio` | `aspect_ratio` | 如 `16:9`, `9:16` |
| `duration` | `duration` | 秒数 |
| `resolution` | `resolution` | 如 `720p`, `1080p` |
| `audio` | `generate_audio` | 是否生成音频 |

```
/tool video_generate action=list
```

## 切换生图 / 生视频模型

**方式 A — 每次话术指定（推荐）**

```
请使用 ClawBBA 生成图片能力，模型 black-forest-labs/flux.2-pro，为我生成 9:16 竖图：…
```

**方式 B — 改 OpenClaw 默认**

```bash
openclaw config set agents.defaults.imageGenerationModel.primary openrouter/black-forest-labs/flux.2-pro
openclaw config set agents.defaults.videoGenerationModel.primary openrouter/google/veo-3.1
openclaw gateway restart
```

常用 model_id 与友好名：`references/clawbba-media-models.md`  
运行时列表：`/tool image_generate action=list`、`/tool video_generate action=list`

## 更新参数 catalog

```bash
./scripts/setup.sh --yes
```

## 故障排查

| 现象 | 处理 |
|------|------|
| 没有 `image_generate` / `video_generate` | OpenClaw ≥ 2026.5；重跑一键安装；`openclaw gateway restart` |
| 工具存在但 401 / 403 | 重跑 `install-clawbba-api.sh` 或 `fix-provider-config.mjs`；确认 Key 为真实 `cbb_sk_live_…` 而非占位符 |
| 报「余额不足」但账户有余额 | 多为 **鉴权/配置**（401），不是 CDKey；见 `openclaw-agent-behavior.md`，勿反复 estimate |
| 生图/生视频成功但用户要追问 | 升级 **1.1.6+**，重跑 setup；见 `media-delivery-local.md` |
| Agent 长篇诊断、只给 URL | 更新 skill 至 1.1.5+；Agent 须读 `openclaw-agent-behavior.md` |
| `Background task started` 后又重复生图 | Agent 应等待完成，禁止再次 `image_generate` |
| 视频一直 pending | `openclaw tasks list` 或轮询 `/api/v1/videos/:jobId` |
| 参数被忽略 | 查 `params.clawbbaImage` / `clawbbaVideo` 允许枚举 |

## OpenClaw 版本

需 **OpenClaw 2026.5+**（内置生图/生视频扩展）。升级：

```bash
npm i -g openclaw@latest
openclaw --version
```

## 高级：手动 curl（调试 API，非 Agent 默认路径）

Agent **不应**用 curl 代替 `image_generate`，除非用户明确要求 API 调试。

```bash
curl -X POST https://www.clawbba.com/api/v1/chat/completions \
  -H "Authorization: Bearer $CLAWBBA_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "google/gemini-3-pro-image-preview",
    "messages": [{"role": "user", "content": "a cat"}],
    "modalities": ["image"],
    "image_config": {"aspect_ratio": "16:9", "image_size": "2K"}
  }'
```
