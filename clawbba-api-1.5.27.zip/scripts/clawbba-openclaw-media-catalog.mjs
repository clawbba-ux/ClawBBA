/**
 * ClawBBA × OpenClaw 生图/生视频 — 唯一配置源（安装脚本 + 官网 API Keys 页）
 * @see references/clawbba-media-models.md
 */

export const CLAWBBA_SKILL_VERSION = '1.5.27'

export const CLAWBBA_INSTALL_BASE = 'https://www.clawbba.com/downloads'

export const DEFAULT_IMAGE_MODEL_ID = 'google/gemini-3.1-flash-image-preview'
export const DEFAULT_IMAGE_MODEL_LABEL = 'Nano Banana 2'

export const DEFAULT_VIDEO_MODEL_ID = 'google/veo-3.1-fast'
export const DEFAULT_VIDEO_MODEL_LABEL = 'Veo 3.1 Fast'

/** generate-openclaw-patch.mjs 选默认生图/生视频时的优先级 */
export const PATCH_IMAGE_MODEL_PREFER = [
  'google/gemini-3.1-flash-image-preview',
  'google/gemini-3-pro-image-preview',
  'google/gemini-2.5-flash-image',
  'openai/gpt-5.4-image-2',
]

export const PATCH_VIDEO_MODEL_PREFER = [
  'google/veo-3.1-fast',
  'google/veo-3.1',
  'alibaba/wan-2.6',
  'openai/sora-2-pro',
]

export const IMAGE_PARAM_ROWS = [
  ['9:16 竖图 / 竖版', '宽高比 9:16（手机壁纸、短视频封面）'],
  ['16:9 横图 / 横版', '宽高比 16:9（横幅、桌面壁纸）'],
  ['1:1 方图', '宽高比 1:1（头像、电商主图）'],
  ['4:3 / 3:4', '其它常见比例，写在话术里即可'],
  ['2K / 4K', '清晰度（部分模型支持，如 Nano Banana Pro、FLUX）'],
  ['参考图 / 图生图', '附上本地图片路径或 URL，说明「按参考图风格」'],
]

export const VIDEO_PARAM_ROWS = [
  ['16:9 / 9:16', '横版或竖版视频'],
  ['5 秒 / 8 秒 / 10 秒', '时长（写在话术里，如「8 秒视频」）'],
  ['720p / 1080p', '分辨率（视模型支持）'],
  ['带音频 / 不要音频', '是否生成声音（部分模型支持）'],
]

/**
 * 生图模型示例（与站内目录一致；未上架的 id 会在 API 指南里自动过滤）
 * ratio / resolution 为推荐示例参数
 */
export const IMAGE_MODEL_SPECS = [
  {
    id: 'google/gemini-3.1-flash-image-preview',
    label: 'Nano Banana 2',
    note: '默认 · 速度快',
    ratio: '9:16',
    resolution: '',
    featured: true,
  },
  {
    id: 'google/gemini-3-pro-image-preview',
    label: 'Nano Banana Pro',
    note: '高质量 · 支持 2K',
    ratio: '9:16',
    resolution: '2K',
  },
  {
    id: 'google/gemini-2.5-flash-image',
    label: 'Nano Banana',
    note: '经济型',
    ratio: '1:1',
    resolution: '',
  },
  {
    id: 'black-forest-labs/flux.2-pro',
    label: 'FLUX.2 Pro',
    note: '写实风格',
    ratio: '16:9',
    resolution: '',
    featured: true,
  },
  {
    id: 'black-forest-labs/flux.2-max',
    label: 'FLUX.2 Max',
    note: '旗舰 FLUX',
    ratio: '16:9',
    resolution: '',
  },
  {
    id: 'black-forest-labs/flux.2-flex',
    label: 'FLUX.2 Flex',
    note: '灵活构图',
    ratio: '16:9',
    resolution: '',
  },
  {
    id: 'black-forest-labs/flux.2-klein-4b',
    label: 'FLUX.2 Klein',
    note: '轻量',
    ratio: '1:1',
    resolution: '',
  },
  {
    id: 'bytedance-seed/seedream-4.5',
    label: 'Seedream 4.5',
    note: '字节 Seedream',
    ratio: '9:16',
    resolution: '',
  },
  {
    id: 'openai/gpt-5.4-image-2',
    label: 'GPT-5.4 Image',
    note: 'OpenAI 生图',
    ratio: '1:1',
    resolution: '',
  },
  {
    id: 'openai/gpt-5-image',
    label: 'GPT-5 Image',
    note: 'OpenAI',
    ratio: '1:1',
    resolution: '',
  },
  {
    id: 'openai/gpt-5-image-mini',
    label: 'GPT-5 Image Mini',
    note: '经济',
    ratio: '1:1',
    resolution: '',
  },
  {
    id: 'x-ai/grok-imagine-image-quality',
    label: 'Grok Imagine',
    note: 'xAI 高质量',
    ratio: '9:16',
    resolution: '',
  },
  {
    id: 'sourceful/riverflow-v2-pro',
    label: 'Riverflow Pro',
    note: 'Sourceful',
    ratio: '16:9',
    resolution: '',
  },
]

export const VIDEO_MODEL_SPECS = [
  {
    id: 'google/veo-3.1-fast',
    label: 'Veo 3.1 Fast',
    note: '默认 · 速度快',
    ratio: '16:9',
    duration: 8,
    featured: true,
  },
  {
    id: 'google/veo-3.1',
    label: 'Veo 3.1',
    note: '高质量',
    ratio: '16:9',
    duration: 8,
    featured: true,
  },
  {
    id: 'google/veo-3.1-lite',
    label: 'Veo 3.1 Lite',
    note: '经济',
    ratio: '9:16',
    duration: 5,
  },
  {
    id: 'bytedance/seedance-2.0',
    label: 'Seedance 2.0',
    note: '字节 Seedance',
    ratio: '9:16',
    duration: 5,
    featured: true,
  },
  {
    id: 'bytedance/seedance-2.0-fast',
    label: 'Seedance 2.0 Fast',
    note: '快速',
    ratio: '9:16',
    duration: 5,
  },
  {
    id: 'bytedance/seedance-1-5-pro',
    label: 'Seedance 1.5 Pro',
    note: '上一代 Pro',
    ratio: '16:9',
    duration: 8,
  },
  {
    id: 'kwaivgi/kling-v3.0-pro',
    label: 'Kling 3.0 Pro',
    note: '可灵 Pro',
    ratio: '16:9',
    duration: 8,
    featured: true,
  },
  {
    id: 'kwaivgi/kling-v3.0-std',
    label: 'Kling 3.0 Standard',
    note: '可灵标准',
    ratio: '16:9',
    duration: 8,
  },
  {
    id: 'openai/sora-2-pro',
    label: 'Sora 2 Pro',
    note: 'OpenAI 视频',
    ratio: '16:9',
    duration: 8,
  },
  {
    id: 'alibaba/wan-2.7',
    label: 'Wan 2.7',
    note: '阿里万相',
    ratio: '16:9',
    duration: 8,
  },
  {
    id: 'alibaba/wan-2.6',
    label: 'Wan 2.6',
    note: '阿里',
    ratio: '16:9',
    duration: 8,
  },
  {
    id: 'minimax/hailuo-2.3',
    label: 'Hailuo 2.3',
    note: 'MiniMax',
    ratio: '9:16',
    duration: 5,
  },
  {
    id: 'x-ai/grok-imagine-video',
    label: 'Grok Imagine Video',
    note: 'xAI',
    ratio: '16:9',
    duration: 8,
  },
]

export const OPENCLAW_IMAGE_EXAMPLE_DESC =
  '赛博朋克城市夜景，霓虹灯与雨雾，电影感构图'

export const OPENCLAW_VIDEO_EXAMPLE_DESC = '海浪拍打礁石，电影感航拍，慢镜头'

export function toOpenClawMediaPrimary(platformModelId) {
  return `openrouter/${String(platformModelId || '').trim()}`
}

export function buildOpenclawImagePrompt(opts = {}) {
  const {
    modelId,
    description = OPENCLAW_IMAGE_EXAMPLE_DESC,
    ratio = '9:16',
    resolution,
  } = opts
  const modelPart = modelId ? `，模型 ${modelId}` : ''
  const ratioLabel =
    ratio === '9:16' ? '竖图' : ratio === '16:9' ? '横图' : ratio === '1:1' ? '方图' : '图片'
  const geoParts = [ratio, resolution].filter(Boolean)
  const geo = geoParts.length
    ? `${geoParts.join('、')}${ratioLabel ? ` ${ratioLabel}` : ''}`
    : ratioLabel
  return `请使用 ClawBBA 生成图片能力${modelPart}，为我生成 ${geo}：${description}`
}

export function buildOpenclawVideoPrompt(opts = {}) {
  const {
    modelId,
    description = OPENCLAW_VIDEO_EXAMPLE_DESC,
    ratio = '16:9',
    duration = 8,
    resolution,
    audio,
  } = opts
  const modelPart = modelId ? `，模型 ${modelId}` : ''
  const parts = [ratio, `${duration} 秒`]
  if (resolution) parts.push(resolution)
  if (audio === true) parts.push('带音频')
  if (audio === false) parts.push('不要音频')
  return `请使用 ClawBBA 生成视频能力${modelPart}，为我生成 ${parts.join('、')}视频：${description}`
}

export function mergeMediaSpecsWithCatalogRows(specs, catalogRows, category) {
  const enabled = new Set(
    catalogRows
      .filter((r) => String(r.model_category || '').toLowerCase() === category)
      .map((r) => String(r.model_id || '').trim())
      .filter(Boolean),
  )
  const specById = new Map(specs.map((s) => [s.id, s]))
  const out = []
  for (const spec of specs) {
    if (enabled.size && !enabled.has(spec.id)) continue
    const row = catalogRows.find((r) => r.model_id === spec.id)
    out.push({
      ...spec,
      name: row?.name || spec.label,
      openclaw_model_ref: toOpenClawMediaPrimary(spec.id),
    })
  }
  for (const row of catalogRows) {
    if (String(row.model_category || '').toLowerCase() !== category) continue
    const id = String(row.model_id || '').trim()
    if (!id || specById.has(id)) continue
    out.push({
      id,
      label: row.name || id.split('/').pop(),
      note: '站内可用',
      ratio: category === 'image' ? '9:16' : '16:9',
      duration: category === 'video' ? 8 : undefined,
      resolution: '',
      name: row.name || id,
      openclaw_model_ref: toOpenClawMediaPrimary(id),
    })
  }
  return out
}
