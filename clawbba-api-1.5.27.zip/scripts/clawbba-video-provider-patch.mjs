/**
 * OpenClaw openrouter video-generation-provider patches (ClawBBA).
 * - Strip openrouter/clawbba prefix from model before POST /videos (upstream expects google/veo-…)
 * - Raise submit HTTP timeout (default 60s aborts slow ClawBBA proxy + OR submit)
 */
import fs from 'fs'
import path from 'path'

export const VIDEO_PROVIDER_MARKER = '/* clawbba-video-provider */'
export const VIDEO_HTTP_TIMEOUT_MARKER = '/* clawbba-video-http-timeout */'
export const VIDEO_POLL_EXTEND_MARKER = '/* clawbba-video-poll-extended */'
export const VIDEO_DOWNLOAD_PREFER_CONTENT_MARKER = '/* clawbba-video-download-prefer-content */'

function findOpenRouterVideoProviderFile(dist) {
  return fs.readdirSync(dist).find((name) => {
    if (!name.startsWith('video-generation-provider-') || !name.endsWith('.js')) return false
    const src = fs.readFileSync(path.join(dist, name), 'utf8')
    return (
      src.includes('id: "openrouter"') &&
      src.includes('auditContext: "openrouter-video-submit"') &&
      src.includes('async generateVideo(req)')
    )
  })
}

const MODEL_LINE_NEEDLE = '\t\t\tconst model = normalizeOptionalString(req.model) ?? DEFAULT_MODEL;'
const MODEL_LINE_REPLACEMENT = `\t\t\t${VIDEO_PROVIDER_MARKER}
\t\t\tlet model = normalizeOptionalString(req.model) ?? DEFAULT_MODEL;
\t\t\tmodel = model.replace(/^(openrouter|clawbba)\\//i, "");`

const HTTP_TIMEOUT_NEEDLE = 'const DEFAULT_HTTP_TIMEOUT_MS = 6e4;'
const HTTP_TIMEOUT_REPLACEMENT = `${VIDEO_HTTP_TIMEOUT_MARKER}
const DEFAULT_HTTP_TIMEOUT_MS = 3e5;`

const POLL_ATTEMPTS_NEEDLE = 'const MAX_POLL_ATTEMPTS = 120;'
const POLL_ATTEMPTS_REPLACEMENT = `${VIDEO_POLL_EXTEND_MARKER}
const MAX_POLL_ATTEMPTS = 720;`

const POLL_HTTP_NEEDLE = 'defaultTimeoutMs: DEFAULT_HTTP_TIMEOUT_MS\n\t\t\t}),\n\t\t\terrorContext: "OpenRouter video status request failed"'
const POLL_HTTP_REPLACEMENT = 'defaultTimeoutMs: 3e5\n\t\t\t}),\n\t\t\terrorContext: "OpenRouter video status request failed"'

const SUBMIT_HTTP_NEEDLE = 'defaultTimeoutMs: DEFAULT_HTTP_TIMEOUT_MS\n\t\t\t}),\n\t\t\tfetchFn: fetch,\n\t\t\tallowPrivateNetwork,\n\t\t\tdispatcherPolicy,\n\t\t\tauditContext: "openrouter-video-submit"'
const SUBMIT_HTTP_REPLACEMENT = 'defaultTimeoutMs: 3e5\n\t\t\t}),\n\t\t\tfetchFn: fetch,\n\t\t\tallowPrivateNetwork,\n\t\t\tdispatcherPolicy,\n\t\t\tauditContext: "openrouter-video-submit"'

const DOWNLOAD_URL_NEEDLE =
  '\t\t\t\t\tvideos: [await downloadOpenRouterVideo({\n\t\t\t\t\t\turl: completed.unsigned_urls?.find((url) => normalizeOptionalString(url)) ?? resolveOpenRouterContentUrl({\n\t\t\t\t\t\t\tbaseUrl,\n\t\t\t\t\t\t\tjobId: completedJobId\n\t\t\t\t\t\t}),'

const DOWNLOAD_URL_REPLACEMENT = `\t\t\t\t\tvideos: [await downloadOpenRouterVideo({
\t\t\t\t\t\turl: (() => {
\t\t\t\t\t\t\t${VIDEO_DOWNLOAD_PREFER_CONTENT_MARKER}
\t\t\t\t\t\t\tconst contentUrl = resolveOpenRouterContentUrl({
\t\t\t\t\t\t\t\tbaseUrl,
\t\t\t\t\t\t\t\tjobId: completedJobId
\t\t\t\t\t\t\t});
\t\t\t\t\t\t\tconst bu = String(baseUrl || "");
\t\t\t\t\t\t\tif (!bu.includes("openrouter.ai") && normalizeOptionalString(contentUrl)) {
\t\t\t\t\t\t\t\treturn contentUrl;
\t\t\t\t\t\t\t}
\t\t\t\t\t\t\treturn completed.unsigned_urls?.find((url) => normalizeOptionalString(url)) ?? contentUrl;
\t\t\t\t\t\t})(),`

/**
 * @param {string} dist
 * @returns {'patched'|'skip'|'missing'|'pattern-missing'}
 */
export function patchOpenRouterVideoProvider(dist) {
  const file = findOpenRouterVideoProviderFile(dist)
  if (!file) return 'missing'

  const filePath = path.join(dist, file)
  let src = fs.readFileSync(filePath, 'utf8')
  let changed = false

  if (src.includes(VIDEO_PROVIDER_MARKER)) {
    if (!src.includes('model.replace(/^(openrouter|clawbba)')) {
      return 'pattern-missing'
    }
  } else if (src.includes(MODEL_LINE_NEEDLE)) {
    src = src.replace(MODEL_LINE_NEEDLE, MODEL_LINE_REPLACEMENT)
    changed = true
  } else {
    return 'pattern-missing'
  }

  if (!src.includes(VIDEO_HTTP_TIMEOUT_MARKER)) {
    if (src.includes(HTTP_TIMEOUT_NEEDLE)) {
      src = src.replace(HTTP_TIMEOUT_NEEDLE, HTTP_TIMEOUT_REPLACEMENT)
      changed = true
    } else if (!src.includes('DEFAULT_HTTP_TIMEOUT_MS = 3e5')) {
      // already patched with different value
    }
  }

  if (!src.includes(VIDEO_POLL_EXTEND_MARKER) && src.includes(POLL_ATTEMPTS_NEEDLE)) {
    src = src.replace(POLL_ATTEMPTS_NEEDLE, POLL_ATTEMPTS_REPLACEMENT)
    changed = true
  }

  if (src.includes(POLL_HTTP_NEEDLE)) {
    src = src.replace(POLL_HTTP_NEEDLE, POLL_HTTP_REPLACEMENT)
    changed = true
  }

  if (src.includes(SUBMIT_HTTP_NEEDLE)) {
    src = src.replace(SUBMIT_HTTP_NEEDLE, SUBMIT_HTTP_REPLACEMENT)
    changed = true
  }

  if (!src.includes(VIDEO_DOWNLOAD_PREFER_CONTENT_MARKER)) {
    if (src.includes(DOWNLOAD_URL_NEEDLE)) {
      src = src.replace(DOWNLOAD_URL_NEEDLE, DOWNLOAD_URL_REPLACEMENT)
      changed = true
    } else if (!src.includes('clawbba-video-download-prefer-content')) {
      // pattern may differ across openclaw versions
    }
  }

  if (changed) {
    fs.writeFileSync(filePath, src)
    return 'patched'
  }
  return 'skip'
}
