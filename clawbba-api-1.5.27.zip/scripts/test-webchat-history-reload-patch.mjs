#!/usr/bin/env node
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { execSync } from 'node:child_process'
import { patchSubagentAnnounceDeliveryDist } from './openclaw-announce-patch.mjs'
import { patchWebChatLiveInjectHelperInToolsFile } from './clawbba-webchat-live-inject.mjs'

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'clawbba-reload-'))
execSync('npm pack openclaw@2026.5.27 --silent', { cwd: tmp, stdio: 'pipe' })
const tgz = fs.readdirSync(tmp).find((n) => n.endsWith('.tgz'))
execSync(`tar -xzf ${JSON.stringify(tgz)}`, { cwd: tmp })
const dist = path.join(tmp, 'package', 'dist')
const findDistFile = (_dist, prefix) => fs.readdirSync(_dist).find((n) => n.startsWith(prefix))

const announce = findDistFile(dist, 'subagent-announce-delivery-')
const gateway = findDistFile(dist, 'gateway-request-scope-')
const globalSingleton = findDistFile(dist, 'global-singleton-')
const tools = findDistFile(dist, 'openclaw-tools-')
const plugins = findDistFile(dist, 'server-plugins-')

assert.ok(announce && gateway && globalSingleton && tools && plugins)

const announceResult = patchSubagentAnnounceDeliveryDist(dist, findDistFile)
assert.match(String(announceResult), /patched|skip|deduped|live-helper/)

const announceSrc = fs.readFileSync(path.join(dist, announce), 'utf8')
assert.ok(announceSrc.includes('clawbbaBroadcastWebChatSessionReload'))
assert.ok(announceSrc.includes('clawbbaInjectWebChatGeneratedMediaLive'))

assert.equal(
  patchWebChatLiveInjectHelperInToolsFile(
    path.join(dist, tools),
    plugins,
    globalSingleton,
    gateway,
  ),
  'patched',
)
const toolsSrc = fs.readFileSync(path.join(dist, tools), 'utf8')
assert.ok(toolsSrc.includes('clawbbaBroadcastWebChatSessionReload'))
assert.ok(toolsSrc.includes('clawbbaPickModuleExport'))
assert.ok(toolsSrc.includes('clawbbaPickModuleExport(pluginsModule, "dispatchGatewayMethodInProcess", ["r"])'))
assert.ok(toolsSrc.includes('return bestRunId || pref || null'))
assert.ok(toolsSrc.includes('session.message'))

console.log('test-webchat-history-reload-patch: ok')
