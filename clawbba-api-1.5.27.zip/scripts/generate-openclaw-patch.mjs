#!/usr/bin/env node
/**
 * 从 ClawBBA /api/v1/models 生成 openclaw config patch（JSON5 兼容 JSON）
 * 含生图/生视频参数 + OpenClaw 媒体工具（image_generate / video_generate）对接。
 *
 * OpenClaw ≥ 2026.5：内置 OpenRouter 扩展提供 image_generate / video_generate；
 * 将 models.providers.openrouter.baseUrl 指向 ClawBBA Platform API 即可复用同一套
 * OpenAI 兼容生图（chat/completions + modalities）与生视频（/videos）协议。
 *
 * 用法: CLAWBBA_API_KEY=... node scripts/generate-openclaw-patch.mjs
 */
import {
  buildClawbbaProviderBlock,
  buildMinimalModelDefinition,
  buildOpenclawEnvBlock,
  buildOpenrouterMediaModelsFromCatalogRows,
  buildOpenrouterProviderBlock,
} from './openclaw-provider-block.mjs'
import { CLAWBBA_AGENT_SYSTEM_RULES } from './clawbba-agent-rules.mjs'
import {
  PATCH_IMAGE_MODEL_PREFER,
  PATCH_VIDEO_MODEL_PREFER,
} from './clawbba-openclaw-media-catalog.mjs'
import {
  applyVisionInputToProviderEntry,
  normCatalogCategory,
  resolveImageModelPrimary,
  rowSupportsVisionInput,
} from './clawbba-vision-models.mjs'

const API_BASE = (process.env.CLAWBBA_API_BASE || 'https://www.clawbba.com/api/v1').replace(/\/$/, '')
const API_KEY = String(process.env.CLAWBBA_API_KEY || '').trim()

if (!API_KEY) {
  console.error('错误: 请设置环境变量 CLAWBBA_API_KEY')
  process.exit(1)
}
if (!API_KEY.startsWith('cbb_sk_live_')) {
  console.error('错误: CLAWBBA_API_KEY 应以 cbb_sk_live_ 开头（Platform API Key）')
  process.exit(1)
}

async function fetchJson(path) {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { Authorization: `Bearer ${API_KEY}`, Accept: 'application/json' },
  })
  const text = await res.text()
  let body
  try {
    body = text ? JSON.parse(text) : {}
  } catch {
    throw new Error(`HTTP ${res.status}: 非 JSON 响应`)
  }
  if (!res.ok) {
    const msg = body.error || body.message || text.slice(0, 200) || res.statusText
    throw new Error(`HTTP ${res.status}: ${msg}`)
  }
  return body
}

function normCat(m) {
  return normCatalogCategory(m)
}

function pickDefaultModelId(models) {
  const prefer = [
    'google/gemini-2.5-flash-preview',
    'google/gemini-2.0-flash-001',
    'anthropic/claude-sonnet-4',
    'openai/gpt-4o-mini',
  ]
  const ids = models.map((m) => m.id)
  for (const p of prefer) {
    if (ids.includes(p)) return p
  }
  const textLike = models.find(
    (m) =>
      normCat(m) === 'text' &&
      !/image|video|tts|audio|embedding/i.test(String(m.id)),
  )
  return textLike?.id || models.find((m) => normCat(m) === 'text')?.id || models[0]?.id
}

function pickFirstModelId(models, preferList, category) {
  const ids = new Set(models.map((m) => m.id))
  for (const p of preferList) {
    if (ids.has(p)) return p
  }
  const hit = models.find((m) => normCat(m) === category)
  return hit?.id || null
}

function compactMediaParams(opts) {
  if (!opts || typeof opts !== 'object') return undefined
  const out = {}
  const keys = [
    'modalities',
    'aspect_ratios',
    'default_aspect_ratio',
    'image_sizes',
    'default_image_size',
    'supports_image_input',
    'supports_strength',
    'default_strength',
    'max_reference_images',
    'duration_presets',
    'default_duration',
    'resolutions',
    'resolutions_text',
    'resolutions_image',
    'show_audio_toggle',
    'default_generate_audio',
    'supports_image_to_video',
    'supported_frame_types',
    'supports_seed',
    'skus',
  ]
  for (const k of keys) {
    if (opts[k] !== undefined && opts[k] !== null) out[k] = opts[k]
  }
  return Object.keys(out).length ? out : undefined
}

/** OpenClaw clawbba provider 模型条目（catalog category 为准，勿用 id 正则误判生图模型） */
function toProviderModel(m) {
  const id = String(m.id || '').trim()
  const cat = normCat(m)
  const category = cat === 'image' ? 'image' : cat === 'video' ? 'video' : 'text'
  const entry = buildMinimalModelDefinition(id, m.name || id, category, {
    visionText: category === 'text' && rowSupportsVisionInput(m),
  })
  applyVisionInputToProviderEntry(entry, m)
  const ctx = Number(m.context_length)
  if (Number.isFinite(ctx) && ctx > 0) entry.contextWindow = ctx
  return entry
}

function agentModelEntry(m) {
  const id = String(m.id || '').trim()
  const cat = normCat(m)
  const entry = {}
  const imageParams = compactMediaParams(m.image_options)
  const videoParams = compactMediaParams(m.video_options)
  if (imageParams) entry.params = { ...entry.params, clawbbaImage: imageParams }
  if (videoParams) entry.params = { ...entry.params, clawbbaVideo: videoParams }
  if (cat === 'image') {
    entry.alias = entry.alias || id.split('/').pop()?.slice(0, 48) || 'clawbba-image'
  }
  if (cat === 'video') {
    entry.alias = entry.alias || id.split('/').pop()?.slice(0, 48) || 'clawbba-video'
  }
  return entry
}

async function main() {
  const balance = await fetchJson('/account/balance')
  const list = await fetchJson('/models')
  const rows = Array.isArray(list.data) ? list.data : []
  if (!rows.length) {
    throw new Error('模型列表为空，请确认账户与站点配置')
  }

  const providerModels = rows.map(toProviderModel).filter((m) => m.id)
  const openrouterMediaModels = buildOpenrouterMediaModelsFromCatalogRows(rows)
  const defaultTextId = pickDefaultModelId(rows)
  const defaultImageId = pickFirstModelId(rows, PATCH_IMAGE_MODEL_PREFER, 'image')
  const defaultVideoId = pickFirstModelId(rows, PATCH_VIDEO_MODEL_PREFER, 'video')

  const agentModels = {}
  for (const m of rows) {
    const id = String(m.id || '').trim()
    if (!id) continue
    agentModels[`clawbba/${id}`] = agentModelEntry(m)
    if (normCat(m) === 'image' || normCat(m) === 'video') {
      const slug = id.split('/').pop()?.slice(0, 48) || id
      agentModels[`openrouter/${id}`] = { alias: `clawbba-${slug}` }
    }
  }

  const patch = {
    env: buildOpenclawEnvBlock(API_KEY),
    messages: {
      visibleReplies: 'automatic',
    },
    models: {
      mode: 'merge',
      providers: {
        clawbba: buildClawbbaProviderBlock(API_KEY, { models: providerModels }),
        openrouter: buildOpenrouterProviderBlock(API_KEY, { models: openrouterMediaModels }),
      },
    },
    agents: {
      defaults: {
        model: { primary: `clawbba/${defaultTextId}` },
        models: agentModels,
        systemPromptOverride: CLAWBBA_AGENT_SYSTEM_RULES,
      },
    },
    skills: {
      entries: {
        'clawbba-api': { enabled: true },
      },
    },
  }

  if (defaultImageId) {
    patch.agents.defaults.imageGenerationModel = {
      primary: `openrouter/${defaultImageId}`,
      timeoutMs: 180_000,
    }
  }

  if (defaultVideoId) {
    patch.agents.defaults.videoGenerationModel = {
      primary: `openrouter/${defaultVideoId}`,
      timeoutMs: 600_000,
    }
  }

  const imageModelPrimary = resolveImageModelPrimary(rows, defaultTextId)
  if (imageModelPrimary) {
    patch.agents.defaults.imageModel = { primary: imageModelPrimary }
  }

  process.stdout.write(`${JSON.stringify(patch, null, 2)}\n`)
  const bits = [
    `balance_usd≈${balance.balance_usd ?? '?'}`,
    `models=${providerModels.length}`,
    `default=clawbba/${defaultTextId}`,
  ]
  if (defaultImageId) bits.push(`imageGen=ClawBBA/${defaultImageId}`)
  if (defaultVideoId) bits.push(`videoGen=ClawBBA/${defaultVideoId}`)
  if (imageModelPrimary) bits.push(`imageModel=${imageModelPrimary}`)
  process.stderr.write(
    `[clawbba-api] ${bits.join(' ')} allowlist=${Object.keys(agentModels).filter((k) => k.startsWith('clawbba/')).length}\n`,
  )
}

main().catch((e) => {
  console.error(`[clawbba-api] ${e.message || e}`)
  process.exit(1)
})
