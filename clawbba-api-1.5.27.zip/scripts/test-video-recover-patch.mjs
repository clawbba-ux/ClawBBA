#!/usr/bin/env node
/**
 * Smoke test: recover + WebChat live inject patch on openclaw@2026.5.27.
 */
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { execSync } from 'node:child_process'
import {
  patchVideoGenerateRecoverAction,
  upgradeVideoRecoverChatRunId,
  VIDEO_RECOVER_WEBCHAT_LIVE_MARKER,
} from './clawbba-video-recover-patch.mjs'
import { patchWebChatLiveInjectHelperInToolsFile } from './clawbba-webchat-live-inject.mjs'

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'clawbba-vid-recover-'))
const tgz = path.join(tmp, 'openclaw.tgz')
execSync(`npm pack openclaw@2026.5.27 --silent`, { cwd: tmp, stdio: 'pipe' })
const packed = fs.readdirSync(tmp).find((n) => n.endsWith('.tgz'))
fs.renameSync(path.join(tmp, packed), tgz)
execSync(`tar -xzf ${JSON.stringify(path.basename(tgz))}`, { cwd: tmp })

const dist = path.join(tmp, 'package', 'dist')
const toolsFile = fs.readdirSync(dist).find((n) => n.startsWith('openclaw-tools-'))
const pluginsFile = fs.readdirSync(dist).find((n) => n.startsWith('server-plugins-'))
const gatewayFile = fs.readdirSync(dist).find((n) => n.startsWith('gateway-request-scope-'))
const globalSingletonFile = fs.readdirSync(dist).find((n) => n.startsWith('global-singleton-'))
assert.ok(toolsFile, 'openclaw-tools bundle missing')
assert.ok(pluginsFile, 'server-plugins bundle missing')
assert.ok(gatewayFile, 'gateway-request-scope bundle missing')
assert.ok(globalSingletonFile, 'global-singleton bundle missing')
const toolsPath = path.join(dist, toolsFile)

assert.equal(
  patchWebChatLiveInjectHelperInToolsFile(toolsPath, pluginsFile, globalSingletonFile, gatewayFile),
  'patched',
)
assert.equal(patchVideoGenerateRecoverAction(toolsPath), 'patched')

const src = fs.readFileSync(toolsPath, 'utf8')
assert.ok(src.includes('clawbbaRecoverVideoTask'))
assert.ok(src.includes('clawbbaResolveOpenRouterApiKey'))
assert.ok(src.includes('clawbbaShouldInjectWebChatMediaLive'))
assert.ok(src.includes('clawbbaDispatchWebChatMediaLiveInject'))
assert.ok(src.includes('clawbbaBroadcastWebChatSessionReload'))
assert.ok(src.includes('clawbbaResolveGatewayBroadcastContext'))
assert.ok(src.includes('chatRunId: options?.runId'))
assert.ok(src.includes(VIDEO_RECOVER_WEBCHAT_LIVE_MARKER))
assert.ok(src.includes('chatRunId,'))
assert.ok(!src.includes('clawbbaPromptWebChatHistoryReload'))
assert.ok(!src.includes('resolveApiKeyForProvider({ provider: "openrouter"'))

const upgraded = upgradeVideoRecoverChatRunId(src)
assert.equal(upgraded, src)

assert.equal(
  patchWebChatLiveInjectHelperInToolsFile(toolsPath, pluginsFile, globalSingletonFile, gatewayFile),
  'skip',
)
assert.equal(patchVideoGenerateRecoverAction(toolsPath), 'skip')

console.log('test-video-recover-patch: ok')
