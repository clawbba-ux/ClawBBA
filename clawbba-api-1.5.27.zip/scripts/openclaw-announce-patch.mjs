/**
 * OpenClaw subagent-announce-delivery patches（多版本兼容）
 * @see references/openclaw-compat.md
 */
import fs from 'fs'
import path from 'path'
import { dedupeClawbbaInjectHelperBlocks, escapeRegExp } from './clawbba-patch-dedupe.mjs'
import { buildWebChatHistoryReloadBlock, WEBCHAT_HISTORY_RELOAD_MARKER } from './clawbba-webchat-live-inject.mjs'

export const ANNOUNCE_MARKER = '/* clawbba-local-media-delivery */'
export const WEBCHAT_LIVE_MARKER = '/* clawbba-webchat-media-live */'

export const CLAWBBA_WEBCHAT_MEDIA_BLOCK = `\t\tconst clawbbaLocalMediaWebChatCompletion = (() => {
\t\t\tif (!agentMediatedCompletion || expectedMediaUrls.length === 0) return false;
\t\t\tconst tool = normalizeOptionalLowercaseString(params.sourceTool) ?? "";
\t\t\tif (tool !== "image_generate" && tool !== "video_generate") return false;
\t\t\tconst sessionKey = String(params.requesterSessionKey ?? params.targetRequesterSessionKey ?? "");
\t\t\tif (sessionKey.includes(":dashboard:")) return true;
\t\t\tconst ch = normalizeMessageChannel(requesterSessionOrigin?.channel ?? sessionOnlyOrigin?.channel ?? effectiveDirectOrigin?.channel ?? requesterEntry?.channel);
\t\t\treturn ch === "webchat";
\t\t})();`

/** Injects assistant MEDIA lines via chat.inject so WebChat updates without refresh. */
export function buildWebChatLiveHelper(globalSingletonBasename, gatewayRequestScopeBasename) {
  const reloadBlock = buildWebChatHistoryReloadBlock(globalSingletonBasename, gatewayRequestScopeBasename)
  return `${WEBCHAT_LIVE_MARKER}
${reloadBlock}
export async function clawbbaInjectWebChatGeneratedMediaLive(params) {
\tconst mediaUrls = Array.isArray(params.mediaUrls) ? params.mediaUrls.filter((url) => typeof url === "string" && url.trim().length > 0) : [];
\tif (mediaUrls.length === 0 || !params.sessionKey?.trim()) return false;
\tconst label = typeof params.completionLabel === "string" && params.completionLabel.trim() ? params.completionLabel.trim() : "media";
\tconst preset = typeof params.message === "string" ? params.message.trim() : "";
\tconst message = preset && preset.includes("MEDIA:") ? preset : [
\t\t\`The generated \${label} is ready.\`,
\t\t...mediaUrls.map((url) => \`MEDIA:\${url.trim()}\`)
\t].join("\\n");
\ttry {
\t\tconst injectResult = await subagentAnnounceDeliveryDeps.dispatchGatewayMethodInProcess("chat.inject", {
\t\t\tsessionKey: params.sessionKey.trim(),
\t\t\tmessage,
\t\t\tlabel: params.sourceTool === "video_generate" ? "ClawBBA video" : "ClawBBA image"
\t\t}, { timeoutMs: 3e4 });
\t\tawait clawbbaBroadcastWebChatSessionReload({
\t\t\tsessionKey: params.sessionKey.trim(),
\t\t\tchatRunId: params.chatRunId,
\t\t\tmediaMessage: message,
\t\t\tinjectMessageId: injectResult?.messageId
\t\t});
\t\treturn true;
\t} catch (err) {
\t\tdefaultRuntime.log(\`[warn] clawbba webchat media live inject failed: \${String(err?.message ?? err)}\`);
\t\treturn false;
\t}
}
`
}

export const WEBCHAT_LIVE_TRY_DIRECT_NEEDLE = `\t\tconst tryGeneratedMediaDirectDelivery = async (announceResponse) => {
\t\t\tif (requesterActivity.isActive && !activeRequesterWakeFailed) return;`

export const WEBCHAT_LIVE_TRY_DIRECT_REPLACEMENT = `\t\tconst tryGeneratedMediaDirectDelivery = async (announceResponse) => {
\t\t\tif (requesterActivity.isActive && !activeRequesterWakeFailed) {
\t\t\t\tif (clawbbaLocalMediaWebChatCompletion && expectedMediaUrls.length > 0) {
\t\t\t\t\tconst clawbbaLiveMediaUrls = resolveGeneratedMediaDirectFallbackUrls({
\t\t\t\t\t\texpectedMediaUrls,
\t\t\t\t\t\tannounceResponse
\t\t\t\t\t});
\t\t\t\t\tif (clawbbaLiveMediaUrls.length > 0) {
\t\t\t\t\t\tconst clawbbaLiveMirrored = await clawbbaInjectWebChatGeneratedMediaLive({
\t\t\t\t\t\t\tsessionKey: canonicalRequesterSessionKey,
\t\t\t\t\t\t\tmediaUrls: clawbbaLiveMediaUrls,
\t\t\t\t\t\t\tsourceTool: params.sourceTool,
\t\t\t\t\t\t\tcompletionLabel: resolveGeneratedMediaCompletionLabel({
\t\t\t\t\t\t\t\tsourceTool: params.sourceTool,
\t\t\t\t\t\t\t\tinternalEvents: params.internalEvents
\t\t\t\t\t\t\t})
\t\t\t\t\t\t});
\t\t\t\t\t\tif (clawbbaLiveMirrored) return {
\t\t\t\t\t\t\tdelivered: true,
\t\t\t\t\t\t\tpath: "clawbba-webchat-live"
\t\t\t\t\t\t};
\t\t\t\t\t}
\t\t\t\t}
\t\t\t\treturn;
\t\t\t}`

export const WEBCHAT_LIVE_STEER_NEEDLE = `\t\t\tconst wakeOutcome = await resolveActiveWakeWithRetries(requesterActivity.sessionId, params.triggerMessage, wakeOptions, params.signal);
\t\t\tif (wakeOutcome.queued) return {
\t\t\t\tdelivered: true,
\t\t\t\tdeliveredAt: wakeOutcome.deliveredAtMs,
\t\t\t\tenqueuedAt: wakeOutcome.enqueuedAtMs,
\t\t\t\tpath: "steered"
\t\t\t};`

export const WEBCHAT_LIVE_STEER_REPLACEMENT = `\t\t\tconst wakeOutcome = await resolveActiveWakeWithRetries(requesterActivity.sessionId, params.triggerMessage, wakeOptions, params.signal);
\t\t\tif (wakeOutcome.queued) {
\t\t\t\tif (clawbbaLocalMediaWebChatCompletion && expectedMediaUrls.length > 0) {
\t\t\t\t\tawait clawbbaInjectWebChatGeneratedMediaLive({
\t\t\t\t\t\tsessionKey: canonicalRequesterSessionKey,
\t\t\t\t\t\tmediaUrls: expectedMediaUrls,
\t\t\t\t\t\tsourceTool: params.sourceTool,
\t\t\t\t\t\tcompletionLabel: resolveGeneratedMediaCompletionLabel({
\t\t\t\t\t\t\tsourceTool: params.sourceTool,
\t\t\t\t\t\t\tinternalEvents: params.internalEvents
\t\t\t\t\t\t})
\t\t\t\t\t});
\t\t\t\t}
\t\t\t\treturn {
\t\t\t\t\tdelivered: true,
\t\t\t\t\tdeliveredAt: wakeOutcome.deliveredAtMs,
\t\t\t\t\tenqueuedAt: wakeOutcome.enqueuedAtMs,
\t\t\t\t\tpath: "steered"
\t\t\t\t};
\t\t\t}`

/** OpenClaw 2026.5.28+：resolveQueueEmbeddedPiMessageOutcome + steered path */
export const WEBCHAT_LIVE_STEER_QUEUE_NEEDLE = `\t\t\tif (wakeOutcome.queued) return {
\t\t\t\tdelivered: true,
\t\t\t\tdeliveredAt: wakeOutcome.deliveredAtMs,
\t\t\t\tenqueuedAt: wakeOutcome.enqueuedAtMs,
\t\t\t\tpath: "steered"
\t\t\t};`

export const WEBCHAT_LIVE_STEER_QUEUE_REPLACEMENT = `\t\t\tif (wakeOutcome.queued) {
\t\t\t\tif (clawbbaLocalMediaWebChatCompletion && expectedMediaUrls.length > 0) {
\t\t\t\t\tawait clawbbaInjectWebChatGeneratedMediaLive({
\t\t\t\t\t\tsessionKey: canonicalRequesterSessionKey,
\t\t\t\t\t\tmediaUrls: expectedMediaUrls,
\t\t\t\t\t\tsourceTool: params.sourceTool,
\t\t\t\t\t\tcompletionLabel: resolveGeneratedMediaCompletionLabel({
\t\t\t\t\t\t\tsourceTool: params.sourceTool,
\t\t\t\t\t\t\tinternalEvents: params.internalEvents
\t\t\t\t\t\t})
\t\t\t\t\t});
\t\t\t\t}
\t\t\t\treturn {
\t\t\t\t\tdelivered: true,
\t\t\t\t\tdeliveredAt: wakeOutcome.deliveredAtMs,
\t\t\t\t\tenqueuedAt: wakeOutcome.enqueuedAtMs,
\t\t\t\t\tpath: "steered"
\t\t\t\t};
\t\t\t}`

/** Direct announce 成功返回前 chat.inject（无需刷新 WebChat） */
export const WEBCHAT_LIVE_DIRECT_SUCCESS_NEEDLE = `\t\tif (params.expectsCompletionMessage && shouldDeliverAgentFinal && !hasVisibleGatewayAgentPayload(directAnnounceResponse)) return {
\t\t\tdelivered: false,
\t\t\tpath: "direct",
\t\t\terror: "completion agent did not produce a visible reply"
\t\t};
\t\treturn {
\t\t\tdelivered: true,
\t\t\tpath: "direct"
\t\t};`

export const WEBCHAT_LIVE_DIRECT_SUCCESS_REPLACEMENT = `\t\tif (params.expectsCompletionMessage && shouldDeliverAgentFinal && !hasVisibleGatewayAgentPayload(directAnnounceResponse)) return {
\t\t\tdelivered: false,
\t\t\tpath: "direct",
\t\t\terror: "completion agent did not produce a visible reply"
\t\t};
\t\tif (clawbbaLocalMediaWebChatCompletion && expectedMediaUrls.length > 0) {
\t\t\tawait clawbbaInjectWebChatGeneratedMediaLive({
\t\t\t\tsessionKey: canonicalRequesterSessionKey,
\t\t\t\tmediaUrls: expectedMediaUrls,
\t\t\t\tsourceTool: params.sourceTool,
\t\t\t\tcompletionLabel: resolveGeneratedMediaCompletionLabel({
\t\t\t\t\tsourceTool: params.sourceTool,
\t\t\t\t\tinternalEvents: params.internalEvents
\t\t\t\t})
\t\t\t});
\t\t}
\t\treturn {
\t\t\tdelivered: true,
\t\t\tpath: "direct"
\t\t};`

/** 2026.5.18 – 2026.5.26：agentMediated && (media || policy) */
export const ANNOUNCE_PATCH_2026518 = {
  id: '2026.5.18-media-or-policy',
  needle: `\t\tconst expectedMediaUrls = collectExpectedMediaFromInternalEvents(params.internalEvents);
\t\tconst requiresMessageToolDelivery = agentMediatedCompletion && (expectedMediaUrls.length > 0 || completionRequiresMessageToolDelivery({
\t\t\tcfg,
\t\t\trequesterSessionKey: params.requesterSessionKey,
\t\t\ttargetRequesterSessionKey: canonicalRequesterSessionKey,
\t\t\trequesterEntry,
\t\t\tdirectOrigin: effectiveDirectOrigin,
\t\t\trequesterSessionOrigin
\t\t}));`,
  replacement: `\t\tconst expectedMediaUrls = collectExpectedMediaFromInternalEvents(params.internalEvents);
\t\t${ANNOUNCE_MARKER}
${CLAWBBA_WEBCHAT_MEDIA_BLOCK}
\t\tconst requiresMessageToolDelivery = agentMediatedCompletion && ((expectedMediaUrls.length > 0 && !clawbbaLocalMediaWebChatCompletion) || completionRequiresMessageToolDelivery({
\t\t\tcfg,
\t\t\trequesterSessionKey: params.requesterSessionKey,
\t\t\ttargetRequesterSessionKey: canonicalRequesterSessionKey,
\t\t\trequesterEntry,
\t\t\tdirectOrigin: effectiveDirectOrigin,
\t\t\trequesterSessionOrigin
\t\t}));`,
}

/** 2026.5.27+、部分 5.x：policy || (agentMediated && media) */
export const ANNOUNCE_PATCH_LEGACY = {
  id: 'legacy-policy-or-media',
  needle: `\t\tconst expectedMediaUrls = collectExpectedMediaFromInternalEvents(params.internalEvents);
\t\tconst requiresMessageToolDelivery = params.expectsCompletionMessage && completionRequiresMessageToolDelivery({
\t\t\tcfg,
\t\t\trequesterSessionKey: params.requesterSessionKey,
\t\t\ttargetRequesterSessionKey: canonicalRequesterSessionKey,
\t\t\trequesterEntry,
\t\t\tdirectOrigin: effectiveDirectOrigin,
\t\t\trequesterSessionOrigin
\t\t}) || agentMediatedCompletion && expectedMediaUrls.length > 0;`,
  replacement: `\t\tconst expectedMediaUrls = collectExpectedMediaFromInternalEvents(params.internalEvents);
\t\t${ANNOUNCE_MARKER}
${CLAWBBA_WEBCHAT_MEDIA_BLOCK}
\t\tconst requiresMessageToolDelivery = params.expectsCompletionMessage && completionRequiresMessageToolDelivery({
\t\t\tcfg,
\t\t\trequesterSessionKey: params.requesterSessionKey,
\t\t\ttargetRequesterSessionKey: canonicalRequesterSessionKey,
\t\t\trequesterEntry,
\t\t\tdirectOrigin: effectiveDirectOrigin,
\t\t\trequesterSessionOrigin
\t\t}) || (agentMediatedCompletion && expectedMediaUrls.length > 0 && !clawbbaLocalMediaWebChatCompletion);`,
}

/** 2026.5.12 – 2026.5.17：无 expectedMediaUrls，仅 agentMediated && policy */
export const ANNOUNCE_PATCH_2026512 = {
  id: '2026.5.12-agent-mediated-and-policy',
  needle: `\t\tconst requiresMessageToolDelivery = requiresAgentMediatedCompletionDelivery({
\t\t\texpectsCompletionMessage: params.expectsCompletionMessage,
\t\t\tsourceTool: params.sourceTool
\t\t}) && completionRequiresMessageToolDelivery({
\t\t\tcfg,
\t\t\trequesterSessionKey: params.requesterSessionKey,
\t\t\ttargetRequesterSessionKey: params.targetRequesterSessionKey,
\t\t\trequesterEntry,
\t\t\tdirectOrigin: effectiveDirectOrigin,
\t\t\trequesterSessionOrigin
\t\t});`,
  replacement: `\t\tconst agentMediatedCompletion = requiresAgentMediatedCompletionDelivery({
\t\t\texpectsCompletionMessage: params.expectsCompletionMessage,
\t\t\tsourceTool: params.sourceTool
\t\t});
\t\tconst expectedMediaUrls = collectExpectedMediaFromInternalEvents(params.internalEvents);
\t\t${ANNOUNCE_MARKER}
${CLAWBBA_WEBCHAT_MEDIA_BLOCK}
\t\tconst requiresMessageToolDelivery = agentMediatedCompletion && ((expectedMediaUrls.length > 0 && !clawbbaLocalMediaWebChatCompletion) || completionRequiresMessageToolDelivery({
\t\t\tcfg,
\t\t\trequesterSessionKey: params.requesterSessionKey,
\t\t\ttargetRequesterSessionKey: params.targetRequesterSessionKey,
\t\t\trequesterEntry,
\t\t\tdirectOrigin: effectiveDirectOrigin,
\t\t\trequesterSessionOrigin
\t\t}));`,
}

export const ANNOUNCE_PATCHES_ORDERED = [
  ANNOUNCE_PATCH_2026518,
  ANNOUNCE_PATCH_LEGACY,
  ANNOUNCE_PATCH_2026512,
]

function hasAnnouncePolicyPatch(src) {
  return src.includes(ANNOUNCE_MARKER) && src.includes('clawbbaLocalMediaWebChatCompletion')
}

function hasWebChatLiveHelper(src) {
  return (
    (src.match(new RegExp(`function ${'clawbbaInjectWebChatGeneratedMediaLive'}`, 'g')) || []).length === 1 &&
    src.includes('export async function clawbbaInjectWebChatGeneratedMediaLive') &&
    src.includes(WEBCHAT_HISTORY_RELOAD_MARKER) &&
    src.includes('clawbbaBroadcastWebChatSessionReload')
  )
}

/** Export chat.inject helper (wake path imports this). Always dedupe before insert. */
function applyWebChatLiveHelperExport(src, globalSingletonBasename, gatewayRequestScopeBasename) {
  let next = dedupeClawbbaInjectHelperBlocks(src)

  if (!hasAnnouncePolicyPatch(next)) {
    return { src: next, result: next !== src ? 'deduped-only' : 'live-skipped-no-announce' }
  }

  if (hasWebChatLiveHelper(next)) {
    return { src: next, result: next !== src ? 'deduped' : 'skip-live' }
  }

  const sendAnchor = 'async function sendSubagentAnnounceDirectly(params) {'
  if (!next.includes(sendAnchor)) {
    return { src: next, result: 'live-send-anchor-missing' }
  }

  if (!globalSingletonBasename || !gatewayRequestScopeBasename) {
    return { src: next, result: 'live-gateway-scope-missing' }
  }

  const helper = buildWebChatLiveHelper(globalSingletonBasename, gatewayRequestScopeBasename)
  if (next.includes(WEBCHAT_LIVE_MARKER)) {
    next = next.replace(
      new RegExp(
        `${escapeRegExp(WEBCHAT_LIVE_MARKER)}[\\s\\S]*?(?=\\nasync function sendSubagentAnnounceDirectly \\(params\\))`,
        'm',
      ),
      helper.trimEnd(),
    )
  } else {
    next = next.replace(sendAnchor, `${helper}\n${sendAnchor}`)
  }
  return { src: next, result: 'patched-live-helper' }
}

function applyAnnouncePolicyPatch(src) {
  if (hasAnnouncePolicyPatch(src)) return { src, result: 'skip' }
  for (const patch of ANNOUNCE_PATCHES_ORDERED) {
    if (src.includes(patch.needle)) {
      return { src: src.replace(patch.needle, patch.replacement), result: `patched-${patch.id}` }
    }
  }
  return { src, result: 'pattern-missing' }
}

/**
 * @param {string} filePath
 * @returns {string} patched-* | skip | pattern-missing
 */
export function patchSubagentAnnounceDeliveryFile(
  filePath,
  globalSingletonBasename,
  gatewayRequestScopeBasename,
) {
  const raw = fs.readFileSync(filePath, 'utf8')
  let src = dedupeClawbbaInjectHelperBlocks(raw)

  if (hasAnnouncePolicyPatch(src) && hasWebChatLiveHelper(src)) {
    if (src !== raw) fs.writeFileSync(filePath, src)
    return src !== raw ? 'deduped' : 'skip'
  }
  const policy = applyAnnouncePolicyPatch(src)
  let next = policy.src
  const live = applyWebChatLiveHelperExport(next, globalSingletonBasename, gatewayRequestScopeBasename)
  src = live.src

  if (policy.result === 'pattern-missing' && live.result.startsWith('live-')) {
    return 'pattern-missing'
  }

  if (policy.result === 'skip' && (live.result === 'skip-live' || live.result === 'deduped')) {
    if (src !== raw) fs.writeFileSync(filePath, src)
    return live.result === 'deduped' ? 'deduped' : 'skip'
  }

  if (src !== raw) {
    fs.writeFileSync(filePath, src)
  }

  if (policy.result !== 'skip' && live.result === 'patched-live-helper') {
    return `${policy.result}+live-helper`
  }
  if (policy.result !== 'skip') return policy.result
  if (live.result === 'patched-live-helper') return live.result
  if (live.result === 'skip-live') return 'skip'
  return live.result
}

/**
 * @param {string} dist
 * @param {(prefix: string) => string|undefined} findDistFile
 */
export function patchSubagentAnnounceDeliveryDist(dist, findDistFile) {
  const file = findDistFile(dist, 'subagent-announce-delivery-')
  const gatewayScopeFile = findDistFile(dist, 'gateway-request-scope-')
  const globalSingletonFile = findDistFile(dist, 'global-singleton-')
  if (!file || !gatewayScopeFile || !globalSingletonFile) return 'missing-file'
  const result = patchSubagentAnnounceDeliveryFile(
    path.join(dist, file),
    globalSingletonFile,
    gatewayScopeFile,
  )
  if (result === 'pattern-missing') {
    process.stderr.write(
      `[clawbba-api] warn: subagent announce 无匹配模式 (${file})；2026.5.2 等极旧版可能仅依赖 wake patch\n`,
    )
  }
  if (result === 'live-send-anchor-missing' || result === 'live-skipped-no-announce') {
    process.stderr.write(
      `[clawbba-api] warn: webchat chat.inject helper 未写入 (${file})；请确认 wake patch 已应用\n`,
    )
  }
  return result
}
