/**
 * OpenClaw runtime patches: ClawBBA 话术 → image_generate / video_generate 工具参数
 * 模型 id 规范：references/media-model-ref.md（平台 id → openrouter/<id>）
 */
import fs from 'fs'
import path from 'path'
import { buildOpenClawNormalizeModelFnBlock } from './clawbba-media-model-ref.mjs'

export const MEDIA_DISPATCH_MARKER = '/* clawbba-media-dispatch */'
const NORMALIZE_FN_MARKER = 'clawbbaToOpenClawMediaModel'

/** 注入到 openclaw-tools image_generate：从 session 最近用户消息解析 ClawBBA 模板 */
export function buildImageGenerateDispatchBlock() {
  return `${buildOpenClawNormalizeModelFnBlock()}
${MEDIA_DISPATCH_MARKER}
\t\t\tawait (async () => {
\t\t\t\tlet mediaText = prompt;
\t\t\t\ttry {
\t\t\t\t\tconst sk = typeof options?.agentSessionKey === "string" ? options.agentSessionKey.trim() : "";
\t\t\t\t\tif (sk) {
\t\t\t\t\t\tconst rt = await getRuntime();
\t\t\t\t\t\tconst { storePath, entry } = rt.loadSessionEntry(sk);
\t\t\t\t\t\tconst sessionId = entry?.sessionId;
\t\t\t\t\t\tif (sessionId && storePath) {
\t\t\t\t\t\t\tconst msgs = await rt.readSessionMessagesAsync(sessionId, storePath, entry?.sessionFile, { mode: "recent", maxMessages: 24, maxBytes: 512000 });
\t\t\t\t\t\t\tfor (let i = msgs.length - 1; i >= 0; i--) {
\t\t\t\t\t\t\t\tconst m = msgs[i];
\t\t\t\t\t\t\t\tif (m?.role !== "user") continue;
\t\t\t\t\t\t\t\tconst t = typeof m.content === "string" ? m.content : Array.isArray(m.content) ? m.content.map((p) => typeof p?.text === "string" ? p.text : typeof p === "string" ? p : "").join("") : "";
\t\t\t\t\t\t\t\tif (/请使用\\s*ClawBBA\\s*生成(图片|视频)/i.test(t)) { mediaText = t; break; }
\t\t\t\t\t\t\t}
\t\t\t\t\t\t}
\t\t\t\t\t}
\t\t\t\t} catch (_) {}
\t\t\t\tconst stripPref = (id) => String(id || "").trim().replace(/^(clawbba|openrouter)\\//i, "");
\t\t\t\tconst mModel = mediaText.match(/模型\\s+([a-z0-9][a-z0-9._\\-\\/]*)/i) || mediaText.match(/\\bmodel\\s+([a-z0-9][a-z0-9._-]+\\/[a-z0-9][a-z0-9._-]+)/i);
\t\t\t\tconst parsedModelRaw = mModel ? mModel[1].replace(/^(clawbba|openrouter)\\//i, "") : null;
\t\t\t\tconst parsedModel = parsedModelRaw && /^[a-z0-9][a-z0-9._-]*\\/[a-z0-9][a-z0-9._-]+$/i.test(parsedModelRaw) ? parsedModelRaw : null;
\t\t\t\tlet parsedAspect = null;
\t\t\t\tif (/16\\s*[:：]\\s*9|横图|横屏/i.test(mediaText) && !/竖图|竖屏/i.test(mediaText)) parsedAspect = "16:9";
\t\t\t\telse if (/9\\s*[:：]\\s*16|竖图|竖屏/i.test(mediaText) && !/横图|横屏/i.test(mediaText)) parsedAspect = "9:16";
\t\t\t\telse for (const pair of [["21:9", /21\\s*[:：]\\s*9/], ["16:9", /16\\s*[:：]\\s*9/], ["9:16", /9\\s*[:：]\\s*16/], ["4:3", /4\\s*[:：]\\s*3/], ["3:4", /3\\s*[:：]\\s*4/], ["1:1", /1\\s*[:：]\\s*1/]]) if (pair[1].test(mediaText)) { parsedAspect = pair[0]; break; }
\t\t\t\tlet parsedPrompt = mediaText.replace(/^请使用\\s*ClawBBA\\s*生成图片能力[,，]?\\s*/i, "").replace(/^(?:模型\\s+[^，,]+[,，]?\\s*)?(?:为我生成\\s*)?(?:(?:\\d{1,2}\\s*[:：]\\s*\\d{1,2})|(?:横图|竖图)|(?:\\dK))[^：:]*[:：]\\s*/i, "").trim();
\t\t\t\tif (!parsedPrompt) parsedPrompt = prompt;
\t\t\t\tif (!model && parsedModel) model = clawbbaToOpenClawMediaModel(parsedModel);
\t\t\t\telse if (model) { const __nm = clawbbaToOpenClawMediaModel(model); if (__nm) model = __nm; }
\t\t\t\tif (!aspectRatio && parsedAspect) aspectRatio = normalizeAspectRatio$1(parsedAspect);
\t\t\t\tif (parsedPrompt && parsedPrompt !== prompt) prompt = parsedPrompt;
\t\t\t})();`
}

/** 注入到 openclaw-tools video_generate */
export function buildVideoGenerateDispatchBlock() {
  return `${buildOpenClawNormalizeModelFnBlock()}
${MEDIA_DISPATCH_MARKER}
\t\t\tawait (async () => {
\t\t\t\tlet mediaText = prompt;
\t\t\t\ttry {
\t\t\t\t\tconst sk = typeof options?.agentSessionKey === "string" ? options.agentSessionKey.trim() : "";
\t\t\t\t\tif (sk) {
\t\t\t\t\t\tconst rt = await getRuntime();
\t\t\t\t\t\tconst { storePath, entry } = rt.loadSessionEntry(sk);
\t\t\t\t\t\tconst sessionId = entry?.sessionId;
\t\t\t\t\t\tif (sessionId && storePath) {
\t\t\t\t\t\t\tconst msgs = await rt.readSessionMessagesAsync(sessionId, storePath, entry?.sessionFile, { mode: "recent", maxMessages: 24, maxBytes: 512000 });
\t\t\t\t\t\t\tfor (let i = msgs.length - 1; i >= 0; i--) {
\t\t\t\t\t\t\t\tconst m = msgs[i];
\t\t\t\t\t\t\t\tif (m?.role !== "user") continue;
\t\t\t\t\t\t\t\tconst t = typeof m.content === "string" ? m.content : Array.isArray(m.content) ? m.content.map((p) => typeof p?.text === "string" ? p.text : typeof p === "string" ? p : "").join("") : "";
\t\t\t\t\t\t\t\tif (/请使用\\s*ClawBBA\\s*生成(图片|视频)/i.test(t)) { mediaText = t; break; }
\t\t\t\t\t\t\t}
\t\t\t\t\t\t}
\t\t\t\t\t}
\t\t\t\t} catch (_) {}
\t\t\t\tconst stripPref = (id) => String(id || "").trim().replace(/^(clawbba|openrouter)\\//i, "");
\t\t\t\tconst mModel = mediaText.match(/模型\\s+([a-z0-9][a-z0-9._\\-\\/]*)/i) || mediaText.match(/\\bmodel\\s+([a-z0-9][a-z0-9._-]+\\/[a-z0-9][a-z0-9._-]+)/i);
\t\t\t\tconst parsedModelRaw = mModel ? mModel[1].replace(/^(clawbba|openrouter)\\//i, "") : null;
\t\t\t\tconst parsedModel = parsedModelRaw && /^[a-z0-9][a-z0-9._-]*\\/[a-z0-9][a-z0-9._-]+$/i.test(parsedModelRaw) ? parsedModelRaw : null;
\t\t\t\tlet parsedAspect = null;
\t\t\t\tif (/16\\s*[:：]\\s*9|横图|横屏/i.test(mediaText) && !/竖图|竖屏/i.test(mediaText)) parsedAspect = "16:9";
\t\t\t\telse if (/9\\s*[:：]\\s*16|竖图|竖屏/i.test(mediaText) && !/横图|横屏/i.test(mediaText)) parsedAspect = "9:16";
\t\t\t\telse for (const pair of [["21:9", /21\\s*[:：]\\s*9/], ["16:9", /16\\s*[:：]\\s*9/], ["9:16", /9\\s*[:：]\\s*16/]]) if (pair[1].test(mediaText)) { parsedAspect = pair[0]; break; }
\t\t\t\tconst mDur = mediaText.match(/(\\d+)\\s*秒/);
\t\t\t\tconst parsedDur = mDur ? Math.max(1, parseInt(mDur[1], 10)) : null;
\t\t\t\tlet parsedPrompt = mediaText.replace(/^请使用\\s*ClawBBA\\s*生成视频能力[,，]?\\s*/i, "").replace(/^(?:模型\\s+[^，,]+[,，]?\\s*)?(?:为我生成\\s*)?(?:(?:\\d{1,2}\\s*[:：]\\s*\\d{1,2})|(?:横图|竖图)|(?:\\d+\\s*秒))[^：:，,]*[：:,，]?\\s*/i, "").trim();
\t\t\t\tif (!parsedPrompt) parsedPrompt = prompt;
\t\t\t\tif (!model && parsedModel) model = clawbbaToOpenClawMediaModel(parsedModel);
\t\t\t\telse if (model) { const __nm = clawbbaToOpenClawMediaModel(model); if (__nm) model = __nm; }
\t\t\t\tif (!aspectRatio && parsedAspect) aspectRatio = normalizeAspectRatio(parsedAspect);
\t\t\t\tif (durationSeconds == null && parsedDur != null) durationSeconds = parsedDur;
\t\t\t\tif (parsedPrompt && parsedPrompt !== prompt) prompt = parsedPrompt;
\t\t\t\tawait clawbbaMaybeMergeSessionReferenceImages({ args, options, tool: "video_generate", maxCount: 5 });
\t\t\t})();`
}

const MODEL_ASSIGN_UPGRADE =
  'if (!model && parsedModel) model = clawbbaToOpenClawMediaModel(parsedModel);\n\t\t\t\telse if (model) { const __nm = clawbbaToOpenClawMediaModel(model); if (__nm) model = __nm; }'

function upgradeMediaDispatchModelAssign(src) {
  let out = src
  const patterns = [
    /if \(!model && parsedModel\) model = parsedModel;/g,
    /if \(!model && parsedModel\) model = `openrouter\/\$\{parsedModel\}`;/g,
  ]
  for (const re of patterns) {
    if (re.test(out)) {
      out = out.replace(re, MODEL_ASSIGN_UPGRADE)
      return out
    }
  }
  return out
}

function injectNormalizeFnBeforeMediaDispatch(src) {
  if (src.includes(NORMALIZE_FN_MARKER)) return src
  const block = buildOpenClawNormalizeModelFnBlock()
  const idx = src.indexOf(MEDIA_DISPATCH_MARKER)
  if (idx < 0) return src
  return `${src.slice(0, idx)}${block}\n${src.slice(idx)}`
}

export function patchImageGenerateMediaDispatch(filePath) {
  let src = fs.readFileSync(filePath, 'utf8')
  if (src.includes(MEDIA_DISPATCH_MARKER)) {
    const upgraded = upgradeMediaDispatchModelAssign(injectNormalizeFnBeforeMediaDispatch(src))
    if (upgraded !== src) {
      fs.writeFileSync(filePath, upgraded)
      return 'patched'
    }
    if (src.includes('clawbbaToOpenClawMediaModel(parsedModel)')) return 'skip'
    return 'skip'
  }

  src = src.replace(
    '\t\t\tconst prompt = readStringParam$1(params, "prompt", { required: true });',
    '\t\t\tlet prompt = readStringParam$1(params, "prompt", { required: true });',
  )
  src = src.replace(
    '\t\t\tconst model = readStringParam$1(params, "model");',
    '\t\t\tlet model = readStringParam$1(params, "model");',
  )
  src = src.replace(
    '\t\t\tconst aspectRatio = normalizeAspectRatio$1(readStringParam$1(params, "aspectRatio"));',
    `\t\t\tlet aspectRatio = normalizeAspectRatio$1(readStringParam$1(params, "aspectRatio"));
${buildImageGenerateDispatchBlock()}`,
  )

  if (!src.includes(MEDIA_DISPATCH_MARKER)) {
    throw new Error(`image_generate media dispatch not injected in ${path.basename(filePath)}`)
  }
  fs.writeFileSync(filePath, src)
  return 'patched'
}

export function patchVideoGenerateMediaDispatch(filePath) {
  let src = fs.readFileSync(filePath, 'utf8')
  if (src.includes(MEDIA_DISPATCH_MARKER) && src.includes('durationSeconds == null && parsedDur')) {
    const upgraded = upgradeMediaDispatchModelAssign(injectNormalizeFnBeforeMediaDispatch(src))
    if (upgraded !== src) {
      fs.writeFileSync(filePath, upgraded)
      return 'patched'
    }
    if (src.includes('clawbbaToOpenClawMediaModel(parsedModel)')) return 'skip'
    return 'skip'
  }

  src = src.replace(
    '\t\t\tconst prompt = readStringParam$1(args, "prompt", { required: true });',
    '\t\t\tlet prompt = readStringParam$1(args, "prompt", { required: true });',
  )
  src = src.replace(
    '\t\t\tconst model = readStringParam$1(args, "model");',
    '\t\t\tlet model = readStringParam$1(args, "model");',
  )
  src = src.replace(
    '\t\t\tconst aspectRatio = normalizeAspectRatio(readStringParam$1(args, "aspectRatio"));',
    `\t\t\tlet aspectRatio = normalizeAspectRatio(readStringParam$1(args, "aspectRatio"));`,
  )
  src = src.replace(
    `\t\t\tconst durationSeconds = readNumberParam(args, "durationSeconds", {
\t\t\t\tinteger: true,
\t\t\t\tstrict: true
\t\t\t});`,
    `\t\t\tlet durationSeconds = readNumberParam(args, "durationSeconds", {
\t\t\t\tinteger: true,
\t\t\t\tstrict: true
\t\t\t});
${buildVideoGenerateDispatchBlock()}`,
  )

  if (!src.includes('durationSeconds == null && parsedDur')) {
    throw new Error(`video_generate media dispatch not injected in ${path.basename(filePath)}`)
  }
  fs.writeFileSync(filePath, src)
  return 'patched'
}

export function patchOpenRouterImageProviderAspect(dist) {
  const files = fs.readdirSync(dist).filter((name) => name.startsWith('image-generation-provider-') && name.endsWith('.js'))
  const file = files.find((name) => {
    const src = fs.readFileSync(path.join(dist, name), 'utf8')
    return src.includes('function buildImageConfig(req, model)') && src.includes('`${baseUrl}/chat/completions`')
  })
  if (!file) return 'missing'
  const filePath = path.join(dist, file)
  let src = fs.readFileSync(filePath, 'utf8')
  if (src.includes(MEDIA_DISPATCH_MARKER)) return 'skip'

  const needle = `function buildImageConfig(req, model) {
\tif (!isGeminiImageModel(model)) return {};
\tconst imageConfig = {};`
  const replacement = `function buildImageConfig(req, model) {
\t${MEDIA_DISPATCH_MARKER}
\tconst imageConfig = {};`

  if (!src.includes(needle)) {
    if (src.includes('function buildImageConfig(req, model)')) return 'skip'
    return 'missing'
  }
  src = src.replace(needle, replacement)
  fs.writeFileSync(filePath, src)
  return 'patched'
}

const MEDIA_DISPATCH_HEADERS_MARKER = '/* clawbba-media-dispatch-headers */'
const MEDIA_DISPATCH_HEADERS_FIX_MARKER = '/* clawbba-media-dispatch-headers-v2 */'

const CLAWBBA_IMAGE_HEADER_MERGE_BLOCK = `\t\t\t${MEDIA_DISPATCH_HEADERS_MARKER}
\t\t\t${MEDIA_DISPATCH_HEADERS_FIX_MARKER}
\t\t\tconst clawbbaAspectHdr = normalizeOptionalString(req.aspectRatio);
\t\t\tconst clawbbaResHdr = normalizeOptionalString(req.resolution);
\t\t\tconst __clawbbaMergedImgHeaders = new Headers(headers);
\t\t\t__clawbbaMergedImgHeaders.set("Content-Type", "application/json");
\t\t\tif (model) __clawbbaMergedImgHeaders.set("X-ClawBBA-Image-Model", model);
\t\t\tif (clawbbaAspectHdr) __clawbbaMergedImgHeaders.set("X-ClawBBA-Image-Aspect", clawbbaAspectHdr);
\t\t\tif (clawbbaResHdr) __clawbbaMergedImgHeaders.set("X-ClawBBA-Image-Resolution", clawbbaResHdr);
\t\t\tconst __clawbbaOrHdr = req.cfg?.models?.providers?.openrouter?.headers;
\t\t\tif (__clawbbaOrHdr && typeof __clawbbaOrHdr === "object") {
\t\t\t\tfor (const [__k, __v] of Object.entries(__clawbbaOrHdr)) {
\t\t\t\t\tif (typeof __v === "string" && __v.trim()) __clawbbaMergedImgHeaders.set(__k, __v.trim());
\t\t\t\t}
\t\t\t}`

const BROKEN_HEADERS_SPREAD = 'headers: { ...headers, ...clawbbaMediaHeaders }'

/** ClawBBA Platform API：undici 空 body 恢复时从 HTTP 头读取 model / aspect */
export function patchOpenRouterImageProviderHeaders(dist) {
  const files = fs.readdirSync(dist).filter((name) => name.startsWith('image-generation-provider-') && name.endsWith('.js'))
  const file = files.find((name) => {
    const src = fs.readFileSync(path.join(dist, name), 'utf8')
    return (
      src.includes('async generateImage(req)') &&
      src.includes('postJsonRequest') &&
      src.includes('`${baseUrl}/chat/completions`')
    )
  })
  if (!file) return 'missing'
  const filePath = path.join(dist, file)
  let src = fs.readFileSync(filePath, 'utf8')

  if (src.includes(MEDIA_DISPATCH_HEADERS_FIX_MARKER)) {
    return 'skip'
  }

  const upgradeBrokenHeadersSpread = () => {
    if (!src.includes(BROKEN_HEADERS_SPREAD) && !(src.includes(MEDIA_DISPATCH_HEADERS_MARKER) && src.includes('clawbbaMediaHeaders'))) {
      return false
    }
    src = src.replace(
      /\t\t\t\/\* clawbba-media-dispatch-headers \*\/[\s\S]*?headers: \{ \.\.\.headers, \.\.\.clawbbaMediaHeaders \},/,
      `${CLAWBBA_IMAGE_HEADER_MERGE_BLOCK}
\t\t\tconst { response, release } = await postJsonRequest({
\t\t\t\turl: \`\${baseUrl}/chat/completions\`,
\t\t\t\theaders: __clawbbaMergedImgHeaders,`,
    )
    if (src.includes(BROKEN_HEADERS_SPREAD)) {
      const postNeedle = `\t\t\tconst { response, release } = await postJsonRequest({
\t\t\t\turl: \`\${baseUrl}/chat/completions\`,
\t\t\t\theaders: __clawbbaMergedImgHeaders,`
      if (!src.includes('__clawbbaMergedImgHeaders')) {
        src = src.replace(BROKEN_HEADERS_SPREAD, 'headers: __clawbbaMergedImgHeaders')
        src = src.replace(
          postNeedle,
          `${CLAWBBA_IMAGE_HEADER_MERGE_BLOCK}
${postNeedle}`,
        )
      } else {
        src = src.replace(BROKEN_HEADERS_SPREAD, 'headers: __clawbbaMergedImgHeaders')
      }
    }
    return src.includes(MEDIA_DISPATCH_HEADERS_FIX_MARKER) && !src.includes(BROKEN_HEADERS_SPREAD)
  }

  if (upgradeBrokenHeadersSpread()) {
    fs.writeFileSync(filePath, src)
    return 'fixed-broken-spread'
  }
  if (src.includes(BROKEN_HEADERS_SPREAD) || (src.includes(MEDIA_DISPATCH_HEADERS_MARKER) && src.includes('clawbbaMediaHeaders'))) {
    return 'broken-spread-unfixed'
  }

  const needle = `\t\t\t});
\t\t\tconst { response, release } = await postJsonRequest({
\t\t\t\turl: \`\${baseUrl}/chat/completions\`,
\t\t\t\theaders,`
  const replacement = `\t\t\t});
${CLAWBBA_IMAGE_HEADER_MERGE_BLOCK}
\t\t\tconst { response, release } = await postJsonRequest({
\t\t\t\turl: \`\${baseUrl}/chat/completions\`,
\t\t\t\theaders: __clawbbaMergedImgHeaders,`

  if (!src.includes(needle)) return 'missing'
  src = src.replace(needle, replacement)
  fs.writeFileSync(filePath, src)
  return 'patched'
}
