/**
 * OpenClaw reference-image helpers for image_generate / video_generate.
 * Injected into openclaw-tools-*.js (see patchReferenceImagesInToolsFile).
 * @see references/media-dispatch-spec.md §3.3
 */
import fs from 'fs'
import path from 'path'

export const REFERENCE_IMAGES_MARKER = '/* clawbba-reference-images */'

/** Max reference images (OpenClaw openrouter edit default). */
export const MAX_REFERENCE_IMAGES = 5

/**
 * Extract image reference paths/URLs from an OpenClaw session user message.
 * @param {unknown} msg
 * @returns {string[]}
 */
export function extractImageRefsFromMessage(msg) {
  const out = []
  if (!msg || typeof msg !== 'object') return out
  const record = /** @type {Record<string, unknown>} */ (msg)
  const content = record.content

  const push = (raw) => {
    const v = String(raw ?? '').trim()
    if (v && looksLikeImageRef(v) && !out.includes(v)) out.push(v)
  }

  if (typeof content === 'string') {
    pushMediaLinesFromText(content, push)
    return out
  }

  if (!Array.isArray(content)) return out

  for (const part of content) {
    if (!part || typeof part !== 'object') continue
    const p = /** @type {Record<string, unknown>} */ (part)
    const type = String(p.type ?? '').toLowerCase()

    if (type === 'image') {
      push(p.path ?? p.filePath ?? p.url)
      const src = p.source
      if (src && typeof src === 'object') {
        const s = /** @type {Record<string, unknown>} */ (src)
        push(s.url ?? s.path)
      }
    }
    if (type === 'image_url') {
      const iu = p.image_url ?? p.imageUrl
      if (iu && typeof iu === 'object') {
        push(/** @type {Record<string, unknown>} */ (iu).url)
      }
    }
    if (type === 'file' || type === 'attachment') {
      const mime = String(p.mimeType ?? p.mime ?? '').toLowerCase()
      if (!mime || mime.startsWith('image/')) {
        push(p.path ?? p.filePath ?? p.url)
        const att = p.attachment
        if (att && typeof att === 'object') {
          const a = /** @type {Record<string, unknown>} */ (att)
          push(a.path ?? a.url)
        }
      }
    }
    if (typeof p.text === 'string') pushMediaLinesFromText(p.text, push)
  }

  const attachments = record.attachments
  if (Array.isArray(attachments)) {
    for (const att of attachments) {
      if (!att || typeof att !== 'object') continue
      const a = /** @type {Record<string, unknown>} */ (att)
      const mime = String(a.mimeType ?? a.mime ?? '').toLowerCase()
      if (!mime || mime.startsWith('image/')) push(a.path ?? a.filePath ?? a.url)
    }
  }

  return out
}

/**
 * @param {string} text
 * @param {(v: string) => void} push
 */
function pushMediaLinesFromText(text, push) {
  for (const m of text.matchAll(/MEDIA:([^\s\n]+)/g)) {
    if (m[1]) push(m[1])
  }
}

/**
 * @param {string} value
 * @returns {boolean}
 */
export function looksLikeImageRef(value) {
  const v = String(value ?? '').trim()
  if (!v) return false
  if (v.startsWith('data:image/')) return true
  if (v.startsWith('file://')) return true
  if (v.includes('.openclaw/media/') || v.includes('.openclaw\\media\\')) return true
  if (v.startsWith('~/')) return true
  if (/\.(png|jpe?g|webp|gif|bmp|svg)(\?|#|$)/i.test(v)) return true
  if (/^https?:\/\//i.test(v)) {
    return (
      /\.(png|jpe?g|webp|gif|bmp|svg)(\?|#|$)/i.test(v) ||
      /\/media\//i.test(v) ||
      /\/uploads\//i.test(v) ||
      /\/inbound\//i.test(v)
    )
  }
  return /^\/[^ \n]+$/.test(v)
}

/**
 * @param {unknown} msg
 * @returns {string}
 */
export function messageTextFromRecord(msg) {
  if (!msg || typeof msg !== 'object') return ''
  const content = /** @type {Record<string, unknown>} */ (msg).content
  if (typeof content === 'string') return content
  if (!Array.isArray(content)) return ''
  return content
    .map((part) => {
      if (!part || typeof part !== 'object') return typeof part === 'string' ? part : ''
      const p = /** @type {Record<string, unknown>} */ (part)
      return typeof p.text === 'string' ? p.text : ''
    })
    .join('')
}

/**
 * @param {Record<string, unknown>} record
 * @returns {boolean}
 */
export function paramsHaveReferenceImages(record) {
  const single = record.image
  if (typeof single === 'string' && single.trim()) return true
  const multi = record.images
  return Array.isArray(multi) && multi.some((v) => typeof v === 'string' && String(v).trim())
}

/**
 * @param {Record<string, unknown>} record
 * @returns {boolean}
 */
export function paramsHaveVideoImageRoles(record) {
  const roles = record.imageRoles
  return Array.isArray(roles) && roles.some((r) => typeof r === 'string' && String(r).trim())
}

/**
 * Inline helpers injected once into openclaw-tools bundle.
 */
export function buildReferenceImagesHelperSource() {
  return `${REFERENCE_IMAGES_MARKER}
function clawbbaMessageTextFromRecord(msg) {
\tif (!msg || typeof msg !== "object") return "";
\tconst content = msg.content;
\tif (typeof content === "string") return content;
\tif (!Array.isArray(content)) return "";
\treturn content.map((part) => {
\t\tif (!part || typeof part !== "object") return typeof part === "string" ? part : "";
\t\treturn typeof part.text === "string" ? part.text : "";
\t}).join("");
}
function clawbbaLooksLikeImageRef(value) {
\tconst v = String(value ?? "").trim();
\tif (!v) return false;
\tif (v.startsWith("data:image/")) return true;
\tif (v.startsWith("file://")) return true;
\tif (v.includes(".openclaw/media/") || v.includes(".openclaw\\\\media\\\\")) return true;
\tif (v.startsWith("~/")) return true;
\tif (/\\.(png|jpe?g|webp|gif|bmp|svg)(\\?|#|$)/i.test(v)) return true;
\tif (/^https?:\\/\\//i.test(v)) return /\\.(png|jpe?g|webp|gif|bmp|svg)(\\?|#|$)/i.test(v) || /\\/media\\//i.test(v) || /\\/uploads\\//i.test(v) || /\\/inbound\\//i.test(v);
\treturn /^\\/[^ \\n]+$/.test(v);
}
function clawbbaExtractImageRefsFromMessage(msg) {
\tconst out = [];
\tif (!msg || typeof msg !== "object") return out;
\tconst push = (raw) => {
\t\tconst v = String(raw ?? "").trim();
\t\tif (!v || !clawbbaLooksLikeImageRef(v) || out.includes(v)) return;
\t\tout.push(v);
\t};
\tconst content = msg.content;
\tif (typeof content === "string") {
\t\tfor (const m of content.matchAll(/MEDIA:([^\\s\\n]+)/g)) if (m[1]) push(m[1]);
\t\treturn out;
\t}
\tif (!Array.isArray(content)) return out;
\tfor (const part of content) {
\t\tif (!part || typeof part !== "object") continue;
\t\tconst type = String(part.type ?? "").toLowerCase();
\t\tif (type === "image") {
\t\t\tpush(part.path ?? part.filePath ?? part.url);
\t\t\tif (part.source && typeof part.source === "object") push(part.source.url ?? part.source.path);
\t\t}
\t\tif (type === "image_url" && part.image_url && typeof part.image_url === "object") push(part.image_url.url);
\t\tif (type === "file" || type === "attachment") {
\t\t\tconst mime = String(part.mimeType ?? part.mime ?? "").toLowerCase();
\t\t\tif (!mime || mime.startsWith("image/")) {
\t\t\t\tpush(part.path ?? part.filePath ?? part.url);
\t\t\t\tif (part.attachment && typeof part.attachment === "object") push(part.attachment.path ?? part.attachment.url);
\t\t\t}
\t\t}
\t\tif (typeof part.text === "string") for (const m of part.text.matchAll(/MEDIA:([^\\s\\n]+)/g)) if (m[1]) push(m[1]);
\t}
\tif (Array.isArray(msg.attachments)) for (const att of msg.attachments) {
\t\tif (!att || typeof att !== "object") continue;
\t\tconst mime = String(att.mimeType ?? att.mime ?? "").toLowerCase();
\t\tif (!mime || mime.startsWith("image/")) push(att.path ?? att.filePath ?? att.url);
\t}
\treturn out;
}
function clawbbaParamsHaveReferenceImages(record) {
\tif (!record || typeof record !== "object") return false;
\tif (typeof record.image === "string" && record.image.trim()) return true;
\treturn Array.isArray(record.images) && record.images.some((v) => typeof v === "string" && String(v).trim());
}
function clawbbaParamsHaveVideoImageRoles(record) {
\treturn Array.isArray(record?.imageRoles) && record.imageRoles.some((r) => typeof r === "string" && String(r).trim());
}
async function clawbbaMaybeMergeSessionReferenceImages(opts) {
\tconst record = opts.params ?? opts.args;
\tif (!record || typeof record !== "object" || clawbbaParamsHaveReferenceImages(record)) return;
\tconst sk = typeof opts.options?.agentSessionKey === "string" ? opts.options.agentSessionKey.trim() : "";
\tif (!sk) return;
\ttry {
\t\tconst rt = await getRuntime();
\t\tconst { storePath, entry } = rt.loadSessionEntry(sk);
\t\tconst sessionId = entry?.sessionId;
\t\tif (!sessionId || !storePath) return;
\t\tconst msgs = await rt.readSessionMessagesAsync(sessionId, storePath, entry?.sessionFile, { mode: "recent", maxMessages: 24, maxBytes: 512000 });
\t\tconst isVideo = opts.tool === "video_generate";
\t\tconst templateRe = isVideo ? /请使用\\s*ClawBBA\\s*生成视频/i : /请使用\\s*ClawBBA\\s*生成图片/i;
\t\tconst intentRe = isVideo ? /参考|图生视频|首帧|尾帧|上传|附件|垫图|同款|以图/i : /参考|图生图|上传|附件|垫图|同款|以图|根据图|垫图/i;
\t\tlet templateIdx = -1;
\t\tlet mediaText = "";
\t\tfor (let i = msgs.length - 1; i >= 0; i--) {
\t\t\tconst m = msgs[i];
\t\t\tif (m?.role !== "user") continue;
\t\t\tconst t = clawbbaMessageTextFromRecord(m);
\t\t\tif (templateRe.test(t)) {
\t\t\t\ttemplateIdx = i;
\t\t\t\tmediaText = t;
\t\t\t\tbreak;
\t\t\t}
\t\t}
\t\tif (templateIdx < 0) return;
\t\tconst refs = [];
\t\tconst seen = new Set();
\t\tconst pushRef = (raw) => {
\t\t\tconst v = String(raw ?? "").trim();
\t\t\tif (!v || seen.has(v) || !clawbbaLooksLikeImageRef(v)) return;
\t\t\tseen.add(v);
\t\t\trefs.push(v);
\t\t};
\t\tfor (const r of clawbbaExtractImageRefsFromMessage(msgs[templateIdx])) pushRef(r);
\t\tif (refs.length === 0 && intentRe.test(mediaText)) {
\t\t\tfor (let i = templateIdx - 1; i >= 0 && templateIdx - i <= 3; i--) {
\t\t\t\tconst m = msgs[i];
\t\t\t\tif (m?.role !== "user") continue;
\t\t\t\tfor (const r of clawbbaExtractImageRefsFromMessage(m)) pushRef(r);
\t\t\t}
\t\t}
\t\tif (refs.length === 0) return;
\t\tconst max = typeof opts.maxCount === "number" && opts.maxCount > 0 ? Math.min(opts.maxCount, ${MAX_REFERENCE_IMAGES}) : ${MAX_REFERENCE_IMAGES};
\t\tconst trimmed = refs.slice(0, max);
\t\tif (trimmed.length === 1) record.image = trimmed[0];
\t\telse record.images = trimmed;
\t\tif (isVideo && !clawbbaParamsHaveVideoImageRoles(record)) {
\t\t\tconst role = /尾帧|last[\\s_-]?frame/i.test(mediaText) ? "last_frame" : /首帧|first[\\s_-]?frame|图生视频/i.test(mediaText) ? "first_frame" : "reference_image";
\t\t\trecord.imageRoles = trimmed.map(() => role);
\t\t}
\t} catch (_) {}
}`
}

export const IMAGE_REFERENCE_PRE_NORMALIZE_NEEDLE = `\t\t\tconst prompt = readStringParam$1(params, "prompt", { required: true });
\t\t\tconst imageInputs = normalizeReferenceImages(params);`

export const IMAGE_REFERENCE_PRE_NORMALIZE_REPLACEMENT_LET = `\t\t\tlet prompt = readStringParam$1(params, "prompt", { required: true });
\t\t\t${REFERENCE_IMAGES_MARKER}
\t\t\tawait clawbbaMaybeMergeSessionReferenceImages({ params, options, tool: "image_generate", maxCount: ${MAX_REFERENCE_IMAGES} });
\t\t\tconst imageInputs = normalizeReferenceImages(params);`

export const IMAGE_REFERENCE_PRE_NORMALIZE_REPLACEMENT_ALREADY_LET = `\t\t\tlet prompt = readStringParam$1(params, "prompt", { required: true });
\t\t\t${REFERENCE_IMAGES_MARKER}
\t\t\tawait clawbbaMaybeMergeSessionReferenceImages({ params, options, tool: "image_generate", maxCount: ${MAX_REFERENCE_IMAGES} });
\t\t\tconst imageInputs = normalizeReferenceImages(params);`

export const VIDEO_REFERENCE_DISPATCH_TAIL = `\t\t\t\tif (parsedPrompt && parsedPrompt !== prompt) prompt = parsedPrompt;
\t\t\t\tawait clawbbaMaybeMergeSessionReferenceImages({ args, options, tool: "video_generate", maxCount: ${MAX_REFERENCE_IMAGES} });
\t\t\t})();`

export const VIDEO_REFERENCE_DISPATCH_TAIL_OLD = `\t\t\t\tif (parsedPrompt && parsedPrompt !== prompt) prompt = parsedPrompt;
\t\t\t})();`

const HELPERS_ANCHOR = 'function normalizeReferenceImages(args) {'

/**
 * @param {string} filePath
 * @returns {'skip'|'patched'|'upgraded'|'missing-anchor'}
 */
export function patchReferenceImagesInToolsFile(filePath) {
  const original = fs.readFileSync(filePath, 'utf8')
  let src = original
  const hasHelpers = src.includes(REFERENCE_IMAGES_MARKER) && src.includes('clawbbaMaybeMergeSessionReferenceImages')
  const hasImagePre = src.includes('clawbbaMaybeMergeSessionReferenceImages({ params, options, tool: "image_generate"')

  if (!hasHelpers) {
    if (!src.includes(HELPERS_ANCHOR)) return 'missing-anchor'
    src = src.replace(HELPERS_ANCHOR, `${buildReferenceImagesHelperSource()}\n${HELPERS_ANCHOR}`)
  }

  if (!hasImagePre) {
    if (src.includes(IMAGE_REFERENCE_PRE_NORMALIZE_REPLACEMENT_ALREADY_LET.split('\n')[0])) {
      // already let prompt from media dispatch
      if (src.includes('\t\t\tconst imageInputs = normalizeReferenceImages(params);')) {
        src = src.replace(
          '\t\t\tconst imageInputs = normalizeReferenceImages(params);',
          `\t\t\t${REFERENCE_IMAGES_MARKER}\n\t\t\tawait clawbbaMaybeMergeSessionReferenceImages({ params, options, tool: "image_generate", maxCount: ${MAX_REFERENCE_IMAGES} });\n\t\t\tconst imageInputs = normalizeReferenceImages(params);`,
        )
      }
    } else if (src.includes(IMAGE_REFERENCE_PRE_NORMALIZE_NEEDLE)) {
      src = src.replace(
        IMAGE_REFERENCE_PRE_NORMALIZE_NEEDLE,
        IMAGE_REFERENCE_PRE_NORMALIZE_REPLACEMENT_LET,
      )
    } else {
      return 'missing-image-needle'
    }
  }

  if (src.includes(VIDEO_REFERENCE_DISPATCH_TAIL_OLD) && !src.includes('tool: "video_generate"')) {
    src = src.replace(VIDEO_REFERENCE_DISPATCH_TAIL_OLD, VIDEO_REFERENCE_DISPATCH_TAIL)
  }

  if (src === original) return 'skip'

  fs.writeFileSync(filePath, src)
  if (hasHelpers && hasImagePre) return 'skip'
  if (hasHelpers) return 'upgraded-video'
  return 'patched'
}
