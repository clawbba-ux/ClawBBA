/**
 * OpenClaw WebChat / Dashboard：前台工具完成后 chat.inject 推送 MEDIA:（无需刷新）。
 * recover 与 wake/announce 共用：fallback gateway context + chatRunId + session.message。
 */
import fs from 'fs'
import path from 'path'
import { escapeRegExp } from './clawbba-patch-dedupe.mjs'
import { findDistJsFile } from './openclaw-dist-paths.mjs'

export const WEBCHAT_LIVE_INJECT_HELPER_MARKER = '/* clawbba-webchat-live-inject-helper */'
export const WEBCHAT_HISTORY_RELOAD_MARKER = '/* clawbba-webchat-history-reload */'

const DISPATCH_IMPORT_LEGACY =
  /const \{ dispatchGatewayMethodInProcess \} = await import\("\.\/(server-plugins-[^"]+)"\);/

export function toolsSrcHasLegacyPluginImport(src) {
  return (
    DISPATCH_IMPORT_LEGACY.test(src) ||
    /const \{ getPluginRuntimeGatewayRequestScope \} = await import\("\.\/gateway-request-scope-/.test(src) ||
    /const \{ resolveGlobalSingleton \} = await import\("\.\/global-singleton-/.test(src)
  )
}

export function repairLegacyPluginImport(src) {
  let next = src.replace(
    DISPATCH_IMPORT_LEGACY,
    'const pluginsModule = await import("./$1");\n\t\tconst dispatchGatewayMethodInProcess = clawbbaPickModuleExport(pluginsModule, "dispatchGatewayMethodInProcess", ["r"]);',
  )
  next = next.replace(
    /const \{ getPluginRuntimeGatewayRequestScope \} = await import\("\.\/(gateway-request-scope-[^"]+)"\);/g,
    'const scopeModule = await import("./$1");\n\t\tconst getPluginRuntimeGatewayRequestScope = clawbbaPickModuleExport(scopeModule, "getPluginRuntimeGatewayRequestScope", ["t"]);',
  )
  next = next.replace(
    /const \{ resolveGlobalSingleton \} = await import\("\.\/(global-singleton-[^"]+)"\);/g,
    'const singletonModule = await import("./$1");\n\t\tconst resolveGlobalSingleton = clawbbaPickModuleExport(singletonModule, "resolveGlobalSingleton", ["n"]);',
  )
  return next
}

export function buildClawbbaPickModuleExportHelper() {
  return `function clawbbaPickModuleExport(module, preferredName, aliasNames) {
\tif (typeof module?.[preferredName] === "function") return module[preferredName];
\tfor (const alias of aliasNames) {
\t\tif (typeof module?.[alias] === "function") return module[alias];
\t}
\tthrow new Error(\`export \${preferredName} missing\`);
}`
}

const DIST_IMPORT_PREFIXES = [
  ['server-plugins-', 'dispatchGatewayMethodInProcess'],
  ['global-singleton-', 'resolveGlobalSingleton'],
  ['gateway-request-scope-', 'getPluginRuntimeGatewayRequestScope'],
]

/**
 * Prior buggy findDistFile could embed server-plugins-*.d.ts in dynamic import().
 * @param {string} src
 * @param {string} dist
 */
export function repairWrongDistDtsImports(src, dist) {
  let next = src
  for (const [prefix, needle] of DIST_IMPORT_PREFIXES) {
    const escapedPrefix = escapeRegExp(prefix)
    const re = new RegExp(`import\\("\\./(${escapedPrefix}[^"]+\\.d\\.ts)"\\)`, 'g')
    next = next.replace(re, () => {
      const js = findDistJsFile(dist, prefix, needle)
      return js ? `import("./${js}")` : `import("./${prefix}MISSING.js")`
    })
  }
  return next
}

export function toolsSrcHasWrongDistDtsImport(src) {
  return DIST_IMPORT_PREFIXES.some(([prefix]) => {
    const escapedPrefix = escapeRegExp(prefix)
    return new RegExp(`import\\("\\./${escapedPrefix}[^"]+\\.d\\.ts"\\)`).test(src)
  })
}

export function buildWebChatGatewayContextBlock(globalSingletonBasename, gatewayRequestScopeBasename) {
  const pickExport = buildClawbbaPickModuleExportHelper()
  return `${WEBCHAT_HISTORY_RELOAD_MARKER}
${pickExport}
async function clawbbaResolveGatewayBroadcastContext() {
\ttry {
\t\tconst scopeModule = await import("./${gatewayRequestScopeBasename}");
\t\tconst getPluginRuntimeGatewayRequestScope = clawbbaPickModuleExport(scopeModule, "getPluginRuntimeGatewayRequestScope", ["t"]);
\t\tconst scoped = getPluginRuntimeGatewayRequestScope()?.context;
\t\tif (scoped?.broadcast && scoped?.nodeSendToSession) return scoped;
\t\tconst singletonModule = await import("./${globalSingletonBasename}");
\t\tconst resolveGlobalSingleton = clawbbaPickModuleExport(singletonModule, "resolveGlobalSingleton", ["n"]);
\t\tconst state = resolveGlobalSingleton(Symbol.for("openclaw.fallbackGatewayContextState"), () => ({
\t\t\tcontext: void 0,
\t\t\tresolveContext: void 0
\t\t}));
\t\tconst fallback = state.resolveContext?.() ?? state.context;
\t\tif (fallback?.broadcast && fallback?.nodeSendToSession) return fallback;
\t} catch (err) {
\t\ttry {
\t\t\tlog$5.warn("clawbba gateway context resolve failed", { error: String(err?.message ?? err) });
\t\t} catch (_) {}
\t}
\treturn null;
}
function clawbbaSessionKeysMatch(requested, active) {
\tconst left = typeof requested === "string" ? requested.trim() : "";
\tconst right = typeof active === "string" ? active.trim() : "";
\tif (!left || !right) return false;
\tif (left === right) return true;
\tif ((left === "main" || left.endsWith(":main")) && (right === "main" || right.endsWith(":main"))) {
\t\ttry {
\t\t\tconst pl = parseAgentSessionKey(left);
\t\t\tconst pr = parseAgentSessionKey(right);
\t\t\tif (pl && pr) return pl.agentId === pr.agentId;
\t\t} catch (_) {}
\t\treturn true;
\t}
\ttry {
\t\tconst pl = parseAgentSessionKey(left);
\t\tconst pr = parseAgentSessionKey(right);
\t\tif (pl && pr) {
\t\t\tconst lr = (pl.rest || "main").toLowerCase();
\t\t\tconst rr = (pr.rest || "main").toLowerCase();
\t\t\treturn pl.agentId === pr.agentId && lr === rr;
\t\t}
\t} catch (_) {}
\treturn false;
}
function clawbbaFindActiveChatRunIdForSession(sessionKey, context, preferredRunId) {
\tconst pref = typeof preferredRunId === "string" ? preferredRunId.trim() : "";
\tif (!context?.chatAbortControllers) return pref || null;
\tif (pref && context.chatAbortControllers.has(pref)) return pref;
\tconst sk = typeof sessionKey === "string" ? sessionKey.trim() : "";
\tlet bestRunId = null;
\tlet bestStartedAt = -1;
\tfor (const [runId, active] of context.chatAbortControllers) {
\t\tif (!active || !sk || !clawbbaSessionKeysMatch(sk, active.sessionKey)) continue;
\t\tconst startedAt = typeof active.startedAtMs === "number" ? active.startedAtMs : 0;
\t\tif (startedAt >= bestStartedAt) {
\t\t\tbestStartedAt = startedAt;
\t\t\tbestRunId = runId;
\t\t}
\t}
\treturn bestRunId || pref || null;
}
function clawbbaCollectWebChatBroadcastSessionKeys(sessionKey, context, runId) {
\tconst keys = /* @__PURE__ */ new Set();
\tconst add = (value) => {
\t\tconst trimmed = typeof value === "string" ? value.trim() : "";
\t\tif (trimmed) keys.add(trimmed);
\t};
\tadd(sessionKey);
\tif (context?.chatAbortControllers && typeof runId === "string" && runId.trim()) {
\t\tconst active = context.chatAbortControllers.get(runId.trim());
\t\tif (active?.sessionKey) add(active.sessionKey);
\t}
\tif (context?.chatAbortControllers) {
\t\tfor (const [, active] of context.chatAbortControllers) {
\t\t\tif (active?.sessionKey && clawbbaSessionKeysMatch(sessionKey, active.sessionKey)) add(active.sessionKey);
\t\t}
\t}
\treturn [...keys];
}
function clawbbaSendGatewaySessionEvent(ctx, channel, sessionKeys, payload) {
\tfor (const sk of sessionKeys) {
\t\tconst next = { ...payload, sessionKey: sk };
\t\tctx.broadcast(channel, next);
\t\tctx.nodeSendToSession(sk, channel, next);
\t}
}
async function clawbbaBroadcastWebChatSessionReload(params) {
\tconst sessionKey = typeof params.sessionKey === "string" ? params.sessionKey.trim() : "";
\tif (!sessionKey) return false;
\tconst ctx = await clawbbaResolveGatewayBroadcastContext();
\tif (!ctx?.broadcast || !ctx?.nodeSendToSession) return false;
\tconst activeRunId = clawbbaFindActiveChatRunIdForSession(sessionKey, ctx, params.chatRunId);
\tconst sessionKeys = clawbbaCollectWebChatBroadcastSessionKeys(sessionKey, ctx, activeRunId);
\tlet reloaded = false;
\tif (activeRunId) {
\t\tconst seq = (ctx.agentRunSeq?.get(activeRunId) ?? 0) + 1;
\t\tctx.agentRunSeq?.set(activeRunId, seq);
\t\tclawbbaSendGatewaySessionEvent(ctx, "chat", sessionKeys, {
\t\t\trunId: activeRunId,
\t\t\tseq,
\t\t\tstate: "final",
\t\t\tmessage: { role: "assistant", content: [] }
\t\t});
\t\treloaded = true;
\t}
\tconst mediaMessage = typeof params.mediaMessage === "string" ? params.mediaMessage.trim() : "";
\tif (mediaMessage && !activeRunId) {
\t\tconst sessionMessage = {
\t\t\tmessage: {
\t\t\t\trole: "assistant",
\t\t\t\tcontent: [{ type: "text", text: mediaMessage }],
\t\t\t\ttimestamp: Date.now()
\t\t\t},
\t\t\t...typeof params.injectMessageId === "string" ? { messageId: params.injectMessageId } : {},
\t\t\tts: Date.now()
\t\t};
\t\tclawbbaSendGatewaySessionEvent(ctx, "session.message", sessionKeys, sessionMessage);
\t\treloaded = true;
\t}
\tif (!reloaded) {
\t\tconst changed = {
\t\t\tphase: "message",
\t\t\tts: Date.now(),
\t\t\t...typeof params.injectMessageId === "string" ? { messageId: params.injectMessageId } : {}
\t\t};
\t\tclawbbaSendGatewaySessionEvent(ctx, "sessions.changed", sessionKeys, changed);
\t}
\treturn reloaded;
}`
}

export function buildWebChatHistoryReloadBlock(
  globalSingletonBasename,
  gatewayRequestScopeBasename,
) {
  return buildWebChatGatewayContextBlock(globalSingletonBasename, gatewayRequestScopeBasename)
}

export function buildWebChatLiveInjectHelperBlock(
  serverPluginsBasename,
  globalSingletonBasename,
  gatewayRequestScopeBasename,
) {
  const reloadBlock = buildWebChatHistoryReloadBlock(globalSingletonBasename, gatewayRequestScopeBasename)
  return `${WEBCHAT_LIVE_INJECT_HELPER_MARKER}
function clawbbaShouldInjectWebChatMediaLive(sessionKey) {
\tconst sk = typeof sessionKey === "string" ? sessionKey.trim() : "";
\tif (!sk) return false;
\tif (sk.includes(":dashboard:")) return true;
\tconst parsed = parseAgentSessionKey(sk);
\tif (parsed) {
\t\tconst rest = normalizeLowercaseStringOrEmpty(parsed.rest);
\t\tif (!rest || rest === "main") return true;
\t\tif (rest.includes("webchat")) return true;
\t\tconst delivery = inferDeliveryFromSessionKey(sk);
\t\tif (delivery?.channel) {
\t\t\tconst ch = normalizeMessageChannel(delivery.channel);
\t\t\tif (ch === "webchat") return true;
\t\t\tif (ch && isDeliverableMessageChannel(ch)) return false;
\t\t}
\t\tconst head = rest.split(":")[0] ?? "";
\t\tconst ch = normalizeMessageChannel(head);
\t\tif (ch && isDeliverableMessageChannel(ch) && ch !== "webchat") return false;
\t\treturn true;
\t}
\treturn normalizeLowercaseStringOrEmpty(sk) === "main";
}
${reloadBlock}
async function clawbbaDispatchWebChatMediaLiveInject(params) {
\tconst mediaUrls = Array.isArray(params.mediaUrls) ? params.mediaUrls.filter((u) => typeof u === "string" && u.trim()) : [];
\tconst sessionKey = typeof params.sessionKey === "string" ? params.sessionKey.trim() : "";
\tif (!sessionKey || mediaUrls.length === 0 || !clawbbaShouldInjectWebChatMediaLive(sessionKey)) return false;
\tconst preset = typeof params.message === "string" ? params.message.trim() : "";
\tconst message = preset && preset.includes("MEDIA:") ? preset : [
\t\t\`The generated \${typeof params.completionLabel === "string" && params.completionLabel.trim() ? params.completionLabel.trim() : "media"} is ready.\`,
\t\t...mediaUrls.map((url) => \`MEDIA:\${url.trim()}\`)
\t].join("\\n");
\ttry {
\t\tconst pluginsModule = await import("./${serverPluginsBasename}");
\t\tconst dispatchGatewayMethodInProcess = clawbbaPickModuleExport(pluginsModule, "dispatchGatewayMethodInProcess", ["r"]);
\t\tconst injectResult = await dispatchGatewayMethodInProcess("chat.inject", {
\t\t\tsessionKey,
\t\t\tmessage,
\t\t\tlabel: params.label || (params.sourceTool === "video_generate" ? "ClawBBA video" : "ClawBBA image")
\t\t}, { timeoutMs: 3e4 });
\t\tawait clawbbaBroadcastWebChatSessionReload({
\t\t\tsessionKey,
\t\t\tchatRunId: params.chatRunId,
\t\t\tmediaMessage: message,
\t\t\tinjectMessageId: injectResult?.messageId
\t\t});
\t\treturn true;
\t} catch (err) {
\t\ttry {
\t\t\tlog$5.warn("clawbba webchat media live inject failed", { error: String(err?.message ?? err) });
\t\t} catch (_) {}
\t\treturn false;
\t}
}`
}

const LEGACY_RECOVER_INJECT_RE =
  /\/\* clawbba-video-recover-webchat-live \*\/[\s\S]*?catch \(_\) \{\}/

const RECOVER_RETURN_AFTER_LINES =
  /\treturn \{\n\t\tcontent: \[\{ type: "text", text: lines\.join\("\\n"\) \}\],\n\t\tdetails: \{\n\t\t\tjobId,\n\t\t\trecovered: true,\n\t\t\tpath: saved\.path,/

/**
 * @param {string} src
 */
export function recoverFnHasWebChatDispatchInject(src) {
  const start = src.indexOf('async function clawbbaRecoverVideoTask')
  if (start < 0) return false
  const end = src.indexOf('async function clawbbaListVideoTasks', start)
  const body = src.slice(start, end > start ? end : src.length)
  return body.includes('await clawbbaDispatchWebChatMediaLiveInject({')
}

/**
 * @param {string} src
 */
export function recoverWebChatInjectNeedsUpgrade(src) {
  if (!src.includes('clawbbaRecoverVideoTask')) return false
  if (!recoverFnHasWebChatDispatchInject(src)) return true
  const start = src.indexOf('async function clawbbaRecoverVideoTask')
  const end = src.indexOf('async function clawbbaListVideoTasks', start)
  const body = src.slice(start, end > start ? end : src.length)
  return body.includes('__clawbbaSk.includes("webchat")')
}

/**
 * @param {string} src
 */
export function stripLegacyRecoverWebChatInject(src) {
  if (!src.includes('clawbba-video-recover-webchat-live')) return src
  if (recoverFnHasWebChatDispatchInject(src) && !src.includes('__clawbbaSk.includes("webchat")')) {
    return src
  }
  const marker = escapeRegExp('/* clawbba-video-recover-webchat-live */')
  const stripped = src.replace(
    new RegExp(`${marker}[\\s\\S]*?(?=\\treturn \\{\\n\\t\\tcontent: \\[\\{ type: "text", text: lines\\.join)`, 'm'),
    '',
  )
  if (stripped !== src) return stripped
  return src.replace(LEGACY_RECOVER_INJECT_RE, '')
}

export function helperBlockNeedsUpgrade(src) {
  if (toolsSrcHasWrongDistDtsImport(src)) return true
  if (toolsSrcHasLegacyPluginImport(src)) return true
  return (
    src.includes(WEBCHAT_LIVE_INJECT_HELPER_MARKER) &&
    (!src.includes('clawbbaResolveGatewayBroadcastContext') ||
      !src.includes('clawbbaBroadcastWebChatSessionReload') ||
      !src.includes('clawbbaSessionKeysMatch') ||
      !src.includes('clawbbaCollectWebChatBroadcastSessionKeys') ||
      !src.includes('return bestRunId || pref || null') ||
      !src.includes('clawbbaPickModuleExport'))
  )
}

/**
 * @param {string} src
 * @param {string} reloadBlock
 */
function applySurgicalWebChatReloadUpgrade(src, reloadBlock) {
  let next = src
  if (!next.includes('clawbbaBroadcastWebChatSessionReload')) {
    const dispatchAnchor = 'async function clawbbaDispatchWebChatMediaLiveInject(params) {'
    if (next.includes(dispatchAnchor)) {
      next = next.replace(dispatchAnchor, `${reloadBlock.trimEnd()}\n${dispatchAnchor}`)
    }
  }
  if (
    next.includes('clawbbaBroadcastWebChatSessionReload') &&
    !next.includes('clawbbaCollectWebChatBroadcastSessionKeys')
  ) {
    next = next.replace(
      /function clawbbaFindActiveChatRunIdForSession[\s\S]*?^async function clawbbaBroadcastWebChatSessionReload/m,
      (block) => {
        if (block.includes('clawbbaCollectWebChatBroadcastSessionKeys')) return block
        return block
          .replace(
            /return bestRunId;\n\}/,
            'return bestRunId || pref || null;\n}',
          )
          .replace(
            /async function clawbbaBroadcastWebChatSessionReload/,
            `function clawbbaCollectWebChatBroadcastSessionKeys(sessionKey, context, runId) {
\tconst keys = /* @__PURE__ */ new Set();
\tconst add = (value) => {
\t\tconst trimmed = typeof value === "string" ? value.trim() : "";
\t\tif (trimmed) keys.add(trimmed);
\t};
\tadd(sessionKey);
\tif (context?.chatAbortControllers && typeof runId === "string" && runId.trim()) {
\t\tconst active = context.chatAbortControllers.get(runId.trim());
\t\tif (active?.sessionKey) add(active.sessionKey);
\t}
\tif (context?.chatAbortControllers) {
\t\tfor (const [, active] of context.chatAbortControllers) {
\t\t\tif (active?.sessionKey && clawbbaSessionKeysMatch(sessionKey, active.sessionKey)) add(active.sessionKey);
\t\t}
\t}
\treturn [...keys];
}
function clawbbaSendGatewaySessionEvent(ctx, channel, sessionKeys, payload) {
\tfor (const sk of sessionKeys) {
\t\tconst next = { ...payload, sessionKey: sk };
\t\tctx.broadcast(channel, next);
\t\tctx.nodeSendToSession(sk, channel, next);
\t}
}
async function clawbbaBroadcastWebChatSessionReload`,
          )
      },
    )
  }
  if (
    next.includes('dispatchGatewayMethodInProcess("chat.inject"') &&
    !next.includes('clawbbaBroadcastWebChatSessionReload')
  ) {
    next = next.replace(
      /await dispatchGatewayMethodInProcess\("chat\.inject", \{[\s\S]*?\}, \{ timeoutMs: 3e4 \}\);/,
      (m) => `${m.replace('await dispatchGatewayMethodInProcess', 'const injectResult = await dispatchGatewayMethodInProcess')}\n\t\tawait clawbbaBroadcastWebChatSessionReload({ sessionKey, chatRunId: params.chatRunId, mediaMessage: message, injectMessageId: injectResult?.messageId });`,
    )
  }
  if (next.includes('await clawbbaPromptWebChatHistoryReload(sessionKey)')) {
    next = next.replace(
      /await clawbbaPromptWebChatHistoryReload\(sessionKey\);/g,
      'await clawbbaBroadcastWebChatSessionReload({ sessionKey, chatRunId: params.chatRunId, mediaMessage: message, injectMessageId: injectResult?.messageId });',
    )
  }
  return next
}

function replaceWebChatLiveInjectHelperBlock(
  src,
  block,
  globalSingletonBasename,
  gatewayRequestScopeBasename,
) {
  const marker = escapeRegExp(WEBCHAT_LIVE_INJECT_HELPER_MARKER)
  const upgraded = src.replace(
    new RegExp(
      `${marker}[\\s\\S]*?(?=\\n/\\* clawbba-video-recover \\*/|\\nasync function executeVideoGenerationJob \\(params\\))`,
      'm',
    ),
    block.trimEnd(),
  )
  if (upgraded !== src) return upgraded
  return applySurgicalWebChatReloadUpgrade(
    src,
    buildWebChatHistoryReloadBlock(globalSingletonBasename, gatewayRequestScopeBasename),
  )
}

/**
 * @param {string} toolsPath
 * @param {string} serverPluginsBasename
 * @param {string} globalSingletonBasename
 * @param {string} gatewayRequestScopeBasename
 */
export function patchWebChatLiveInjectHelperInToolsFile(
  toolsPath,
  serverPluginsBasename,
  globalSingletonBasename,
  gatewayRequestScopeBasename,
) {
  const dist = path.dirname(toolsPath)
  const raw = fs.readFileSync(toolsPath, 'utf8')
  if (toolsSrcHasWrongDistDtsImport(raw)) {
    const repaired = repairWrongDistDtsImports(raw, dist)
    if (repaired !== raw) {
      fs.writeFileSync(toolsPath, repaired)
      return 'patched-dts-repair'
    }
  }
  if (toolsSrcHasLegacyPluginImport(raw)) {
    let repaired = repairLegacyPluginImport(raw)
    if (!repaired.includes('function clawbbaPickModuleExport(')) {
      const marker = WEBCHAT_HISTORY_RELOAD_MARKER
      if (repaired.includes(marker)) {
        repaired = repaired.replace(marker, `${marker}\n${buildClawbbaPickModuleExportHelper()}`)
      }
    }
    if (repaired !== raw) {
      fs.writeFileSync(toolsPath, repaired)
      return 'patched-import-repair'
    }
  }
  let src = raw
  const block = buildWebChatLiveInjectHelperBlock(
    serverPluginsBasename,
    globalSingletonBasename,
    gatewayRequestScopeBasename,
  )

  if (src.includes(WEBCHAT_LIVE_INJECT_HELPER_MARKER) && !helperBlockNeedsUpgrade(src)) {
    if (
      src.includes('clawbbaShouldInjectWebChatMediaLive') &&
      src.includes('clawbbaBroadcastWebChatSessionReload') &&
      src.includes('clawbbaResolveGatewayBroadcastContext')
    ) {
      return 'skip'
    }
  }

  if (!src.includes('function inferDeliveryFromSessionKey')) {
    return 'infer-delivery-missing'
  }
  if (!serverPluginsBasename || !globalSingletonBasename || !gatewayRequestScopeBasename) {
    return 'server-plugins-missing'
  }

  const anchor = src.includes('/* clawbba-video-recover */')
    ? '/* clawbba-video-recover */'
    : 'async function executeVideoGenerationJob(params) {'

  if (!src.includes(anchor)) {
    return 'anchor-missing'
  }

  const before = src
  if (src.includes(WEBCHAT_LIVE_INJECT_HELPER_MARKER)) {
    src = replaceWebChatLiveInjectHelperBlock(
      src,
      block,
      globalSingletonBasename,
      gatewayRequestScopeBasename,
    )
    if (helperBlockNeedsUpgrade(src)) {
      src = applySurgicalWebChatReloadUpgrade(
        src,
        buildWebChatHistoryReloadBlock(globalSingletonBasename, gatewayRequestScopeBasename),
      )
    }
  } else {
    src = src.replace(anchor, `${block}\n${anchor}`)
  }

  if (!src.includes('clawbbaBroadcastWebChatSessionReload')) {
    return 'upgrade-failed'
  }

  if (src === before) {
    return helperBlockNeedsUpgrade(src) || toolsSrcHasWrongDistDtsImport(src) ? 'upgrade-failed' : 'skip'
  }

  src = repairWrongDistDtsImports(src, dist)
  src = repairLegacyPluginImport(src)
  fs.writeFileSync(toolsPath, src)
  return 'patched'
}
export function patchWebChatLiveInjectHelperDist(dist, findDistFile) {
  const toolsFile = findDistFile(dist, 'openclaw-tools-')
  const pluginsFile = findDistFile(dist, 'server-plugins-')
  const gatewayScopeFile = findDistFile(dist, 'gateway-request-scope-')
  const globalSingletonFile = findDistFile(dist, 'global-singleton-')
  if (!toolsFile || !pluginsFile || !gatewayScopeFile || !globalSingletonFile) return 'missing-file'
  return patchWebChatLiveInjectHelperInToolsFile(
    path.join(dist, toolsFile),
    pluginsFile,
    globalSingletonFile,
    gatewayScopeFile,
  )
}
